// scripts/usdt-macos-setup.ts
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";
import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import { randomBytes, createHash as createHash3 } from "node:crypto";
import { setGlobalProxyFromEnv } from "node:http";

// scripts/usdt-exchange.ts
import { createHash, createHmac } from "node:crypto";
var spot = "https://api.binance.com";
var futures = "https://fapi.binance.com";
var tradingPaths = /* @__PURE__ */ new Set(["/fapi/v1/order", "/fapi/v1/algoOrder", "/fapi/v1/leverage", "/fapi/v1/marginType", "/fapi/v1/positionMargin"]);
var UsdtApiError = class extends Error {
  status;
  code;
  constructor(status, code) {
    super("\u5E01\u5B89 U \u672C\u4F4D\u8BF7\u6C42\u5931\u8D25\uFF08HTTP " + status + (code == null ? "" : "\uFF0C\u4EE3\u7801 " + code) + "\uFF09");
    this.status = status;
    this.code = code;
  }
};
var quantityText = /^\d+(?:\.\d+)?$/;
function quantityUnits(raw, step) {
  if (!quantityText.test(raw) || !quantityText.test(step)) throw Error("\u5E01\u5B89\u59D4\u6258\u6570\u91CF\u683C\u5F0F\u65E0\u6548");
  const decimals = Math.max(raw.split(".")[1]?.length ?? 0, step.split(".")[1]?.length ?? 0);
  const scaled = (value) => BigInt(value.replace(".", "") + "0".repeat(decimals - (value.split(".")[1]?.length ?? 0)));
  const size = scaled(step);
  const units = scaled(raw);
  if (size <= 0n || units % size !== 0n || units / size > BigInt(Number.MAX_SAFE_INTEGER)) throw Error("\u5E01\u5B89\u6570\u91CF\u4E0E\u4EA4\u6613\u6B65\u957F\u4E0D\u4E00\u81F4");
  return Number(units / size);
}
function createUsdtRequest(credentials, fetcher = fetch) {
  const clocks = /* @__PURE__ */ new Map();
  const send = async (method, path, params) => {
    const base = path.startsWith("/fapi/") ? futures : spot;
    if (!/^\/(?:fapi|sapi|api)\/v\d+\/(?:[a-zA-Z]+\/)*[a-zA-Z0-9]+$/.test(path) || method === "POST" && !tradingPaths.has(path) || method === "DELETE" && path !== "/fapi/v1/algoOrder" && path !== "/fapi/v1/order")
      throw Error("\u5E01\u5B89\u7B7E\u540D\u8BF7\u6C42\u8DEF\u5F84\u65E0\u6548");
    const signal = AbortSignal.timeout(1e4);
    let clock = clocks.get(base);
    if (!clock || Date.now() - clock.sampled >= 3e4 || Date.now() < clock.sampled) {
      const response2 = await fetcher(base + (base === futures ? "/fapi/v1/time" : "/api/v3/time"), { redirect: "error", signal });
      if (!response2.ok) throw new UsdtApiError(response2.status);
      const { serverTime } = await response2.json();
      if (!Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u949F\u4E0D\u53EF\u7528");
      clock = { sampled: Date.now(), offset: serverTime - Date.now() };
      clocks.set(base, clock);
    }
    const query = new URLSearchParams({ ...params, recvWindow: method === "GET" ? "12000" : "5000", timestamp: String(Date.now() + clock.offset) });
    query.set("signature", createHmac("sha256", credentials.secret).update(query.toString()).digest("hex"));
    const response = await fetcher(base + path + (method === "POST" ? "" : "?" + query), {
      method,
      redirect: "error",
      signal,
      headers: { "X-MBX-APIKEY": credentials.apiKey, ...method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : {} },
      ...method === "POST" ? { body: query.toString() } : {}
    });
    const body = await response.text().then((text) => JSON.parse(
      text,
      (key, value, context) => ["orderId", "uid", "id", "algoId"].includes(key) && typeof value === "number" && /^\d+$/.test(context?.source ?? "") ? context.source : value
    )).catch(() => void 0);
    if (body?.code === -1021) clocks.delete(base);
    if (!response.ok || body?.code < 0) throw new UsdtApiError(response.status, typeof body?.code === "number" ? body.code : void 0);
    if (body == null) throw Error("\u5E01\u5B89\u54CD\u5E94\u4E0D\u53EF\u8BC6\u522B");
    return body;
  };
  return async (method, path, params = {}) => {
    try {
      return await send(method, path, params);
    } catch (error) {
      if (method === "GET" && (error instanceof TypeError || error instanceof DOMException || error instanceof UsdtApiError && (error.code === -1021 || error.status >= 500))) return send(method, path, params);
      throw error;
    }
  };
}
async function readUsdtMarket(symbol, fetcher = fetch) {
  if (!/^[A-Z0-9]{2,24}USDT$/.test(symbol)) return;
  const response = await fetcher(futures + "/fapi/v1/exchangeInfo", { signal: AbortSignal.timeout(9e3), redirect: "error" });
  if (!response.ok) throw new UsdtApiError(response.status);
  const body = await response.json();
  if (!Array.isArray(body.symbols)) throw Error("\u65E0\u6CD5\u8BFB\u53D6\u5E01\u5B89\u5408\u7EA6\u89C4\u683C");
  const contract = body.symbols.find((row) => row.symbol === symbol && row.quoteAsset === "USDT" && row.marginAsset === "USDT" && row.contractType === "PERPETUAL" && row.status === "TRADING");
  if (!contract) return;
  const lot = contract.filters?.find((row) => row.filterType === "LOT_SIZE");
  const marketLot = contract.filters?.find((row) => row.filterType === "MARKET_LOT_SIZE");
  const minimum = contract.filters?.find((row) => row.filterType === "MIN_NOTIONAL");
  const price = contract.filters?.find((row) => row.filterType === "PRICE_FILTER");
  const step = lot?.stepSize;
  const minNotional = Number(minimum?.notional);
  if (typeof step !== "string" || Number(step) <= 0 || !Number.isFinite(minNotional) || minNotional < 0) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u89C4\u683C\u4E0D\u5B8C\u6574");
  const min = Math.max(1, Math.ceil(Math.max(Number(lot.minQty), Number(marketLot.minQty)) / Number(step) - 1e-9));
  const max = Math.floor(Math.min(Number(lot.maxQty), Number(marketLot.maxQty)) / Number(step) + 1e-9);
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max < min) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u6570\u91CF\u8303\u56F4\u4E0D\u53EF\u7528");
  return { symbol, step, min, max, minNotional, marketStep: marketLot?.stepSize, priceTick: price?.tickSize };
}
function createUsdtExchange(request, fetcher = fetch) {
  const positionSide = (mode) => mode === "hedge" ? "LONG" : "BOTH";
  return {
    async account() {
      const [user, key, account, mode] = await Promise.all([
        request("GET", "/api/v3/account", { omitZeroBalances: "true" }),
        request("GET", "/sapi/v1/account/apiRestrictions"),
        request("GET", "/fapi/v3/account"),
        request("GET", "/fapi/v1/positionSide/dual")
      ]);
      if (!/^[1-9]\d*$/.test(String(user.uid)) || key.enableReading !== true || key.enableFutures !== true || key.ipRestrict !== true || typeof mode.dualSidePosition !== "boolean" || !Array.isArray(account.assets) || !Array.isArray(account.positions) || account.canTrade === false) throw Error("\u5E01\u5B89 U \u672C\u4F4D\u8D26\u6237\u3001\u5408\u7EA6\u6743\u9650\u6216 IP \u767D\u540D\u5355\u672A\u901A\u8FC7\u9A8C\u8BC1");
      return { id: String(user.uid), mode: mode.dualSidePosition ? "hedge" : "one-way" };
    },
    async market(symbol) {
      return readUsdtMarket(symbol, fetcher);
    },
    async book(symbol, side) {
      const p = new URLSearchParams({ symbol });
      const response = await fetcher(
        futures + "/fapi/v1/ticker/bookTicker?" + p,
        { signal: AbortSignal.timeout(8e3), redirect: "error" }
      );
      if (!response.ok) throw new UsdtApiError(response.status);
      const quote = await response.json();
      const price = String(side === "BUY" ? quote.askPrice : quote.bidPrice);
      if (quote.symbol !== symbol || !quantityText.test(price) || !Number.isFinite(Number(price)) || Number(price) <= 0) throw Error("\u5E01\u5B89\u76D8\u53E3\u4EF7\u683C\u65E0\u6548");
      return price;
    },
    async check(market, mode, held, entry, opening, leverage, managed, knownProtection, unsettledBuyId, confirmOpening) {
      const { symbol } = market;
      const [positions, regular, algo, settings, modes] = await Promise.all([
        request("GET", "/fapi/v3/positionRisk", { symbol }),
        request("GET", "/fapi/v1/openOrders", { symbol }),
        request("GET", "/fapi/v1/openAlgoOrders", { symbol }),
        request("GET", "/fapi/v1/symbolConfig", { symbol }),
        request("GET", "/fapi/v1/positionSide/dual")
      ]);
      if (modes.dualSidePosition !== (mode === "hedge")) throw Error("\u5E01\u5B89\u6301\u4ED3\u6A21\u5F0F\u5DF2\u53D8\u5316");
      if (![positions, regular, algo, settings].every(Array.isArray)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6216\u6302\u5355\u8BFB\u6570\u4E0D\u53EF\u7528");
      if (unsettledBuyId && regular.some((order) => order.clientOrderId === unsettledBuyId))
        throw Error("\u5E01\u5B89\u4ECD\u6709\u8FD9\u7B14\u4E70\u5165\u59D4\u6258\u5728\u6302\u5355\u4E2D\uFF0C\u7B49\u5F85\u5B8C\u6210\u540E\u9000\u51FA");
      if ((regular.length || algo.some((row2) => !knownProtection?.includes(row2.clientAlgoId))) && (leverage !== 0 || managed))
        throw Error("\u8BE5\u5408\u7EA6\u6709\u5916\u90E8\u6302\u5355\uFF0C\u9700\u6838\u5BF9\u4ED3\u4F4D");
      const active = positions.filter((row2) => Number(row2.positionAmt) !== 0);
      const row = active.find((item) => item.symbol === symbol && item.positionSide === positionSide(mode));
      if (active.some((item) => item !== row && !(managed && mode === "hedge" && item.positionSide === "SHORT")) || (row && Number(row.positionAmt) > 0 ? quantityUnits(String(row.positionAmt), market.step) : row ? -1 : 0) !== held || held > 0 && (!Number.isFinite(Number(row.entryPrice)) || Math.abs(Number(row.entryPrice) - entry) > Math.max(1e-8, entry * 1e-5))) {
        throw Error("\u5E01\u5B89\u5B9E\u9645\u4ED3\u4F4D\u4E0E\u672C\u673A\u6210\u4EA4\u8BB0\u5F55\u4E0D\u4E00\u81F4");
      }
      if (leverage === 0 || managed) return;
      const config = settings.find((item) => item.symbol === symbol);
      if (!config) throw Error("\u5E01\u5B89\u5408\u7EA6\u914D\u7F6E\u4E0D\u53EF\u7528");
      if (opening) {
        if (config.marginType !== "ISOLATED") {
          confirmOpening?.();
          try {
            await request("POST", "/fapi/v1/marginType", { symbol, marginType: "ISOLATED" });
          } catch (error) {
            if (!(error instanceof UsdtApiError) || error.code !== -4046) throw error;
          }
        }
        if (Number(config.leverage) !== leverage) {
          confirmOpening?.();
          const result = await request("POST", "/fapi/v1/leverage", { symbol, leverage: String(leverage) });
          if (result.symbol !== symbol || Number(result.leverage) !== leverage) throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u65B9\u6848\u6760\u6746");
        }
      } else if (config.marginType !== "ISOLATED" || Number(config.leverage) !== leverage) {
        throw Error("\u5E01\u5B89\u9010\u4ED3\u6216\u6760\u6746\u8BBE\u7F6E\u4E0E\u51BB\u7ED3\u65B9\u6848\u4E0D\u4E00\u81F4");
      }
    },
    async order(market, mode, order, send) {
      const { symbol } = market;
      const position = positionSide(mode);
      let report;
      if (send) {
        try {
          report = await request("POST", "/fapi/v1/order", {
            symbol,
            side: order.side,
            positionSide: position,
            ...order.limitPrice ? { type: "LIMIT", timeInForce: "IOC", price: order.limitPrice } : { type: "MARKET" },
            quantity: order.quantity,
            newClientOrderId: order.id,
            newOrderRespType: "RESULT",
            ...mode === "one-way" && order.side === "SELL" ? { reduceOnly: "true" } : {}
          });
        } catch (error) {
          if (error instanceof UsdtApiError && [-1013, -1021, -1102, -1111, -2014, -2015, -2019, -2022, -4164].includes(error.code ?? 0)) {
            return { terminal: true, fills: [], issue: error.message };
          }
        }
      }
      if (!report) {
        try {
          report = await request("GET", "/fapi/v1/order", { symbol, origClientOrderId: order.id });
        } catch (error) {
          if (error instanceof UsdtApiError && error.code === -2013) return;
          throw error;
        }
      }
      if (report.symbol !== symbol || report.clientOrderId !== order.id || report.side !== order.side || report.positionSide !== position || !/^\d+$/.test(String(report.orderId)) || quantityUnits(String(report.origQty), market.step) !== quantityUnits(order.quantity, market.step)) {
        throw Error("\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u4E0E\u59D4\u6258\u4E0D\u4E00\u81F4");
      }
      const terminal = ["FILLED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED", "REJECTED"].includes(report.status);
      const filled = quantityUnits(String(report.executedQty), market.step);
      if (!terminal && !["NEW", "PARTIALLY_FILLED"].includes(report.status)) throw Error("\u5E01\u5B89\u8BA2\u5355\u72B6\u6001\u4E0D\u53EF\u8BC6\u522B");
      if (filled > quantityUnits(order.quantity, market.step) || report.status === "FILLED" && filled !== quantityUnits(order.quantity, market.step)) throw Error("\u5E01\u5B89\u7D2F\u8BA1\u6210\u4EA4\u91CF\u8D85\u8FC7\u59D4\u6258");
      const trades = filled ? await request("GET", "/fapi/v1/userTrades", { symbol, orderId: String(report.orderId), limit: "1000" }) : [];
      if (!Array.isArray(trades)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u65E0\u6548");
      const ids = /* @__PURE__ */ new Set();
      const fills = trades.map((trade) => {
        const id = String(trade.id), price = Number(trade.price), at = Number(trade.time);
        const quantity = quantityUnits(String(trade.qty), market.step), commission = Number(trade.commission), realized = Number(trade.realizedPnl);
        if (trade.symbol !== symbol || String(trade.orderId) !== String(report.orderId) || trade.side !== order.side || trade.positionSide !== position || !/^\d+$/.test(id) || ids.has(id) || quantity <= 0 || !Number.isFinite(price) || price <= 0 || !Number.isSafeInteger(at) || at <= 0 || !Number.isFinite(commission) || !Number.isFinite(realized) || typeof trade.commissionAsset !== "string" || !trade.commissionAsset) throw Error("\u5E01\u5B89\u6210\u4EA4\u8EAB\u4EFD\u6216\u91D1\u989D\u4E0D\u7B26");
        ids.add(id);
        return { id, quantity, price, at, commission, commissionAsset: trade.commissionAsset, realized };
      });
      if (fills.reduce((units, fill) => units + fill.quantity, 0) !== filled) return;
      return { exchangeId: String(report.orderId), terminal, fills, issue: terminal && !filled ? "\u5E01\u5B89\u8BA2\u5355\u5DF2\u7EC8\u6B62\uFF0C\u672A\u6210\u4EA4" : void 0 };
    }
  };
}

// scripts/usdt-macos-credentials.ts
import { execFileSync } from "node:child_process";
import { createHash as createHash2 } from "node:crypto";
import { resolve } from "node:path";
var service = "app.veil-of-ignorance.usdt-executor";
var identity = (directory2) => createHash2("sha256").update(resolve(directory2)).digest("hex");
var security = (args, input) => execFileSync("/usr/bin/security", args, {
  input,
  stdio: ["pipe", "pipe", "ignore"],
  timeout: 3e4
});
function readMacUsdtCredentials(directory2, run = security) {
  let buffer;
  try {
    buffer = run(["find-generic-password", "-s", service, "-a", identity(directory2), "-w"]);
    const data = JSON.parse(Buffer.from(buffer.toString("utf8").trim(), "base64").toString("utf8"));
    if (!/^[a-zA-Z0-9]{16,256}$/.test(data.apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(data.secret)) throw Error();
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6 Mac \u94A5\u5319\u4E32\u4E2D\u7684\u5E01\u5B89\u51ED\u8BC1\uFF0C\u8BF7\u5148\u914D\u7F6E\u5E76\u5141\u8BB8\u672C\u673A\u94A5\u5319\u4E32\u8BBF\u95EE\u3002");
  } finally {
    buffer?.fill(0);
  }
}
function saveMacUsdtCredentials(directory2, apiKey, secret, run = security) {
  if (!/^[a-zA-Z0-9]{16,256}$/.test(apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(secret)) throw Error("API Key \u6216 Secret \u683C\u5F0F\u65E0\u6548\u3002");
  const payload = Buffer.from(JSON.stringify({ apiKey, secret })).toString("base64");
  const input = Buffer.from(`add-generic-password -U -s ${service} -a ${identity(directory2)} -w ${payload}
`);
  try {
    run(["-i", "-q"], input);
    const saved = readMacUsdtCredentials(directory2, run);
    try {
      if (saved.apiKey !== apiKey || saved.secret.toString() !== secret) throw Error();
    } finally {
      saved.secret.fill(0);
    }
  } catch {
    throw Error("Mac \u94A5\u5319\u4E32\u4FDD\u5B58\u672A\u901A\u8FC7\u56DE\u8BFB\u6838\u5BF9\uFF0C\u8BF7\u91CD\u8BD5\u3002");
  } finally {
    input.fill(0);
  }
}

// scripts/usdt-macos-setup.ts
var directory = join(homedir(), "Library", "Application Support", "VeilUSDTExecutor");
async function question(label, hidden = false) {
  const quiet = new Writable({ write(_chunk, _encoding, done) {
    done();
  } });
  const prompt = createInterface({ input: process.stdin, output: hidden ? quiet : process.stdout, terminal: true });
  if (hidden) process.stdout.write(label);
  try {
    return (await prompt.question(hidden ? "" : label)).trim();
  } finally {
    prompt.close();
    if (hidden) process.stdout.write("\n");
  }
}
async function main() {
  if (process.platform !== "darwin" || !process.stdin.isTTY) throw Error("\u8BF7\u5728 Mac \u7684\u7EC8\u7AEF\u4E2D\u8FD0\u884C\u914D\u7F6E\u3002");
  const owner = await question("\u65E0\u77E5\u4E4B\u5E55 \u2192 \u5373\u65F6\u4EA4\u6613 \u2192 \u6761\u4EF6\u8BBE\u7F6E \u2192 \u5E01\u5B89\u5B9E\u76D8\u4E2D\u663E\u793A\u7684\u8D26\u53F7 ID\uFF1A");
  if (!/^[a-f0-9-]{36}$/i.test(owner)) throw Error("\u7F51\u7AD9\u8D26\u53F7 ID \u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u590D\u5236\u8BE5\u5165\u53E3\u663E\u793A\u7684\u5B8C\u6574\u8D26\u53F7 ID\u3002");
  if (existsSync(join(directory, "usdt-follow.json"))) throw Error("Mac \u5DF2\u914D\u7F6E\u8FC7\u3002\u4E3A\u4FDD\u7559\u914D\u5BF9\u548C\u8D26\u672C\uFF0C\u672C\u5165\u53E3\u4E0D\u4F1A\u8986\u76D6\u73B0\u6709\u8BBE\u7F6E\u3002");
  const proxy = await question("\u4EE3\u7406 HTTP \u5730\u5740\uFF08\u4F8B\u5982 http://127.0.0.1:7890\uFF1B\u76F4\u8FDE\u5219\u7559\u7A7A\uFF09\uFF1A");
  if (proxy && !/^https?:\/\/[^\s]+$/.test(proxy)) throw Error("\u4EE3\u7406\u5730\u5740\u5E94\u4F7F\u7528 http:// \u6216 https://\u3002");
  setGlobalProxyFromEnv({ HTTPS_PROXY: proxy, HTTP_PROXY: proxy, NO_PROXY: "127.0.0.1,localhost" });
  const apiKey = await question("\u5E01\u5B89 API Key\uFF08\u8F93\u5165\u4E0D\u663E\u793A\uFF09\uFF1A", true);
  const secret = await question("\u5E01\u5B89 Secret Key\uFF08\u8F93\u5165\u4E0D\u663E\u793A\uFF09\uFF1A", true);
  if (!/^[a-zA-Z0-9]{16,256}$/.test(apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(secret)) throw Error("API Key \u6216 Secret \u683C\u5F0F\u65E0\u6548\u3002");
  const credentials = { apiKey, secret: Buffer.from(secret) };
  try {
    const verified = await createUsdtExchange(createUsdtRequest(credentials)).account();
    mkdirSync(directory, { recursive: true, mode: 448 });
    saveMacUsdtCredentials(directory, apiKey, secret);
    const token = randomBytes(32).toString("hex");
    writeFileSync(join(directory, "proxy.json"), JSON.stringify({ proxy }), { mode: 384, flag: "wx" });
    writeFileSync(join(directory, "usdt-follow.json"), JSON.stringify({ owner, token, account: createHash3("sha256").update(verified.id).digest("hex") }), { mode: 384, flag: "wx" });
    console.log("\u8D26\u6237\u53EA\u8BFB\u9A8C\u8BC1\u901A\u8FC7\uFF0C\u51ED\u8BC1\u5DF2\u5B58\u5165 Mac \u94A5\u5319\u4E32\u3002\u914D\u7F6E\u8FC7\u7A0B\u6CA1\u6709\u4E0B\u5355\u3002");
    console.log("\u672C\u673A\u914D\u5BF9\u7801\uFF08\u4EC5\u7C98\u8D34\u5230\u672C\u673A\u65E0\u77E5\u4E4B\u5E55\u7684\u5B9E\u76D8\u914D\u5BF9\u5165\u53E3\uFF09\uFF1A\n" + token);
  } finally {
    credentials.secret.fill(0);
  }
}
void main().catch((error) => {
  console.error(error instanceof Error ? error.message : "Mac \u914D\u7F6E\u5931\u8D25");
  process.exitCode = 1;
});
