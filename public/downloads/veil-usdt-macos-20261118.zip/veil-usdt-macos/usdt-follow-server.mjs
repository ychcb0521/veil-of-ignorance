// src/lib/fish/usdtPositionMirror.ts
var usdtMirrorKey = (position) => position.symbol + ":" + position.positionSide;
var usdtMirrorRevision = (position) => JSON.stringify([usdtMirrorKey(position), position.quantity, position.direction, position.entryPrice, position.updatedAt]);
var amountFormat = new Intl.NumberFormat("en-US", { maximumFractionDigits: 8 });
function usdtPositionDecimal(text) {
  return text.includes(".") ? text.replace(/0+$/, "").replace(/\.$/, "") : text;
}

// scripts/usdt-position-reader.ts
var validSymbol = (symbol) => typeof symbol === "string" && /^[A-Z0-9_]{3,32}$/.test(symbol);
var validSide = (side) => side === "BOTH" || side === "LONG" || side === "SHORT";
var validId = (id) => (typeof id === "string" || typeof id === "number" && Number.isSafeInteger(id)) && /^\d{1,25}$/.test(String(id));
var decimal = /^-?\d{1,30}(?:\.\d{1,18})?$/;
var decimalText = (value) => {
  if (typeof value !== "string" || !decimal.test(value)) throw Error("\u5E01\u5B89\u8FD4\u56DE\u7684\u4ED3\u4F4D\u6216\u6210\u4EA4\u91D1\u989D\u65E0\u6548");
  return value;
};
var asUnits = (value) => {
  const [whole, fraction = ""] = value.replace(/^-/, "").split(".");
  return (value.startsWith("-") ? -1n : 1n) * BigInt(whole + fraction.padEnd(18, "0"));
};
var quantityText = (value) => {
  const digits = String(value < 0n ? -value : value).padStart(19, "0");
  const fraction = digits.slice(-18).replace(/0+$/, "");
  return digits.slice(0, -18) + (fraction ? "." + fraction : "");
};
var day = 24 * 60 * 60 * 1e3;
var pageSize = 1e3;
var positionTradeCaughtUp = (fillAt, positionUpdatedAt) => fillAt >= positionUpdatedAt - 1;
function decodePositions(value) {
  if (!Array.isArray(value)) throw Error("\u5E01\u5B89 U \u672C\u4F4D\u6301\u4ED3\u56DE\u62A5\u65E0\u6548");
  const positions = /* @__PURE__ */ new Map();
  for (const row of value) {
    const amount = decimalText(row?.positionAmt);
    const net = asUnits(amount);
    if (net === 0n) continue;
    if (!validSymbol(row.symbol) || !validSide(row.positionSide) || !Number.isSafeInteger(row.updateTime) || row.updateTime < 0 || row.positionSide === "LONG" && net < 0n || row.positionSide === "SHORT" && net > 0n) {
      throw Error("\u5E01\u5B89 U \u672C\u4F4D\u6301\u4ED3\u65B9\u5411\u6216\u66F4\u65B0\u65F6\u95F4\u65E0\u6548");
    }
    const position = {
      symbol: row.symbol,
      positionSide: row.positionSide,
      direction: net > 0n ? "long" : "short",
      quantity: amount.replace(/^-/, ""),
      entryPrice: decimalText(row.entryPrice),
      markPrice: decimalText(row.markPrice),
      unrealizedPnl: decimalText(row.unRealizedProfit),
      updatedAt: row.updateTime
    };
    for (const key2 of ["breakEvenPrice", "liquidationPrice", "positionInitialMargin", "isolatedWallet", "maintMargin", "notional"]) {
      if (typeof row[key2] === "string" && decimal.test(row[key2])) position[key2] = row[key2];
    }
    const leverage = Number(row.leverage);
    if (Number.isSafeInteger(leverage) && leverage > 0) position.leverage = leverage;
    if (row.marginType === "isolated" || row.marginType === "cross") position.marginMode = row.marginType;
    else if (row.marginType === "crossed") position.marginMode = "cross";
    else if (Number(position.isolatedWallet) > 0) position.marginMode = "isolated";
    const key = usdtMirrorKey(position);
    if (positions.has(key)) throw Error("\u5E01\u5B89\u6301\u4ED3\u56DE\u62A5\u91CD\u590D");
    positions.set(key, position);
  }
  return [...positions.values()].sort((a, b) => a.symbol.localeCompare(b.symbol) || a.positionSide.localeCompare(b.positionSide));
}
function decodeTrade(row, position, start, end) {
  if (row?.symbol !== position.symbol || !validSide(row.positionSide)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u4E0E\u4ED3\u4F4D\u4E0D\u7B26");
  if (row.positionSide !== position.positionSide) return;
  if (!Number.isSafeInteger(row.time) || row.time < start || row.time > end || !validId(row.id) || !validId(row.orderId) || row.side !== "BUY" && row.side !== "SELL") throw Error("\u5E01\u5B89\u6210\u4EA4\u65F6\u95F4\u6216\u8EAB\u4EFD\u65E0\u6548");
  const quantity2 = decimalText(row.qty), price = decimalText(row.price);
  if (asUnits(quantity2) <= 0n || asUnits(price) <= 0n) throw Error("\u5E01\u5B89\u6210\u4EA4\u6570\u91CF\u6216\u4EF7\u683C\u65E0\u6548");
  return { id: String(row.id), orderId: String(row.orderId), at: row.time, side: row.side, price, quantity: quantity2 };
}
var descending = (a, b) => b.at - a.at || (BigInt(a.id) > BigInt(b.id) ? -1 : a.id === b.id ? 0 : 1);
function createUsdtPositionReader(read, clock = Date.now) {
  let snapshot;
  let loading;
  const histories = /* @__PURE__ */ new Map();
  const working = /* @__PURE__ */ new Map();
  const positions = () => {
    if (loading) return loading;
    if (snapshot && clock() - snapshot.observedAt < 4e3 && clock() >= snapshot.observedAt) return Promise.resolve(snapshot);
    loading = (async () => {
      const positions2 = decodePositions(await read("GET", "/fapi/v3/positionRisk"));
      const keys = new Set(positions2.map(usdtMirrorKey));
      for (const key of histories.keys()) if (!keys.has(key)) histories.delete(key);
      return snapshot = { positions: positions2, observedAt: clock() };
    })().finally(() => {
      loading = void 0;
    });
    return loading;
  };
  const rebuild = async (position) => {
    const now = clock();
    let requests = 0;
    let end = Math.max(now, position.updatedAt);
    const oldest = now - 89 * day;
    let remaining = asUnits(position.quantity) * (position.direction === "long" ? 1n : -1n);
    const fills = [];
    const seen = /* @__PURE__ */ new Set();
    const page = async (start, stop) => {
      if (++requests > 40) throw Error("\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
      const rows = await read("GET", "/fapi/v1/userTrades", { symbol: position.symbol, startTime: String(start), endTime: String(stop), limit: String(pageSize) });
      if (!Array.isArray(rows)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u65E0\u6548");
      if (rows.length >= pageSize) {
        if (start === stop) throw Error("\u540C\u4E00\u6BEB\u79D2\u7684\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
        const mid = start + Math.floor((stop - start) / 2);
        return await page(mid + 1, stop) ?? await page(start, mid);
      }
      const ordered = rows.map((row) => decodeTrade(row, position, start, stop)).filter((trade) => !!trade).sort(descending);
      for (const fill of ordered) {
        if (seen.has(fill.id)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u91CD\u590D");
        seen.add(fill.id);
        const delta2 = asUnits(fill.quantity) * (fill.side === "BUY" ? 1n : -1n);
        const before = remaining - delta2;
        if (before === 0n || before > 0n !== remaining > 0n) {
          fills.push({ ...fill, positionQuantity: quantityText(remaining), action: "open" });
          return { openedAt: fill.at, fills: fills.reverse() };
        }
        if (fills.length >= 5e3) throw Error("\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
        fills.push({ ...fill, positionQuantity: fill.quantity, action: remaining > 0n === delta2 > 0n ? "add" : "reduce" });
        remaining = before;
      }
    };
    let history2;
    try {
      while (end >= oldest && !history2) {
        const start = Math.max(oldest, end - 7 * day + 1);
        history2 = await page(start, end);
        end = start - 1;
      }
      if (!history2) history2 = { fills: [], issue: "\u5386\u53F2\u6210\u4EA4\u4E0D\u8DB3\uFF0C\u65E0\u6CD5\u6838\u5BF9\u5B9E\u9645\u5F00\u4ED3\u65F6\u95F4" };
    } catch (error) {
      return { fills: [], issue: error instanceof Error ? error.message : "\u65E0\u6CD5\u8BFB\u53D6\u5B9E\u9645\u6210\u4EA4" };
    }
    if (history2.openedAt && position.updatedAt && !positionTradeCaughtUp(history2.fills.at(-1).at, position.updatedAt)) {
      return { fills: [], issue: "\u6210\u4EA4\u8BB0\u5F55\u5C1A\u65E0\u6CD5\u4E0E\u5F53\u524D\u4ED3\u4F4D\u6838\u5BF9\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
    }
    const current = decodePositions(await read("GET", "/fapi/v3/positionRisk", { symbol: position.symbol })).find((row) => row.positionSide === position.positionSide);
    if (!current || usdtMirrorRevision(current) !== usdtMirrorRevision(position)) return { fills: [], issue: "\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u7B49\u5F85\u4E0B\u6B21\u540C\u6B65" };
    return history2;
  };
  const history = async (symbol, side, revision) => {
    if (!validSymbol(symbol) || !validSide(side) || typeof revision !== "string" || revision.length > 300) throw Error("\u8BF7\u5148\u5237\u65B0\u5E01\u5B89\u4ED3\u4F4D");
    const key = usdtMirrorKey({ symbol, positionSide: side });
    const position = (await positions()).positions.find((row) => usdtMirrorKey(row) === key);
    if (!position || usdtMirrorRevision(position) !== revision) return { fills: [], issue: "\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u7B49\u5F85\u4E0B\u6B21\u540C\u6B65" };
    const cached = histories.get(key);
    if (cached?.revision === revision) return cached.history;
    if (working.has(revision)) return working.get(revision);
    if (working.size >= 2) return { fills: [], issue: "\u6B63\u5728\u540C\u6B65\u5176\u4ED6\u4ED3\u4F4D\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
    const task = rebuild(position).then((result) => {
      if (result.openedAt) {
        histories.delete(key);
        histories.set(key, { revision, history: result });
        if (histories.size > 64) histories.delete(histories.keys().next().value);
      }
      return result;
    }).finally(() => {
      working.delete(revision);
    });
    working.set(revision, task);
    return task;
  };
  return { positions, history, invalidate: () => {
    snapshot = void 0;
  } };
}

// scripts/usdt-macos-credentials.ts
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
var service = "app.veil-of-ignorance.usdt-executor";
var identity = (directory) => createHash("sha256").update(resolve(directory)).digest("hex");
var security = (args, input) => execFileSync("/usr/bin/security", args, {
  input,
  stdio: ["pipe", "pipe", "ignore"],
  timeout: 3e4
});
function readMacUsdtCredentials(directory, run = security) {
  let buffer;
  try {
    buffer = run(["find-generic-password", "-s", service, "-a", identity(directory), "-w"]);
    const data = JSON.parse(Buffer.from(buffer.toString("utf8").trim(), "base64").toString("utf8"));
    if (!/^[a-zA-Z0-9]{16,256}$/.test(data.apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(data.secret)) throw Error();
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6 Mac \u94A5\u5319\u4E32\u4E2D\u7684\u5E01\u5B89\u51ED\u8BC1\uFF0C\u8BF7\u5148\u914D\u7F6E\u5E76\u5141\u8BB8\u672C\u673A\u94A5\u5319\u4E32\u8BBF\u95EE\u3002");
  } finally {
    buffer?.fill(0);
  }
}

// scripts/usdt-campaign-reader.ts
var DAY = 864e5;
var WINDOW = 7 * DAY;
var LIMIT = 1e3;
var symbolPattern = /^[A-Z0-9_]{3,32}$/;
var decimal2 = /^-?\d{1,30}(?:\.\d{1,18})?$/;
var idPattern = /^\d{1,25}$/;
function units(raw) {
  if (!decimal2.test(raw)) throw Error("\u5E01\u5B89\u6210\u4EA4\u6570\u91CF\u65E0\u6548");
  const [whole, fraction = ""] = raw.replace(/^-/, "").split(".");
  return BigInt(whole + fraction.padEnd(18, "0")) * (raw.startsWith("-") ? -1n : 1n);
}
function quantity(value) {
  const n = (value < 0n ? -value : value).toString().padStart(19, "0");
  const fraction = n.slice(-18).replace(/0+$/, "");
  return n.slice(0, -18) + (fraction ? "." + fraction : "");
}
function money(raw) {
  if (typeof raw !== "string" || !decimal2.test(raw)) throw Error("\u5E01\u5B89\u6210\u4EA4\u91D1\u989D\u65E0\u6548");
  return Number(raw);
}
function readTrade(raw, symbol, start, end) {
  const row = raw;
  if (!row || row.symbol !== symbol || row.positionSide !== "BOTH" && row.positionSide !== "LONG" && row.positionSide !== "SHORT" || row.side !== "BUY" && row.side !== "SELL" || typeof row.time !== "number" || !Number.isSafeInteger(row.time) || row.time < start || row.time > end || !idPattern.test(String(row.id)) || !idPattern.test(String(row.orderId)) || typeof row.qty !== "string" || units(row.qty) <= 0n || typeof row.price !== "string" || money(row.price) <= 0 || typeof row.commissionAsset !== "string" || !symbolPattern.test(row.commissionAsset)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u683C\u5F0F\u6709\u8BEF");
  const asset = typeof row.marginAsset === "string" && symbolPattern.test(row.marginAsset) ? row.marginAsset : symbol.split("_")[0].endsWith("USDC") ? "USDC" : "USDT";
  return {
    id: String(row.id),
    orderId: String(row.orderId),
    at: row.time,
    quantity: row.qty,
    price: row.price,
    side: row.side,
    positionSide: row.positionSide,
    asset,
    realized: money(row.realizedPnl),
    commission: money(row.commission),
    commissionAsset: row.commissionAsset
  };
}
var compareId = (a, b) => BigInt(a) < BigInt(b) ? -1 : BigInt(a) > BigInt(b) ? 1 : 0;
var delta = (row) => units(row.quantity) * (row.side === "BUY" ? 1n : -1n);
function startingBalances(positions, trades) {
  const balances = /* @__PURE__ */ new Map();
  for (const pos of positions) balances.set(pos.positionSide, units(pos.quantity) * (pos.direction === "short" ? -1n : 1n));
  for (const trade of trades) balances.set(trade.positionSide, (balances.get(trade.positionSide) ?? 0n) - delta(trade));
  return balances;
}
function reconstructUsdtCampaigns(symbol, positions, trades) {
  const rows = [...new Map(trades.map((trade) => [trade.id, trade])).values()].sort((a, b) => a.at - b.at || compareId(a.id, b.id));
  const balances = startingBalances(positions, rows);
  const open = /* @__PURE__ */ new Map();
  const campaigns = [];
  for (const trade of rows) {
    const { positionSide, asset, ...raw } = trade;
    const before = balances.get(positionSide) ?? 0n;
    const after = before + delta(trade);
    if (positionSide === "LONG" && (before < 0n || after < 0n) || positionSide === "SHORT" && (before > 0n || after > 0n))
      throw Error("\u5E01\u5B89\u6210\u4EA4\u4E0E\u6301\u4ED3\u65B9\u5411\u6682\u672A\u5BF9\u9F50");
    balances.set(positionSide, after);
    const flipped = before !== 0n && after !== 0n && before < 0n !== after < 0n;
    const campaign = open.get(positionSide);
    const closed = before !== 0n && (flipped || after === 0n);
    const closeFee = flipped ? raw.commission * (Number(quantity(before)) / Number(raw.quantity)) : raw.commission;
    if (campaign) {
      const increases = before < 0n === delta(trade) < 0n;
      const action = increases ? raw.orderId === campaign.fills[0].orderId ? "open" : "add" : "reduce";
      campaign.fills.push({
        ...raw,
        action,
        positionQuantity: flipped ? quantity(before) : raw.quantity,
        commission: closeFee
      });
      campaign.quantity = closed ? "0" : quantity(after);
      if (closed) {
        campaign.closedAt = raw.at;
        open.delete(positionSide);
      }
    }
    if (before === 0n || flipped) {
      const initial = {
        symbol,
        asset,
        positionSide,
        direction: after > 0n ? "long" : "short",
        quantity: quantity(after),
        openedAt: raw.at,
        fills: [{
          ...raw,
          action: "open",
          positionQuantity: quantity(after),
          ...flipped ? { realized: 0, commission: raw.commission - closeFee } : {}
        }]
      };
      campaigns.push(initial);
      open.set(positionSide, initial);
    }
  }
  return campaigns;
}
function createUsdtCampaignReader(read, clock = Date.now) {
  let running;
  let cached;
  async function scan(since, known, target) {
    const params = target ? { symbol: target } : void 0;
    const positions = decodePositions(await read("GET", "/fapi/v3/positionRisk", params));
    const observedAt = clock();
    const earliest = Math.max(1, observedAt - 89 * DAY);
    const start = Math.max(earliest, Math.min(since, observedAt));
    const groups = /* @__PURE__ */ new Map();
    for (const position of positions) groups.set(position.symbol, [...groups.get(position.symbol) ?? [], position]);
    let budget = 140;
    let incomplete = since < earliest;
    const windows = async (path, from, through, params2) => {
      if (from > through) return [];
      if (through - from >= WINDOW) {
        const cutoff = from + WINDOW - 1;
        return [...await windows(path, from, cutoff, params2), ...await windows(path, cutoff + 1, through, params2)];
      }
      if (--budget < 0) throw Error("\u672C\u8F6E\u6210\u4EA4\u8FC7\u591A\uFF0C\u6218\u5F79\u540C\u6B65\u7A0D\u540E\u91CD\u8BD5");
      const rows = await read("GET", path, { ...params2, startTime: String(from), endTime: String(through), limit: String(LIMIT) });
      if (!Array.isArray(rows)) throw Error("\u5E01\u5B89\u8FD4\u56DE\u7684\u8BA2\u5355\u6216\u6210\u4EA4\u4E0D\u53EF\u8BC6\u522B");
      if (rows.length < LIMIT) return rows;
      if (from === through) throw Error("\u540C\u4E00\u6BEB\u79D2\u5185\u7684\u5E01\u5B89\u6210\u4EA4\u8FC7\u591A");
      const middle = Math.floor((from + through) / 2);
      return [...await windows(path, from, middle, params2), ...await windows(path, middle + 1, through, params2)];
    };
    const orders = target ? [] : await windows("/fapi/v1/allOrders", start, observedAt);
    const symbols = /* @__PURE__ */ new Set([...groups.keys(), ...known.keys()]);
    for (const order of orders) {
      const item = order;
      if (item.symbol && symbolPattern.test(item.symbol) && item.executedQty && units(item.executedQty) > 0n) symbols.add(item.symbol);
    }
    const campaigns = [];
    const scanSymbol = async (symbol) => {
      const current2 = groups.get(symbol) ?? [];
      const openingTimes = known.get(symbol);
      let from = Math.max(earliest, Math.min(start, ...openingTimes ?? []));
      const recent = (a, b) => windows("/fapi/v1/userTrades", a, b, { symbol }).then((rows) => rows.map((row) => readTrade(row, symbol, a, b)));
      let trades = await recent(from, observedAt);
      const unique = () => [...new Map(trades.map((trade) => [trade.id, trade])).values()];
      const before = () => [...startingBalances(current2, unique()).values()].some((value) => value !== 0n);
      while (from > earliest && before()) {
        const prior = Math.max(earliest, from - WINDOW);
        trades = [...await recent(prior, from - 1), ...trades];
        from = prior;
      }
      if (before()) incomplete = true;
      if (current2.some((pos) => pos.updatedAt >= from && !trades.some((trade) => trade.positionSide === pos.positionSide && positionTradeCaughtUp(trade.at, pos.updatedAt))))
        throw Error("\u5E01\u5B89\u6700\u65B0\u6210\u4EA4\u8FD8\u672A\u8FD4\u56DE\uFF0C\u6B63\u5728\u91CD\u65B0\u6838\u5BF9");
      campaigns.push(...reconstructUsdtCampaigns(symbol, current2, unique()).filter((row) => !row.closedAt || row.closedAt >= start || openingTimes?.has(row.openedAt)));
    };
    const queue = [...symbols];
    for (let i = 0; i < queue.length; i += 3) await Promise.all(queue.slice(i, i + 3).map(scanSymbol));
    const current = decodePositions(await read("GET", "/fapi/v3/positionRisk", params));
    const anchor = (rows) => JSON.stringify(rows.map((p) => [p.symbol, p.positionSide, p.direction, p.quantity, p.updatedAt]));
    if (anchor(positions) !== anchor(current)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u521A\u53D1\u751F\u53D8\u5316\uFF0C\u6B63\u5728\u91CD\u65B0\u6838\u5BF9\u6210\u4EA4");
    return { observedAt, campaigns, ...incomplete ? { incomplete } : {} };
  }
  const readBatch = (since, open, target) => {
    if (typeof since !== "number" || !Number.isSafeInteger(since) || since < 1 || since > clock() + 6e4 || !Array.isArray(open) || open.length > 200) throw Error("\u5E01\u5B89\u6218\u5F79\u540C\u6B65\u8BF7\u6C42\u65E0\u6548");
    const known = /* @__PURE__ */ new Map();
    for (const anchor of open) {
      if (typeof anchor?.symbol !== "string" || !symbolPattern.test(anchor.symbol) || !Number.isSafeInteger(anchor.openedAt) || anchor.openedAt < 1 || anchor.openedAt > clock() + 6e4) throw Error("\u5E01\u5B89\u6218\u5F79\u5F00\u4ED3\u65F6\u95F4\u65E0\u6548");
      const openingTimes = known.get(anchor.symbol) ?? /* @__PURE__ */ new Set();
      openingTimes.add(anchor.openedAt);
      known.set(anchor.symbol, openingTimes);
    }
    if (target) return scan(since, known, target);
    const key = JSON.stringify([since, target, [...known].map(([symbol, openingTimes]) => [symbol, [...openingTimes]])]);
    if (cached?.key === key && clock() - cached.data.observedAt < 4e3) return Promise.resolve(cached.data);
    if (running) return running.then(() => readBatch(since, open, target), () => readBatch(since, open, target));
    running = scan(since, known, target).then((data) => {
      cached = { key, data };
      return data;
    }).finally(() => {
      running = void 0;
    });
    return running;
  };
  return readBatch;
}

// src/lib/fish/usdtLiveCampaign.ts
var usdtLiveCampaignId = (campaign) => ["fish-instant-live", campaign.symbol, campaign.positionSide, campaign.direction, campaign.fills[0].id, campaign.fills[0].orderId].join("-");
var isUsdtLiveCampaignId = (id) => /^fish-instant-live-[A-Z0-9_]+-(?:BOTH|LONG|SHORT)-(?:long|short)-\d+-\d+$/.test(id ?? "");
function findUsdtCampaignFollow(campaign, statuses) {
  const opening = campaign.fills[0];
  return opening && statuses.find((status) => (status.market ?? status.symbol.replace(/\//g, "")) === campaign.symbol && status.executions?.some((execution) => execution.actionId === "open" && execution.orderId === opening.orderId && execution.fills.some((fill) => fill.id === opening.id)));
}

// src/lib/fish/usdtFollowMonitorBasis.ts
var USDT_FOLLOW_MONITOR_BASIS = "binance-follow-monitor-basis-v1";

// scripts/usdt-follow-server.ts
import { execFileSync as execFileSync2 } from "node:child_process";
import { createHash as createHash3, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";
import { join } from "node:path";
import { mkdirSync, openSync, closeSync, unlinkSync, writeFileSync, readFileSync } from "node:fs";

// scripts/usdt-exchange.ts
import { createHash as createHash2, createHmac } from "node:crypto";
var spot = "https://api.binance.com";
var futures = "https://fapi.binance.com";
var tradingPaths = /* @__PURE__ */ new Set(["/fapi/v1/order", "/fapi/v1/algoOrder", "/fapi/v1/leverage", "/fapi/v1/marginType", "/fapi/v1/positionMargin"]);
var UsdtApiError = class extends Error {
  status;
  code;
  constructor(status, code) {
    super("\u5E01\u5B89 U \u672C\u4F4D\u8BF7\u6C42\u5931\u8D25\uFF08HTTP " + status + (code == null ? "" : "\uFF0C\u4EE3\u7801 " + code) + "\uFF09");
    this.status = status;
    this.code = code;
  }
};
var usdtOrderId = (owner, campaign, action) => "veil-" + createHash2("sha256").update(JSON.stringify([owner, campaign, action])).digest("hex").slice(0, 30);
var quantityText2 = /^\d+(?:\.\d+)?$/;
function quantityUnits(raw, step) {
  if (!quantityText2.test(raw) || !quantityText2.test(step)) throw Error("\u5E01\u5B89\u59D4\u6258\u6570\u91CF\u683C\u5F0F\u65E0\u6548");
  const decimals = Math.max(raw.split(".")[1]?.length ?? 0, step.split(".")[1]?.length ?? 0);
  const scaled = (value) => BigInt(value.replace(".", "") + "0".repeat(decimals - (value.split(".")[1]?.length ?? 0)));
  const size = scaled(step);
  const units2 = scaled(raw);
  if (size <= 0n || units2 % size !== 0n || units2 / size > BigInt(Number.MAX_SAFE_INTEGER)) throw Error("\u5E01\u5B89\u6570\u91CF\u4E0E\u4EA4\u6613\u6B65\u957F\u4E0D\u4E00\u81F4");
  return Number(units2 / size);
}
function formatQuantity(units2, step) {
  if (!Number.isSafeInteger(units2) || units2 < 0 || !quantityText2.test(step)) throw Error("\u5E01\u5B89\u59D4\u6258\u6570\u91CF\u65E0\u6548");
  const decimals = step.split(".")[1]?.length ?? 0;
  const digits = String(BigInt(units2) * BigInt(step.replace(".", ""))).padStart(decimals + 1, "0");
  return decimals ? digits.slice(0, -decimals) + "." + digits.slice(-decimals) : digits;
}
function createUsdtRequest(credentials, fetcher = fetch) {
  const clocks = /* @__PURE__ */ new Map();
  const send = async (method, path, params) => {
    const base = path.startsWith("/fapi/") ? futures : spot;
    if (!/^\/(?:fapi|sapi|api)\/v\d+\/(?:[a-zA-Z]+\/)*[a-zA-Z0-9]+$/.test(path) || method === "POST" && !tradingPaths.has(path) || method === "DELETE" && path !== "/fapi/v1/algoOrder" && path !== "/fapi/v1/order")
      throw Error("\u5E01\u5B89\u7B7E\u540D\u8BF7\u6C42\u8DEF\u5F84\u65E0\u6548");
    const signal = AbortSignal.timeout(1e4);
    let clock = clocks.get(base);
    if (!clock || Date.now() - clock.sampled >= 3e4 || Date.now() < clock.sampled) {
      const response2 = await fetcher(base + (base === futures ? "/fapi/v1/time" : "/api/v3/time"), { redirect: "error", signal });
      if (!response2.ok) throw new UsdtApiError(response2.status);
      const { serverTime } = await response2.json();
      if (!Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u949F\u4E0D\u53EF\u7528");
      clock = { sampled: Date.now(), offset: serverTime - Date.now() };
      clocks.set(base, clock);
    }
    const query = new URLSearchParams({ ...params, recvWindow: method === "GET" ? "12000" : "5000", timestamp: String(Date.now() + clock.offset) });
    query.set("signature", createHmac("sha256", credentials.secret).update(query.toString()).digest("hex"));
    const response = await fetcher(base + path + (method === "POST" ? "" : "?" + query), {
      method,
      redirect: "error",
      signal,
      headers: { "X-MBX-APIKEY": credentials.apiKey, ...method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : {} },
      ...method === "POST" ? { body: query.toString() } : {}
    });
    const body = await response.text().then((text) => JSON.parse(
      text,
      (key, value, context) => ["orderId", "uid", "id", "algoId"].includes(key) && typeof value === "number" && /^\d+$/.test(context?.source ?? "") ? context.source : value
    )).catch(() => void 0);
    if (body?.code === -1021) clocks.delete(base);
    if (!response.ok || body?.code < 0) throw new UsdtApiError(response.status, typeof body?.code === "number" ? body.code : void 0);
    if (body == null) throw Error("\u5E01\u5B89\u54CD\u5E94\u4E0D\u53EF\u8BC6\u522B");
    return body;
  };
  return async (method, path, params = {}) => {
    try {
      return await send(method, path, params);
    } catch (error) {
      if (method === "GET" && (error instanceof TypeError || error instanceof DOMException || error instanceof UsdtApiError && (error.code === -1021 || error.status >= 500))) return send(method, path, params);
      throw error;
    }
  };
}
async function readUsdtMarket(symbol, fetcher = fetch) {
  if (!/^[A-Z0-9]{2,24}USDT$/.test(symbol)) return;
  const response = await fetcher(futures + "/fapi/v1/exchangeInfo", { signal: AbortSignal.timeout(9e3), redirect: "error" });
  if (!response.ok) throw new UsdtApiError(response.status);
  const body = await response.json();
  if (!Array.isArray(body.symbols)) throw Error("\u65E0\u6CD5\u8BFB\u53D6\u5E01\u5B89\u5408\u7EA6\u89C4\u683C");
  const contract = body.symbols.find((row) => row.symbol === symbol && row.quoteAsset === "USDT" && row.marginAsset === "USDT" && row.contractType === "PERPETUAL" && row.status === "TRADING");
  if (!contract) return;
  const lot = contract.filters?.find((row) => row.filterType === "LOT_SIZE");
  const marketLot = contract.filters?.find((row) => row.filterType === "MARKET_LOT_SIZE");
  const minimum = contract.filters?.find((row) => row.filterType === "MIN_NOTIONAL");
  const price = contract.filters?.find((row) => row.filterType === "PRICE_FILTER");
  const step = lot?.stepSize;
  const minNotional = Number(minimum?.notional);
  if (typeof step !== "string" || Number(step) <= 0 || !Number.isFinite(minNotional) || minNotional < 0) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u89C4\u683C\u4E0D\u5B8C\u6574");
  const min = Math.max(1, Math.ceil(Math.max(Number(lot.minQty), Number(marketLot.minQty)) / Number(step) - 1e-9));
  const max = Math.floor(Math.min(Number(lot.maxQty), Number(marketLot.maxQty)) / Number(step) + 1e-9);
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max < min) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u6570\u91CF\u8303\u56F4\u4E0D\u53EF\u7528");
  return { symbol, step, min, max, minNotional, marketStep: marketLot?.stepSize, priceTick: price?.tickSize };
}
async function readUsdtMark(symbol, fetcher = fetch) {
  const query = new URLSearchParams({ symbol });
  const reply = await fetcher(
    futures + "/fapi/v1/premiumIndex?" + query,
    { signal: AbortSignal.timeout(8e3), redirect: "error" }
  );
  if (!reply.ok) throw new UsdtApiError(reply.status);
  const mark = await reply.json();
  if (mark.symbol !== symbol || typeof mark.markPrice !== "string" || !quantityText2.test(mark.markPrice) || !Number.isFinite(Number(mark.markPrice)) || Number(mark.markPrice) <= 0) throw Error("\u5E01\u5B89\u6807\u8BB0\u4EF7\u683C\u65E0\u6548");
  return mark.markPrice;
}
function createUsdtExchange(request, fetcher = fetch) {
  const positionSide = (mode) => mode === "hedge" ? "LONG" : "BOTH";
  return {
    async account() {
      const [user, key, account, mode] = await Promise.all([
        request("GET", "/api/v3/account", { omitZeroBalances: "true" }),
        request("GET", "/sapi/v1/account/apiRestrictions"),
        request("GET", "/fapi/v3/account"),
        request("GET", "/fapi/v1/positionSide/dual")
      ]);
      if (!/^[1-9]\d*$/.test(String(user.uid)) || key.enableReading !== true || key.enableFutures !== true || key.ipRestrict !== true || typeof mode.dualSidePosition !== "boolean" || !Array.isArray(account.assets) || !Array.isArray(account.positions) || account.canTrade === false) throw Error("\u5E01\u5B89 U \u672C\u4F4D\u8D26\u6237\u3001\u5408\u7EA6\u6743\u9650\u6216 IP \u767D\u540D\u5355\u672A\u901A\u8FC7\u9A8C\u8BC1");
      return { id: String(user.uid), mode: mode.dualSidePosition ? "hedge" : "one-way" };
    },
    async market(symbol) {
      return readUsdtMarket(symbol, fetcher);
    },
    async book(symbol, side) {
      const p = new URLSearchParams({ symbol });
      const response = await fetcher(
        futures + "/fapi/v1/ticker/bookTicker?" + p,
        { signal: AbortSignal.timeout(8e3), redirect: "error" }
      );
      if (!response.ok) throw new UsdtApiError(response.status);
      const quote = await response.json();
      const price = String(side === "BUY" ? quote.askPrice : quote.bidPrice);
      if (quote.symbol !== symbol || !quantityText2.test(price) || !Number.isFinite(Number(price)) || Number(price) <= 0) throw Error("\u5E01\u5B89\u76D8\u53E3\u4EF7\u683C\u65E0\u6548");
      return price;
    },
    async check(market, mode, held, entry, opening, leverage, managed, knownProtection, unsettledBuyId, confirmOpening) {
      const { symbol } = market;
      const [positions, regular, algo, settings, modes] = await Promise.all([
        request("GET", "/fapi/v3/positionRisk", { symbol }),
        request("GET", "/fapi/v1/openOrders", { symbol }),
        request("GET", "/fapi/v1/openAlgoOrders", { symbol }),
        request("GET", "/fapi/v1/symbolConfig", { symbol }),
        request("GET", "/fapi/v1/positionSide/dual")
      ]);
      if (modes.dualSidePosition !== (mode === "hedge")) throw Error("\u5E01\u5B89\u6301\u4ED3\u6A21\u5F0F\u5DF2\u53D8\u5316");
      if (![positions, regular, algo, settings].every(Array.isArray)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6216\u6302\u5355\u8BFB\u6570\u4E0D\u53EF\u7528");
      if (unsettledBuyId && regular.some((order) => order.clientOrderId === unsettledBuyId))
        throw Error("\u5E01\u5B89\u4ECD\u6709\u8FD9\u7B14\u4E70\u5165\u59D4\u6258\u5728\u6302\u5355\u4E2D\uFF0C\u7B49\u5F85\u5B8C\u6210\u540E\u9000\u51FA");
      if ((regular.length || algo.some((row2) => !knownProtection?.includes(row2.clientAlgoId))) && (leverage !== 0 || managed))
        throw Error("\u8BE5\u5408\u7EA6\u6709\u5916\u90E8\u6302\u5355\uFF0C\u9700\u6838\u5BF9\u4ED3\u4F4D");
      const active = positions.filter((row2) => Number(row2.positionAmt) !== 0);
      const row = active.find((item) => item.symbol === symbol && item.positionSide === positionSide(mode));
      if (active.some((item) => item !== row && !(managed && mode === "hedge" && item.positionSide === "SHORT")) || (row && Number(row.positionAmt) > 0 ? quantityUnits(String(row.positionAmt), market.step) : row ? -1 : 0) !== held || held > 0 && (!Number.isFinite(Number(row.entryPrice)) || Math.abs(Number(row.entryPrice) - entry) > Math.max(1e-8, entry * 1e-5))) {
        throw Error("\u5E01\u5B89\u5B9E\u9645\u4ED3\u4F4D\u4E0E\u672C\u673A\u6210\u4EA4\u8BB0\u5F55\u4E0D\u4E00\u81F4");
      }
      if (leverage === 0 || managed) return;
      const config = settings.find((item) => item.symbol === symbol);
      if (!config) throw Error("\u5E01\u5B89\u5408\u7EA6\u914D\u7F6E\u4E0D\u53EF\u7528");
      if (opening) {
        if (config.marginType !== "ISOLATED") {
          confirmOpening?.();
          try {
            await request("POST", "/fapi/v1/marginType", { symbol, marginType: "ISOLATED" });
          } catch (error) {
            if (!(error instanceof UsdtApiError) || error.code !== -4046) throw error;
          }
        }
        if (Number(config.leverage) !== leverage) {
          confirmOpening?.();
          const result = await request("POST", "/fapi/v1/leverage", { symbol, leverage: String(leverage) });
          if (result.symbol !== symbol || Number(result.leverage) !== leverage) throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u65B9\u6848\u6760\u6746");
        }
      } else if (config.marginType !== "ISOLATED" || Number(config.leverage) !== leverage) {
        throw Error("\u5E01\u5B89\u9010\u4ED3\u6216\u6760\u6746\u8BBE\u7F6E\u4E0E\u51BB\u7ED3\u65B9\u6848\u4E0D\u4E00\u81F4");
      }
    },
    async order(market, mode, order, send) {
      const { symbol } = market;
      const position = positionSide(mode);
      let report;
      if (send) {
        try {
          report = await request("POST", "/fapi/v1/order", {
            symbol,
            side: order.side,
            positionSide: position,
            ...order.limitPrice ? { type: "LIMIT", timeInForce: "IOC", price: order.limitPrice } : { type: "MARKET" },
            quantity: order.quantity,
            newClientOrderId: order.id,
            newOrderRespType: "RESULT",
            ...mode === "one-way" && order.side === "SELL" ? { reduceOnly: "true" } : {}
          });
        } catch (error) {
          if (error instanceof UsdtApiError && [-1013, -1021, -1102, -1111, -2014, -2015, -2019, -2022, -4164].includes(error.code ?? 0)) {
            return { terminal: true, fills: [], issue: error.message };
          }
        }
      }
      if (!report) {
        try {
          report = await request("GET", "/fapi/v1/order", { symbol, origClientOrderId: order.id });
        } catch (error) {
          if (error instanceof UsdtApiError && error.code === -2013) return;
          throw error;
        }
      }
      if (report.symbol !== symbol || report.clientOrderId !== order.id || report.side !== order.side || report.positionSide !== position || !/^\d+$/.test(String(report.orderId)) || quantityUnits(String(report.origQty), market.step) !== quantityUnits(order.quantity, market.step)) {
        throw Error("\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u4E0E\u59D4\u6258\u4E0D\u4E00\u81F4");
      }
      const terminal = ["FILLED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED", "REJECTED"].includes(report.status);
      const filled = quantityUnits(String(report.executedQty), market.step);
      if (!terminal && !["NEW", "PARTIALLY_FILLED"].includes(report.status)) throw Error("\u5E01\u5B89\u8BA2\u5355\u72B6\u6001\u4E0D\u53EF\u8BC6\u522B");
      if (filled > quantityUnits(order.quantity, market.step) || report.status === "FILLED" && filled !== quantityUnits(order.quantity, market.step)) throw Error("\u5E01\u5B89\u7D2F\u8BA1\u6210\u4EA4\u91CF\u8D85\u8FC7\u59D4\u6258");
      const trades = filled ? await request("GET", "/fapi/v1/userTrades", { symbol, orderId: String(report.orderId), limit: "1000" }) : [];
      if (!Array.isArray(trades)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u65E0\u6548");
      const ids = /* @__PURE__ */ new Set();
      const fills = trades.map((trade) => {
        const id = String(trade.id), price = Number(trade.price), at = Number(trade.time);
        const quantity2 = quantityUnits(String(trade.qty), market.step), commission = Number(trade.commission), realized = Number(trade.realizedPnl);
        if (trade.symbol !== symbol || String(trade.orderId) !== String(report.orderId) || trade.side !== order.side || trade.positionSide !== position || !/^\d+$/.test(id) || ids.has(id) || quantity2 <= 0 || !Number.isFinite(price) || price <= 0 || !Number.isSafeInteger(at) || at <= 0 || !Number.isFinite(commission) || !Number.isFinite(realized) || typeof trade.commissionAsset !== "string" || !trade.commissionAsset) throw Error("\u5E01\u5B89\u6210\u4EA4\u8EAB\u4EFD\u6216\u91D1\u989D\u4E0D\u7B26");
        ids.add(id);
        return { id, quantity: quantity2, price, at, commission, commissionAsset: trade.commissionAsset, realized };
      });
      if (fills.reduce((units2, fill) => units2 + fill.quantity, 0) !== filled) return;
      return { exchangeId: String(report.orderId), terminal, fills, issue: terminal && !filled ? "\u5E01\u5B89\u8BA2\u5355\u5DF2\u7EC8\u6B62\uFF0C\u672A\u6210\u4EA4" : void 0 };
    }
  };
}

// scripts/usdt-follow-store.ts
import { DatabaseSync } from "node:sqlite";
function decodeLedger(payload) {
  const row = JSON.parse(String(payload));
  if (!("switchedMonitor" in row)) return row;
  const { switchedMonitor, switchedStatus, ...rest } = row;
  return { ...rest, managed: switchedMonitor, status: switchedStatus };
}
function openUsdtFollowStore(file, account, owner) {
  const db = new DatabaseSync(file);
  try {
    db.exec("PRAGMA busy_timeout=4000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL");
    db.exec("CREATE TABLE IF NOT EXISTS connection (id INTEGER PRIMARY KEY CHECK(id=1), account TEXT NOT NULL, owner TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS campaigns (id TEXT PRIMARY KEY, payload TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS managed_campaigns (id TEXT PRIMARY KEY, payload TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS position_controls (id TEXT PRIMARY KEY, payload TEXT NOT NULL, pending INTEGER NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS desk_orders (id TEXT PRIMARY KEY, payload TEXT NOT NULL, pending INTEGER NOT NULL)");
    db.prepare("INSERT OR IGNORE INTO connection VALUES (1, ?, ?)").run(account, owner);
    const connection = db.prepare("SELECT account, owner FROM connection WHERE id=1").get();
    if (connection?.account !== account || connection.owner !== owner) throw Error("\u672C\u673A\u5B9E\u76D8\u8D26\u672C\u7ED1\u5B9A\u4E86\u53E6\u4E00\u4E2A\u8D26\u6237");
  } catch (error) {
    db.close();
    throw error;
  }
  const read = db.prepare("SELECT payload FROM campaigns ORDER BY rowid");
  const readManaged = db.prepare("SELECT payload FROM managed_campaigns ORDER BY rowid");
  const save = db.prepare("INSERT INTO campaigns VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload");
  const saveManaged = db.prepare("INSERT INTO managed_campaigns VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload");
  const getControl = db.prepare("SELECT payload FROM position_controls WHERE id=?");
  const listControls = db.prepare("SELECT payload FROM position_controls WHERE pending=1 ORDER BY rowid");
  const saveControl = db.prepare("INSERT INTO position_controls VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, pending=excluded.pending");
  const getDesk = db.prepare("SELECT payload FROM desk_orders WHERE id=?");
  const listDesk = db.prepare("SELECT payload FROM desk_orders WHERE pending=1");
  const saveDesk = db.prepare("INSERT INTO desk_orders VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, pending=excluded.pending");
  const readSetting = db.prepare("SELECT value FROM settings WHERE key=?");
  const saveSetting = db.prepare("INSERT INTO settings VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const controlRevision = () => Number(readSetting.get("follow-control-revision")?.value ?? 0);
  return {
    paused: () => db.prepare("SELECT 1 FROM settings WHERE key='paused'").get() != null,
    controlRevision,
    setPaused(paused) {
      db.exec("BEGIN IMMEDIATE");
      try {
        if (paused) saveSetting.run("paused", "1");
        else db.prepare("DELETE FROM settings WHERE key='paused'").run();
        saveSetting.run("follow-control-revision", String(controlRevision() + 1));
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
    },
    readAll: () => [...read.all(), ...readManaged.all()].map((row) => decodeLedger(row.payload)),
    save(row) {
      if (row.managed?.followBasis) {
        const { managed, status, ...rest } = row;
        const payload = { ...rest, status: { ...status, state: "ignored" }, switchedMonitor: managed, switchedStatus: status };
        save.run(row.campaign.id, JSON.stringify(payload));
      } else (row.managed ? saveManaged : save).run(row.campaign.id, JSON.stringify(row));
    },
    getPositionControl(id) {
      const row = getControl.get(id);
      return row && JSON.parse(String(row.payload));
    },
    pendingPositionControls() {
      return listControls.all().map((row) => JSON.parse(String(row.payload)));
    },
    savePositionControl(id, value, pending) {
      saveControl.run(id, JSON.stringify(value), Number(pending));
    },
    getDeskOrder(id) {
      const row = getDesk.get(id);
      return row && JSON.parse(String(row.payload));
    },
    pendingDeskOrders() {
      return listDesk.all().map((row) => JSON.parse(String(row.payload)));
    },
    saveDeskOrder(id, value, pending) {
      saveDesk.run(id, JSON.stringify(value), Number(pending));
    },
    positionLeverage(id) {
      const row = readSetting.get("position-leverage:" + id);
      return row && JSON.parse(String(row.value));
    },
    savePositionLeverage(id, value) {
      const key = "position-leverage:" + id;
      const old = readSetting.get(key);
      if (!old || Number(JSON.parse(String(old.value)).at) < value.at) saveSetting.run(key, JSON.stringify(value));
    },
    close: () => db.close()
  };
}

// src/lib/fish/binanceManualMonitor.ts
var BINANCE_MANUAL_MONITOR_VERSION = "binance-manual-monitor-v1";
var MANAGED_MINUTE = 6e4;
var binanceManualId = (anchor) => ["fish-instant-live", anchor.symbol, anchor.positionSide, "long", anchor.openingTradeId, anchor.openingOrderId].join("-");
function initialBinanceManualCheckpoint(position, key = "") {
  if (position.checkpoint) return position.checkpoint;
  const { entryPrice, entryQuantity, armedAt, monitor, exchangeReduction } = position;
  const entryTime = position.followBasis?.effectiveAt ?? Math.ceil(position.anchor.openedAt / MANAGED_MINUTE) * MANAGED_MINUTE;
  const remainingQuantity = exchangeReduction?.quantity ?? entryQuantity;
  const averageEntryPrice = exchangeReduction?.entryPrice ?? entryPrice;
  return {
    status: "open",
    key,
    sampleId: binanceManualId(position.anchor),
    groupId: monitor.plan.id,
    evaluatedAt: armedAt,
    entryPrice,
    entryTime,
    endPrice: entryPrice,
    endTime: Math.max(entryTime, Math.ceil(Math.max(armedAt, exchangeReduction?.at ?? 0) / MANAGED_MINUTE) * MANAGED_MINUTE),
    initialNotional: entryPrice * entryQuantity,
    remainingQuantity,
    remainingCost: averageEntryPrice * remainingQuantity,
    averageEntryPrice,
    realizedPnl: exchangeReduction?.realized ?? 0,
    followBasis: position.followBasis
  };
}

// scripts/usdt-managed-execution.ts
var minuteCeiling = (at) => Math.ceil(at / MANAGED_MINUTE) * MANAGED_MINUTE;
function matchesManualAnchor(anchor, actual) {
  const entry = actual?.fills[0];
  return !!entry && !!actual && actual.symbol === anchor.symbol && actual.positionSide === anchor.positionSide && actual.direction === "long" && actual.asset === "USDT" && actual.openedAt === anchor.openedAt && entry.id === anchor.openingTradeId && entry.orderId === anchor.openingOrderId && entry.action === "open" && entry.side === "BUY";
}
function actualFill(fill, market) {
  return {
    id: fill.id,
    at: fill.at,
    quantity: quantityUnits(fill.positionQuantity, market.step),
    price: Number(fill.price),
    realized: fill.realized,
    commission: fill.commission,
    commissionAsset: fill.commissionAsset
  };
}
function createManagedUsdtLedger(anchor, monitor, actual, market, now) {
  if (!matchesManualAnchor(anchor, actual) || actual.closedAt || market.symbol !== anchor.symbol || actual.fills.some((fill) => fill.action !== "open" || fill.side !== "BUY" || fill.orderId !== anchor.openingOrderId)) {
    throw Error("\u53EA\u80FD\u63A5\u624B\u9996\u4ED3\u9010\u7B14\u6210\u4EA4\u5DF2\u7ECF\u6838\u5B9E\u4E14\u4ECD\u5728\u6301\u6709\u7684\u5E01\u5B89\u591A\u4ED3");
  }
  const fills = actual.fills.map((fill) => actualFill(fill, market));
  const units2 = fills.reduce((sum, fill) => sum + fill.quantity, 0);
  const entryQuantity = Number(formatQuantity(units2, market.step));
  const entryPrice = fills.reduce((sum, fill) => sum + fill.price * fill.quantity, 0) / units2;
  const notional = entryQuantity * entryPrice;
  if (!Number.isSafeInteger(units2) || units2 <= 0 || units2 !== quantityUnits(actual.quantity, market.step) || !Number.isFinite(notional) || notional <= 0) throw Error("\u5E01\u5B89\u9996\u4ED3\u6570\u91CF\u6216\u6210\u4EA4\u91D1\u989D\u65E0\u6CD5\u6838\u5BF9");
  const id = binanceManualId(anchor);
  const managed = {
    version: BINANCE_MANUAL_MONITOR_VERSION,
    anchor,
    monitor,
    armedAt: Math.max(now, ...fills.map((fill) => fill.at)),
    entryQuantity,
    entryPrice,
    revision: 0
  };
  const open = {
    id: anchor.openingOrderId,
    exchangeId: anchor.openingOrderId,
    side: "BUY",
    terminal: true,
    quantity: formatQuantity(units2, market.step),
    fills
  };
  return {
    campaign: {
      id,
      source: { symbol: anchor.symbol, exchange: "binance" },
      admittedAt: now,
      notional,
      leverage: 1,
      actions: [{ id: "open", action: "open", at: anchor.openedAt }]
    },
    managed,
    orders: { open },
    skipped: [],
    status: { id, symbol: anchor.symbol, state: "tracking" }
  };
}
function mergeUsdtExitFills(row, actual, market, allowPartial) {
  const present = new Set(actual.fills.map((fill) => fill.id));
  const recorded = Object.values(row.orders).flatMap((order) => order.fills ?? []);
  if (recorded.some((fill) => !present.has(fill.id))) throw Error("\u5E01\u5B89\u6210\u4EA4\u56DE\u62A5\u8FD8\u672A\u540C\u6B65\u5B8C\u6210");
  const known = new Set(recorded.map((fill) => fill.id));
  const external = actual.fills.filter((fill) => !known.has(fill.id));
  if (external.length && !actual.closedAt && (!allowPartial || external.some((fill) => fill.action !== "reduce" || fill.side !== "SELL")))
    throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6709\u65B0\u7684\u624B\u52A8\u52A0\u51CF\u4ED3\uFF0C\u7B49\u5F85\u6838\u5BF9\u540E\u518D\u7EE7\u7EED\u7B56\u7565");
  for (const fill of external) {
    row.orders["binance:" + fill.id] = {
      id: fill.id,
      exchangeId: fill.orderId,
      side: fill.side,
      terminal: true,
      quantity: fill.positionQuantity,
      fills: [actualFill(fill, market)]
    };
  }
  return external;
}
function verifyManagedUsdtFills(row, actual, market) {
  if (!row.managed || !matchesManualAnchor(row.managed.anchor, actual)) throw Error("\u5E01\u5B89\u6301\u4ED3\u5DF2\u6362\u6210\u53E6\u4E00\u7B14\u9996\u4ED3");
  mergeUsdtExitFills(row, actual, market, false);
  return !!actual.closedAt;
}
function settleManagedUsdtDecision(row, key, market, remaining) {
  const managed = row.managed, pending = managed?.pending, order = row.orders[key];
  if (!managed || !pending || !order?.terminal || pending.action.id !== key && !key.startsWith(pending.action.id + ":")) return;
  if (pending.kind === "close" && remaining.held > 0) {
    if (!order.fills?.length) {
      row.status.state = "blocked";
      row.status.issue = order.exchangeId ? "\u672C\u6B21\u5E73\u4ED3\u672A\u6210\u4EA4\uFF0C\u7B49\u5F85\u91CD\u65B0\u6838\u5BF9\u4F59\u4ED3" : "\u5E01\u5B89\u62D2\u7EDD\u4E86\u672C\u6B21\u5E73\u4ED3\uFF0C\u7B49\u5F85\u91CD\u65B0\u6838\u5BF9\u4F59\u4ED3";
    }
    return;
  }
  const prior = managed.checkpoint;
  if (!prior) throw Error("\u624B\u52A8\u6258\u7BA1\u7F3A\u5C11\u6301\u4ED3\u7B56\u7565\u68C0\u67E5\u70B9");
  const fills = Object.values(row.orders).flatMap((o) => o.fills ?? []);
  const actual = order.fills ?? [];
  const units2 = actual.reduce((sum, fill) => sum + fill.quantity, 0);
  const through = Math.max(prior.endTime ?? 0, pending.through, minuteCeiling(Math.max(...fills.map((f) => f.at))));
  let checkpoint = {
    ...prior,
    endTime: through,
    pendingExit: void 0,
    remainingQuantity: Number(formatQuantity(remaining.held, market.step)),
    averageEntryPrice: remaining.entry,
    remainingCost: Number(formatQuantity(remaining.held, market.step)) * remaining.entry,
    realizedPnl: remaining.realized - (managed.followBasis?.realizedBefore ?? 0)
  };
  if (units2 > 0) {
    const quantity2 = Number(formatQuantity(units2, market.step));
    const price = actual.reduce((sum, fill) => sum + fill.price * fill.quantity, 0) / units2;
    const at = Math.max(...actual.map((fill) => fill.at));
    checkpoint = { ...checkpoint, endPrice: price };
    if (pending.kind === "add") {
      const addition = { ...pending.evidence, price, quantity: quantity2, notional: price * quantity2 };
      const additions = [...prior.additionFills ?? (prior.additionFill ? [prior.additionFill] : []), addition];
      const newVetoStage = pending.vetoStageSwitches?.at(-1);
      const peak = Math.max(price, prior.vetoPath?.peak ?? managed.entryPrice * (1 + (prior.peakPct ?? 0) / 100));
      checkpoint = {
        ...checkpoint,
        additionFill: additions[0],
        additionFills: additions,
        routeDecision: pending.routeDecision ?? prior.routeDecision,
        sellStageSwitches: pending.sellStageSwitches ?? prior.sellStageSwitches,
        vetoStageSwitches: pending.vetoStageSwitches ?? prior.vetoStageSwitches,
        ...newVetoStage?.afterAdditions === (managed.followBasis?.carriedAdditions ?? 0) + additions.length ? { vetoPath: {
          entry: managed.entryPrice,
          peak: newVetoStage.peakBasis === "holding" ? peak : price,
          minimum: price,
          dynamic: 0
        } } : {}
      };
    } else if (pending.kind === "mirror") {
      checkpoint.mirrorFill = {
        ...pending.evidence,
        price,
        fraction: Math.min(1, quantity2 / managed.entryQuantity),
        gainPct: (price / managed.entryPrice - 1) * 100
      };
    } else if (pending.kind === "support-reduction") {
      const costRemoved = quantity2 * remaining.entry;
      const reduction = {
        ...pending.evidence,
        price,
        quantity: quantity2,
        costRemoved,
        fraction: units2 / (remaining.held + units2),
        realizedPnl: actual.reduce((sum, fill) => sum + fill.realized, 0)
      };
      checkpoint.additionReductions = [...prior.additionReductions ?? [], reduction];
    } else if (!remaining.held) {
      checkpoint = { ...checkpoint, status: "closed", complete: true, endTime: at, reason: pending.reason };
    }
  }
  managed.checkpoint = checkpoint;
  managed.pending = void 0;
  managed.revision++;
}

// src/lib/fish/qualityHoldingLedger.ts
var HOLDING_LEDGER_ADDITION_VERSION = "holding-ledger-addition-v1";
function replayQualityHoldingLedger(o) {
  if (![o.notional, o.entryPrice, o.entryAt].every(Number.isFinite) || !(o.notional > 0) || !(o.entryPrice > 0) || o.entryAt <= 0) throw Error("\u6301\u4ED3\u8D26\u521D\u59CB\u72B6\u6001\u65E0\u6548");
  const through = o.through ?? Infinity, initialQuantity = o.notional / o.entryPrice;
  if (!Number.isFinite(through) && through !== Infinity || through < o.entryAt) throw Error("\u6301\u4ED3\u8D26\u8BFB\u53D6\u65F6\u70B9\u65E0\u6548\u6216\u65E9\u4E8E\u5EFA\u4ED3");
  const lots = o.details === false ? [] : [{ index: 0, at: o.entryAt, price: o.entryPrice, quantity: initialQuantity, cost: o.notional }];
  let held = initialQuantity, cost = o.notional, realized = 0, totalInvested = o.notional, totalQuantity = initialQuantity;
  let mirrorQuantity = 0, mirrorCost = 0, mirrorProfit = 0, reductionProfit = 0;
  const sales = [];
  const events = [];
  const validAt = (at) => {
    if (!Number.isFinite(at) || at < o.entryAt) throw Error("\u6301\u4ED3\u6210\u4EA4\u65F6\u95F4\u65E0\u6548");
  };
  o.additions.forEach((f, index) => {
    validAt(f.at);
    if (f.at <= through) events.push({ at: f.at, priority: 2, index, kind: "add" });
  });
  o.reductions?.forEach((f, index) => {
    validAt(f.at);
    if (f.at <= through) events.push({ at: f.at, priority: 1, index, kind: "reduce" });
  });
  const m = o.mirror;
  if (m) validAt(m.at);
  if (m && (m.at < through || m.at === through && (o.includeIntraminute || m.atOpen))) events.push({ at: m.at, priority: m.atOpen ? 0 : 3, index: 0, kind: "mirror" });
  events.sort((a, b) => a.at - b.at || a.priority - b.priority || a.index - b.index);
  for (const event of events) {
    if (!Number.isFinite(event.at) || event.at < o.entryAt) throw Error("\u6301\u4ED3\u6210\u4EA4\u65F6\u95F4\u65E0\u6548");
    if (event.kind === "add") {
      const f = o.additions[event.index];
      if (!(held > 0) || ![f.price, f.quantity, f.notional].every(Number.isFinite) || !(f.price > 0) || !(f.quantity > 0) || !(f.notional > 0)) throw Error("\u52A0\u4ED3\u6210\u4EA4\u6216\u5269\u4F59\u6301\u4ED3\u65E0\u6548");
      if (Math.abs(f.quantity * f.price - f.notional) > 1e-9 * Math.max(1, f.notional)) throw Error("\u52A0\u4ED3\u5E01\u6570\u4E0E\u91D1\u989D\u4E0D\u4E00\u81F4");
      held += f.quantity;
      cost += f.notional;
      totalInvested += f.notional;
      totalQuantity += f.quantity;
      if (o.details !== false) lots.push({ index: event.index + 1, at: f.at, price: f.price, quantity: f.quantity, cost: f.notional });
      continue;
    }
    const cut = event.kind === "reduce" ? o.reductions[event.index] : void 0;
    const price = cut?.price ?? m.price, fraction = cut?.fraction ?? m.fraction;
    if (!Number.isFinite(price) || !(price > 0) || !Number.isFinite(fraction) || fraction < 0 || fraction > 1) throw Error("\u51CF\u4ED3\u6210\u4EA4\u65E0\u6548");
    const quantity2 = event.kind === "mirror" ? fraction === 1 ? held : Math.min(held, initialQuantity * fraction) : held * fraction;
    if (!(quantity2 > 0)) continue;
    const proportion = quantity2 / held, sold = lots.filter((l) => l.quantity > 0).map((l) => {
      const q = l.quantity * proportion, c = l.cost * proportion, pnl2 = q * price - c;
      l.quantity *= 1 - proportion;
      l.cost *= 1 - proportion;
      return { index: l.index, quantity: q, costRemoved: c, realizedPnl: pnl2 };
    });
    const costRemoved = cost * proportion, pnl = quantity2 * price - costRemoved;
    held *= 1 - proportion;
    cost *= 1 - proportion;
    realized += pnl;
    if (event.kind === "mirror") {
      mirrorQuantity += quantity2;
      mirrorCost += costRemoved;
      mirrorProfit += pnl;
    } else reductionProfit += pnl;
    if (o.details !== false) sales.push({ kind: event.kind, at: event.at, price, quantity: quantity2, costRemoved, realizedPnl: pnl, lots: sold });
  }
  if (![initialQuantity, held, cost, realized, totalInvested, totalQuantity, mirrorQuantity, mirrorCost, mirrorProfit, reductionProfit].every(Number.isFinite) || held < 0 || cost < 0) throw Error("\u6301\u4ED3\u8D26\u91D1\u989D\u6216\u5E01\u6570\u8D85\u51FA\u53EF\u8BA1\u7B97\u8303\u56F4");
  return { initialQuantity, held, cost, realized, totalInvested, totalQuantity, mirrorQuantity, mirrorCost, mirrorProfit, reductionProfit, lots, sales };
}
function calculateHoldingLedgerAddition(p, T, K) {
  const blank = (error, shortfall = 0) => ({ error, addCoins: 0, baseCoins: 0, mirrorCoins: 0, mirrorUsed: 0, coverageGap: 0, oldLossShortfall: shortfall });
  if (![p.held, p.cost, p.realized, T, K].every(Number.isFinite) || p.held < 0 || p.cost < 0 || T <= 0 || K <= 0) return blank("invalid_input");
  if (!(p.held > 0)) return blank("position_closed");
  if (!(T > K)) return blank("price_not_above_support");
  const cushion = p.held * K - p.cost, raw = cushion + p.realized, risk = T - K;
  if (!Number.isFinite(raw)) return blank("invalid_input");
  const tolerance = 64 * Number.EPSILON * Math.max(1, p.held * K, p.cost, Math.abs(p.realized));
  if (raw < -tolerance) return blank("risk_budget_insufficient", -raw);
  const budget = Math.max(0, raw);
  const addCoins = budget / risk, baseCoins = Math.max(0, cushion + Math.min(0, p.realized)) / risk, mirrorCoins = Math.max(0, p.realized - Math.max(0, -cushion)) / risk;
  if (![addCoins, baseCoins, mirrorCoins].every(Number.isFinite)) return blank("invalid_input");
  return { error: null, addCoins, baseCoins, mirrorCoins, mirrorUsed: 0, coverageGap: budget - addCoins * risk, oldLossShortfall: 0 };
}

// src/lib/fish/usdtLiveEntry.ts
var USDT_EXECUTION_SAFETY = 2;
var USDT_EXECUTION_PATH = "/api/usdt-follow/safe";
function validUsdtLiveEntry(campaign) {
  const entry = campaign.liveEntry;
  return !!entry && entry.version === 1 && Number.isSafeInteger(entry.capturedAt) && entry.capturedAt > 0 && entry.capturedAt <= campaign.admittedAt && typeof entry.templateId === "string" && !!entry.templateId.trim() && entry.templateId.length <= 200 && Number.isFinite(entry.notional) && entry.notional > 0 && entry.notional === campaign.notional && Number.isInteger(entry.leverage) && entry.leverage >= 1 && entry.leverage <= 125 && entry.leverage === campaign.leverage;
}

// src/lib/fish/instantMonitorSwitchCheckpoint.ts
function rebaseInstantMonitorCheckpoint(current, initialNotional, from, to, at, key = current.key) {
  if (to.plan.engine || to.plan.initialization) throw Error("\u8BE5\u6A21\u677F\u987B\u4ECE\u5F00\u4ED3\u5F00\u59CB\u8FD0\u884C\uFF0C\u65E0\u6CD5\u63A5\u624B\u5DF2\u6709\u6301\u4ED3");
  if (current.status !== "open" || !current.entryPrice || !current.endTime || current.mirrorFill?.fraction === 1 || !Number.isFinite(initialNotional) || initialNotional <= 0) {
    throw Error("\u8BE5\u6301\u4ED3\u5DF2\u7ED3\u675F\u6216\u9996\u4ED3\u5C1A\u672A\u6838\u5BF9");
  }
  if (current.pendingExit) throw Error("\u539F\u65B9\u6848\u5DF2\u6709\u5F85\u6210\u4EA4\u7684\u5356\u51FA\uFF0C\u8BF7\u7B49\u6210\u4EA4\u6838\u5BF9\u5B8C\u6210");
  const route = to.plan.router;
  if (route?.afterAdditions && (current.additionFills?.length || (current.additionFill ? 1 : 0)) >= route.afterAdditions) {
    throw Error("\u8FD9\u7B14\u4ED3\u4F4D\u5DF2\u8D8A\u8FC7\u65B0\u6A21\u677F\u7684\u5206\u6D41\u8F6E\u6B21\uFF0C\u8BF7\u9009\u62E9\u53EF\u63A5\u7EED\u5F53\u524D\u8F6E\u6B21\u7684\u65B9\u6848");
  }
  const effectiveAt = Math.max(current.endTime, Math.ceil(at / 6e4) * 6e4);
  return {
    ...current,
    key,
    groupId: to.plan.id,
    evaluatedAt: at,
    endTime: effectiveAt,
    initialNotional,
    instantMonitorSwitches: [...current.instantMonitorSwitches ?? [], { at, effectiveAt, from, to }],
    routeDecision: void 0,
    activeSellStage: void 0,
    sellStageSwitches: void 0,
    activeVetoStage: void 0,
    vetoStageSwitches: void 0,
    vetoPath: void 0,
    advantageState: void 0,
    boxStopStates: void 0,
    additionGuardPlus: void 0,
    additionNote: void 0,
    boxMarketRepair: void 0,
    exitSnapshot: void 0,
    exitReading: void 0
  };
}

// scripts/usdt-follow-engine.ts
var entryAgeMs = 12e4;
var increaseAgeMs = 12e4;
var positionTimeout = 45e3;
var unsettledBuyIssue = "\u4E70\u5355\u56DE\u62A5\u5C1A\u672A\u6838\u5B9E\uFF0C\u7EE7\u7EED\u6309\u539F\u8BA2\u5355\u7F16\u53F7\u5BF9\u8D26";
var externalReductionIssue = "\u5E01\u5B89\u51FA\u73B0\u7B56\u7565\u5916\u51CF\u4ED3\uFF0C\u8BF7\u6309\u5B9E\u9645\u4F59\u4ED3\u91CD\u65B0\u786E\u8BA4\u5207\u6362";
var freshIncrease = (action, at) => action.action === "add" && action.impulseFreshUntil !== void 0 ? action.at <= at && at < action.impulseFreshUntil : action.at <= at && at - action.at <= increaseAgeMs;
function createUsdtFollower(store, exchange, owner, mode, startedAt, readManaged, managedClock = Date.now, protectionIds, readPositions, protection) {
  const rows = new Map(store.readAll().map((row) => [row.campaign.id, row]));
  const markets = /* @__PURE__ */ new Map();
  const cooldown = /* @__PURE__ */ new Map();
  const managedChecked = /* @__PURE__ */ new Map();
  let active = false;
  let manual = false;
  let finishTick;
  let lastContactAt = 0;
  let accepting = !store.paused();
  let entryAfter = startedAt;
  const write = (row) => {
    store.save(row);
    rows.set(row.campaign.id, row);
  };
  const ingest = (campaigns, now = Date.now()) => {
    for (const incoming of campaigns) {
      const row = rows.get(incoming.id);
      if (row?.managed) continue;
      if (!row) {
        const open = incoming.actions[0];
        if (!validUsdtLiveEntry(incoming) || incoming.liveEntry.capturedAt < entryAfter || !accepting || incoming.admittedAt < entryAfter || open.at < entryAfter || now - incoming.admittedAt > entryAgeMs || now - open.at > entryAgeMs || incoming.actions.some((action) => action.action === "close")) continue;
        write({ campaign: incoming, orders: {}, skipped: [], status: { id: incoming.id, symbol: incoming.source.symbol, state: "waiting" } });
        continue;
      }
      if (row.campaign.notional !== incoming.notional || row.campaign.leverage !== incoming.leverage || row.campaign.source.symbol !== incoming.source.symbol || row.campaign.admittedAt !== incoming.admittedAt || row.campaign.source.exchange !== incoming.source.exchange || row.campaign.source.market !== incoming.source.market) {
        throw Error("\u540C\u4E00\u5373\u65F6\u4EA4\u6613\u6218\u5F79\u7684\u51BB\u7ED3\u53C2\u6570\u4E0D\u4E00\u81F4");
      }
      if (row.status.state === "closed" || row.status.state === "ignored") continue;
      const prior = new Map(row.campaign.actions.map((action) => [action.id, action]));
      let changed = false;
      for (const action of incoming.actions) {
        const saved = prior.get(action.id);
        if (saved && JSON.stringify(saved) !== JSON.stringify(action)) throw Error("\u540C\u4E00\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u7684\u5DF2\u8BB0\u8F7D\u6761\u4EF6\u4E0D\u4E00\u81F4");
        if (!saved) {
          prior.set(action.id, action);
          changed = true;
        }
      }
      if (changed) {
        row.campaign.actions = [...incoming.actions, ...[...prior.values()].filter((old) => !incoming.actions.some((action) => action.id === old.id))];
        write(row);
      }
    }
    lastContactAt = now;
  };
  const mayIncrease = (row, action, at, signalTime) => accepting && at - lastContactAt <= positionTimeout && action.at >= entryAfter && (row.managed || validUsdtLiveEntry(row.campaign) && (action.action !== "open" || row.campaign.liveEntry.capturedAt >= entryAfter)) && freshIncrease(action, signalTime);
  function balance(row) {
    let held = 0, entry = 0, initial = 0, realized = 0, fee = 0;
    const feesByAsset = /* @__PURE__ */ Object.create(null);
    const fills = Object.entries(row.orders).flatMap(([key, order]) => (order.fills ?? []).map((fill) => ({ ...fill, opening: key === "open", side: order.side })));
    fills.sort((a, b) => a.at - b.at || a.id.length - b.id.length || a.id.localeCompare(b.id));
    for (const fill of fills) {
      if (fill.side === "BUY") {
        entry = (entry * held + fill.price * fill.quantity) / (held + fill.quantity);
        held += fill.quantity;
        if (fill.opening) initial += fill.quantity;
      } else {
        held -= fill.quantity;
        if (held < 0) throw Error("\u5B9E\u76D8\u51CF\u4ED3\u91CF\u8D85\u8FC7\u6218\u5F79\u4F59\u4ED3");
      }
      realized += fill.realized;
      feesByAsset[fill.commissionAsset] = (feesByAsset[fill.commissionAsset] ?? 0) + fill.commission;
      if (fill.commissionAsset === "USDT") fee += fill.commission;
    }
    return { held, entry, initial, realized, fee, feesByAsset };
  }
  const syncBalance = (row, market) => {
    const current = balance(row);
    Object.assign(row.status, {
      market: market.symbol,
      asset: market.symbol.slice(0, -4),
      quantity: Number(formatQuantity(current.held, market.step)),
      entryPrice: current.held ? current.entry : void 0,
      realizedUsdt: current.realized,
      feeUsdt: current.fee,
      feesByAsset: current.feesByAsset,
      limitUsdt: row.campaign.notional,
      executions: Object.entries(row.orders).flatMap(([actionId, order]) => order.exchangeId && order.fills?.length ? [{
        actionId,
        orderId: order.exchangeId,
        side: order.side,
        fills: order.fills.map((fill) => ({ ...fill, quantity: Number(formatQuantity(fill.quantity, market.step)) }))
      }] : [])
    });
    return current;
  };
  async function readMarket(symbol) {
    const cached = markets.get(symbol);
    if (cached && Date.now() - cached.at < 10 * 6e4) return cached.value;
    const value = await exchange.market(symbol);
    if (value) markets.set(symbol, { value, at: Date.now() });
    return value;
  }
  async function adopt(anchor, monitor, revision = store.controlRevision()) {
    if (!readManaged || !accepting) throw Error("\u8BF7\u5148\u5F00\u542F\u672C\u673A\u5B9E\u76D8\u8DDF\u968F");
    if (anchor.positionSide !== (mode === "hedge" ? "LONG" : "BOTH")) throw Error("\u5E01\u5B89\u6301\u4ED3\u6A21\u5F0F\u4E0E\u624B\u52A8\u4ED3\u4F4D\u4E0D\u7B26");
    const id = binanceManualId(anchor);
    if (rows.has(id)) return rows.get(id).managed;
    const [actual, market] = await Promise.all([readManaged(anchor), readMarket(anchor.symbol)]);
    if (!market) throw Error("\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6\u65E0\u6CD5\u6838\u5BF9");
    const row = createManagedUsdtLedger(anchor, monitor, actual, market, managedClock());
    const initial = syncBalance(row, market);
    await exchange.check(market, mode, initial.held, initial.entry, false, 0, "existing-position", protectionIds?.(market.symbol, usdtLiveCampaignId(actual)));
    if (rows.has(id)) return rows.get(id).managed;
    if (!accepting || revision !== store.controlRevision()) throw Error("\u5B9E\u76D8\u8DDF\u968F\u72B6\u6001\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u7B56\u7565\u6258\u7BA1");
    if ([...rows.values()].some((row2) => row2.campaign.source.symbol === anchor.symbol && (balance(row2).held > 0 || Object.values(row2.orders).some((order) => !order.terminal)))) {
      throw Error("\u8BE5\u5E01\u5B89\u5408\u7EA6\u5DF2\u6709\u4E00\u7B14\u7531\u672C\u673A\u8DDF\u968F\u7684\u4EA4\u6613");
    }
    row.managed.armedAt = Math.max(row.managed.armedAt, managedClock());
    write(row);
    return row.managed;
  }
  async function switchManaged(id, epoch, monitor) {
    const current = rows.get(id);
    if (!current?.managed || current.managed.followBasis || current.status.state !== "tracking" || !readManaged) throw Error("\u53EA\u53EF\u5207\u6362\u5BF9\u8D26\u5B8C\u6210\u7684\u624B\u52A8\u6258\u7BA1\u6301\u4ED3");
    const row = structuredClone(current);
    const managed = row.managed;
    if ((managed.planEpoch ?? 0) !== epoch) throw Error("\u6301\u4ED3\u65B9\u6848\u5DF2\u5728\u522B\u5904\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9");
    if (managed.monitor.templateId === monitor.templateId) throw Error("\u5F53\u524D\u6301\u4ED3\u5DF2\u4F7F\u7528\u6B64\u6A21\u677F");
    if (managed.pending || Object.values(row.orders).some((order) => !order.terminal)) throw Error("\u6B63\u5728\u6838\u5BF9\u5B9E\u76D8\u59D4\u6258\uFF0C\u8BF7\u7B49\u6210\u4EA4\u56DE\u62A5");
    const [actual, market] = await Promise.all([readManaged(managed.anchor), readMarket(managed.anchor.symbol)]);
    if (!market || verifyManagedUsdtFills(row, actual, market)) throw Error("\u5B9E\u76D8\u4ED3\u4F4D\u5DF2\u5E73\u4ED3\u6216\u7B49\u5F85\u5BF9\u8D26");
    const held = balance(row);
    if (!held.held || quantityUnits(actual.quantity, market.step) !== held.held) throw Error("\u5B9E\u76D8\u4ED3\u4F4D\u6570\u91CF\u5DF2\u53D8\u5316\uFF0C\u8BF7\u7B49\u5F85\u5BF9\u8D26");
    await exchange.check(market, mode, held.held, held.entry, false, 0, "existing-position", protectionIds?.(market.symbol, id));
    if (rows.get(id) !== current) throw Error("\u4ED3\u4F4D\u6B63\u5728\u540C\u6B65\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u5207\u6362");
    const checkpoint = initialBinanceManualCheckpoint(managed);
    const initialNotional = managed.entryPrice * managed.entryQuantity;
    const expected = replayQualityHoldingLedger({
      notional: initialNotional,
      entryPrice: managed.entryPrice,
      entryAt: checkpoint.entryTime,
      additions: checkpoint.additionFills ?? (checkpoint.additionFill ? [checkpoint.additionFill] : []),
      mirror: checkpoint.mirrorFill,
      reductions: checkpoint.additionReductions,
      details: false
    });
    if (Math.abs(expected.held - Number(formatQuantity(held.held, market.step))) > Math.max(1e-9, expected.held * 1e-12) || Math.abs(expected.cost / expected.held - held.entry) > Math.max(1e-8, held.entry * 1e-5)) {
      throw Error("\u7B56\u7565\u6210\u4EA4\u4E0E\u5E01\u5B89\u4F59\u4ED3\u7684\u6570\u91CF\u6216\u5747\u4EF7\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u5148\u6838\u5BF9");
    }
    managed.checkpoint = rebaseInstantMonitorCheckpoint(checkpoint, initialNotional, managed.monitor, monitor, managedClock());
    managed.monitor = monitor;
    managed.planEpoch = epoch + 1;
    managed.revision++;
    write(row);
    return managed;
  }
  async function switchFollowMonitor(id, anchor, epoch, monitor, original, followSample) {
    const current = rows.get(id);
    if (!current?.campaign.liveEntry || !readManaged || !readPositions || current.status.state !== "tracking" && current.status.issue !== externalReductionIssue || current.managed && !current.managed.followBasis) throw Error("\u627E\u4E0D\u5230\u53EF\u6838\u5BF9\u7684\u7CFB\u7EDF\u8DDF\u5355\u5B9E\u76D8\u4ED3\u4F4D");
    const previous = current.managed;
    if ((previous?.planEpoch ?? 0) !== epoch) throw Error("\u6301\u4ED3\u65B9\u6848\u5DF2\u5728\u522B\u5904\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9");
    const originalId = current.campaign.liveEntry.templateId;
    const from = previous?.monitor ?? (original?.templateId === originalId ? original : { templateId: originalId, name: "\u539F\u8DDF\u5355\u65B9\u6848" });
    if (from.templateId === monitor.templateId && current.status.issue !== externalReductionIssue) throw Error("\u5F53\u524D\u6301\u4ED3\u5DF2\u4F7F\u7528\u6B64\u6A21\u677F");
    if (monitor.plan.engine || monitor.plan.initialization) throw Error("\u8BE5\u6A21\u677F\u987B\u4ECE\u5F00\u4ED3\u5F00\u59CB\u8FD0\u884C\uFF0C\u65E0\u6CD5\u63A5\u624B\u5DF2\u6709\u6301\u4ED3");
    const unsettled = () => current.managed?.pending || Object.values(current.orders).some((order) => !order.terminal) || current.campaign.actions.some((action) => !current.orders[action.id] && !current.skipped.includes(action.id));
    if (unsettled()) throw Error("\u539F\u65B9\u6848\u6709\u59D4\u6258\u6216\u4FE1\u53F7\u7B49\u5F85\u5904\u7406\uFF0C\u8BF7\u7B49\u6210\u4EA4\u6838\u5BF9\u5B8C\u6210");
    const market = await readMarket(anchor.symbol);
    const opening = market && openAnchor(current, market);
    if (!market || !opening || binanceManualId(opening) !== binanceManualId(anchor) || opening.openedAt !== anchor.openedAt)
      throw Error("\u5B9E\u76D8\u9996\u4ED3\u7F16\u53F7\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u540C\u6B65");
    const actual = await readOriginalPosition(current, market);
    const row = structuredClone(current);
    mergeUsdtExitFills(row, actual, market, true);
    const held = syncBalance(row, market);
    if (actual.closedAt || held.held <= 0 || quantityUnits(actual.quantity, market.step) !== held.held) throw Error("\u5B9E\u76D8\u4F59\u4ED3\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u540C\u6B65");
    const position = (await readPositions()).positions.find((p) => p.symbol === anchor.symbol && p.positionSide === anchor.positionSide && p.direction === "long");
    const entryPrice = Number(position?.entryPrice);
    if (!position || quantityUnits(position.quantity, market.step) !== held.held || !(entryPrice > 0) || !Number.isFinite(entryPrice) || Math.abs(entryPrice - held.entry) > Math.max(1e-8, held.entry * 1e-5)) throw Error("\u5E01\u5B89\u4F59\u4ED3\u6216\u6210\u672C\u5747\u4EF7\u6682\u672A\u5BF9\u9F50");
    await exchange.check(market, mode, held.held, entryPrice, false, 0, "existing-position", protectionIds?.(market.symbol, binanceManualId(anchor)));
    if (rows.get(id) !== current || unsettled()) throw Error("\u539F\u65B9\u6848\u51FA\u73B0\u65B0\u7684\u5F85\u5904\u7406\u4FE1\u53F7\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u5207\u6362");
    const carriedAdditions = row.campaign.actions.filter((action) => action.action === "add" && row.orders[action.id]?.fills?.length).length;
    if (monitor.plan.router?.afterAdditions && carriedAdditions >= monitor.plan.router.afterAdditions)
      throw Error("\u5DF2\u8D8A\u8FC7\u65B0\u6A21\u677F\u4E00\u6B21\u6027\u5206\u6D41\u7684\u8F6E\u6B21\uFF0C\u8BF7\u9009\u62E9\u80FD\u63A5\u7EED\u5F53\u524D\u8F6E\u6B21\u7684\u65B9\u6848");
    const at = managedClock();
    const latestFill = Math.max(at, ...Object.values(row.orders).flatMap((order) => (order.fills ?? []).map((fill) => fill.at)));
    const effectiveAt = Math.max(previous?.checkpoint?.endTime ?? 0, Math.ceil(latestFill / MANAGED_MINUTE) * MANAGED_MINUTE);
    const quantity2 = Number(formatQuantity(held.held, market.step));
    const followBasis = { version: USDT_FOLLOW_MONITOR_BASIS, effectiveAt, carriedAdditions, quantity: quantity2, entryPrice, realizedBefore: held.realized };
    const managed = {
      version: BINANCE_MANUAL_MONITOR_VERSION,
      anchor,
      monitor,
      armedAt: at,
      entryPrice,
      entryQuantity: quantity2,
      planEpoch: epoch + 1,
      revision: (previous?.revision ?? 0) + 1,
      followBasis,
      followSample: previous?.followSample ?? followSample
    };
    managed.checkpoint = { ...initialBinanceManualCheckpoint(managed), instantMonitorSwitches: [
      ...previous?.checkpoint?.instantMonitorSwitches ?? [],
      { at, effectiveAt, from, to: monitor, followBasis }
    ] };
    row.managed = managed;
    row.status.state = "tracking";
    row.status.issue = void 0;
    write(row);
    return managed;
  }
  function updateManaged(id, revision, checkpoint, decision, planEpoch, followBasisVersion) {
    const current = rows.get(id);
    if (!current?.managed || current.status.state === "closed") throw Error("\u627E\u4E0D\u5230\u4ECD\u5728\u6301\u6709\u7684\u624B\u52A8\u6258\u7BA1\u4ED3\u4F4D");
    if (current.managed.revision !== revision || current.managed.pending || current.managed.planEpoch !== planEpoch) return current.managed;
    if (current.managed.followBasis && followBasisVersion !== USDT_FOLLOW_MONITOR_BASIS) throw Error("\u8BF7\u66F4\u65B0\u7F51\u9875\u540E\u7EE7\u7EED\u5B9E\u76D8\u7B56\u7565");
    if (current.status.state !== "tracking") throw Error("\u5E01\u5B89\u5B9E\u76D8\u4ED3\u4F4D\u7B49\u5F85\u5BF9\u8D26");
    const row = structuredClone(current);
    const managed = row.managed;
    const entry = managed.followBasis?.effectiveAt ?? Math.ceil(managed.anchor.openedAt / MANAGED_MINUTE) * MANAGED_MINUTE;
    const earliest = Math.max(entry, managed.checkpoint?.endTime ?? Math.ceil(managed.armedAt / MANAGED_MINUTE) * MANAGED_MINUTE);
    const now = managedClock();
    if (checkpoint.status !== "open" || checkpoint.entryPrice !== managed.entryPrice || checkpoint.entryTime !== entry || !Number.isSafeInteger(checkpoint.endTime) || checkpoint.endTime % MANAGED_MINUTE !== 0 || checkpoint.endTime < earliest || checkpoint.endTime > now + MANAGED_MINUTE) {
      throw Error("\u624B\u52A8\u6258\u7BA1\u68C0\u67E5\u70B9\u672A\u4E0E\u540C\u4E00\u7B14\u6210\u4EA4\u5BF9\u9F50");
    }
    if (managed.followBasis) {
      const prior = managed.checkpoint;
      const realizedReductions = (value) => (value.additionReductions ?? []).filter((fill) => fill.fraction > 0);
      if (checkpoint.initialNotional !== prior.initialNotional || JSON.stringify(checkpoint.additionFills ?? (checkpoint.additionFill ? [checkpoint.additionFill] : [])) !== JSON.stringify(prior.additionFills ?? (prior.additionFill ? [prior.additionFill] : [])) || JSON.stringify(checkpoint.mirrorFill) !== JSON.stringify(prior.mirrorFill) || JSON.stringify(realizedReductions(checkpoint)) !== JSON.stringify(realizedReductions(prior))) {
        throw Error("\u5B9E\u76D8\u7B56\u7565\u8FDB\u5EA6\u4E0E\u5DF2\u786E\u8BA4\u7684\u6210\u4EA4\u4E0D\u4E00\u81F4");
      }
    }
    if (decision) {
      const action = decision.action;
      if (!action || action.id !== "managed-" + revision || !["add", "mirror", "support-reduction", "close"].includes(decision.kind) || decision.kind !== action.action || !Number.isSafeInteger(action.at) || action.at < earliest || action.at > now + 1e3 || decision.through < action.at || !Number.isSafeInteger(decision.through) || decision.through > now + MANAGED_MINUTE || decision.through % MANAGED_MINUTE !== 0) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u52A8\u4F5C\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if (action.action === "add" && (decision.kind !== "add" || !(action.notional > 0 && Number.isFinite(action.notional)) || action.at !== decision.evidence?.at || action.notional !== decision.evidence.notional || action.impulseFreshUntil !== void 0 && (action.at % 3e5 !== 0 || action.impulseFreshUntil !== action.at + 3e5))) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u52A0\u4ED3\u91D1\u989D\u6216\u65F6\u70B9\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if ((action.action === "mirror" || action.action === "support-reduction") && (decision.kind !== "mirror" && decision.kind !== "support-reduction" || !(action.fraction > 0 && action.fraction < 1) || action.fraction !== decision.evidence?.fraction || action.at !== decision.evidence.at)) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u51CF\u4ED3\u6BD4\u4F8B\u6216\u65F6\u70B9\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if (checkpoint.endTime > action.at) throw Error("\u624B\u52A8\u6258\u7BA1\u52A8\u4F5C\u65E9\u4E8E\u5DF2\u786E\u8BA4\u8FDB\u5EA6");
      managed.pending = decision;
      row.campaign.actions.push(action);
    }
    managed.checkpoint = managed.planEpoch == null ? checkpoint : {
      ...checkpoint,
      instantMonitorSwitches: managed.checkpoint.instantMonitorSwitches,
      followBasis: managed.followBasis
    };
    managed.revision++;
    lastContactAt = Date.now();
    write(row);
    return managed;
  }
  function skipManagedAction(row, market, action, current) {
    if (row.managed?.pending?.action.id !== action.id) return;
    row.orders[action.id] = {
      id: usdtOrderId(owner, row.campaign.id, action.id),
      side: action.action === "add" ? "BUY" : "SELL",
      quantity: "0",
      terminal: true,
      fills: []
    };
    settleManagedUsdtDecision(row, action.id, market, current);
  }
  function reconcileExit(row, actual, market) {
    const next = structuredClone(row);
    const pendingBuy = Object.values(next.orders).some((order) => order.side === "BUY" && !order.terminal);
    if (pendingBuy) {
      const known = new Set(Object.values(next.orders).flatMap((order) => (order.fills ?? []).map((fill) => fill.id)));
      if (actual.fills.some((fill) => fill.side === "BUY" && !known.has(fill.id))) {
        throw Error("\u5E01\u5B89\u6709\u5C1A\u672A\u5F52\u5C5E\u7684\u4E70\u5165\u6210\u4EA4\uFF0C\u7B49\u5F85\u6838\u5BF9\u5B9E\u76D8\u4F59\u4ED3");
      }
    }
    const fills = mergeUsdtExitFills(next, actual, market, true);
    if (!fills.length && !actual.closedAt) return false;
    const held = syncBalance(next, market);
    if (held.held !== quantityUnits(actual.quantity, market.step)) throw Error("\u5E01\u5B89\u5B9E\u9645\u6210\u4EA4\u4E0E\u5F53\u524D\u4F59\u4ED3\u6682\u672A\u5BF9\u9F50");
    const managed = next.managed;
    if (managed) {
      if (managed.pending) next.skipped.push(managed.pending.action.id);
      managed.pending = void 0;
      managed.revision++;
      if (fills.length) {
        const at = fills.at(-1).at;
        const quantity2 = Number(formatQuantity(held.held, market.step));
        const prior = managed.checkpoint;
        if (prior && !actual.closedAt) {
          managed.checkpoint = {
            ...prior,
            remainingQuantity: quantity2,
            remainingCost: held.entry * quantity2,
            averageEntryPrice: held.entry,
            realizedPnl: held.realized,
            pendingExit: void 0,
            endTime: Math.max(prior.endTime ?? 0, Math.ceil(at / MANAGED_MINUTE) * MANAGED_MINUTE)
          };
        } else if (!prior && !actual.closedAt) {
          managed.exchangeReduction = { at, quantity: quantity2, entryPrice: held.entry, realized: held.realized };
        }
      }
    }
    const pausedAfterReduction = !!managed?.followBasis && !!fills.length && !actual.closedAt;
    next.status.state = pendingBuy || pausedAfterReduction ? "blocked" : actual.closedAt ? "closed" : "tracking";
    next.status.issue = pendingBuy ? unsettledBuyIssue : pausedAfterReduction ? externalReductionIssue : void 0;
    write(next);
    return true;
  }
  function openAnchor(row, market) {
    const open = row.orders.open;
    const first = [...open?.fills ?? []].sort((a, b) => a.at - b.at || a.id.length - b.id.length || a.id.localeCompare(b.id))[0];
    return row.managed?.anchor ?? (open?.exchangeId && first ? {
      symbol: market.symbol,
      positionSide: mode === "hedge" ? "LONG" : "BOTH",
      openedAt: first.at,
      openingTradeId: first.id,
      openingOrderId: open.exchangeId
    } : void 0);
  }
  async function readOriginalPosition(row, market) {
    const anchor = openAnchor(row, market);
    if (!anchor || !readManaged) throw Error("\u7F3A\u5C11\u53EF\u6838\u5BF9\u7684\u5E01\u5B89\u9996\u4ED3\u6210\u4EA4\uFF0C\u6682\u7F13\u5B9E\u76D8\u64CD\u4F5C");
    const actual = await readManaged(anchor);
    if (!matchesManualAnchor(anchor, actual)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u6362\u6210\u53E6\u4E00\u7B14\u9996\u4ED3\uFF0C\u6682\u7F13\u5B9E\u76D8\u64CD\u4F5C");
    return actual;
  }
  async function step(row, now) {
    if (row.status.state === "closed" || row.status.state === "ignored") return;
    const { campaign } = row;
    const opened = row.orders.open;
    const outstanding = Object.entries(row.orders).filter(([, order2]) => !order2.terminal);
    const existing = outstanding.find(([, order2]) => order2.side === "SELL") ?? outstanding[0];
    const closing = row.managed ? row.managed.pending?.action.action === "close" ? row.managed.pending.action : void 0 : campaign.actions.find((action2) => action2.action === "close");
    if (!opened && !existing && (closing || !accepting || campaign.actions[0].at < entryAfter || !validUsdtLiveEntry(campaign) || campaign.liveEntry.capturedAt < entryAfter || now > campaign.actions[0].at + entryAgeMs)) {
      row.status.state = "ignored";
      row.status.issue = "\u5F00\u4ED3\u4FE1\u53F7\u5DF2\u8FC7\u65F6\u6216\u5DF2\u5E73\u4ED3\uFF0C\u672A\u8FFD\u5355";
      return write(row);
    }
    const market = !campaign.source.market && (!campaign.source.exchange || campaign.source.exchange === "binance") ? await readMarket(campaign.source.symbol) : void 0;
    if (!market) {
      if (opened) throw Error("\u5B9E\u76D8\u6301\u4ED3\u7684\u539F\u5408\u7EA6\u89C4\u683C\u6682\u4E0D\u53EF\u7528");
      row.status.state = "ignored";
      row.status.issue = "\u5F53\u524D\u6807\u7684\u7F3A\u5C11\u540C\u4E00\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6";
      return write(row);
    }
    let current = syncBalance(row, market);
    let unsettledBuyId;
    if (existing) {
      const [key2, order2] = existing;
      const canCheckExit = closing && order2.side === "BUY" && order2.limitPrice && current.held > 0;
      const report2 = await exchange.order(market, mode, order2, false).catch((error) => {
        if (!canCheckExit) throw error;
        return void 0;
      });
      if (report2) applyReport(row, key2, market, report2);
      if (report2?.terminal) return;
      if (!canCheckExit) {
        if (!report2) throw Error(order2.side === "BUY" ? unsettledBuyIssue : "\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u672A\u9F50\uFF0C\u6B63\u5728\u6309\u539F\u7F16\u53F7\u6838\u5BF9");
        return;
      }
      unsettledBuyId = order2.id;
      current = syncBalance(row, market);
    }
    if (row.managed) {
      if (!readManaged) throw Error("\u5F53\u524D\u6267\u884C\u5668\u65E0\u6CD5\u6838\u5BF9\u624B\u52A8\u6258\u7BA1\u4ED3\u4F4D");
      const pending = row.managed.pending;
      if (!pending && (managedChecked.get(campaign.id) ?? 0) + 12e3 > now) return;
      const actual = await readManaged(row.managed.anchor);
      if (row !== rows.get(campaign.id)) return;
      managedChecked.set(campaign.id, now);
      if (readPositions && reconcileExit(row, actual, market)) return;
      if (verifyManagedUsdtFills(row, actual, market)) {
        syncBalance(row, market);
        row.status.state = "closed";
        row.status.issue = void 0;
        row.managed.pending = void 0;
        return write(row);
      }
      current = syncBalance(row, market);
      if (!pending) {
        if (row.status.issue === externalReductionIssue) return;
        if (row.status.state !== "tracking" && !closing) {
          row.status.state = "tracking";
          row.status.issue = void 0;
          write(row);
        }
        return;
      }
    }
    if (!row.managed && readPositions && readManaged && opened?.exchangeId && opened.fills?.length && current.held) {
      const positionSide = mode === "hedge" ? "LONG" : "BOTH";
      const snapshot = await readPositions();
      const position = snapshot.positions.find((item) => item.symbol === market.symbol && item.positionSide === positionSide && item.direction === "long");
      if (!position || quantityUnits(position.quantity, market.step) !== current.held || Math.abs(Number(position.entryPrice) - current.entry) > Math.max(1e-8, current.entry * 1e-5)) {
        const actual = await readOriginalPosition(row, market);
        if (reconcileExit(row, actual, market)) return;
      }
    }
    if (opened && !current.held) {
      row.status.state = current.initial ? "closed" : "ignored";
      if (!current.initial) row.status.issue ||= "\u9996\u4ED3\u672A\u6210\u4EA4";
      return write(row);
    }
    let action = unsettledBuyId ? closing : row.managed?.followBasis ? row.managed.pending?.action : campaign.actions.find((event) => !row.orders[event.id] && !row.skipped.includes(event.id));
    if (closing && current.held && action?.action !== "close") {
      row.skipped.push(...campaign.actions.filter((event) => event.action !== "close" && !row.orders[event.id] && !row.skipped.includes(event.id)).map((event) => event.id));
      action = closing;
    }
    if (closing && current.held && !action && !row.skipped.includes(closing.id)) action = closing;
    if (!action || row.skipped.includes(action.id)) return;
    const side = action.action === "open" || action.action === "add" ? "BUY" : "SELL";
    const signalNow = row.managed ? managedClock() : now;
    if (side === "BUY" && !mayIncrease(row, action, now, signalNow)) {
      row.skipped.push(action.id);
      row.status.issue = "\u8BE5\u7B14\u4E70\u5165\u5DF2\u8FC7\u65F6\uFF0C\u672A\u8FFD\u5355";
      skipManagedAction(row, market, action, current);
      return write(row);
    }
    const pendingOther = [...rows.values()].some((other) => other !== row && other.campaign.source.symbol === market.symbol && (balance(other).held > 0 || Object.values(other.orders).some((order2) => !order2.terminal)));
    if (pendingOther) throw Error("\u540C\u4E00\u5408\u7EA6\u5DF2\u6709\u53E6\u4E00\u7B14\u5B9E\u76D8\u6218\u5F79");
    const book = action.action === "close" ? void 0 : await exchange.book(market.symbol, side);
    const price = Number(book);
    const notional = action.action === "open" ? campaign.notional : action.action === "add" ? action.notional : 0;
    const stepSize = Number(market.step);
    const desired = action.action === "close" ? current.held : "fraction" in action ? Math.floor((action.action === "mirror" ? row.managed?.followBasis ? Math.round(row.managed.followBasis.quantity / stepSize) : current.initial : current.held) * action.fraction + 1e-9) : Math.floor(notional / price / stepSize + 1e-9);
    const decision = row.managed?.pending;
    let limit = side === "BUY" ? market.max : current.held;
    if (decision?.kind === "add" && decision.evidence.sizing) {
      const { support } = decision.evidence.sizing;
      if (price <= support) limit = 0;
      else if (decision.evidence.positionVersion === HOLDING_LEDGER_ADDITION_VERSION) {
        const held = current.held * stepSize;
        const budget = calculateHoldingLedgerAddition({
          held,
          cost: held * current.entry,
          realized: current.realized - (row.managed?.followBasis?.realizedBefore ?? 0)
        }, price, support);
        limit = budget.error ? 0 : Math.min(limit, Math.floor(budget.addCoins / stepSize + 1e-9));
      } else {
        const plannedRisk = decision.evidence.quantity * (decision.evidence.price - support);
        limit = Math.min(limit, Math.max(0, Math.floor(plannedRisk / (price - support) / stepSize + 1e-9)));
      }
    }
    const units2 = Math.min(desired, market.max, limit);
    const quantity2 = formatQuantity(units2, market.step);
    if (units2 < market.min || side === "BUY" && Number(quantity2) * price < market.minNotional || side === "SELL" && action.action !== "close" && Number(quantity2) * price < market.minNotional) {
      row.skipped.push(action.id);
      row.status.state = opened ? "tracking" : "ignored";
      if (action.action === "close") row.status.state = "blocked";
      row.status.issue = "\u6309\u65B9\u6848\u91D1\u989D\u6216\u51CF\u4ED3\u6BD4\u4F8B\u6362\u7B97\u540E\u4F4E\u4E8E\u5E01\u5B89\u6700\u5C0F\u59D4\u6258";
      if (action.action !== "close") skipManagedAction(row, market, action, current);
      return write(row);
    }
    const opening = opened?.fills?.[0];
    const liveId = opened?.exchangeId && opening ? usdtLiveCampaignId({
      symbol: market.symbol,
      positionSide: mode === "hedge" ? "LONG" : "BOTH",
      direction: "long",
      fills: [{ id: opening.id, orderId: opened.exchangeId }]
    }) : void 0;
    const liveLeverage = readPositions && liveId ? store.positionLeverage(liveId)?.leverage : void 0;
    const maySendBuy = () => {
      const checkedAt = Math.max(now, Date.now());
      return mayIncrease(row, action, checkedAt, row.managed ? managedClock() : checkedAt) && !(row.managed ? row.managed.pending?.action.action === "close" : row.campaign.actions.some((event) => event.action === "close"));
    };
    const confirmOpening = () => {
      if (!maySendBuy()) throw Error("\u5F00\u4ED3\u6761\u4EF6\u5DF2\u5931\u6548\uFF0C\u6682\u7F13\u4FEE\u6539\u5B9E\u76D8\u5408\u7EA6\u8BBE\u7F6E");
    };
    if (action.action === "open") await protection?.beforeOpening(market.symbol);
    await exchange.check(
      market,
      mode,
      current.held,
      current.entry,
      action.action === "open",
      side === "BUY" ? liveLeverage ?? campaign.leverage : 0,
      row.managed ? "existing-position" : void 0,
      liveId ? protectionIds?.(market.symbol, liveId) : void 0,
      unsettledBuyId,
      ...action.action === "open" ? [confirmOpening] : []
    );
    if (action.action !== "open") {
      const actual = await readOriginalPosition(row, market);
      if (row !== rows.get(campaign.id) || reconcileExit(row, actual, market)) return;
      if (quantityUnits(actual.quantity, market.step) !== current.held) throw Error("\u5E01\u5B89\u9996\u4ED3\u5DF2\u6838\u5B9E\uFF0C\u5B9E\u9645\u4F59\u4ED3\u4ECD\u5F85\u5BF9\u8D26");
    }
    if (side === "BUY" && !maySendBuy()) return;
    const attempts = Object.entries(row.orders).filter(([key2]) => key2 === closing?.id || key2.startsWith(closing?.id + ":"));
    const failedCloses = attempts.filter(([, order2]) => !order2.fills?.length).length;
    if (action.action === "close" && (row.managed ? failedCloses >= 3 : attempts.length && !attempts.at(-1)?.[1].fills?.length)) {
      row.skipped.push(action.id);
      row.status.state = "blocked";
      row.status.issue = "\u5E73\u4ED3\u672A\u6210\u4EA4\uFF0C\u5E01\u5B89\u4ECD\u6709\u4F59\u4ED3\uFF0C\u7B49\u5F85\u4EBA\u5DE5\u6838\u5BF9";
      return write(row);
    }
    const priorCloses = attempts.length;
    const key = action.action === "close" && priorCloses ? action.id + ":" + priorCloses : action.id;
    const order = {
      id: usdtOrderId(owner, campaign.id, key),
      side,
      quantity: quantity2,
      terminal: false,
      ...side === "BUY" ? { limitPrice: book } : {}
    };
    row.orders[key] = order;
    row.status.state = "waiting";
    row.status.issue = unsettledBuyId ? unsettledBuyIssue : void 0;
    write(row);
    const report = await exchange.order(market, mode, order, true);
    if (!report) throw Error("\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u672A\u9F50\uFF0C\u6B63\u5728\u6309\u539F\u7F16\u53F7\u6838\u5BF9");
    applyReport(row, key, market, report);
  }
  function applyReport(row, key, market, report) {
    const previous = row.orders[key];
    const previousManaged = row.managed && structuredClone(row.managed);
    if (previous.exchangeId && report.exchangeId !== previous.exchangeId) throw Error("\u5E01\u5B89\u8BA2\u5355\u7F16\u53F7\u4E0E\u672C\u673A\u8BB0\u5F55\u4E0D\u540C");
    if (report.fills.reduce((sum, fill) => sum + fill.quantity, 0) < (previous.fills ?? []).reduce((sum, fill) => sum + fill.quantity, 0))
      throw Error("\u5E01\u5B89\u8FD4\u56DE\u4E86\u8F83\u65E7\u7684\u7D2F\u8BA1\u6210\u4EA4\u8BB0\u5F55");
    const next = { ...previous, terminal: report.terminal, exchangeId: report.exchangeId, fills: report.fills };
    row.orders[key] = next;
    try {
      const held = syncBalance(row, market);
      const pendingBuy = Object.values(row.orders).some((order) => order.side === "BUY" && !order.terminal);
      row.status.state = report.terminal ? pendingBuy ? "blocked" : held.held ? "tracking" : held.initial ? "closed" : "ignored" : "waiting";
      row.status.orderId = report.exchangeId;
      row.status.issue = pendingBuy && report.terminal ? unsettledBuyIssue : report.issue ?? (report.terminal && report.fills.reduce((sum, fill) => sum + fill.quantity, 0) < quantityUnits(previous.quantity, market.step) ? "\u8BA2\u5355\u90E8\u5206\u6210\u4EA4\uFF0C\u4F59\u4ED3\u6309\u5E01\u5B89\u56DE\u62A5\u8DDF\u8E2A" : void 0);
      settleManagedUsdtDecision(row, key, market, held);
      if (row.managed?.pending?.kind === "close" && report.terminal && !report.fills.length) {
        cooldown.set(row.campaign.id, Date.now() + 5e3);
      }
      write(row);
    } catch (error) {
      row.orders[key] = previous;
      row.managed = previousManaged;
      throw error;
    }
  }
  return {
    ingest,
    adopt,
    switchManaged,
    switchFollowMonitor,
    updateManaged,
    async runPositionControl(run) {
      if (manual) throw Error("\u53E6\u4E00\u7B14\u5B9E\u76D8\u64CD\u4F5C\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      manual = true;
      try {
        if (active) await new Promise((resolve2) => {
          finishTick = resolve2;
        });
        return await run();
      } finally {
        manual = false;
      }
    },
    managed: (includeFollow = false) => [...rows.values()].filter((row) => row.managed && row.status.state !== "closed" && (includeFollow || !row.managed.followBasis)).map((row) => ({ position: row.managed, status: row.status })),
    managedArchive: (id) => {
      const managed = rows.get(id)?.managed;
      return managed && {
        version: managed.version,
        monitor: managed.monitor,
        armedAt: managed.armedAt,
        ...managed.checkpoint?.instantMonitorSwitches ? { switches: managed.checkpoint.instantMonitorSwitches } : {},
        ...managed.checkpoint?.status === "closed" ? { exitReason: managed.checkpoint.reason } : {}
      };
    },
    pauseNewOrders: () => {
      store.setPaused(true);
      accepting = false;
    },
    resumeNewOrders: (now = Date.now()) => {
      store.setPaused(false);
      entryAfter = now;
      accepting = true;
    },
    get entryAfter() {
      return entryAfter;
    },
    get paused() {
      return !accepting;
    },
    statuses: () => [...rows.values()].map((row) => row.campaign.liveEntry && (!row.managed || row.managed.followBasis) ? {
      ...row.status,
      followMonitorTemplateId: row.managed?.monitor.templateId ?? row.campaign.liveEntry.templateId,
      canSwitchFollowMonitor: !row.managed?.pending && (row.status.state === "tracking" || row.status.issue === externalReductionIssue)
    } : row.status),
    async tick(now = Date.now()) {
      if (active || manual) return;
      active = true;
      try {
        const prioritized = [...rows.values()].sort((a, b) => Number(b.campaign.actions.some((event) => event.action === "close")) - Number(a.campaign.actions.some((event) => event.action === "close")));
        for (const row of prioritized) {
          if (manual) break;
          if (row !== rows.get(row.campaign.id)) continue;
          if ((cooldown.get(row.campaign.id) ?? 0) > now) continue;
          if (row.status.state === "closed") continue;
          try {
            await step(row, now);
          } catch (error) {
            if (row !== rows.get(row.campaign.id)) continue;
            row.status.state = "blocked";
            row.status.issue = error instanceof Error ? error.message : "\u5E01\u5B89\u540C\u6B65\u6682\u4E0D\u53EF\u7528";
            write(row);
            cooldown.set(row.campaign.id, Date.now() + 3e3);
          }
          if (rows.get(row.campaign.id)?.status.state === "closed") {
            await protection?.cleanup(row.campaign.source.symbol).catch(() => void 0);
          }
        }
      } finally {
        active = false;
        finishTick?.();
        finishTick = void 0;
      }
    }
  };
}

// scripts/usdt-order-desk.ts
var regularOrderPath = "/fapi/v1/order";
var conditionalOrderPath = "/fapi/v1/algoOrder";
var symbolPattern2 = /^[A-Z0-9]{2,24}USDT$/;
var decimal3 = /^\d{1,20}(?:\.\d{1,18})?$/;
var positive = (value) => typeof value === "string" && decimal3.test(value) && Number(value) > 0;
var validId2 = (value) => typeof value === "string" && /^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/.test(value);
function validDeskOrder(order) {
  if (order?.type === "limit") return positive(order.price) && ["GTC", "IOC", "FOK", "GTX"].includes(order.timeInForce);
  if (order?.type === "conditional") return positive(order.triggerPrice);
  return order?.type === "market" && (order.slippage === void 0 || Number.isFinite(order.slippage) && order.slippage >= 0.01 && order.slippage <= 10);
}
async function deskOrderParameters(order, market, side, clientId, mark, book) {
  const tick = market.priceTick;
  const checkedPrice = (price) => {
    if (!tick || !quantityUnits(price, tick)) throw Error("\u4EF7\u683C\u4E0D\u7B26\u5408\u5E01\u5B89\u6700\u5C0F\u4EF7\u683C\u5355\u4F4D");
    return price;
  };
  const regular = { newClientOrderId: clientId, newOrderRespType: "RESULT" };
  if (order.type === "limit") return {
    path: regularOrderPath,
    params: { ...regular, type: "LIMIT", price: checkedPrice(order.price), timeInForce: order.timeInForce }
  };
  if (order.type === "conditional") {
    const triggerPrice = checkedPrice(order.triggerPrice), trigger = Number(triggerPrice);
    if (!(mark > 0) || mark === trigger) throw Error("\u89E6\u53D1\u4EF7\u987B\u4E0E\u5E01\u5B89\u5F53\u524D\u6807\u8BB0\u4EF7\u4E0D\u540C");
    const stop = side === "BUY" === trigger > mark;
    return { path: conditionalOrderPath, params: {
      algoType: "CONDITIONAL",
      type: stop ? "STOP_MARKET" : "TAKE_PROFIT_MARKET",
      workingType: "MARK_PRICE",
      triggerPrice,
      clientAlgoId: clientId
    } };
  }
  if (order.slippage !== void 0) {
    if (!tick) throw Error("\u65E0\u6CD5\u6838\u5BF9\u5E01\u5B89\u6700\u5C0F\u4EF7\u683C\u5355\u4F4D");
    const multiplier = 1 + (side === "BUY" ? 1 : -1) * order.slippage / 100;
    const boundary = Number(await book()) * multiplier / Number(tick);
    const ticks = side === "BUY" ? Math.floor(boundary) : Math.ceil(boundary);
    return { path: regularOrderPath, params: {
      ...regular,
      type: "LIMIT",
      price: checkedPrice(formatQuantity(ticks, tick)),
      timeInForce: "IOC"
    } };
  }
  return { path: regularOrderPath, params: { ...regular, type: "MARKET" } };
}
function createUsdtOrderDesk(request, exchange, store, owner, mode, checkOpening, clock = Date.now, markPrice = readUsdtMark) {
  const contracts = /* @__PURE__ */ new Map();
  const marketFor = async (symbol) => {
    if (typeof symbol !== "string" || !symbolPattern2.test(symbol)) throw Error("\u8BF7\u9009\u62E9\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6");
    const cached = contracts.get(symbol);
    if (cached && cached.expires > clock()) return cached.market;
    const market = await exchange.market(symbol);
    if (!market?.priceTick) throw Error("\u8BE5\u5408\u7EA6\u7684\u4EA4\u6613\u89C4\u683C\u6682\u4E0D\u53EF\u7528");
    contracts.set(symbol, { market, expires: clock() + 6e4 });
    return market;
  };
  const details = async (symbol, market) => {
    const [account, config, mark, ask, bid] = await Promise.all([
      request("GET", "/fapi/v3/account"),
      request("GET", "/fapi/v1/symbolConfig", { symbol }),
      markPrice(symbol),
      exchange.book(symbol, "BUY"),
      exchange.book(symbol, "SELL")
    ]);
    const available = account.assets?.find((row) => row.asset === "USDT")?.availableBalance;
    const terms = config?.find((row) => row.symbol === symbol);
    const leverage = Number(terms?.leverage), maxNotional = terms?.maxNotionalValue;
    if (!decimal3.test(String(available)) || !positive(String(maxNotional)) || !Number.isInteger(leverage) || leverage < 1 || !positive(mark)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u914D\u7F6E\u6216\u53EF\u7528\u4F59\u989D\u6682\u4E0D\u53EF\u7528");
    return {
      symbol,
      ask,
      bid,
      mark,
      available: String(available),
      leverage,
      priceTick: market.priceTick,
      orderStep: market.step,
      marketStep: market.marketStep && Number(market.marketStep) > 0 ? market.marketStep : market.step,
      maxQuantity: formatQuantity(market.max, market.step),
      maxNotional: String(maxNotional)
    };
  };
  const info = async (symbol) => {
    const market = await marketFor(symbol);
    return details(market.symbol, market);
  };
  async function execute(value) {
    if (!value || !validId2(value.id) || !symbolPattern2.test(value.symbol) || !["long", "short"].includes(value.direction) || !positive(value.quantity) || !validDeskOrder(value.order)) throw Error("\u5F00\u4ED3\u59D4\u6258\u53C2\u6570\u65E0\u6548");
    const { id, symbol, direction, quantity: quantity2, order } = value;
    const fingerprint = JSON.stringify([symbol, direction, quantity2, order]);
    let row = store.getDeskOrder(id);
    if (row && row.fingerprint !== fingerprint) throw Error("\u540C\u4E00\u5B9E\u76D8\u59D4\u6258\u7F16\u53F7\u7684\u53C2\u6570\u4E0D\u4E00\u81F4");
    if (row?.result) return row.result;
    let response;
    if (!row) {
      if (store.pendingDeskOrders().some((item) => item.symbol === symbol))
        throw Error("\u540C\u4E00\u5408\u7EA6\u4E0A\u4E00\u7B14\u5F00\u4ED3\u4ECD\u5728\u6838\u5BF9\uFF0C\u8BF7\u5148\u67E5\u539F\u7F16\u53F7");
      await checkOpening(symbol);
      const market = await marketFor(symbol);
      const [quote, currentMode, rawPositions] = await Promise.all([
        details(symbol, market),
        request("GET", "/fapi/v1/positionSide/dual"),
        request("GET", "/fapi/v3/positionRisk", { symbol })
      ]);
      if (currentMode.dualSidePosition !== (mode === "hedge") || !Array.isArray(rawPositions)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6A21\u5F0F\u6216\u4ED3\u4F4D\u6570\u636E\u5DF2\u53D8\u5316");
      const side = direction === "long" ? "BUY" : "SELL", positionSide = mode === "one-way" ? "BOTH" : direction === "long" ? "LONG" : "SHORT";
      if (mode === "one-way" && rawPositions.some((item) => Number(item.positionAmt) && Number(item.positionAmt) > 0 !== (side === "BUY")))
        throw Error("\u5355\u5411\u6A21\u5F0F\u4E2D\u6709\u53CD\u5411\u4ED3\u4F4D\uFF0C\u8BF7\u5148\u5728\u5E73\u4ED3\u680F\u5904\u7406");
      const units2 = quantityUnits(quantity2, market.step);
      if (units2 < market.min || units2 > market.max) throw Error("\u6570\u91CF\u8D85\u51FA\u5E01\u5B89\u5355\u7B14\u59D4\u6258\u89C4\u683C");
      if (order.type !== "limit") quantityUnits(quantity2, quote.marketStep);
      const book = side === "BUY" ? quote.ask : quote.bid;
      const basis = Number(order.type === "limit" ? order.price : order.type === "conditional" ? order.triggerPrice : book);
      const notional = Number(quantity2) * basis;
      if (notional < market.minNotional) throw Error("\u4F4E\u4E8E\u5E01\u5B89\u6700\u4F4E\u59D4\u6258\u91D1\u989D");
      if (notional > Math.min(Number(quote.available) * quote.leverage, Number(quote.maxNotional)))
        throw Error("\u5E01\u5B89\u53EF\u7528\u4FDD\u8BC1\u91D1\u6216\u5408\u7EA6\u989D\u5EA6\u4E0D\u8DB3");
      const wire2 = await deskOrderParameters(order, market, side, usdtOrderId(owner, "desk-open", id), Number(quote.mark), async () => book);
      row = { fingerprint, symbol, side, positionSide, quantity: quantity2, wire: wire2, sentAt: clock() };
      store.saveDeskOrder(id, row, true);
      const params = Object.fromEntries(Object.entries(wire2.params).filter(([, item]) => typeof item === "string"));
      try {
        response = await request("POST", wire2.path, { ...params, symbol, side, positionSide, quantity: quantity2 });
      } catch (error) {
        if (error instanceof UsdtApiError && [-1013, -1021, -1100, -1102, -1111, -2019, -2021, -4164].includes(error.code ?? 0)) {
          row.result = { issue: error.message };
          store.saveDeskOrder(id, row, false);
          return row.result;
        }
      }
    }
    const { wire } = row;
    const conditional = wire.path === conditionalOrderPath;
    if (!response) {
      const query = conditional ? { clientAlgoId: wire.params.clientAlgoId } : { symbol, origClientOrderId: wire.params.newClientOrderId };
      try {
        response = await request("GET", wire.path, query);
      } catch (error) {
        if (error instanceof UsdtApiError && [-2011, -2013].includes(error.code ?? 0) && clock() - row.sentAt > 6e4) {
          row.result = { issue: "\u5E01\u5B89\u672A\u67E5\u5230\u539F\u59D4\u6258\uFF0C\u8BF7\u5728\u5E01\u5B89\u6838\u5BF9\u540E\u518D\u64CD\u4F5C" };
          store.saveDeskOrder(id, row, false);
          return row.result;
        }
        return { pending: true };
      }
    }
    const reportedId = conditional ? response?.clientAlgoId : response?.clientOrderId;
    if (reportedId !== (wire.params.clientAlgoId ?? wire.params.newClientOrderId) || response?.symbol !== symbol || response?.side !== row.side || response?.positionSide !== row.positionSide) return { pending: true };
    const status = conditional ? response.algoStatus : response.status;
    const filled = Number(response.executedQty) > 0 && Number(response.executedQty) <= Number(quantity2) ? String(response.executedQty) : void 0;
    if (!["NEW", "PARTIALLY_FILLED", "FILLED", "TRIGGERING", "TRIGGERED", "FINISHED", "REJECTED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED"].includes(status))
      return { pending: true };
    row.result = { filledQuantity: filled, issue: ["REJECTED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED"].includes(status) ? filled ? "\u90E8\u5206\u6210\u4EA4\uFF0C\u4F59\u91CF\u5DF2\u7ED3\u675F" : "\u59D4\u6258\u672A\u6210\u4EA4\uFF0C\u5DF2\u7ED3\u675F" : void 0 };
    store.saveDeskOrder(id, row, false);
    return row.result;
  }
  return { info, execute };
}

// scripts/usdt-position-controls.ts
var riskPath = "/fapi/v3/positionRisk";
var openAlgoPath = "/fapi/v1/openAlgoOrders";
var algoPath = "/fapi/v1/algoOrder";
var orderPath = "/fapi/v1/order";
var configPath = "/fapi/v1/symbolConfig";
var leveragePath = "/fapi/v1/leverage";
var marginPath = "/fapi/v1/positionMargin";
var numberId = /^\d{1,25}$/;
var marketSymbol = /^[A-Z0-9]{2,24}USDT$/;
var positiveDecimal = /^\d{1,20}(?:\.\d{1,18})?$/;
var closingSide = (position) => position.direction === "long" ? "SELL" : "BUY";
var matchingLeg = (row, target) => row.symbol === target.symbol && row.positionSide === target.positionSide && row.direction === target.direction;
var percent = (value) => Number.isFinite(value) && value > 0 && value <= 1;
var isDone = (step) => step.state === "done";
var isTrackedProtection = (step) => step.method === "POST" && step.path === algoPath && !step.retired && (step.state === "sent" || step.state === "done");
function parseCommand(value, now) {
  const { id, target, action } = value ?? {};
  if (typeof id !== "string" || !/^[a-f0-9-]{36}$/.test(id) || !target || !marketSymbol.test(target.symbol) || !["BOTH", "LONG", "SHORT"].includes(target.positionSide) || !["long", "short"].includes(target.direction) || !Number.isSafeInteger(target.openedAt) || target.openedAt <= 0 || target.openedAt > now || typeof target.revision !== "string" || target.revision.length > 300 || !isUsdtLiveCampaignId(target.campaignId) || !action) throw Error("\u5E01\u5B89\u5B9E\u76D8\u64CD\u4F5C\u53C2\u6570\u65E0\u6548");
  switch (action.kind) {
    case "close":
      if (percent(action.fraction) && (action.order === void 0 || validDeskOrder(action.order))) return value;
      break;
    case "protect":
      if (percent(action.fraction) && (action.tp !== null || action.sl !== null) && [action.tp, action.sl].every((price) => price === null || Number.isFinite(price) && price > 0)) return value;
      break;
    case "cancel":
      if (typeof action.orderId === "string" && numberId.test(action.orderId)) return value;
      break;
    case "leverage":
      if (Number.isInteger(action.leverage) && action.leverage >= 1 && action.leverage <= 125) return value;
      break;
    case "margin":
      if (Number.isFinite(action.delta) && action.delta !== 0 && positiveDecimal.test(String(Math.abs(action.delta)))) return value;
      break;
  }
  throw Error("\u5E01\u5B89\u5B9E\u76D8\u64CD\u4F5C\u53C2\u6570\u65E0\u6548");
}
function quantityFor(raw, fraction, market) {
  const step = market.marketStep && Number(market.marketStep) > 0 ? market.marketStep : market.step;
  const lots = quantityUnits(raw, market.step);
  const factor = Number(step) / Number(market.step);
  const marketLots = Math.min(lots, Math.floor(lots * fraction + 1e-9));
  const quantity2 = formatQuantity(Math.floor(marketLots / factor + 1e-9), step);
  const checked = quantityUnits(quantity2, market.step);
  if (checked < market.min || checked > market.max || checked > lots) throw Error("\u6570\u91CF\u4E0D\u7B26\u5408\u5E01\u5B89\u5E02\u4EF7\u59D4\u6258\u4E0A\u4E0B\u9650\uFF0C\u8BF7\u8C03\u6574\u6BD4\u4F8B");
  if (fraction === 1 && checked !== lots) throw Error("\u5168\u90E8\u5E73\u4ED3\u7684\u6570\u91CF\u4E0E\u5E01\u5B89\u5E02\u4EF7\u6B65\u957F\u4E0D\u7B26\uFF0C\u8BF7\u6838\u5BF9\u4F59\u4ED3");
  return quantity2;
}
function protectionRows(raw, position) {
  if (!Array.isArray(raw)) throw Error("\u5E01\u5B89\u6B62\u76C8\u6B62\u635F\u59D4\u6258\u6682\u4E0D\u53EF\u8BFB");
  return raw.flatMap((row) => {
    const tp = row.orderType === "TAKE_PROFIT_MARKET" || row.orderType === "TAKE_PROFIT";
    const sl = row.orderType === "STOP_MARKET" || row.orderType === "STOP";
    if (!tp && !sl || row.symbol !== position.symbol || row.side !== closingSide(position) || row.positionSide !== position.positionSide || !(row.closePosition === true || row.reduceOnly === true || row.positionSide !== "BOTH") || !numberId.test(String(row.algoId)) || !positiveDecimal.test(String(row.triggerPrice)) || Number(row.triggerPrice) <= 0) return [];
    return [{
      id: String(row.algoId),
      clientId: typeof row.clientAlgoId === "string" ? row.clientAlgoId : void 0,
      kind: tp ? "tp" : "sl",
      triggerPrice: String(row.triggerPrice),
      quantity: row.closePosition === true ? void 0 : String(row.quantity),
      workingType: row.workingType === "MARK_PRICE" ? "MARK_PRICE" : "CONTRACT_PRICE"
    }];
  });
}
var definitelyRejected = (error) => error instanceof UsdtApiError && error.status < 500 && (error.status >= 400 || error.code !== void 0) && error.status !== 408 && error.status !== 429 && ![-1e3, -1001, -1006, -1007, -4116].includes(error.code ?? 0);
function createUsdtPositionControls(request, store, owner, readMarket, readCampaigns, invalidate, clock = Date.now, readBook) {
  const rawOrders = (symbol) => request("GET", openAlgoPath, { symbol });
  const risk = async (symbol) => decodePositions(await request("GET", riskPath, { symbol }));
  const activeCampaign = async (target) => (await readCampaigns(
    Math.max(1, target.openedAt - 1e3),
    [{ symbol: target.symbol, openedAt: target.openedAt }],
    target.symbol
  )).campaigns.find((row) => usdtLiveCampaignId(row) === target.campaignId);
  async function freshTarget(target) {
    const evidence = await activeCampaign(target);
    const current = (await risk(target.symbol)).find((row) => matchingLeg(row, target));
    if (!evidence || evidence.closedAt || evidence.openedAt !== target.openedAt || !current || usdtPositionDecimal(evidence.quantity) !== usdtPositionDecimal(current.quantity) || usdtMirrorRevision(current) !== target.revision)
      throw Error("\u8FD9\u7B14\u5B9E\u76D8\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u8BF7\u540C\u6B65\u540E\u91CD\u65B0\u786E\u8BA4");
    return current;
  }
  const readDetails = async (snapshot) => {
    const symbols = [...new Set(snapshot.positions.map((row) => row.symbol))];
    const details = new Map(await Promise.all(symbols.map(async (symbol) => {
      const [orders, settings] = await Promise.allSettled([rawOrders(symbol), request("GET", configPath, { symbol })]);
      return [symbol, { orders, settings }];
    })));
    return { ...snapshot, positions: snapshot.positions.map((position) => {
      const { orders, settings } = details.get(position.symbol);
      const config = settings.status === "fulfilled" && Array.isArray(settings.value) ? settings.value.find((row) => row.symbol === position.symbol) : void 0;
      const leverage = Number(config?.leverage);
      let protectionOrders;
      let protectionIssue;
      try {
        protectionOrders = protectionRows(orders.status === "fulfilled" ? orders.value : void 0, position).map(({ clientId, ...order }) => order);
      } catch {
        protectionIssue = "\u5E01\u5B89\u6B62\u76C8\u6B62\u635F\u6682\u672A\u540C\u6B65";
      }
      return {
        ...position,
        leverage: leverage > 0 ? leverage : position.leverage,
        marginMode: config?.marginType === "ISOLATED" ? "isolated" : config?.marginType === "CROSSED" || config?.marginType === "CROSS" ? "cross" : position.marginMode,
        protectionOrders,
        protectionIssue
      };
    }) };
  };
  const save = (row) => {
    store.savePositionControl(row.id, row, row.steps.some((step) => isTrackedProtection(step) || trackedLimit(step) || step.state === "sent"));
    const leverage = row.steps.find((step) => step.path === leveragePath && isDone(step));
    if (leverage?.sentAt !== void 0)
      store.savePositionLeverage(row.target.campaignId, { leverage: Number(leverage.params.leverage), at: leverage.sentAt });
  };
  const matchedOrder = (row, step) => row?.symbol === step.params.symbol && row?.side === step.params.side && row?.positionSide === step.params.positionSide;
  const protectionMatches = (row, step) => matchedOrder(row, step) && row.clientAlgoId === step.params.clientAlgoId && (row.orderType ?? row.type) === step.params.type && Number(row.triggerPrice) === Number(step.params.triggerPrice) && row.workingType === step.params.workingType && (step.params.closePosition === "true" ? row.closePosition === true : row.closePosition !== true && Number(row.quantity) === Number(step.params.quantity) && (step.params.reduceOnly !== "true" || row.reduceOnly === true));
  async function accept(step, response) {
    if (step.path === orderPath) {
      if (!matchedOrder(response, step) || response.clientOrderId !== step.params.newClientOrderId || !positiveDecimal.test(String(response.executedQty)) || Number(response.executedQty) > Number(step.params.quantity)) return;
      step.filledQuantity = String(response.executedQty);
      if (step.params.type === "LIMIT" && ["NEW", "PARTIALLY_FILLED"].includes(response.status) && ["GTC", "GTX"].includes(step.params.timeInForce)) step.state = "done";
      if (["FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"].includes(response.status)) {
        step.state = "done";
        if (Number(step.filledQuantity) !== Number(step.params.quantity))
          step.issue = "\u5E01\u5B89\u5E73\u4ED3\u672A\u5168\u90E8\u6210\u4EA4\uFF0C\u4F59\u4ED3\u4EE5\u5B9E\u9645\u540C\u6B65\u4E3A\u51C6";
      }
    } else if (step.method === "DELETE" && numberId.test(String(response?.algoId)) && String(response.algoId) === step.params.algoId) {
      step.state = "done";
    } else if (step.path === algoPath && protectionMatches(response, step)) {
      if (response.algoStatus === "NEW") step.state = "done";
      else if (["CANCELED", "EXPIRED", "REJECTED", "TRIGGERING", "TRIGGERED", "FINISHED"].includes(response.algoStatus)) {
        step.state = "failed";
        step.issue = "\u5E01\u5B89\u672A\u786E\u8BA4\u65B0\u4FDD\u62A4\u5355\u4ECD\u5728\u6302\u5355\u4E2D";
      }
    } else if (step.path === leveragePath && response?.symbol === step.params.symbol && Number(response.leverage) === Number(step.params.leverage)) {
      step.state = "done";
    } else if (step.path === marginPath && Number(response?.code) === 200 && Number(response.amount) === Number(step.params.amount) && Number(response.type) === Number(step.params.type)) {
      step.state = "done";
    }
  }
  async function recover(step) {
    try {
      if (step.path === orderPath) {
        await accept(step, await request("GET", orderPath, { symbol: step.params.symbol, origClientOrderId: step.params.newClientOrderId }));
      } else if (step.method === "DELETE") {
        const orders = await rawOrders(step.params.symbol);
        if (Array.isArray(orders) && !orders.some((row) => String(row.algoId) === step.params.algoId)) step.state = "done";
      } else if (step.path === algoPath) {
        await accept(step, await request("GET", algoPath, { clientAlgoId: step.params.clientAlgoId }));
      } else if (step.path === marginPath && step.sentAt !== void 0) {
        const rows = await request("GET", marginPath + "/history", {
          symbol: step.params.symbol,
          type: step.params.type,
          startTime: String(step.sentAt),
          endTime: String(clock()),
          limit: "100"
        });
        if (Array.isArray(rows) && rows.some((row) => row.symbol === step.params.symbol && row.positionSide === step.params.positionSide && Number(row.type) === Number(step.params.type) && Math.abs(Number(row.amount)) === Number(step.params.amount) && Number(row.time) >= step.sentAt && Number(row.time) <= step.sentAt + 3e4)) step.state = "done";
      } else {
        const rows = await request("GET", configPath, { symbol: step.params.symbol });
        if (Array.isArray(rows)) await accept(step, rows.find((row) => row.symbol === step.params.symbol));
      }
    } catch (error) {
      if (error instanceof UsdtApiError && (error.code === -2011 || error.code === -2013) && step.sentAt !== void 0 && clock() - step.sentAt > 6e4) {
        step.state = "failed";
        step.issue = "\u5E01\u5B89\u67E5\u8BE2\u4E0D\u5230\u539F\u59D4\u6258\uFF0C\u5DF2\u7ED3\u675F\u6838\u5BF9\uFF0C\u8BF7\u786E\u8BA4\u5F53\u524D\u4ED3\u4F4D\u540E\u91CD\u65B0\u64CD\u4F5C";
      }
    }
  }
  const trackedLimit = (step) => step.path === orderPath && step.params.type === "LIMIT" && ["GTC", "GTX"].includes(step.params.timeInForce) && isDone(step) && !step.retired;
  async function execute(value) {
    const { id, target, action } = parseCommand(value, clock());
    const fingerprint = JSON.stringify([target, action]);
    let row = store.getPositionControl(id);
    if (row && row.fingerprint !== fingerprint) throw Error("\u540C\u4E00\u5B9E\u76D8\u8BF7\u6C42\u7F16\u53F7\u7684\u53C2\u6570\u4E0D\u4E00\u81F4");
    if (!row) {
      const previous = store.pendingPositionControls().filter((item) => item.target.symbol === target.symbol && item.target.positionSide === target.positionSide);
      for (const item of previous) {
        for (const step of item.steps.filter((step2) => step2.state === "sent")) await recover(step);
        save(item);
      }
      if (previous.some((item) => item.steps.some((step) => step.state === "sent"))) throw Error("\u4E0A\u4E00\u7B14\u5B9E\u76D8\u64CD\u4F5C\u7B49\u5F85\u5E01\u5B89\u56DE\u62A5");
      const position = await freshTarget(target);
      const base = { symbol: position.symbol, positionSide: position.positionSide, side: closingSide(position) };
      const reduce = position.positionSide === "BOTH" ? { reduceOnly: "true" } : {};
      const steps = [];
      if (action.kind === "cancel") {
        if (!protectionRows(await rawOrders(position.symbol), position).some((order) => order.id === action.orderId))
          throw Error("\u8FD9\u5F20\u6B62\u76C8\u6B62\u635F\u5355\u5DF2\u6210\u4EA4\u6216\u5DF2\u64A4\u9500");
        steps.push({ method: "DELETE", path: algoPath, params: { symbol: position.symbol, algoId: action.orderId } });
      } else if (action.kind === "leverage") {
        steps.push({ method: "POST", path: leveragePath, params: { symbol: position.symbol, leverage: String(action.leverage) } });
      } else if (action.kind === "margin") {
        const config = await request("GET", configPath, { symbol: position.symbol });
        if (!Array.isArray(config) || !config.some((row2) => row2.symbol === position.symbol && row2.marginType === "ISOLATED"))
          throw Error("\u53EA\u6709\u5E01\u5B89\u9010\u4ED3\u4ED3\u4F4D\u53EF\u4EE5\u8C03\u6574\u5355\u72EC\u4FDD\u8BC1\u91D1");
        steps.push({ method: "POST", path: marginPath, params: {
          symbol: position.symbol,
          positionSide: position.positionSide,
          amount: String(Math.abs(action.delta)),
          type: action.delta > 0 ? "1" : "2"
        } });
      } else {
        const market = await readMarket(position.symbol);
        if (!market) throw Error("\u65E0\u6CD5\u6838\u5BF9\u5E01\u5B89 USDT \u6C38\u7EED\u4EA4\u6613\u89C4\u683C");
        if (action.kind === "close") {
          const side = closingSide(position);
          const wire = await deskOrderParameters(
            action.order ?? { type: "market" },
            market,
            side,
            usdtOrderId(owner, target.campaignId, id),
            Number(position.markPrice),
            () => {
              if (!readBook) throw Error("\u76D8\u53E3\u4EF7\u683C\u8BFB\u53D6\u4E0D\u53EF\u7528");
              return readBook(position.symbol, side);
            }
          );
          const spec = wire.params.type === "LIMIT" ? { ...market, marketStep: market.step } : market;
          const params = Object.fromEntries(Object.entries(wire.params).filter(([, value2]) => typeof value2 === "string"));
          steps.push({ method: "POST", path: wire.path, params: {
            ...base,
            ...reduce,
            ...params,
            quantity: quantityFor(position.quantity, action.fraction, spec)
          } });
        } else {
          const size = action.fraction === 1 ? { closePosition: "true" } : { quantity: quantityFor(position.quantity, action.fraction, market), ...reduce };
          const mark = Number(position.markPrice);
          const existing = protectionRows(await rawOrders(position.symbol), position);
          for (const [kind, value2] of [["sl", action.sl], ["tp", action.tp]]) {
            if (value2 === null) continue;
            if (!(mark > 0) || (position.direction === "long" === (kind === "tp") ? value2 <= mark : value2 >= mark))
              throw Error("\u89E6\u53D1\u4EF7\u4E0E\u5F53\u524D\u5E01\u5B89\u6807\u8BB0\u4EF7\u683C\u65B9\u5411\u4E0D\u7B26");
            if (!market.priceTick || !quantityUnits(String(value2), market.priceTick)) throw Error("\u89E6\u53D1\u4EF7\u4E0E\u5E01\u5B89\u4EF7\u683C\u6B65\u957F\u4E0D\u7B26");
            const replacementId = usdtOrderId(owner, target.campaignId, id + kind);
            steps.push({ method: "POST", path: algoPath, params: {
              ...base,
              ...size,
              algoType: "CONDITIONAL",
              type: kind === "tp" ? "TAKE_PROFIT_MARKET" : "STOP_MARKET",
              workingType: "MARK_PRICE",
              triggerPrice: String(value2),
              clientAlgoId: replacementId
            } });
            for (const order of existing.filter((order2) => order2.kind === kind)) {
              steps.push({ method: "DELETE", path: algoPath, replacementId, params: { symbol: position.symbol, algoId: order.id } });
            }
          }
        }
      }
      row = { id, target, fingerprint, steps };
      save(row);
    }
    await advance(row, action.kind === "protect");
    const pending = row.steps.some((step) => step.state === "sent");
    const filledQuantity = row.steps.find((step) => step.path === orderPath)?.filledQuantity;
    let issue = row.steps.find((step) => step.issue)?.issue;
    if (action.kind === "close" && !pending && Number(filledQuantity) > 0) {
      try {
        await cleanup(target.symbol);
      } catch {
        issue ||= "\u5E73\u4ED3\u6210\u4EA4\u5DF2\u6536\u5230\uFF0C\u539F\u4ED3\u4F4D\u7684\u6761\u4EF6\u5355\u7B49\u5F85\u6838\u5BF9";
      }
    }
    return { pending, issue, filledQuantity: Number(filledQuantity) > 0 ? filledQuantity : void 0 };
  }
  async function advance(row, protecting, onlyReplacement = false) {
    for (const step of row.steps) {
      if (step.state === "failed") break;
      if (step.state === "done") continue;
      if (step.state === "sent") {
        if (onlyReplacement) break;
        await recover(step);
      } else {
        if (onlyReplacement && !step.replacementId) break;
        try {
          if (protecting && step.method === "DELETE" && !step.replacementId) throw Error("\u65E7\u7248\u66FF\u6362\u8BF7\u6C42\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u6B62\u76C8\u6B62\u635F");
          await freshTarget(row.target);
          if (step.replacementId) {
            const replacement = row.steps.find((candidate) => candidate.params.clientAlgoId === step.replacementId);
            const orders = await rawOrders(row.target.symbol);
            if (!Array.isArray(orders) || !replacement || !isDone(replacement) || !orders.some((order) => order.algoStatus === "NEW" && protectionMatches(order, replacement))) {
              throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u65B0\u4FDD\u62A4\u5355\uFF0C\u672A\u53D1\u9001\u65E7\u5355\u64A4\u9500\u8BF7\u6C42");
            }
            if (!orders.some((order) => String(order.algoId) === step.params.algoId)) {
              step.state = "done";
              save(row);
              continue;
            }
          }
        } catch (error) {
          step.state = "failed";
          step.issue = error instanceof Error ? error.message : "\u65E0\u6CD5\u6838\u5BF9\u5F53\u524D\u5B9E\u76D8\u4ED3\u4F4D";
          save(row);
          break;
        }
        step.state = "sent";
        step.sentAt = clock();
        save(row);
        try {
          const params = step.method === "DELETE" ? { algoId: step.params.algoId } : step.params;
          await accept(step, await request(step.method, step.path, params));
        } catch (error) {
          if (definitelyRejected(error)) {
            step.state = "failed";
            step.issue = error instanceof Error ? error.message : "\u5E01\u5B89\u62D2\u7EDD\u5B9E\u76D8\u59D4\u6258";
          } else await recover(step);
        }
        invalidate();
      }
      save(row);
      if (!isDone(step)) break;
    }
  }
  async function cleanup(symbol) {
    const rows = store.pendingPositionControls();
    for (const row of rows) {
      if (symbol && row.target.symbol !== symbol) continue;
      const awaiting = row.steps.filter((step) => step.state === "sent");
      for (const step of awaiting) await recover(step);
      if (row.steps.some((step) => step.replacementId && !step.state)) await advance(row, true, true);
      const linked = row.steps.filter((step) => isTrackedProtection(step) && step.state === "done");
      const limits = row.steps.filter(trackedLimit);
      if (limits.length) {
        const orders = await request("GET", "/fapi/v1/openOrders", { symbol: row.target.symbol });
        if (!Array.isArray(orders)) throw Error("\u5E01\u5B89\u9650\u4EF7\u6302\u5355\u6682\u4E0D\u53EF\u8BFB");
        const active = limits.filter((step) => orders.some((order) => order.clientOrderId === step.params.newClientOrderId));
        for (const step of limits.filter((step2) => !active.includes(step2))) step.retired = true;
        if (active.length && (await activeCampaign(row.target))?.closedAt) {
          for (const step of active) {
            const order = orders.find((order2) => order2.clientOrderId === step.params.newClientOrderId);
            if (!matchedOrder(order, step)) continue;
            const canceled = await request("DELETE", orderPath, { symbol: row.target.symbol, origClientOrderId: step.params.newClientOrderId });
            if (canceled?.status === "CANCELED" && canceled.clientOrderId === step.params.newClientOrderId) step.retired = true;
          }
        }
      }
      if (linked.length) {
        const active = await rawOrders(row.target.symbol);
        if (!Array.isArray(active)) continue;
        const present = linked.filter((step) => active.some((order) => order.clientAlgoId === step.params.clientAlgoId));
        for (const step of linked.filter((step2) => !present.includes(step2))) step.retired = true;
        if (present.length) {
          const position = (await risk(row.target.symbol)).find((item) => matchingLeg(item, row.target));
          const revision = position && usdtMirrorRevision(position);
          if (symbol || !revision || revision !== (row.checkedRevision ?? row.target.revision)) {
            const campaign = await activeCampaign(row.target);
            if (campaign?.closedAt) {
              for (const step of present) {
                if (!active.some((order) => protectionMatches(order, step))) continue;
                const result = await request("DELETE", algoPath, { clientAlgoId: step.params.clientAlgoId });
                if (result?.clientAlgoId === step.params.clientAlgoId && String(result.code) === "200") {
                  step.retired = true;
                  save(row);
                }
              }
              invalidate();
            } else if (campaign && revision) row.checkedRevision = revision;
          }
        }
      }
      save(row);
    }
  }
  async function beforeOpening(symbol) {
    await cleanup(symbol);
    if (store.pendingPositionControls().some((row) => row.target.symbol === symbol && row.steps.some((step) => isTrackedProtection(step) || trackedLimit(step) || step.path === orderPath && step.state === "sent")))
      throw Error("\u539F\u5B9E\u76D8\u4ED3\u4F4D\u7684\u5E73\u4ED3\u6216\u4FDD\u62A4\u59D4\u6258\u5F85\u6838\u5BF9\uFF0C\u6682\u7F13\u65B0\u5F00\u4ED3");
  }
  const protectionIds = (symbol, campaignId) => store.pendingPositionControls().flatMap((row) => row.target.symbol === symbol && row.target.campaignId === campaignId ? row.steps.filter((step) => isTrackedProtection(step) && step.state === "done").map((step) => step.params.clientAlgoId) : []);
  return { execute, cleanup, beforeOpening, readDetails, protectionIds, hasPending: () => store.pendingPositionControls().length > 0 };
}

// scripts/usdt-follow-server.ts
var origin = "https://veil-of-ignorance-ten.vercel.app";
var dashPort = 47321;
var bodyLimit = 1e6;
function loadCredentials(directory) {
  if (process.platform === "darwin") return readMacUsdtCredentials(directory);
  if (process.platform !== "win32") throw Error("\u5E01\u5B89\u51ED\u8BC1\u7531 Windows \u5F53\u524D\u7528\u6237\u4FDD\u62A4");
  const script = [
    '$ErrorActionPreference="Stop"',
    "$saved = Get-Content -LiteralPath $env:VEIL_BINANCE_CREDENTIAL_FILE -Raw | ConvertFrom-Json",
    "$key = $saved.apiKey | ConvertTo-SecureString",
    "$secret = $saved.secretKey | ConvertTo-SecureString",
    'try { @{apiKey=[net.networkcredential]::new("",$key).Password;secret=[net.networkcredential]::new("",$secret).Password} | ConvertTo-Json -Compress }',
    "finally { $key.Dispose(); $secret.Dispose() }"
  ].join("\n");
  const encoded = Buffer.from(script, "utf16le").toString("base64");
  let buffer;
  try {
    buffer = execFileSync2("pwsh.exe", ["-NoProfile", "-NonInteractive", "-EncodedCommand", encoded], {
      windowsHide: true,
      timeout: 1e4,
      env: { ...process.env, VEIL_BINANCE_CREDENTIAL_FILE: join(directory, "account.dpapi") },
      stdio: ["ignore", "pipe", "ignore"]
    });
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6\u672C\u673A\u52A0\u5BC6\u7684\u5E01\u5B89 API \u51ED\u8BC1");
  }
  try {
    const data = JSON.parse(buffer.toString("utf8"));
    if (typeof data.apiKey !== "string" || typeof data.secret !== "string" || !data.apiKey || !data.secret) throw Error("\u5E01\u5B89\u51ED\u8BC1\u683C\u5F0F\u9519\u8BEF");
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } finally {
    buffer.fill(0);
  }
}
function parseCampaigns(value, now) {
  if (!Array.isArray(value) || value.length > 250) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
  const campaigns = /* @__PURE__ */ new Set();
  const safeTime = (at) => Number.isSafeInteger(at) && at > 0 && at <= now + 1e4;
  const validPositive = (n) => Number.isFinite(n) && n > 0;
  for (const row of value) {
    if (!row || !/^fish-instant-[\w-]{3,80}$/.test(row.id ?? "") || campaigns.has(row.id) || typeof row.source?.symbol !== "string" || !/^[A-Za-z0-9_/.:-]{1,35}$/.test(row.source.symbol) || row.source.exchange != null && typeof row.source.exchange !== "string" || row.source.market != null && typeof row.source.market !== "string" || !safeTime(row.admittedAt) || !validPositive(row.notional) || !Number.isInteger(row.leverage) || row.leverage < 1 || row.leverage > 125 || row.liveEntry !== void 0 && !validUsdtLiveEntry(row) || !Array.isArray(row.actions) || row.actions.length < 1 || row.actions.length > 250 || row.actions[0]?.id !== "open" || row.actions[0].action !== "open") throw Error("\u5373\u65F6\u4EA4\u6613\u6218\u5F79\u683C\u5F0F\u65E0\u6548");
    const ids = /* @__PURE__ */ new Set();
    for (const [index, action] of row.actions.entries()) {
      if (!action || ids.has(action.id) || !safeTime(action.at) || index > 0 && row.actions[index - 1].at > action.at) throw Error("\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u987A\u5E8F\u65E0\u6548");
      const actionValid = action.action === "open" ? index === 0 && action.id === "open" : action.action === "close" ? /^(close|mirror|manual-[1-9]\d*)$/.test(action.id) : action.action === "add" ? validPositive(action.notional) && (action.impulseFreshUntil === void 0 ? /^add-[1-9]\d*$/.test(action.id) : row.requiresGuardPlus === true && /^add-impulse-[a-f0-9]{32}$/.test(action.id) && action.at % 3e5 === 0 && action.impulseFreshUntil === action.at + 3e5) : action.action === "mirror" ? action.id === "mirror" && validPositive(action.fraction) && action.fraction < 1 : action.action === "support-reduction" ? /^support-[1-9]\d*$/.test(action.id) && validPositive(action.fraction) && action.fraction < 1 : action.action === "manual-reduction" && /^manual-[1-9]\d*$/.test(action.id) && validPositive(action.fraction) && action.fraction < 1;
      if (!actionValid) throw Error("\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u53C2\u6570\u65E0\u6548");
      ids.add(action.id);
    }
    campaigns.add(row.id);
  }
  return value;
}
async function jsonBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    if ((size += chunk.length) > bodyLimit) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u8D85\u8FC7\u5927\u5C0F\u9650\u5236");
    chunks.push(chunk);
  }
  const request = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  if (!request || typeof request !== "object" || Array.isArray(request)) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
  return request;
}
var digest = (value) => createHash3("sha256").update(value).digest();
var json = (res, status, data) => {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
};
function manualAnchor(value, now) {
  if (!value || !/^[A-Z0-9]{2,24}USDT$/.test(value.symbol) || value.positionSide !== "LONG" && value.positionSide !== "BOTH" || !Number.isSafeInteger(value.openedAt) || value.openedAt <= 0 || value.openedAt > now + 1e3 || typeof value.openingTradeId !== "string" || !/^\d{1,25}$/.test(value.openingTradeId) || typeof value.openingOrderId !== "string" || !/^\d{1,25}$/.test(value.openingOrderId)) throw Error("\u5E01\u5B89\u9996\u4ED3\u8EAB\u4EFD\u65E0\u6548");
  return {
    symbol: value.symbol,
    positionSide: value.positionSide,
    openedAt: value.openedAt,
    openingTradeId: value.openingTradeId,
    openingOrderId: value.openingOrderId
  };
}
function manualMonitor(value) {
  if (!value || value.version !== "instant-template-monitor-v1" || typeof value.templateId !== "string" || typeof value.name !== "string" || value.name.length > 200 || typeof value.plan?.id !== "string" || !Array.isArray(value.plan.frozenVersions) || !value.plan.frozenVersions.length || value.plan.preEntryThreeStage || value.plan.preEntryConditions) throw Error("\u624B\u52A8\u4ED3\u4F4D\u9700\u8981\u5DF2\u4FDD\u5B58\u4E14\u7248\u672C\u53EF\u6838\u9A8C\u7684\u4E70\u540E\u7B56\u7565");
  return value;
}
function serveUsdtFollower({
  owner,
  token,
  exchange,
  store,
  mode,
  startedAt,
  positionReader,
  campaignReader,
  managedClock,
  positionRequest,
  allowedOrigin = origin,
  port = dashPort,
  statusFile
}) {
  const readManaged = campaignReader && managedClock ? async (anchor) => {
    const from = Math.max(1, anchor.openedAt - 1e3);
    const result = await campaignReader(from, [{ symbol: anchor.symbol, openedAt: anchor.openedAt }], anchor.symbol);
    const actual = result.campaigns.find((campaign) => matchesManualAnchor(anchor, campaign));
    if (!actual) throw Error("\u5E01\u5B89\u672A\u8FD4\u56DE\u8FD9\u4E00\u7B14\u4ED3\u4F4D\u7684\u5B8C\u6574\u6210\u4EA4");
    return actual;
  } : void 0;
  const controls = positionRequest && positionReader && campaignReader ? createUsdtPositionControls(positionRequest, store, owner, exchange.market, campaignReader, positionReader.invalidate, managedClock, exchange.book) : void 0;
  const follower = createUsdtFollower(
    store,
    exchange,
    owner,
    mode,
    startedAt,
    readManaged,
    managedClock,
    controls?.protectionIds,
    controls ? positionReader?.positions : void 0,
    controls
  );
  const desk = controls && positionRequest && createUsdtOrderDesk(positionRequest, exchange, store, owner, mode, async (symbol) => {
    if (follower.statuses().some((row) => (row.market ?? row.symbol) === symbol && !["closed", "ignored"].includes(row.state)))
      throw Error("\u8BE5\u5408\u7EA6\u5B58\u5728\u7B56\u7565\u8DDF\u968F\u7684\u4ED3\u4F4D\u6216\u5F85\u6838\u5BF9\u59D4\u6258\uFF0C\u8BF7\u5148\u5904\u7406\u539F\u4ED3\u4F4D");
    await controls.beforeOpening(symbol);
  }, managedClock);
  const tokenDigest = digest(token);
  const snapshot = () => ({
    connected: true,
    paused: follower.paused,
    startedAt: follower.entryAfter,
    statuses: follower.statuses(),
    guardPlusAdditions: 1,
    executionSafety: USDT_EXECUTION_SAFETY,
    controlRevision: store.controlRevision(),
    ...positionReader ? { positionMirror: 1 } : {},
    ...campaignReader ? { campaignMirror: 1 } : {},
    ...readManaged ? { manualMonitor: 1, monitorSwitch: 1 } : {},
    ...controls ? { positionControls: 1 } : {},
    ...readManaged && controls ? { followMonitorSwitch: USDT_FOLLOW_MONITOR_BASIS } : {},
    ...desk ? { orderDesk: 1 } : {}
  });
  const server = createServer({ maxHeaderSize: 4e3, requestTimeout: 1e4, headersTimeout: 6e3 }, (req, res) => {
    const work = async () => {
      if (req.headers.origin !== allowedOrigin || req.headers.host !== "127.0.0.1:" + server.address().port || req.url !== "/api/usdt-follow" && req.url !== USDT_EXECUTION_PATH) {
        json(res, 403, { error: "\u672C\u673A\u6267\u884C\u7AEF\u53EA\u63A5\u53D7\u914D\u5BF9\u9875\u9762" });
        return;
      }
      res.setHeader("Access-Control-Allow-Origin", allowedOrigin);
      res.setHeader("Vary", "Origin");
      if (req.method === "OPTIONS") {
        res.writeHead(204, {
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Allow-Private-Network": "true"
        }).end();
        return;
      }
      if (req.method !== "POST" || !req.headers["content-type"]?.startsWith("application/json") || !timingSafeEqual(tokenDigest, digest(req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.slice(7) : ""))) {
        json(res, 401, { error: "\u672C\u673A\u914D\u5BF9\u7801\u65E0\u6548" });
        return;
      }
      const content = await jsonBody(req);
      if (content.owner !== owner) return json(res, 403, { error: "\u672C\u673A\u6267\u884C\u7AEF\u7ED1\u5B9A\u4E86\u53E6\u4E00\u4E2A\u65E0\u77E5\u4E4B\u5E55\u8D26\u53F7" });
      if (content.command === "status") return json(res, 200, snapshot());
      if (req.url === USDT_EXECUTION_PATH && desk) {
        if (content.command === "desk-info") return json(res, 200, await desk.info(content.symbol));
        if (content.command === "desk-open")
          return json(res, 200, await follower.runPositionControl(() => desk.execute(content.request)));
        if (content.command === "desk-close" && content.request?.action?.kind === "close" && content.request.action.order)
          return json(res, 200, await follower.runPositionControl(() => controls.execute(content.request)));
      }
      if (content.command === "position-control") {
        if (!controls) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u64CD\u4F5C\u5E01\u5B89\u5B9E\u76D8\u4ED3\u4F4D" });
        return json(res, 200, await follower.runPositionControl(() => controls.execute(content.request)));
      }
      if (readManaged && managedClock) {
        if (content.command === "manual-monitor-status") {
          return json(res, 200, { observedAt: managedClock(), positions: follower.managed(content.followBasisVersion === USDT_FOLLOW_MONITOR_BASIS) });
        }
        if (content.command === "manual-monitor-adopt") {
          if (content.confirmed !== true || content.controlRevision !== store.controlRevision())
            throw Error("\u8BF7\u6309\u5F53\u524D\u5B9E\u76D8\u72B6\u6001\u9010\u7B14\u786E\u8BA4\u7B56\u7565\u6258\u7BA1");
          const position = await follower.runPositionControl(() => follower.adopt(manualAnchor(content.anchor, managedClock()), manualMonitor(content.monitor), content.controlRevision));
          return json(res, 200, { position });
        }
        if (content.command === "manual-monitor-switch" && req.url === USDT_EXECUTION_PATH) {
          if (content.confirmed !== true || typeof content.id !== "string" || !Number.isSafeInteger(content.planEpoch) || content.planEpoch < 0)
            throw Error("\u8BF7\u9010\u7B14\u786E\u8BA4\u5B9E\u76D8\u6301\u4ED3\u65B9\u6848\u5207\u6362");
          const position = await follower.runPositionControl(() => follower.switchManaged(content.id, content.planEpoch, manualMonitor(content.monitor)));
          return json(res, 200, { position });
        }
        if (content.command === "manual-monitor-update") {
          if (typeof content.id !== "string" || !Number.isSafeInteger(content.revision) || !content.checkpoint) throw Error("\u624B\u52A8\u6258\u7BA1\u8FDB\u5EA6\u65E0\u6548");
          follower.updateManaged(content.id, content.revision, content.checkpoint, content.decision, content.planEpoch, content.followBasisVersion);
          json(res, 200, { ok: true });
          void follower.tick();
          return;
        }
        if (content.command === "follow-monitor-switch" && controls && req.url === USDT_EXECUTION_PATH) {
          if (content.confirmed !== true || content.followBasisVersion !== USDT_FOLLOW_MONITOR_BASIS || typeof content.id !== "string" || !Number.isSafeInteger(content.planEpoch) || content.planEpoch < 0) throw Error("\u8BF7\u9010\u7B14\u786E\u8BA4\u8DDF\u5355\u6301\u4ED3\u7684\u65B0\u65B9\u6848");
          const anchor = manualAnchor(content.anchor, managedClock());
          const monitor = manualMonitor(content.monitor);
          const original = content.original && manualMonitor(content.original);
          const position = await follower.runPositionControl(() => follower.switchFollowMonitor(
            content.id,
            anchor,
            content.planEpoch,
            monitor,
            original,
            content.followSample
          ));
          return json(res, 200, { position });
        }
      }
      if (content.command === "position-campaigns") {
        if (!campaignReader) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u540C\u6B65\u5B9E\u76D8\u6218\u5F79" });
        const result = await campaignReader(content.since, content.open);
        const statuses = follower.statuses();
        return json(res, 200, { ...result, campaigns: result.campaigns.map((campaign) => {
          const follow = findUsdtCampaignFollow(campaign, statuses);
          const liveId = usdtLiveCampaignId(campaign);
          const management = follower.managedArchive(follow?.id ?? liveId);
          return { ...campaign, ...management ? { management } : {}, ...follow && follow.id !== liveId ? { followId: follow.id } : {} };
        }) });
      }
      if (content.command === "positions" || content.command === "position-history") {
        if (!positionReader) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u540C\u6B65\u5E01\u5B89\u6301\u4ED3" });
        if (content.command === "positions") {
          const state2 = await positionReader.positions();
          return json(res, 200, content.withDetails === true && controls ? await controls.readDetails(state2) : state2);
        }
        const state = await positionReader.history(content.symbol, content.positionSide, content.revision);
        return json(res, 200, state);
      }
      if (content.command !== "sync" && content.command !== "pause" && content.command !== "resume") throw Error("\u672A\u77E5\u7684\u5B9E\u76D8\u6307\u4EE4");
      const campaigns = parseCampaigns(content.campaigns, Date.now());
      if (content.command !== "sync") {
        const legacyPause = content.command === "pause" && content.controlRevision === void 0;
        if (!legacyPause && campaigns.length || content.command === "resume" && content.controlRevision !== store.controlRevision()) {
          return json(res, 409, { ...snapshot(), staleControl: true, error: "\u5B9E\u76D8\u8DDF\u968F\u72B6\u6001\u5DF2\u53D8\u5316\uFF0C\u8BF7\u6838\u5BF9\u540E\u91CD\u65B0\u64CD\u4F5C" });
        }
        if (content.command === "pause") follower.pauseNewOrders();
        else follower.resumeNewOrders();
      } else follower.ingest(campaigns);
      json(res, 200, snapshot());
      void follower.tick();
    };
    void work().catch((error) => {
      if (!res.headersSent) json(res, 400, { error: error instanceof SyntaxError ? "\u672C\u673A\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548" : error instanceof Error ? error.message : "\u672C\u673A\u6267\u884C\u7AEF\u62D2\u7EDD\u8BF7\u6C42" });
    });
  });
  let nextCleanup = 0;
  const timer = setInterval(() => {
    if (controls && Date.now() >= nextCleanup) {
      nextCleanup = Date.now() + 1e4;
      if (controls.hasPending()) void follower.runPositionControl(controls.cleanup).catch(() => void 0);
    }
    void follower.tick();
    if (statusFile) {
      try {
        writeFileSync(statusFile, JSON.stringify(snapshot()), { mode: 384 });
      } catch {
      }
    }
  }, 1e3);
  server.once("close", () => clearInterval(timer));
  server.listen(port, "127.0.0.1");
  return server;
}
async function main() {
  const directory = process.argv[2];
  if (!directory) throw Error("\u8BF7\u6307\u5B9A\u4FDD\u5B58\u5E01\u5B89\u51ED\u8BC1\u7684\u672C\u673A\u76EE\u5F55");
  const live = process.argv.includes("--live");
  const setup = process.argv.includes("--prepare");
  const credentials = loadCredentials(directory);
  const request = createUsdtRequest(credentials);
  const exchange = createUsdtExchange(request);
  let verified;
  try {
    verified = await exchange.account();
  } catch (error) {
    credentials.secret.fill(0);
    if (error instanceof TypeError) throw Error("\u672C\u673A\u7F51\u7EDC\u65E0\u6CD5\u8BBF\u95EE\u5E01\u5B89 U \u672C\u4F4D\u8D26\u6237\u63A5\u53E3");
    throw error;
  }
  if (setup) {
    const account = createHash3("sha256").update(verified.id).digest("hex");
    credentials.secret.fill(0);
    console.log(JSON.stringify({ connected: true, market: "USDT-M", mode: verified.mode, account }));
    return;
  }
  if (!live) {
    credentials.secret.fill(0);
    console.log(JSON.stringify({ connected: true, market: "USDT-M", mode: verified.mode }));
    return;
  }
  const config = JSON.parse(readFileSync(join(directory, "usdt-follow.json"), "utf8").replace(/^\uFEFF/, ""));
  if (!/^[a-f0-9-]{36}$/i.test(config.owner) || !/^[0-9a-f]{64}$/i.test(config.token) || config.account !== createHash3("sha256").update(verified.id).digest("hex")) throw Error("\u672C\u673A\u5B9E\u76D8\u914D\u5BF9\u8BBE\u7F6E\u4E0E\u5E01\u5B89\u8D26\u6237\u4E0D\u7B26");
  mkdirSync(directory, { recursive: true });
  const lockPath = join(directory, "usdt-follow.lock");
  let lock;
  try {
    lock = openSync(lockPath, "wx");
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    const pid = Number(readFileSync(lockPath, "utf8"));
    if (!Number.isInteger(pid) || pid <= 0) throw Error("\u672C\u673A\u6267\u884C\u7AEF\u6B63\u5728\u542F\u52A8\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
    try {
      process.kill(pid, 0);
    } catch (cause) {
      if (cause.code !== "ESRCH") throw cause;
      unlinkSync(lockPath);
      lock = openSync(lockPath, "wx");
    }
    if (lock == null) throw Error("\u672C\u673A U \u672C\u4F4D\u6267\u884C\u7AEF\u5DF2\u8FD0\u884C");
  }
  writeFileSync(lock, String(process.pid));
  let store;
  const close = () => {
    try {
      store?.close();
    } finally {
      closeSync(lock);
      unlinkSync(lockPath);
      credentials.secret.fill(0);
    }
  };
  process.once("exit", close);
  store = openUsdtFollowStore(join(directory, "usdt-follow.sqlite"), verified.id, config.owner);
  const clockStart = performance.now();
  const clockReply = await fetch("https://fapi.binance.com/fapi/v1/time", { redirect: "error", signal: AbortSignal.timeout(1e4) });
  const { serverTime } = await clockReply.json();
  if (!clockReply.ok || !Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u95F4\u6682\u4E0D\u53EF\u7528");
  const clockMidpoint = (clockStart + performance.now()) / 2;
  const managedClock = () => Math.round(serverTime + performance.now() - clockMidpoint);
  const server = serveUsdtFollower({
    owner: config.owner,
    token: config.token,
    exchange,
    store,
    mode: verified.mode,
    managedClock,
    startedAt: Date.now(),
    positionReader: createUsdtPositionReader(request, managedClock),
    campaignReader: createUsdtCampaignReader(request, managedClock),
    positionRequest: request,
    statusFile: join(directory, "usdt-follow-status.json")
  });
  server.once("listening", () => console.log("\u5E01\u5B89 U \u672C\u4F4D\u6267\u884C\u7AEF\u5DF2\u5C31\u7EEA\uFF0C\u7B49\u5F85\u5DF2\u914D\u5BF9\u7684\u5373\u65F6\u4EA4\u6613\u3002"));
  server.once("error", () => {
    console.error("\u672C\u673A\u6267\u884C\u7AEF\u7AEF\u53E3\u4E0D\u53EF\u7528");
    process.exit(1);
  });
}
if (process.argv[1] && /usdt-follow-server\.(?:mjs|ts)$/.test(process.argv[1])) {
  void main().catch((error) => {
    console.error(error instanceof Error && !error.stack?.includes("readFileSync") ? error.message : "\u672C\u673A\u6267\u884C\u7AEF\u65E0\u6CD5\u542F\u52A8");
    process.exitCode = 1;
  });
}
export {
  serveUsdtFollower
};
