// scripts/usdt-macos-preload.ts
import { readFileSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { setGlobalProxyFromEnv } from "node:http";

// scripts/usdt-macos-credentials.ts
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
var service = "app.veil-of-ignorance.usdt-executor";
var identity = (directory2) => createHash("sha256").update(resolve(directory2)).digest("hex");
var security = (args, input) => execFileSync("/usr/bin/security", args, {
  input,
  stdio: ["pipe", "pipe", "ignore"],
  timeout: 3e4
});
function readMacUsdtCredentials(directory2, run = security) {
  let buffer;
  try {
    buffer = run(["find-generic-password", "-s", service, "-a", identity(directory2), "-w"]);
    const data = JSON.parse(Buffer.from(buffer.toString("utf8").trim(), "base64").toString("utf8"));
    if (!/^[a-zA-Z0-9]{16,256}$/.test(data.apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(data.secret)) throw Error();
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6 Mac \u94A5\u5319\u4E32\u4E2D\u7684\u5E01\u5B89\u51ED\u8BC1\uFF0C\u8BF7\u5148\u914D\u7F6E\u5E76\u5141\u8BB8\u672C\u673A\u94A5\u5319\u4E32\u8BBF\u95EE\u3002");
  } finally {
    buffer?.fill(0);
  }
}

// scripts/usdt-exchange.ts
import { createHash as createHash2, createHmac } from "node:crypto";
var spot = "https://api.binance.com";
var futures = "https://fapi.binance.com";
var tradingPaths = /* @__PURE__ */ new Set(["/fapi/v1/order", "/fapi/v1/algoOrder", "/fapi/v1/leverage", "/fapi/v1/marginType", "/fapi/v1/positionMargin"]);
var UsdtApiError = class extends Error {
  status;
  code;
  constructor(status, code) {
    super("\u5E01\u5B89 U \u672C\u4F4D\u8BF7\u6C42\u5931\u8D25\uFF08HTTP " + status + (code == null ? "" : "\uFF0C\u4EE3\u7801 " + code) + "\uFF09");
    this.status = status;
    this.code = code;
  }
};
function createUsdtRequest(credentials, fetcher = fetch) {
  const clocks = /* @__PURE__ */ new Map();
  const send = async (method, path, params) => {
    const base = path.startsWith("/fapi/") ? futures : spot;
    if (!/^\/(?:fapi|sapi|api)\/v\d+\/(?:[a-zA-Z]+\/)*[a-zA-Z0-9]+$/.test(path) || method === "POST" && !tradingPaths.has(path) || method === "DELETE" && path !== "/fapi/v1/algoOrder" && path !== "/fapi/v1/order")
      throw Error("\u5E01\u5B89\u7B7E\u540D\u8BF7\u6C42\u8DEF\u5F84\u65E0\u6548");
    const signal = AbortSignal.timeout(1e4);
    let clock = clocks.get(base);
    if (!clock || Date.now() - clock.sampled >= 3e4 || Date.now() < clock.sampled) {
      const response2 = await fetcher(base + (base === futures ? "/fapi/v1/time" : "/api/v3/time"), { redirect: "error", signal });
      if (!response2.ok) throw new UsdtApiError(response2.status);
      const { serverTime } = await response2.json();
      if (!Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u949F\u4E0D\u53EF\u7528");
      clock = { sampled: Date.now(), offset: serverTime - Date.now() };
      clocks.set(base, clock);
    }
    const query = new URLSearchParams({ ...params, recvWindow: method === "GET" ? "12000" : "5000", timestamp: String(Date.now() + clock.offset) });
    query.set("signature", createHmac("sha256", credentials.secret).update(query.toString()).digest("hex"));
    const response = await fetcher(base + path + (method === "POST" ? "" : "?" + query), {
      method,
      redirect: "error",
      signal,
      headers: { "X-MBX-APIKEY": credentials.apiKey, ...method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : {} },
      ...method === "POST" ? { body: query.toString() } : {}
    });
    const body = await response.text().then((text) => JSON.parse(
      text,
      (key, value, context) => ["orderId", "uid", "id", "algoId"].includes(key) && typeof value === "number" && /^\d+$/.test(context?.source ?? "") ? context.source : value
    )).catch(() => void 0);
    if (body?.code === -1021) clocks.delete(base);
    if (!response.ok || body?.code < 0) throw new UsdtApiError(response.status, typeof body?.code === "number" ? body.code : void 0);
    if (body == null) throw Error("\u5E01\u5B89\u54CD\u5E94\u4E0D\u53EF\u8BC6\u522B");
    return body;
  };
  return async (method, path, params = {}) => {
    try {
      return await send(method, path, params);
    } catch (error) {
      if (method === "GET" && (error instanceof TypeError || error instanceof DOMException || error instanceof UsdtApiError && (error.code === -1021 || error.status >= 500))) return send(method, path, params);
      throw error;
    }
  };
}

// scripts/usdt-macos-preload.ts
if (process.platform !== "darwin") throw Error("\u6B64\u542F\u52A8\u5165\u53E3\u7528\u4E8E Mac\u3002");
var directory = join(homedir(), "Library", "Application Support", "VeilUSDTExecutor");
var { proxy } = JSON.parse(readFileSync(join(directory, "proxy.json"), "utf8"));
setGlobalProxyFromEnv({ HTTPS_PROXY: proxy, HTTP_PROXY: proxy, NO_PROXY: "127.0.0.1,localhost" });
if (process.argv.includes("--live") && !existsSync(join(directory, "usdt-follow.sqlite"))) {
  const credentials = readMacUsdtCredentials(directory);
  try {
    const positions = await createUsdtRequest(credentials)("GET", "/fapi/v3/positionRisk");
    if (!Array.isArray(positions) || positions.some((row) => Number(row.positionAmt) !== 0)) {
      throw Error("\u8D26\u6237\u4ECD\u6709\u6301\u4ED3\uFF0CMac \u7F3A\u5C11\u539F\u6267\u884C\u8D26\u672C\u3002\u8BF7\u5148\u5B8C\u6210 Windows \u2192 Mac \u7684\u8D26\u672C\u4EA4\u63A5\uFF0C\u518D\u542F\u7528\u5B9E\u76D8\uFF1B\u5F53\u524D\u4FDD\u6301\u53EA\u8BFB\u3002");
    }
  } finally {
    credentials.secret.fill(0);
  }
}
