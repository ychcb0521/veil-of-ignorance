var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/lib/cdaPeriods.ts
var CDA_FIVE_MINUTE_LABEL, CDA_HOURLY_LABEL, CDA_HOURLY_ID, CDA_HOURLY_CHART_ID, CDA_HOURLY_TIME_SCALE, CDA_HOURLY_AVERAGE_HOURS, CDA_HOURLY_RETENTION_HOURS, usesHourlyCda;
var init_cdaPeriods = __esm({
  "src/lib/cdaPeriods.ts"() {
    CDA_FIVE_MINUTE_LABEL = "CDA-5mins";
    CDA_HOURLY_LABEL = "CDA-1h";
    CDA_HOURLY_ID = "cda-1h-v1";
    CDA_HOURLY_CHART_ID = "CDA_1H";
    CDA_HOURLY_TIME_SCALE = 12;
    CDA_HOURLY_AVERAGE_HOURS = 24 * CDA_HOURLY_TIME_SCALE;
    CDA_HOURLY_RETENTION_HOURS = 48 * CDA_HOURLY_TIME_SCALE;
    usesHourlyCda = (def) => (def.chartTemplate ?? def.id) === CDA_HOURLY_ID;
  }
});

// src/lib/fish/qualityPostMirrorProtection.ts
function canGateAfterMirror(v) {
  return v.kind === "box-stop" && v.boxStop?.version === "holding-box-stop-independent-channels-v1" || v.kind === "box-stop" && v.boxStop?.structure.algorithm === "dbl5" && v.boxStop.structure.kSource === "guard" && !v.boxStop.reference || v.kind === "indicator" && isCdaProtection(v.snapshot?.featureId);
}
var POST_MIRROR_PROTECTION_VERSION, POST_MIRROR_PROTECTION_LABEL, isCdaProtection;
var init_qualityPostMirrorProtection = __esm({
  "src/lib/fish/qualityPostMirrorProtection.ts"() {
    init_cdaPeriods();
    POST_MIRROR_PROTECTION_VERSION = "holding-post-mirror-protection-v1";
    POST_MIRROR_PROTECTION_LABEL = "\u4EC5\u5728\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u6210\u4EA4\u540E\u542F\u52A8";
    isCdaProtection = (featureId) => featureId === "cda" || featureId === CDA_HOURLY_ID;
  }
});

// src/lib/fish/qualityMirrorHardStopStages.ts
function validateMirrorHardStopStage(v) {
  const s = v.mirrorStage;
  if (!s) return;
  if (s.version !== MIRROR_HARD_STOP_STAGES_VERSION || !["before", "after"].includes(s.stage) || v.activation) throw Error("\u955C\u50CF\u524D\u540E\u786C\u6027\u7EC8\u6B62\u7684\u9636\u6BB5\u7248\u672C\u6216\u542F\u52A8\u8303\u56F4\u4E0D\u7B26\uFF0C\u8BF7\u4FDD\u7559\u539F\u65B9\u6848\u6838\u67E5");
  if (s.stage === "before" && (v.boxStop?.version === "holding-support-second-break-v1" || ["addition-geometric-profit", "payoff-ratio"].includes(v.kind))) throw Error("\u9996\u6B21\u65AD\u88C2\u505C\u52A0\u4ED3\u53CA\u52A0\u4ED3\uFF0F\u76C8\u4E8F\u6BD4\u6B62\u76C8\u8BF7\u653E\u5728\u955C\u50CF\u540E\u6216\u539F\u5168\u7A0B\u533A\u57DF\uFF1B\u955C\u50CF\u524D\u53EF\u9009\u9632\u5B88\u7EBF\u65AD\u88C2\u5373\u9000\u51FA");
}
var MIRROR_HARD_STOP_STAGES_VERSION, mirrorHardStopStageLabel;
var init_qualityMirrorHardStopStages = __esm({
  "src/lib/fish/qualityMirrorHardStopStages.ts"() {
    init_qualityPostMirrorProtection();
    MIRROR_HARD_STOP_STAGES_VERSION = "holding-mirror-hard-stop-stages-v1";
    mirrorHardStopStageLabel = (stage) => stage ? stage.stage === "before" ? "\u4EC5\u5728\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u524D\u751F\u6548" : "\u4EC5\u5728\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u540E\u751F\u6548" : "";
  }
});

// src/lib/fish/qualityMirrorDeadline.ts
var MIRROR_DEADLINE_KIND, MIRROR_DEADLINE_VERSION, MIRROR_DEADLINE_LABEL;
var init_qualityMirrorDeadline = __esm({
  "src/lib/fish/qualityMirrorDeadline.ts"() {
    MIRROR_DEADLINE_KIND = "mirror-deadline";
    MIRROR_DEADLINE_VERSION = "holding-mirror-deadline-v1";
    MIRROR_DEADLINE_LABEL = "\u672A\u5B9E\u73B0\u955C\u50CF\u5E73\u8861\u51CF\u4ED3";
  }
});

// src/lib/fish/qualityHoldingLedger.ts
function replayQualityHoldingLedger(o) {
  if (![o.notional, o.entryPrice, o.entryAt].every(Number.isFinite) || !(o.notional > 0) || !(o.entryPrice > 0) || o.entryAt <= 0) throw Error("\u6301\u4ED3\u8D26\u521D\u59CB\u72B6\u6001\u65E0\u6548");
  const through = o.through ?? Infinity, initialQuantity = o.notional / o.entryPrice;
  if (!Number.isFinite(through) && through !== Infinity || through < o.entryAt) throw Error("\u6301\u4ED3\u8D26\u8BFB\u53D6\u65F6\u70B9\u65E0\u6548\u6216\u65E9\u4E8E\u5EFA\u4ED3");
  const lots = o.details === false ? [] : [{ index: 0, at: o.entryAt, price: o.entryPrice, quantity: initialQuantity, cost: o.notional }];
  let held = initialQuantity, cost = o.notional, realized = 0, totalInvested = o.notional, totalQuantity = initialQuantity;
  let mirrorQuantity = 0, mirrorCost = 0, mirrorProfit = 0, reductionProfit = 0;
  const sales = [];
  const events = [];
  const validAt = (at) => {
    if (!Number.isFinite(at) || at < o.entryAt) throw Error("\u6301\u4ED3\u6210\u4EA4\u65F6\u95F4\u65E0\u6548");
  };
  o.additions.forEach((f, index) => {
    validAt(f.at);
    if (f.at <= through) events.push({ at: f.at, priority: 2, index, kind: "add" });
  });
  o.reductions?.forEach((f, index) => {
    validAt(f.at);
    if (f.at <= through) events.push({ at: f.at, priority: 1, index, kind: "reduce" });
  });
  const m = o.mirror;
  if (m) validAt(m.at);
  if (m && (m.at < through || m.at === through && (o.includeIntraminute || m.atOpen))) events.push({ at: m.at, priority: m.atOpen ? 0 : 3, index: 0, kind: "mirror" });
  events.sort((a, b) => a.at - b.at || a.priority - b.priority || a.index - b.index);
  for (const event of events) {
    if (!Number.isFinite(event.at) || event.at < o.entryAt) throw Error("\u6301\u4ED3\u6210\u4EA4\u65F6\u95F4\u65E0\u6548");
    if (event.kind === "add") {
      const f = o.additions[event.index];
      if (!(held > 0) || ![f.price, f.quantity, f.notional].every(Number.isFinite) || !(f.price > 0) || !(f.quantity > 0) || !(f.notional > 0)) throw Error("\u52A0\u4ED3\u6210\u4EA4\u6216\u5269\u4F59\u6301\u4ED3\u65E0\u6548");
      if (Math.abs(f.quantity * f.price - f.notional) > 1e-9 * Math.max(1, f.notional)) throw Error("\u52A0\u4ED3\u5E01\u6570\u4E0E\u91D1\u989D\u4E0D\u4E00\u81F4");
      held += f.quantity;
      cost += f.notional;
      totalInvested += f.notional;
      totalQuantity += f.quantity;
      if (o.details !== false) lots.push({ index: event.index + 1, at: f.at, price: f.price, quantity: f.quantity, cost: f.notional });
      continue;
    }
    const cut = event.kind === "reduce" ? o.reductions[event.index] : void 0;
    const price = cut?.price ?? m.price, fraction = cut?.fraction ?? m.fraction;
    if (!Number.isFinite(price) || !(price > 0) || !Number.isFinite(fraction) || fraction < 0 || fraction > 1) throw Error("\u51CF\u4ED3\u6210\u4EA4\u65E0\u6548");
    const quantity2 = event.kind === "mirror" ? fraction === 1 ? held : Math.min(held, initialQuantity * fraction) : held * fraction;
    if (!(quantity2 > 0)) continue;
    const proportion = quantity2 / held, sold = lots.filter((l) => l.quantity > 0).map((l) => {
      const q = l.quantity * proportion, c = l.cost * proportion, pnl2 = q * price - c;
      l.quantity *= 1 - proportion;
      l.cost *= 1 - proportion;
      return { index: l.index, quantity: q, costRemoved: c, realizedPnl: pnl2 };
    });
    const costRemoved = cost * proportion, pnl = quantity2 * price - costRemoved;
    held *= 1 - proportion;
    cost *= 1 - proportion;
    realized += pnl;
    if (event.kind === "mirror") {
      mirrorQuantity += quantity2;
      mirrorCost += costRemoved;
      mirrorProfit += pnl;
    } else reductionProfit += pnl;
    if (o.details !== false) sales.push({ kind: event.kind, at: event.at, price, quantity: quantity2, costRemoved, realizedPnl: pnl, lots: sold });
  }
  if (![initialQuantity, held, cost, realized, totalInvested, totalQuantity, mirrorQuantity, mirrorCost, mirrorProfit, reductionProfit].every(Number.isFinite) || held < 0 || cost < 0) throw Error("\u6301\u4ED3\u8D26\u91D1\u989D\u6216\u5E01\u6570\u8D85\u51FA\u53EF\u8BA1\u7B97\u8303\u56F4");
  return { initialQuantity, held, cost, realized, totalInvested, totalQuantity, mirrorQuantity, mirrorCost, mirrorProfit, reductionProfit, lots, sales };
}
function calculateHoldingLedgerAddition(p, T, K) {
  const blank = (error, shortfall = 0) => ({ error, addCoins: 0, baseCoins: 0, mirrorCoins: 0, mirrorUsed: 0, coverageGap: 0, oldLossShortfall: shortfall });
  if (![p.held, p.cost, p.realized, T, K].every(Number.isFinite) || p.held < 0 || p.cost < 0 || T <= 0 || K <= 0) return blank("invalid_input");
  if (!(p.held > 0)) return blank("position_closed");
  if (!(T > K)) return blank("price_not_above_support");
  const cushion = p.held * K - p.cost, raw = cushion + p.realized, risk = T - K;
  if (!Number.isFinite(raw)) return blank("invalid_input");
  const tolerance = 64 * Number.EPSILON * Math.max(1, p.held * K, p.cost, Math.abs(p.realized));
  if (raw < -tolerance) return blank("risk_budget_insufficient", -raw);
  const budget = Math.max(0, raw);
  const addCoins = budget / risk, baseCoins = Math.max(0, cushion + Math.min(0, p.realized)) / risk, mirrorCoins = Math.max(0, p.realized - Math.max(0, -cushion)) / risk;
  if (![addCoins, baseCoins, mirrorCoins].every(Number.isFinite)) return blank("invalid_input");
  return { error: null, addCoins, baseCoins, mirrorCoins, mirrorUsed: 0, coverageGap: budget - addCoins * risk, oldLossShortfall: 0 };
}
var HOLDING_LEDGER_ADDITION_VERSION;
var init_qualityHoldingLedger = __esm({
  "src/lib/fish/qualityHoldingLedger.ts"() {
    HOLDING_LEDGER_ADDITION_VERSION = "holding-ledger-addition-v1";
  }
});

// src/lib/fish/qualityMirrorLossReview.ts
function validateMirrorLossThreshold(rule) {
  const value = rule.mirrorLossThreshold;
  const schedule = rule.mirrorReviewSchedule;
  if (rule.mirrorDeadlineVersion === MIRROR_PNL_THRESHOLD_VERSION) {
    if (!value || value.version !== MIRROR_PNL_THRESHOLD_VERSION || !["percent", "usdt"].includes(value.unit) || !Number.isFinite(value.value)) throw Error("\u8BF7\u586B\u5199\u6709\u9650\u6570\u5B57\u76C8\u4E8F\u95E8\u69DB");
    validateMirrorLossThreshold({ mirrorDeadlineVersion: schedule?.version ?? MIRROR_LOSS_THRESHOLD_VERSION, mirrorLossThreshold: { ...value, version: MIRROR_LOSS_THRESHOLD_VERSION, value: 0 }, mirrorReviewSchedule: schedule });
    return;
  }
  if (rule.mirrorDeadlineVersion === MIRROR_LOSS_REVIEW_VERSION) {
    if (value !== void 0 || schedule !== void 0) throw Error("\u539F\u7248\u5B9A\u65F6\u68C0\u67E5\u4E0D\u80FD\u81EA\u52A8\u5957\u7528\u65B0\u7248\u4E8F\u635F\u95E8\u69DB\u6216\u95F4\u9694\uFF0C\u8BF7\u65B0\u5EFA\u526F\u672C");
    return;
  }
  if (rule.mirrorDeadlineVersion === MIRROR_REVIEW_ONCE_VERSION) {
    if (schedule?.version !== MIRROR_REVIEW_ONCE_VERSION || schedule.intervalHours !== null || schedule.endHours !== 12) throw Error("\u5355\u6B21\u68C0\u67E5\u7684\u53C2\u6570\u4E0E\u7248\u672C\u4E0D\u7B26");
  } else if (rule.mirrorDeadlineVersion === MIRROR_REVIEW_SCHEDULE_VERSION) {
    if (!schedule || schedule.version !== MIRROR_REVIEW_SCHEDULE_VERSION || !Number.isFinite(schedule.intervalHours) || schedule.intervalHours < 1 / 60 || schedule.intervalHours > 12 || schedule.endHours !== 12) throw Error("\u5224\u65AD\u95F4\u9694\u987B\u4E3A 1 \u5206\u949F\u81F3 12 \u5C0F\u65F6\uFF0C\u5E76\u4FDD\u7559\u539F\u68C0\u67E5\u622A\u6B62\u65F6\u95F4\u548C\u6267\u884C\u7248\u672C");
  } else if (schedule !== void 0) throw Error("\u539F\u7248\u56FA\u5B9A\u5224\u65AD\u95F4\u9694\u4E0D\u80FD\u81EA\u52A8\u8F6C\u6362\uFF0C\u8BF7\u65B0\u5EFA\u526F\u672C");
  if (![MIRROR_LOSS_THRESHOLD_VERSION, MIRROR_REVIEW_SCHEDULE_VERSION, MIRROR_REVIEW_ONCE_VERSION].some((v) => v === rule.mirrorDeadlineVersion) || !value || value.version !== MIRROR_LOSS_THRESHOLD_VERSION || !["percent", "usdt"].includes(value.unit) || !Number.isFinite(value.value) || value.value < 0) throw Error("\u4E8F\u635F\u95E8\u69DB\u987B\u4F7F\u7528\u4FDD\u7559\u7248\u672C\uFF0C\u5E76\u586B\u5199\u5927\u4E8E\u6216\u7B49\u4E8E 0 \u7684\u6709\u9650\u6570\u5B57\u53CA\u6709\u6548\u5355\u4F4D");
}
var MIRROR_LOSS_REVIEW_KIND, MIRROR_LOSS_REVIEW_VERSION, MIRROR_LOSS_THRESHOLD_VERSION, MIRROR_REVIEW_SCHEDULE_VERSION, MIRROR_PNL_THRESHOLD_VERSION, MIRROR_REVIEW_ONCE_VERSION, signedMirrorPnl, mirrorLossReviewSummary;
var init_qualityMirrorLossReview = __esm({
  "src/lib/fish/qualityMirrorLossReview.ts"() {
    init_qualityMirrorDeadline();
    init_qualityHoldingLedger();
    MIRROR_LOSS_REVIEW_KIND = "mirror-loss-review";
    MIRROR_LOSS_REVIEW_VERSION = "holding-mirror-loss-review-v2";
    MIRROR_LOSS_THRESHOLD_VERSION = "holding-mirror-loss-threshold-v3";
    MIRROR_REVIEW_SCHEDULE_VERSION = "holding-mirror-review-schedule-v4";
    MIRROR_PNL_THRESHOLD_VERSION = "holding-mirror-pnl-threshold-v6";
    MIRROR_REVIEW_ONCE_VERSION = "holding-mirror-review-once-v5";
    signedMirrorPnl = (value) => value > 0 ? "+" + value : String(value);
    mirrorLossReviewSummary = (hours, loss, schedule) => `${schedule?.intervalHours === null ? `\u6301\u4ED3 ${hours} \u5C0F\u65F6\u540E\u53EA\u68C0\u67E5\u4E00\u6B21` : `\u9996\u6B21 ${hours} \u5C0F\u65F6\uFF0C\u6B64\u540E\u6BCF ${schedule?.intervalHours ?? 0.5} \u5C0F\u65F6\u68C0\u67E5\u81F3 12 \u5C0F\u65F6`}\uFF1B\u672A\u955C\u50CF\u4E14${loss?.version === MIRROR_PNL_THRESHOLD_VERSION ? `\u6574\u7B14\u76C8\u4E8F < ${signedMirrorPnl(loss.value)}${loss.unit === "percent" ? "%" : " USDT"}` : loss && loss.value > 0 ? `\u4E8F\u635F\u8FBE\u5230 ${loss.value}${loss.unit === "percent" ? "%" : " USDT"}` : "\u6574\u7B14\u8D26\u9762\u76C8\u4E8F < 0"} \u65F6\u5E02\u4EF7\u6E05\u4ED3\uFF0C\u8FBE\u5230\u7EE7\u7EED\u6301\u6709\u6761\u4EF6\u65F6\u7EE7\u7EED\u89C2\u5BDF`;
  }
});

// src/lib/dbl5m.ts
function dbl5Parameters(input = {}) {
  for (const key of Object.keys(input)) if (!(key in DBL5_DEFAULTS) && !GUARD_KEYS.includes(key)) throw Error("DBL-5 \u672A\u77E5\u53C2\u6570\uFF1A" + key);
  const timeframe = input.timeframe ?? "5m";
  if (!Object.prototype.hasOwnProperty.call(DBL5_PROFILES, timeframe)) throw Error("DBL-5 \u7684\u5468\u671F\u65E0\u53EF\u7528\u5B9E\u73B0\uFF1A" + timeframe);
  const { minutes, label } = DBL5_PROFILES[timeframe];
  const p = { ...dbl5Defaults(timeframe), ...input }, W = p.window_minutes / minutes;
  for (const key of ["guard_trend_atr", "guard_range_atr"]) {
    const v = p[key];
    if (v !== void 0 && (!Number.isFinite(v) || v < 0 || v > 20)) throw Error("DBL-5 \u9632\u5B88\u7EBF\u5197\u4F59\u987B\u4E3A 0\u201320 \u500D ATR");
  }
  if (p.guard_range_closes !== void 0 && (!Number.isInteger(p.guard_range_closes) || p.guard_range_closes < 1 || p.guard_range_closes > 12)) throw Error("DBL-5 \u9707\u8361\u671F\u6536\u76D8\u786E\u8BA4\u987B\u4E3A 1\u201312 \u6839");
  if (p.guard_version !== void 0 && p.guard_version !== DBL5_RETEST_GUARD_VERSION) throw Error("DBL-5 \u9632\u5B88\u7EBF\u7248\u672C\u65E0\u53EF\u7528\u5B9E\u73B0\uFF1A" + p.guard_version);
  if (p.timeframe !== timeframe || !Number.isInteger(W) || W < 4 || W > 2016 || !Number.isInteger(p.n) || p.n < 1 || 2 * p.n + 1 >= W) {
    throw Error(timeframe !== "5m" ? `${label} \u7684\u7A97\u53E3\u987B\u4E3A ${4 * minutes}\u2013${2016 * minutes} \u5206\u949F\u4E14\u4E3A ${minutes} \u7684\u6574\u6570\u500D\uFF0C\u6EE1\u8DB3 2n+1<\u7A97\u53E3\u6839\u6570` : "DBL-5 \u9700\u8981\u56FA\u5B9A5m\uFF0C\u7A97\u53E320\u201310080\u5206\u949F\u4E14\u4E3A5\u7684\u6574\u6570\u500D\uFF0C\u6EE1\u8DB3 2n+1<W\uFF08\u9ED8\u8BA4n\u4E3A1\u201335\uFF09");
  }
  if (p.timeframe !== "5m" || p.guard_version === DBL5_RETEST_GUARD_VERSION) {
    return {
      timeframe: p.timeframe,
      n: p.n,
      window_minutes: p.window_minutes,
      ...p.guard_version ? { guard_version: p.guard_version } : {},
      guard_trend_atr: p.guard_trend_atr ?? DBL5_GUARD_DEFAULTS.guard_trend_atr,
      guard_range_atr: p.guard_range_atr ?? DBL5_GUARD_DEFAULTS.guard_range_atr,
      guard_range_closes: p.guard_range_closes ?? DBL5_GUARD_DEFAULTS.guard_range_closes
    };
  }
  return p;
}
function dbl5Hash(value) {
  const s = JSON.stringify(value), h = [2166136261, 608135816, 2242054355, 320440878];
  for (let i = 0; i < s.length; i++) for (let j = 0; j < h.length; j++) h[j] = Math.imul(h[j] ^ s.charCodeAt(i), 16777619 + j * 2);
  return h.map((v) => (v >>> 0).toString(16).padStart(8, "0")).join("");
}
function dbl5ConfigHash(input = {}) {
  const config = dbl5Parameters(input);
  return dbl5Hash([DBL5_PROFILES[config.timeframe].version, config]);
}
var DBL5_ID, DBL5_VERSION, DBL5_VARIANT_TIMEFRAMES, DBL5_PROFILES, dbl5ProfileForFeature, DBL5_DEFAULTS, dbl5Defaults, DBL5_GUARD_DEFAULTS, DBL5_GUARD_VERSION, DBL5_RETEST_GUARD_VERSION, dbl5GuardVersion, DBL5_GUARD_RETEST, GUARD_KEYS, DBL5_FIELDS, DBL5_RENDER_FIELDS;
var init_dbl5m = __esm({
  "src/lib/dbl5m.ts"() {
    DBL5_ID = "darvas_5m_lower";
    DBL5_VERSION = "dbl-5-v2";
    DBL5_VARIANT_TIMEFRAMES = ["1h", "4h", "15m"];
    DBL5_PROFILES = {
      "5m": { timeframe: "5m", id: DBL5_ID, version: DBL5_VERSION, label: "DBL-5-5mins", periodLabel: "5 \u5206\u949F", minutes: 5 },
      "1h": { timeframe: "1h", id: "darvas_1h_lower", version: "dbl-5-1h-v1", label: "DBL-5-1h", periodLabel: "1 \u5C0F\u65F6", minutes: 60 },
      "4h": { timeframe: "4h", id: "darvas_4h_lower", version: "dbl-5-4h-v1", label: "DBL-5-4h", periodLabel: "4 \u5C0F\u65F6", minutes: 240 },
      "15m": { timeframe: "15m", id: "darvas_15m_lower", version: "dbl-5-15m-v1", label: "DBL-5-15m", periodLabel: "15 \u5206\u949F", minutes: 15 }
    };
    dbl5ProfileForFeature = (id2) => Object.values(DBL5_PROFILES).find((profile) => profile.id === id2);
    DBL5_DEFAULTS = Object.freeze({ timeframe: "5m", n: 3, window_minutes: 360 });
    dbl5Defaults = (timeframe = "5m") => timeframe === "5m" ? DBL5_DEFAULTS : { timeframe, n: DBL5_DEFAULTS.n, window_minutes: 72 * DBL5_PROFILES[timeframe].minutes };
    DBL5_GUARD_DEFAULTS = Object.freeze({ guard_trend_atr: 0.5, guard_range_atr: 1, guard_trend_closes: 1, guard_range_closes: 2, overlap: 0.5, atr_period: 14 });
    DBL5_GUARD_VERSION = "dbl5-guard-v1";
    DBL5_RETEST_GUARD_VERSION = "dbl5-guard-v1-20261112";
    dbl5GuardVersion = (config) => config?.guard_version ?? DBL5_GUARD_VERSION;
    DBL5_GUARD_RETEST = Object.freeze({ nearAtr: 0.5, departureAtr: 1 });
    GUARD_KEYS = ["guard_trend_atr", "guard_range_atr", "guard_range_closes", "guard_version"];
    DBL5_FIELDS = ["DBL5", "DBL5_upper", "DBL5_available", "DBL5_distance_bps", "DBL5_width_bps", "DBL5_age_minutes", "DBL5_freshness", "DBL5_event_baseline", "DBL5_event_up_step", "DBL5_event_nested_higher_floor", "DBL5_event_same_floor", "DBL5_event_support_broken", "DBL5_event_support_expired", "DBL5_event_data_gap"];
    DBL5_RENDER_FIELDS = ["_DBL5_guard", "_DBL5_guard_trend", "_DBL5_guard_broken", "_DBL5_guard_segment", "_DBL5_episode", "_DBL5_box", "_DBL5_nested", "_DBL5_baseline", "_DBL5_up_step", "_DBL5_same_floor", "_DBL5_invalid", "_DBL5_warmup"];
  }
});

// src/lib/dbl5mMarketRules.ts
var DBL5_MARKET_RULE_VERSION, DBL5_TICK_CHANGES;
var init_dbl5mMarketRules = __esm({
  "src/lib/dbl5mMarketRules.ts"() {
    init_dbl5m();
    DBL5_MARKET_RULE_VERSION = "binance-usdm-ticks-20260427-v1";
    DBL5_TICK_CHANGES = [{
      symbol: "RAVEUSDT",
      effectiveAt: Date.UTC(2026, 3, 27, 6, 30),
      before: "0.00001",
      after: "0.0001",
      source: "https://www.binance.com/en/support/announcement/detail/bb0c704f3ca344c7a8741c551dd624ce"
    }];
  }
});

// src/lib/dbl5GuardPlus.ts
var DBL5_GUARD_PLUS_VERSION, DBL5_GUARD_PLUS_CONFIGURABLE_K_VERSION, DBL5_GUARD_PLUS_LABEL, IMPULSE_1115_POSITION_VERSION, IMPULSE_1115_CONFIGURABLE_K_VERSION, DBL5_1115_POSITION_RACE_VERSION, IMPULSE_1115_POSITION_LABEL, DBL5_GUARD_1115_DISPLAY_NAME, DBL5_GUARD_PLUS_DISPLAY_NAME, IMPULSE_1115_DISPLAY_NAME, DBL5_GUARD_PLUS_PARAMS, P, dbl5GuardPlusParams, DBL5_GUARD_PLUS_NUMERIC, DBL5_GUARD_PLUS_RENDER;
var init_dbl5GuardPlus = __esm({
  "src/lib/dbl5GuardPlus.ts"() {
    init_dbl5m();
    DBL5_GUARD_PLUS_VERSION = "dbl5-guard-impulse-1115-v1";
    DBL5_GUARD_PLUS_CONFIGURABLE_K_VERSION = "dbl5-guard-impulse-1115-v2";
    DBL5_GUARD_PLUS_LABEL = "DBL-5\u9632\u5B88\u7EBF+\u6025\u62C9-1115";
    IMPULSE_1115_POSITION_VERSION = "holding-impulse-1115-position-v1";
    IMPULSE_1115_CONFIGURABLE_K_VERSION = "holding-impulse-1115-position-v2";
    DBL5_1115_POSITION_RACE_VERSION = "holding-dbl5-1115-position-race-v1";
    IMPULSE_1115_POSITION_LABEL = "\u6025\u62C9\u7EBF-1115";
    DBL5_GUARD_1115_DISPLAY_NAME = "DBL-5-\u9632\u5B88\u7EBF-1115";
    DBL5_GUARD_PLUS_DISPLAY_NAME = "DBL-5-\u9632\u5B88\u7EBF+\u6025\u62C9\u7EBF-1115";
    IMPULSE_1115_DISPLAY_NAME = "DBL-5-\u6025\u62C9\u7EBF-1115";
    DBL5_GUARD_PLUS_PARAMS = Object.freeze({
      interval: "5m",
      atrPeriod: DBL5_GUARD_DEFAULTS.atr_period,
      windowBars: 3,
      referenceBars: 69,
      minIncrements: 14,
      halfLifeBars: 12,
      breakoutBars: 3,
      displacementAtr: 1.2,
      speedAtr: 0.8,
      speedMultiple: 1.5,
      efficiency: 0.65,
      retention: 0.8,
      maxExtensionAtr: 3,
      pauseBars: 2,
      pauseAtr: 1,
      bufferAtr: 0.5,
      expiryMinutes: 360,
      freshnessBars: 1
    });
    P = DBL5_GUARD_PLUS_PARAMS;
    dbl5GuardPlusParams = (impulseBufferAtr) => impulseBufferAtr === void 0 ? P : Object.freeze({ ...P, bufferAtr: impulseBufferAtr });
    DBL5_GUARD_PLUS_NUMERIC = [
      "DBL5P",
      "DBL5P_base",
      "DBL5P_impulse",
      "DBL5P_origin",
      "DBL5P_distance_bps",
      "DBL5P_early",
      "DBL5P_overextended",
      "DBL5P_broken",
      "DBL5P_expired",
      "DBL5P_wick",
      "DBL5P_phase_change"
    ];
    DBL5_GUARD_PLUS_RENDER = ["_DBL5P_segment", "_DBL5P_detected_origin", "_DBL5P_detected_bars", "_DBL5P_end"];
  }
});

// src/lib/impulse1115Classification.ts
var IMPULSE_1115_CLASSIFICATION_VERSION, IMPULSE_1115_CLASSIFICATION_CHART_ID, IMPULSE_1115_CLASSIFICATION_LABEL, IMPULSE_1115_CLASSIFICATION_DEFAULTS, IMPULSE_1115_STATUS, IMPULSE_1115_STATUS_CODES, IMPULSE_1115_CLASSIFICATION_FIELDS;
var init_impulse1115Classification = __esm({
  "src/lib/impulse1115Classification.ts"() {
    init_dbl5m();
    IMPULSE_1115_CLASSIFICATION_VERSION = "impulse-1115-holding-classification-v1";
    IMPULSE_1115_CLASSIFICATION_CHART_ID = "DBL5_IMPULSE_1115_STATES";
    IMPULSE_1115_CLASSIFICATION_LABEL = "DBL-5-\u6025\u62C9\u7EBF-1115 \xB7 \u6301\u4ED3\u5206\u7C7B";
    IMPULSE_1115_CLASSIFICATION_DEFAULTS = Object.freeze({
      nearAtr: DBL5_GUARD_RETEST.nearAtr,
      departureAtr: DBL5_GUARD_RETEST.departureAtr,
      pivotBars: 1,
      weakeningTests: 3,
      weakeningAtr: 0,
      breakCloses: DBL5_GUARD_DEFAULTS.guard_range_closes,
      reclaimCloses: DBL5_GUARD_DEFAULTS.guard_trend_closes,
      quickReclaimBars: 2
    });
    IMPULSE_1115_STATUS = {
      UNTESTED: "\u5EF6\u7EED\u672A\u56DE\u8E29 \xB7 \u5C1A\u672A\u53D7\u6D4B",
      ORIGIN_WAIT: "\u8D77\u70B9\u4E0B\u65B9\u8FD0\u884C\uFF0C\u7B49\u5F85\u56DE\u8E29\u6216\u6536\u590D",
      FIRST_TEST: "\u9996\u6B21\u56DE\u8E29\u4E2D\uFF0C\u7B49\u5F85\u5411\u4E0A\u786E\u8BA4",
      TESTING: "\u56DE\u8E29\u4E2D\uFF0C\u7B49\u5F85\u5411\u4E0A\u786E\u8BA4",
      REBOUND: "\u5DF2\u53CD\u5F39\uFF0C\u7B49\u5F85\u5C40\u90E8\u53CD\u5F39\u9AD8\u70B9\u7A81\u7834",
      HELD: "\u56DE\u8E29\u5B88\u4F4F\u5E76\u8F6C\u5F3A",
      WEAKENING: "\u53CD\u5F39\u51CF\u5F31",
      PIERCED: "\u5DF2\u523A\u7A7F\uFF0C\u7B49\u5F85\u5FEB\u901F\u6536\u56DE\u6216\u8DCC\u7834\u786E\u8BA4",
      QUICK_RECLAIM: "\u77ED\u6682\u523A\u7A7F\uFF0C\u8FC5\u901F\u6536\u56DE",
      SLOW_RECLAIM: "\u523A\u7A7F\u540E\u6536\u56DE\uFF0C\u7B49\u5F85\u518D\u6B21\u56DE\u8E29\u786E\u8BA4",
      BROKEN: "\u5DF2\u8DCC\u7834\uFF0C\u7B49\u5F85\u53CD\u62BD\u7ED3\u679C",
      BELOW_RETEST: "\u7EBF\u4E0B\u53CD\u62BD\u4E2D\uFF0C\u7B49\u5F85\u53CD\u62BD\u7ED3\u679C",
      FAILED_RETEST: "\u53CD\u62BD\u5931\u8D25",
      RECLAIMED: "\u5DF2\u6536\u590D\uFF0C\u7B49\u5F85\u79BB\u5F00\u540E\u518D\u6B21\u56DE\u8E29",
      REPAIR_TEST: "\u6536\u590D\u540E\u56DE\u8E29\u4E2D\uFF0C\u7B49\u5F85\u5B88\u4F4F\u786E\u8BA4",
      REPAIRED: "\u4FEE\u590D\u786E\u8BA4",
      DATA_GAP: "\u884C\u60C5\u4E0D\u8FDE\u7EED\uFF0C\u6682\u505C\u6B64\u7EBF\u5224\u5B9A"
    };
    IMPULSE_1115_STATUS_CODES = Object.keys(IMPULSE_1115_STATUS);
    IMPULSE_1115_CLASSIFICATION_FIELDS = [
      "DBL5C",
      "DBL5C_state",
      "DBL5C_status",
      "DBL5C_line",
      "DBL5C_reference",
      "DBL5C_tests",
      "DBL5C_pierced",
      "DBL5C_changed",
      "DBL5C_detected_at",
      "DBL5C_valid"
    ];
  }
});

// src/lib/sbs5m.ts
function sbsParameters(input = {}) {
  for (const k of Object.keys(input)) if (!(k in SBS5M_DEFAULTS)) throw new Error("SBS-5M \u672A\u77E5\u53C2\u6570\uFF1A" + k);
  const p = { ...SBS5M_DEFAULTS, ...input };
  if (p.bar_interval !== "5m" || !["quote", "base_times_close"].includes(p.volume_mode)) throw new Error("SBS-5M \u4EC5\u652F\u6301\u5DF2\u6536\u76D85m\u4E0E\u660E\u786E\u6210\u4EA4\u989D\u6A21\u5F0F");
  for (const s of SBS5M_PARAMETER_SPECS) {
    const v = p[s.key];
    if (!Number.isFinite(v) || v < s.min || v > s.max || s.integer && !Number.isInteger(v)) throw new Error("SBS-5M \u53C2\u6570\u8D8A\u754C\uFF1A" + s.key);
  }
  return p;
}
function hash(s) {
  const h = [2166136261, 608135816, 2242054355, 320440878];
  for (let i = 0; i < s.length; i++) for (let j = 0; j < h.length; j++) h[j] = Math.imul(h[j] ^ s.charCodeAt(i), 16777619 + j * 2);
  return h.map((x) => (x >>> 0).toString(16).padStart(8, "0")).join("");
}
var SBS5M_ID, SBS5M_VERSION, SBS5M_DEFAULTS, SBS5M_PARAMETER_SPECS, canonical, sbsConfigHash, SBS5M_FIELDS;
var init_sbs5m = __esm({
  "src/lib/sbs5m.ts"() {
    SBS5M_ID = "sbs_5m";
    SBS5M_VERSION = "sbs-5m-v1";
    SBS5M_DEFAULTS = Object.freeze({
      bar_interval: "5m",
      volume_mode: "quote",
      box_formation_bars: 6,
      volatility_lookback_bars: 24,
      volatility_half_life: 30,
      box_min_width_ticks: 4,
      box_max_width_scale: 2,
      box_max_efficiency_ratio: 0.5,
      formation_max_lower_wick_scale: 1.5,
      touch_band_scale: 0.25,
      touch_band_width_fraction: 0.25,
      invalidation_buffer_scale: 0.5,
      candidate_max_age: 60,
      active_box_max_age: 6,
      test_max_bars: 3,
      turnover_reference_bars: 12,
      turnover_reference_half_life: 30,
      test_min_turnover_ratio: 0.25,
      breakout_buffer_scale: 0.1,
      breakout_confirm_bars: 2,
      step_min_raise_ticks: 2,
      step_min_raise_scale: 0.1,
      quality_lookback: 60,
      quality_half_life: 30,
      test_freshness_half_life: 60
    });
    SBS5M_PARAMETER_SPECS = [
      { key: "box_formation_bars", label: "\u7BB1\u4F53\u5F62\u6210", unit: "\u6839", min: 2, max: 288, integer: true, description: "\u6574\u4E2A\u5F62\u6210\u533A\u95F4\u987B\u665A\u4E8E\u4E0A\u6B21\u7EC8\u6B62\u6216\u7236\u7BB1\u7A81\u7834\u3002" },
      { key: "volatility_lookback_bars", label: "\u4E8B\u524D\u6CE2\u52A8\u7A97\u53E3", unit: "\u6839", min: 2, max: 2016, integer: true, description: "\u4EC5\u7528\u5F53\u524D\u6839\u4E4B\u524D\u7684\u6709\u9650\u7A97\u53E3\u771F\u5B9E\u6CE2\u5E45\u3002" },
      { key: "volatility_half_life", label: "\u6CE2\u52A8\u534A\u8870\u671F", unit: "\u5206\u949F", min: 1, max: 10080, description: "\u6309\u5B9E\u9645\u65F6\u95F4\u5DEE\u6307\u6570\u52A0\u6743\uFF0C\u975E\u9ED8\u8BA4 ATR\u3002" },
      { key: "box_min_width_ticks", label: "\u6700\u5C0F\u7BB1\u5BBD", unit: "tick", min: 4, max: 1e4, integer: true, description: "\u81F3\u5C114\u4E2A\u6700\u5C0F\u4EF7\u683C\u5355\u4F4D\uFF0C\u907F\u514D\u6D4B\u8BD5\u5E26\u8986\u76D6\u6D45\u7BB1\u3002" },
      { key: "box_max_width_scale", label: "\u6700\u5927\u7BB1\u5BBD", unit: "\u4E8B\u524D\u5C3A\u5EA6", min: 0.01, max: 100, description: "\u7BB1\u5BBD\u4E0D\u5F97\u8D85\u8FC7\u51BB\u7ED3\u4E8B\u524D\u5C3A\u5EA6\u7684\u8BE5\u500D\u6570\u3002" },
      { key: "box_max_efficiency_ratio", label: "\u6700\u5927\u8DEF\u5F84\u6548\u7387", unit: "\u6BD4\u4F8B", min: 0, max: 1, description: "\u5355\u5411\u4E0A\u6DA8\u4E0D\u80FD\u4EC5\u56E0\u8303\u56F4\u7A84\u800C\u5F62\u6210\u7BB1\u4F53\u3002" },
      { key: "formation_max_lower_wick_scale", label: "\u5F62\u6210\u4E0B\u9488\u4E0A\u9650", unit: "\u5404\u6839\u4E8B\u524D\u5C3A\u5EA6", min: 0.01, max: 100, description: "\u4E25\u683C\u5C0F\u4E8E\uFF1B\u5404\u6839\u5404\u7528\u81EA\u5DF1\u7684\u4E8B\u524D\u5C3A\u5EA6\u3002" },
      { key: "touch_band_scale", label: "\u6D4B\u8BD5\u5E26\u5C3A\u5EA6", unit: "\u51BB\u7ED3\u5C3A\u5EA6", min: 1e-3, max: 1, description: "\u4E0E\u7BB1\u5BBD\u7EA6\u675F\u540C\u65F6\u53D6\u8F83\u5C0F\u503C\uFF0C\u518D\u81F3\u5C111 tick\u3002" },
      { key: "touch_band_width_fraction", label: "\u6D4B\u8BD5\u5E26\u7BB1\u5BBD\u5360\u6BD4", unit: "\u6BD4\u4F8B", min: 1e-3, max: 0.25, description: "\u6700\u591A\u7BB1\u5BBD\u56DB\u5206\u4E4B\u4E00\u3002" },
      { key: "invalidation_buffer_scale", label: "\u5931\u6548\u7F13\u51B2", unit: "\u51BB\u7ED3\u5C3A\u5EA6", min: 0.01, max: 100, description: "\u51BB\u7ED3\u540E\u4E0D\u4E0B\u79FB\uFF0C\u4E0D\u81EA\u52A8\u4FEE\u6539\u5B9E\u9645\u6B62\u635F\u3002" },
      { key: "candidate_max_age", label: "\u5019\u9009\u5BFF\u547D", unit: "\u5206\u949F", min: 5, max: 10080, description: "\u8FBE\u5230\u671F\u9650\u5373\u7EC8\u6B62\uFF0C\u4F18\u5148\u4E8E\u5F53\u6839\u786E\u8BA4\u3002" },
      { key: "active_box_max_age", label: "\u6709\u6548\u652F\u6491\u5BFF\u547D", unit: "\u5C0F\u65F6", min: 1 / 12, max: 168, description: "\u4ECE\u6B63\u5F0F\u786E\u8BA4\u8BA1\u65F6\uFF0C\u518D\u6B21\u6D4B\u8BD5\u4E0D\u7EED\u671F\u3002" },
      { key: "test_max_bars", label: "\u6D4B\u8BD5\u6062\u590D\u671F\u9650", unit: "\u6839\uFF08\u542B\u89E6\u78B0\uFF09", min: 1, max: 288, integer: true, description: "\u6700\u540E\u4E00\u6839\u5148\u68C0\u67E5\u6062\u590D\uFF0C\u518D\u5224\u8D85\u65F6\u3002" },
      { key: "turnover_reference_bars", label: "\u6210\u4EA4\u989D\u57FA\u51C6", unit: "\u6839", min: 1, max: 2016, integer: true, description: "\u53EA\u4F7F\u7528\u89E6\u78B0\u6839\u4E4B\u524D\u7684\u6210\u4EA4\u989D\u3002" },
      { key: "turnover_reference_half_life", label: "\u6210\u4EA4\u989D\u534A\u8870\u671F", unit: "\u5206\u949F", min: 1, max: 10080, description: "\u6309\u5B9E\u9645\u65F6\u95F4\u5DEE\u52A0\u6743\uFF0C\u4E0D\u80FD\u9010\u6839\u5207\u6362\u6210\u4EA4\u53E3\u5F84\u3002" },
      { key: "test_min_turnover_ratio", label: "\u6700\u5C0F\u6210\u4EA4\u6D3B\u52A8", unit: "\u57FA\u51C6\u500D\u6570", min: 0, max: 100, description: "\u771F\u5B9E\u6210\u4EA4\u989D\u5FC5\u987B\u4E3A\u6B63\uFF0C\u4E0D\u628A\u805A\u5408K\u7EBF\u89E3\u91CA\u4E3A\u8BA2\u5355\u5438\u6536\u3002" },
      { key: "breakout_buffer_scale", label: "\u7A81\u7834\u7F13\u51B2", unit: "\u51BB\u7ED3\u5C3A\u5EA6", min: 0, max: 100, description: "\u81F3\u5C111 tick\uFF1B\u53EA\u5728\u786E\u8BA4\u4E4B\u540E\u7684\u6536\u76D8\u8BA1\u6570\u3002" },
      { key: "breakout_confirm_bars", label: "\u7A81\u7834\u786E\u8BA4", unit: "\u8FDE\u7EED\u6536\u76D8\u6839\u6570", min: 1, max: 288, integer: true, description: "\u4E0D\u7EE7\u627F\u7236\u7BB1\u7A81\u7834\u8BA1\u6570\u6216\u65F6\u95F4\u3002" },
      { key: "step_min_raise_ticks", label: "\u6700\u5C0F\u62AC\u5347", unit: "tick", min: 1, max: 1e4, integer: true, description: "\u8FD8\u987B\u6EE1\u8DB3\u5C3A\u5EA6\u62AC\u5347\u3001\u7BB1\u9876\u4E0E\u5931\u6548\u53C2\u8003\u5747\u63D0\u9AD8\u3002" },
      { key: "step_min_raise_scale", label: "\u6700\u5C0F\u5C3A\u5EA6\u62AC\u5347", unit: "\u65B0\u51BB\u7ED3\u5C3A\u5EA6", min: 0, max: 100, description: "\u4E0D\u56E0\u65E7\u4F4E\u70B9\u6EDA\u51FA\u7A97\u53E3\u81EA\u52A8\u62AC\u5347\u3002" },
      { key: "quality_lookback", label: "\u5B88\u4F4F\u8BC1\u636E\u7A97\u53E3", unit: "\u5206\u949F", min: 5, max: 10080, description: "\u5DE6\u5F00\u53F3\u95ED\uFF1B\u96F6\u6210\u4EA4\u4E0D\u589E\u52A0\u5B88\u4F4F\u8BC1\u636E\u3002" },
      { key: "quality_half_life", label: "\u5B88\u4F4F\u8BC1\u636E\u534A\u8870\u671F", unit: "\u5206\u949F", min: 1, max: 10080, description: "\u4E0D\u6539\u53D8\u7D2F\u8BA1\u6700\u5927\u7A7F\u900F\u3002" },
      { key: "test_freshness_half_life", label: "\u6D4B\u8BD5\u65B0\u9C9C\u5EA6\u534A\u8870\u671F", unit: "\u5206\u949F", min: 1, max: 10080, description: "\u4EC5\u6210\u529F\u5B8C\u6210\u7684\u72EC\u7ACB\u6D4B\u8BD5\u5237\u65B0\u3002" }
    ];
    canonical = (v) => JSON.stringify(v, (_k, x) => x && typeof x === "object" && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, x[k]])) : x);
    sbsConfigHash = (p = {}) => hash(canonical([SBS5M_VERSION, sbsParameters(p)]));
    SBS5M_FIELDS = ["SBS5M", "SBS5M_episode_token", "SBS5M_candidate_token", "SBS5M_support_price", "SBS5M_box_top", "SBS5M_invalidation_price", "SBS5M_support_quality", "SBS5M_distance_to_support", "SBS5M_step_height_atr", "SBS5M_step_event_height", "SBS5M_candidate_support_price", "SBS5M_candidate_box_top", "SBS5M_candidate_invalidation_price", "SBS5M_scale_before", "SBS5M_frozen_at", "SBS5M_confirmed_at", "SBS5M_breakout_at", "SBS5M_last_successful_test_at", "SBS5M_invalidated_at", "SBS5M_expired_at"];
  }
});

// src/lib/prs6h.ts
var PRS6H_ID, PRS6H_VERSION, PRS6H_FIELDS;
var init_prs6h = __esm({
  "src/lib/prs6h.ts"() {
    PRS6H_ID = "prs_intraday_add_evidence_6h";
    PRS6H_VERSION = "v1";
    PRS6H_FIELDS = ["PRS6H", "PRS6H_evidence_raw", "PRS6H_T", "PRS6H_S", "PRS6H_D", "PRS6H_B", "PRS6H_V", "PRS6H_market_ready", "PRS6H_support", "PRS6H_platform_upper", "PRS6H_invalidation", "PRS6H_frozen_at", "PRS6H_test_started_at", "PRS6H_test_completed_at", "PRS6H_breakout_at", "PRS6H_scale_before", "PRS6H_max_wick", "PRS6H_max_shock", "PRS6H_scan_to", "PRS6H_state_code"];
  }
});

// src/lib/tradeHistoryStorage.ts
function decode(key, stored) {
  const [id2, start, end, replacement] = JSON.parse(stored.slice(prefix.length));
  const base = bases.get(key);
  if (!base || base.id !== id2 || !Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || end > base.raw.length || typeof replacement !== "string") {
    throw Error("\u4EA4\u6613\u5386\u53F2\u7684\u672C\u673A\u539F\u6587\u5C1A\u672A\u6838\u9A8C");
  }
  return base.raw.slice(0, start) + replacement + base.raw.slice(end);
}
function readHistoryAwareStorage(key) {
  const stored = localStorage.getItem(key);
  return historyKey.test(key) && stored?.startsWith(prefix) ? decode(key, stored) : stored;
}
var prefix, historyKey, bases;
var init_tradeHistoryStorage = __esm({
  "src/lib/tradeHistoryStorage.ts"() {
    prefix = "@veil/history/1:";
    historyKey = /^sim_[^_]+_(trade_history|cancelled_orders|filled_orders|trade_campaigns|campaign_counterfactuals)$/;
    bases = /* @__PURE__ */ new Map();
  }
});

// src/lib/persistedStateStorage.ts
function readPersistedStateRaw(fullKey) {
  const latest = unpersisted.get(fullKey);
  if (latest !== void 0) return latest.raw;
  try {
    return readHistoryAwareStorage(fullKey);
  } catch {
    return null;
  }
}
var unpersisted, STORAGE_RESERVE_CHARS, REBUILDABLE_CACHE_BUDGET_CHARS, AUTH_TOKEN_ROOM_CHARS, lastReserveCheckAt;
var init_persistedStateStorage = __esm({
  "src/lib/persistedStateStorage.ts"() {
    init_tradeHistoryStorage();
    unpersisted = /* @__PURE__ */ new Map();
    STORAGE_RESERVE_CHARS = 128 * 1024;
    REBUILDABLE_CACHE_BUDGET_CHARS = 1024 * 1024;
    AUTH_TOKEN_ROOM_CHARS = 8 * 1024;
    lastReserveCheckAt = Number.NEGATIVE_INFINITY;
  }
});

// src/lib/loginStorage.ts
function loginStorage() {
  return isolatedKey ? sessionStorage : localStorage;
}
var isolatedKey;
var init_loginStorage = __esm({
  "src/lib/loginStorage.ts"() {
    init_persistedStateStorage();
  }
});

// src/lib/userStoragePrefix.ts
function getUserId() {
  try {
    const storage = loginStorage();
    let raw = sessionKey ? storage.getItem(sessionKey) : null;
    if (raw === null) {
      sessionKey = Object.keys(storage).find((key) => key.startsWith("sb-") && key.endsWith("-auth-token"));
      raw = sessionKey ? storage.getItem(sessionKey) : null;
    }
    if (raw !== sessionSnapshot) {
      sessionSnapshot = raw;
      sessionUserId = null;
      if (raw) {
        const id2 = JSON.parse(raw)?.user?.id;
        if (typeof id2 === "string" && id2) sessionUserId = id2;
      }
    }
    return sessionUserId;
  } catch {
    return null;
  }
}
function getUserPrefix(userId = getUserId()) {
  return userId ? `sim_${userId}_` : "sim_anon_";
}
var sessionKey, sessionSnapshot, sessionUserId;
var init_userStoragePrefix = __esm({
  "src/lib/userStoragePrefix.ts"() {
    init_loginStorage();
    sessionSnapshot = null;
    sessionUserId = null;
  }
});

// src/lib/ati6h.ts
var ATI6H_VERSION, ATI6H_NUMERIC_FIELDS;
var init_ati6h = __esm({
  "src/lib/ati6h.ts"() {
    ATI6H_VERSION = "ati6h-v1";
    ATI6H_NUMERIC_FIELDS = ["ATI6H", "ATI6H_sA", "ATI6H_sB", "ATI6H_sC", "ATI6H_sD", "ATI6H_sE", "ATI6H_sF", "ATI6H_min", "ATI6H_s_CP", "ATI6H_s_CV", "ATI6H_U_P", "ATI6H_D_P", "ATI6H_U_V", "ATI6H_D_V", "ATI6H_downside_rms", "ATI6H_W_D", "ATI6H_raw_max_wick", "ATI6H_raw_max_wick_at", "ATI6H_weighted_worst_wick_at", "ATI6H_initial_support_evidence", "ATI6H_best_retest_evidence", "ATI6H_support_position_factor", "ATI6H_support_price", "ATI6H_support_zone_lower", "ATI6H_support_zone_upper", "ATI6H_support_failure_price", "ATI6H_pre_adjustment_high", "ATI6H_breakout_price", "ATI6H_nearest_resistance_price", "ATI6H_nearest_resistance_breakout_price", "ATI6H_breakout_first_observed_at", "ATI6H_structure_confirmed_at", "ATI6H_high_anchor_at", "ATI6H_low_anchor_at", "ATI6H_v_0", "ATI6H_delta_S", "ATI6H_delta_H", "ATI6H_touch_at", "ATI6H_retest_confirmed_at", "ATI6H_structure_status_code"];
  }
});

// src/lib/mbi2.ts
var MBI2_Z0, MBI2_TOOLTIP, MBI2_BAND, MBI2_CONFIRM, MBI2_T_HOURS, mbi2HoursOf, mbi2NOf, mbi2Z0Of, mbi2BandOf, mbi2ConfirmOf;
var init_mbi2 = __esm({
  "src/lib/mbi2.ts"() {
    MBI2_Z0 = 1.25;
    MBI2_TOOLTIP = "MBI2\uFF1A\u72EC\u7ACB\u4EF7\u683C\u9012\u63A8\uFF0C\u6309\u5C0F\u65F6\u6362\u7B97 n\uFF1B0\u4E3A\u5747\u8861\uFF0C\u7A7F\u8FC7\xB1\u7F13\u51B2\u5E26\u5F00\u59CB\u8BD5\u63A2\uFF0C\u8D8A\u8FC7\u786E\u8BA4\u9608\u503C\u540E\u4FDD\u6301\u786E\u8BA4\uFF0C\u76F4\u5230\u7A7F\u8FC7\u5BF9\u4FA7\u7F13\u51B2\u5E26\u3002\u53EA\u7528\u5DF2\u6536\u76D8\u4EF7\u683C\uFF0C\u9884\u70ED\u548C\u7F3A\u5931\u4FDD\u6301\u4E3A\u7A7A\u3002";
    MBI2_BAND = 0.2;
    MBI2_CONFIRM = 0.8;
    MBI2_T_HOURS = 25 * 5 / 60;
    mbi2HoursOf = (p = {}, minutes = 5) => p.MBI2_T_HOURS ?? 25 * minutes / 60;
    mbi2NOf = (p = {}, minutes = 5) => Math.max(5, Math.round(mbi2HoursOf(p, minutes) * 60 / minutes));
    mbi2Z0Of = (p = {}) => p.MBI2_Z0 ?? MBI2_Z0;
    mbi2BandOf = (p = {}) => p.MBI2_BAND ?? MBI2_BAND;
    mbi2ConfirmOf = (p = {}) => p.MBI2_CONFIRM ?? MBI2_CONFIRM;
  }
});

// src/lib/sellerRetention.ts
function retentionFormula(source, baseExpression, core, bound, windowHours = 48) {
  let p = "sr";
  while (new RegExp("\\b" + p + "_").test(source)) p += "_";
  const n = (key) => p + "_" + key;
  const lines = [
    "# seller-retention-v1\uFF1A\u5148\u51BB\u7ED3\u8F93\u5165\uFF0C\u518D\u539F\u6837\u8BA1\u7B97\u526F\u672C\u7684\u539F\u7B97\u6CD5\uFF1B\u4E0D\u8BFB\u53D6\u539F\u7279\u5F81\u7ED3\u679C\u6216\u9012\u63A8\u72B6\u6001",
    `${n("time")} = T`,
    `${n("c")} = C`,
    `${n("e")} = E`,
    `${n("q")} = Q`,
    `${n("b")} = B`,
    `${n("s")} = S`,
    `${n("minutes")} = BAR_MINUTES`,
    source,
    `${n("base")} = ${baseExpression}`,
    "# \u4EE5\u4E0B\u53C2\u6570\u4EC5\u5C5E\u4E8E\u672C\u526F\u672C\u3002gain=0\u65F6\u9010\u6839\u8FD4\u56DE\u539F\u7B97\u6CD5\uFF1B\u7A97\u53E3\u4E0D\u7F29\u77ED\uFF0C\u589E\u5F3A\u5728\u6700\u7EC8\u538B\u7F29\u524D\u8FDB\u884C",
    `${n("version")} = 1`,
    `${n("gain")} = 0.5`,
    `${n("window_h")} = ${windowHours}`,
    `${n("eta")} = 0.5`,
    `${n("alpha")} = 1`,
    `${n("impact_weight")} = 0.25`,
    `${n("flow_floor")} = 0.05`,
    `${n("sigma_floor")} = 0.000001`,
    `${n("epsilon")} = 0.000000000001`,
    `${n("window_n")} = bars(${n("window_h")})`,
    `${n("baseline_n")} = bars(avgh)`,
    `${n("parameters")} = if(${n("gain")} >= 0 and ${n("eta")} >= 0 and ${n("eta")} <= 1 and ${n("alpha")} >= 0 and ${n("impact_weight")} >= 0 and ${n("flow_floor")} > 0 and ${n("sigma_floor")} > 0 and ${n("epsilon")} > 0, 1, 0/0)`,
    `${n("valid")} = if(has(${n("parameters")}) and ${n("q")} > 0 and ${n("b")} >= 0 and ${n("s")} >= 0 and ${n("e")} > 0 and ${n("c")} > 0 and ${n("time")} - prev(${n("time")}) == ${n("minutes")} * 60000, 1, 0/0)`,
    `${n("r")} = if(has(${n("valid")}), ln(${n("e")} / prev(${n("e")})), 0/0)`,
    `${n("vbar")} = if(has(prev(full(${n("valid")}, ${n("baseline_n")}))), prev(avg(${n("q")}, avgh)), 0/0)`,
    `${n("sigma")} = if(has(prev(full(${n("r")}, ${n("baseline_n")}))), prev(sd(${n("r")}, avgh)), 0/0)`,
    `${n("denom")} = max(${n("sigma")}, ${n("sigma_floor")}) + ${n("epsilon")}`,
    `${n("flow")} = (${n("b")} - ${n("s")}) / ${n("q")}`,
    `${n("support")} = ln(1 + (abs(${n("b")} - ${n("s")}) + ${n("eta")} * (${n("q")} - abs(${n("b")} - ${n("s")}))) / ${n("vbar")})`,
    `${n("impact")} = -max(-${n("r")}, 0) / (${n("denom")} * (abs(${n("flow")}) + ${n("flow_floor")}))`,
    `${n("weight")} = ${n("support")} * (1 + ${n("alpha")} * max(-${n("flow")}, 0)) * (1 + ${n("impact_weight")} * max(-${n("flow")}, 0) * tanh(-${n("impact")}))`,
    `${n("ready")} = full(if(has(${n("valid")}) and has(${n("weight")}) and has(${n("sigma")}), 1, 0/0), ${n("window_n")})`,
    `${n("price")} = max(${n("e")}, ${n("c")})`,
    "# retain\u6BCF\u6839\u7528\u5F53\u524Dprice\u91CD\u4F30\u8FC7\u53BB\u5404\u65F6\u70B9\u4F4D\u79FB\uFF1B\u4E0B\u79FB\u672A\u6536\u590D\u4E3A\u8D1F\uFF0C\u6536\u590D\u540E\u56DE\u5347\uFF0C\u96F6\u70B9\u4E0D\u968F\u6837\u672C\u5E73\u79FB",
    `${n("retention_z")} = if(has(${n("ready")}), retain(${n("weight")}, ${n("price")}, prev(${n("e")}), hl, ${n("window_h")}) / ${n("denom")}, 0/0)`,
    `${n("price_z")} = if(has(${n("ready")}), retain(1, ${n("price")}, prev(${n("e")}), hl, ${n("window_h")}) / ${n("denom")}, 0/0)`,
    `${n("anomaly_z")} = if(has(${n("valid")}), ln(${n("price")} / prev(${n("e")})) / ${n("denom")}, 0/0)`
  ];
  const b = n("base"), z = n("retention_z"), g = n("gain");
  if (bound) {
    lines.push(`${n("base_unit")} = clip(${b} / ${bound}, -1 + ${n("epsilon")}, 1 - ${n("epsilon")})`, `${n("base_z")} = 0.5 * ln((1 + ${n("base_unit")}) / (1 - ${n("base_unit")}))`);
    lines.push(`${core} = if(${g} == 0, ${b}, if(has(${b}) and has(${z}) and abs(${b}) <= ${bound}, ${bound} * tanh(${n("base_z")} + ${g} * ${z}), 0/0))`);
  } else lines.push(`${core} = if(${g} == 0, ${b}, if(has(${b}) and has(${z}), ${b} + ${g} * ${z}, 0/0))`);
  return { formula: lines.join("\n"), prefix: p };
}
var SELLER_RETENTION_SPECS, retentionComponents;
var init_sellerRetention = __esm({
  "src/lib/sellerRetention.ts"() {
    SELLER_RETENTION_SPECS = [
      { sourceId: "cdi2", label: "CDI2", id: "cdi2-retain", core: "CDI2_retained", sourceCore: "CDI2", chartId: "CDI2_RETAIN", bound: 1 },
      { sourceId: "seller-control", label: "DSP\xB7bc", id: "seller-control-retain", core: "bc_retained", sourceCore: "bc", chartId: "SELLER_CONTROL_RETAIN", bound: 0 },
      { sourceId: "dss", label: "DSS", id: "dss-retain", core: "DSS_retained", sourceCore: "DSS", chartId: "DSS_RETAIN", bound: 1 },
      { sourceId: "mbi-bear", label: "MBI\xB7\u7A7A\u65B9", id: "mbi-bear-retain", core: "MBI_bear_retained", sourceCore: "MBI_bear", chartId: "MBI_BEAR_RETAIN", bound: 1 },
      { sourceId: "ctba-bear", label: "CTBA\xB7\u7A7A\u65B9", id: "ctba-bear-retain", core: "CTBA_bear_retained", sourceCore: "CTBA_bear", chartId: "CTBA_BEAR_RETAIN", bound: 100 },
      { sourceId: "mbi2-bear", label: "MBI2\xB7\u5356\u65B9", id: "mbi2-bear-retain", core: "MBI2_bear_retained", sourceCore: "MBI2_bear", chartId: "MBI2_BEAR_RETAIN", bound: 1 },
      { sourceId: "ctba_12h-bear", label: "CTBA-12H\xB7\u5356\u65B9", id: "ctba_12h-bear-retain", core: "CTBA_12H_bear_retained", sourceCore: "CTBA_12H_bear", chartId: "CTBA_12H_BEAR_RETAIN", bound: 100 }
    ];
    retentionComponents = (p = "sr") => ["base", "retention_z", "price_z", "support", "flow", "impact", "anomaly_z"].map((n) => p + "_" + n);
  }
});

// src/lib/mbi.ts
var MBI_N, MBI_Z0, MBI_TOOLTIP, mbiNOf, mbiZ0Of;
var init_mbi = __esm({
  "src/lib/mbi.ts"() {
    MBI_N = 25;
    MBI_Z0 = 1.25;
    MBI_TOOLTIP = "MBI\uFF1A\u4EF7\u683C\u504F\u79BB\u6307\u6570\u5747\u7EBF\u591A\u5C11\u4E2A\u65E0\u8D8B\u52BF\u6807\u51C6\u5DEE\uFF0C\u7ECF tanh \u538B\u5230 \u22121 \u5230 1\u3002\u2265 0.8\uFF1A\u4E70\u65B9\u5360\u4F18\u786E\u7ACB\uFF08\u65E0\u8D8B\u52BF\u65F6\u7EA6 8.5% \u7684 K \u7EBF\u80FD\u8FBE\u5230\uFF09\uFF1B0.5\u20130.8\uFF1A\u504F\u5411\u4E70\u65B9\uFF1B\u22120.5\u20130.5\uFF1A\u65E0\u660E\u663E\u4F18\u52BF\uFF1B\u2264 \u22120.8\uFF1A\u5356\u65B9\u5360\u4F18\u3002\u63A5\u8FD1 \xB11 \u662F\u9971\u548C\uFF0C\u4E0D\u4EE3\u8868\u53CD\u8F6C\u3002";
    mbiNOf = (params = {}) => params.MBI_N ?? MBI_N;
    mbiZ0Of = (params = {}) => params.MBI_Z0 ?? MBI_Z0;
  }
});

// src/lib/recentFocusMath.ts
var FOCUS_BASE_ARITIES;
var init_recentFocusMath = __esm({
  "src/lib/recentFocusMath.ts"() {
    init_mbi();
    init_mbi2();
    FOCUS_BASE_ARITIES = { avg: [2], sd: [2], zscore: [2], ema: [2, 3], retain: [4, 5], wsum: [3], rsum: [2], median: [2], mad: [2], rscale: [2], sma: [2], sum: [2], msum: [2], atr: [4], beta: [3], mbiz: [2], mbiz2: [2], ctba: [17] };
  }
});

// src/lib/ctba.ts
function validateCtba(p) {
  for (const k of ["N", "f", "s", "m"]) if (!Number.isSafeInteger(p[k]) || p[k] < (k === "m" ? 2 : 1)) throw Error("CTBA " + k + " \u5FC5\u987B\u4E3A\u6709\u6548\u6B63\u6574\u6570\uFF08m \u2265 2\uFF09");
  if (p.f >= p.s) throw Error("CTBA \u5FC5\u987B\u6EE1\u8DB3 f < s");
  if (!Number.isFinite(p.lambda) || p.lambda < 0 || !Number.isFinite(p.epsilon) || p.epsilon <= 0) throw Error("CTBA \u8981\u6C42 \u03BB \u2265 0\uFF0C\u03B5 > 0");
  if (![p.alpha, p.beta, p.gamma].every((v) => Number.isFinite(v) && v >= 0) || Math.abs(p.alpha + p.beta + p.gamma - 1) > 1e-12) throw Error("CTBA \u6743\u91CD\u5FC5\u987B\u975E\u8D1F\u4E14\u5408\u8BA1\u4E3A 1");
}
function ctbaFormula(p = { ...CTBA_DEFAULTS }) {
  validateCtba(p);
  const args = "C,H,L,E,B,S,clock,N,f,s,m,lambda,epsilon,alpha,ctba_beta,gamma";
  return [
    "# CTBA v1\uFF1A5m \u5DF2\u6536\u76D8\uFF1B\u53C2\u6570\u4EE5\u6839\u8BA1\uFF1B\u771F\u5B9E E=\u6210\u4EA4\u91D1\u989D/\u6210\u4EA4\u6570\u91CF",
    ...Object.entries(p).map(([k, v]) => (k === "beta" ? "ctba_beta" : k) + " = " + v + (k === "beta" ? " # \u03B2\uFF1A\u8D8B\u52BF\u52A8\u80FD\u6743\u91CD" : "")),
    "ctba_version = 1",
    "# EMA \u03B1=2/(k+1)\uFF0C\u4ECE\u9996\u4E2A\u6709\u6548 ln(E) \u8D77\u7B97\uFF0C\u8FDE\u7EED 5s \u6839\u9884\u70ED\uFF1BStd \u4F7F\u7528\u6837\u672C\u6807\u51C6\u5DEE\uFF08m\u22121\uFF09",
    "clock = T",
    ...["T", "M", "F", "no_trade", "data_complete", "CTBA"].map((name, i) => name + " = ctba(" + args + "," + [0, 1, 2, 4, 5, 3][i] + ")")
  ].join("\n");
}
var CTBA_DEFAULTS, CTBA_12H_DEFAULTS, CTBA_ABSOLUTE_BOUND, CTBA_DESCRIPTION;
var init_ctba = __esm({
  "src/lib/ctba.ts"() {
    init_recentFocusMath();
    CTBA_DEFAULTS = { N: 576, f: 12, s: 48, m: 48, lambda: Math.LN2 / 144, epsilon: 1e-12, alpha: 0.35, beta: 0.4, gamma: 0.25 };
    CTBA_12H_DEFAULTS = Object.freeze({ N: 144, f: 8, s: 24, m: 48, lambda: Math.LN2 / 24, epsilon: 1e-12, alpha: 0.35, beta: 0.4, gamma: 0.25 });
    CTBA_ABSOLUTE_BOUND = 100 * Math.tanh(1);
    CTBA_DESCRIPTION = "CTBA\uFF5C\u8D8B\u52BF\u4E70\u65B9\u4F18\u52BF\uFF1A100\xB7tanh[\u03B1\xB7tanh(T)+\u03B2\xB7tanh(M)+\u03B3\xB7F]\u3002T \u4E3A\u4E0D\u542B\u5F53\u6839\u7684\u5386\u53F2\u533A\u95F4\u4F4D\u7F6E\uFF08\u4E0D\u622A\u65AD\uFF09\uFF0CM \u4E3A\u771F\u5B9E VWAP \u5BF9\u6570\u7684\u5FEB\u6162 EMA \u5DEE\u9664\u4EE5\u8FD1\u671F\u6536\u76CA\u7387\u6807\u51C6\u5DEE\uFF0CF \u4E3A\u4E3B\u52A8\u4E70\u5356\u6210\u4EA4\u91D1\u989D\u7684\u8870\u51CF\u52A0\u6743\u5DEE\u989D\u3002\u6B63\u8D1F\u8868\u793A\u7EFC\u5408\u65B9\u5411\uFF0C\u4E0D\u662F\u4E0A\u6DA8\u6982\u7387\uFF1B\u8FD9\u662F\u8D8B\u52BF\u8DDF\u8E2A\u601D\u60F3\u7684\u6269\u5C55\u6A21\u578B\u3002";
  }
});

// src/lib/sellerResponse.ts
var init_sellerResponse = __esm({
  "src/lib/sellerResponse.ts"() {
  }
});

// src/lib/deepDig/formula.ts
function tokenize(src) {
  const text = [...src].map((ch) => NORMALIZE[ch] ?? ch).join("");
  const out = [];
  let line = 1;
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (ch === "\n") {
      out.push({ t: "sep", line });
      line++;
      i++;
      continue;
    }
    if (ch === ";") {
      out.push({ t: "sep", line });
      i++;
      continue;
    }
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    if (ch === "#" || ch === "/" && text[i + 1] === "/") {
      while (i < text.length && text[i] !== "\n") i++;
      continue;
    }
    const num2 = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(text.slice(i));
    if (num2) {
      out.push({ t: "num", v: Number(num2[0]), line });
      i += num2[0].length;
      continue;
    }
    const id2 = /^[\p{L}_][\p{L}\p{N}_]*/u.exec(text.slice(i));
    if (id2) {
      const kw = KEYWORDS[id2[0]];
      out.push(kw ? { t: "op", v: kw, line } : { t: "id", v: id2[0], line });
      i += id2[0].length;
      continue;
    }
    const two = text.slice(i, i + 2);
    if ([">=", "<=", "==", "!=", "&&", "||"].includes(two)) {
      out.push({ t: "op", v: two === "&&" ? "and" : two === "||" ? "or" : two, line });
      i += 2;
      continue;
    }
    if ("+-*/^()<>=,!".includes(ch)) {
      out.push({ t: "op", v: ch === "!" ? "not" : ch, line });
      i++;
      continue;
    }
    throw new FormulaError(`\u770B\u4E0D\u61C2\u300C${ch}\u300D`, line);
  }
  out.push({ t: "end", line });
  return out;
}
function parseFormula(src, known) {
  const statements = new Parser(tokenize(src)).program();
  if (!statements.length) throw new FormulaError("\u8FD8\u6CA1\u5199\u516C\u5F0F", 1);
  const defined = /* @__PURE__ */ new Set();
  const inputs = /* @__PURE__ */ new Set();
  const check = (n) => {
    if (n.k === "var") {
      if (defined.has(n.name)) return;
      if (known.has(n.name)) {
        inputs.add(n.name);
        return;
      }
      throw new FormulaError(`\u4E0D\u8BA4\u8BC6\u300C${n.name}\u300D\uFF1A\u53EF\u7528\u7684\u540D\u5B57\u89C1\u300C\u53EF\u7528\u5199\u6CD5\u300D\uFF0C\u4E2D\u95F4\u91CF\u8981\u5148\u300C${n.name} = \u2026\u300D\u518D\u7528`, n.line);
    }
    if (n.k === "un") check(n.a);
    else if (n.k === "bin") {
      check(n.a);
      check(n.b);
    } else if (n.k === "call") {
      const spec = FN.get(n.name);
      if (!spec) throw new FormulaError(`\u6CA1\u6709\u300C${n.name}\u300D\u8FD9\u4E2A\u51FD\u6570`, n.line);
      if (n.args.length < spec.min || n.args.length > spec.max || spec.counts && !spec.counts.includes(n.args.length)) throw new FormulaError(`${spec.usage} \u7684\u53C2\u6570\u4E2A\u6570\u4E0D\u5BF9`, n.line);
      n.args.forEach(check);
    }
  };
  for (const s of statements) {
    check(s.expr);
    if (s.name) {
      if (FN.has(s.name)) throw new FormulaError(`\u300C${s.name}\u300D\u662F\u51FD\u6570\u540D\uFF0C\u6362\u4E2A\u540D\u5B57`, s.line);
      defined.add(s.name);
    }
  }
  return { statements, inputs };
}
var ORIGINAL_FUNCTIONS, FUNCTIONS, FN, FormulaError, NORMALIZE, KEYWORDS, Parser;
var init_formula = __esm({
  "src/lib/deepDig/formula.ts"() {
    init_ctba();
    init_mbi();
    init_mbi2();
    init_sellerResponse();
    init_recentFocusMath();
    ORIGINAL_FUNCTIONS = [
      { name: "ln", min: 1, max: 1, usage: "ln(x)", help: "\u81EA\u7136\u5BF9\u6570\uFF08\u4E5F\u53EF\u5199 log\uFF09" },
      { name: "log", min: 1, max: 1, usage: "log(x)", help: "\u540C ln" },
      { name: "exp", min: 1, max: 1, usage: "exp(x)", help: "e \u7684 x \u6B21\u65B9" },
      { name: "tanh", min: 1, max: 1, usage: "tanh(x)", help: "\u53CC\u66F2\u6B63\u5207\uFF1A\u628A\u4EFB\u610F\u6570\u5E73\u6ED1\u538B\u5230 \u22121 ~ 1\uFF080 \u2192 0\uFF0C\xB11 \u2192 \xB10.76\uFF0C\xB12 \u2192 \xB10.96\uFF09" },
      { name: "ctba", min: 17, max: 17, usage: "ctba(C,H,L,E,B,S,T,N,f,s,m,lambda,epsilon,alpha,beta,gamma,part)", help: "CTBA \u5171\u4EAB\u6838\u5FC3\uFF1Apart 0/1/2/3/4/5 \u4E3A T/M/F/CTBA/\u65E0\u6210\u4EA4/\u5B8C\u6574\u6027\uFF1B\u4EC55m\uFF0C\u7F3A\u5931\u4E0D\u8865\u96F6" },
      { name: "mbi2state", min: 5, max: 5, usage: "mbi2state(MBI2,T,BAND,CONFIRM,part)", help: "MBI2 \u4E25\u683C\u7F13\u51B2\u72B6\u6001\u673A\uFF1Apart 0/1/2/3/4 \u4E3A\u72B6\u6001/\u672C\u8F6E\u5C0F\u65F6/\u786E\u8BA4\u5C0F\u65F6/\u4E70\u65B9\u8BD5\u63A2\u5F00\u59CB/\u4E70\u65B9\u8FDB\u5165\u786E\u8BA4\uFF1B\u7F3A\u5931\u4E0D\u8865\u96F6" },
      { name: "mbiz2", min: 2, max: 2, usage: "mbiz2(C, MBI2_N)", help: "MBI2 \u72EC\u7ACB\u590D\u5236\u7684\u4EF7\u683C\u504F\u79BB\u6838\u5FC3\uFF1B\u524D5n\u6839\u4FDD\u6301\u7F3A\u5931" },
      { name: "mbiz", min: 2, max: 2, usage: "mbiz(C, MBI_N)", help: "MBI \u7684\u65E0\u8D8B\u52BF\u6807\u51C6\u5DEE\u504F\u79BB z\uFF1A\u03B1 = 1/n\uFF0C\u03BA = 1/\u221A(\u03B1\xB7(2\u2212\u03B1))\uFF1B\u5148\u7528\u4E0A\u4E00\u6839 M\u3001S \u7B97 z \u518D\u66F4\u65B0\u3002\u524D 5n \u6839\u4E3A\u7A7A\uFF0C\u53EA\u7528\u6B63\u6536\u76D8\u4EF7\uFF0C\u4E0D\u8865\u96F6\u3002MBI = tanh(z / MBI_Z0)" },
      { name: "seller_response", min: 3, max: 3, usage: "seller_response(x, gain, scale)", help: "\u8D1F\u5411\u54CD\u5E94\uFF1Ax\u22650 \u539F\u6837\u4FDD\u7559\uFF1Bx<0 \u8FD4\u56DE scale\xB7tanh(gain\xB7atanh(x/scale))\u3002gain>0\u3001scale>0\uFF0C\u7F3A\u5931\u548C\u8D8A\u754C\u4FDD\u6301\u7F3A\u5931\uFF1B0\u4ECD\u4E3A\u5E73\u8861\uFF0C\u4E0D\u6539\u53D8\u4EFB\u4F55\u7A97\u53E3\uFF0C\u9ED8\u8BA4\u589E\u76CA2\u3002" },
      { name: "abs", min: 1, max: 1, usage: "abs(x)", help: "\u7EDD\u5BF9\u503C" },
      { name: "sqrt", min: 1, max: 1, usage: "sqrt(x)", help: "\u5E73\u65B9\u6839" },
      { name: "sign", min: 1, max: 1, usage: "sign(x)", help: "\u6B63 1\u3001\u8D1F \u22121\u3001\u96F6 0" },
      { name: "max", min: 2, max: 2, usage: "max(a, b)", help: "\u9010\u6839\u53D6\u8F83\u5927\u7684" },
      { name: "min", min: 2, max: 2, usage: "min(a, b)", help: "\u9010\u6839\u53D6\u8F83\u5C0F\u7684" },
      { name: "prev", min: 1, max: 2, usage: "prev(x, k)", help: "\u524D k \u6839\u7684\u503C\uFF08k \u9ED8\u8BA4 1\uFF09\uFF1B\u5F00\u5934\u6CA1\u6709\u524D k \u6839\u7684\u8BB0\u7A7A" },
      { name: "ema", min: 2, max: 3, usage: "ema(x, h, \u521D\u503C)", help: "\u6307\u6570\u5E73\u6ED1\uFF0C\u534A\u8870\u671F h \u5C0F\u65F6\uFF08h \u53EF\u5199 hl = \u4E0A\u9762\u9009\u7684\u534A\u8870\u671F\uFF09\uFF1Ay\u209C = \u03C1\xB7y\u209C\u208B\u2081 + (1 \u2212 \u03C1)\xB7x\u209C\uFF0C\u03C1 = 2^(\u2212\u5468\u671F \xF7 h)\uFF0C\u5468\u671F = \u4E0A\u9762\u9009\u7684 K \u7EBF\u5468\u671F\uFF1Bx \u4E3A\u7A7A\u7684\u90A3\u6839\u8DF3\u8FC7\uFF1B\u4E0D\u7ED9\u521D\u503C\u65F6\u4ECE\u7B2C\u4E00\u4E2A\u975E\u7A7A\u503C\u8D77\u7B97" },
      { name: "ago", min: 2, max: 2, usage: "ago(x, h)", help: "h \u5C0F\u65F6\u4EE5\u524D\u90A3\u6839\u7684\u503C\uFF08\u6309 K \u7EBF\u5468\u671F\u6362\u7B97\u6210\u6839\u6570\uFF1B\u5F00\u5934\u4E0D\u591F h \u5C0F\u65F6\u7684\u8BB0\u7A7A\uFF09" },
      { name: "zscore", min: 2, max: 2, usage: "zscore(x, h)", help: "\u6EDA\u52A8\u6807\u51C6\u5316\uFF1A(\u5F53\u6839 \u2212 \u8FC7\u53BB h \u5C0F\u65F6\u7684\u5E73\u5747) \xF7 \u8FC7\u53BB h \u5C0F\u65F6\u7684\u6807\u51C6\u5DEE\uFF08\u542B\u5F53\u6839\uFF0C\u6837\u672C\u6807\u51C6\u5DEE\uFF09\uFF1B\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u5F00\u5934\u4E0D\u6EE1 h \u5C0F\u65F6\u7528\u5DF2\u6709\u7684\uFF0C\u5C11\u4E8E 2 \u4E2A\u6216\u6807\u51C6\u5DEE\u4E3A 0 \u8BB0\u7A7A" },
      { name: "sd", min: 2, max: 2, usage: "sd(x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\u7684\u6807\u51C6\u5DEE\uFF08\u542B\u5F53\u6839\uFF0C\u6837\u672C\u6807\u51C6\u5DEE\uFF09\uFF1A\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u5F00\u5934\u4E0D\u6EE1 h \u5C0F\u65F6\u7528\u5DF2\u6709\u7684\uFF0C\u5C11\u4E8E 2 \u4E2A\u8BB0\u7A7A\u3002\u4F8B\uFF1AR / sd(R, avgh) = \u6309\u81EA\u8EAB\u6CE2\u52A8\u6807\u51C6\u5316\u7684\u6DA8\u8DCC\uFF08Z \u5206\u6570\uFF0C\u5747\u503C\u6309 0\uFF09" },
      { name: "retain", min: 4, max: 5, usage: "retain(K, P, E0, h, W)", help: "\u4FDD\u7559\u52A0\u6743\u548C\uFF08CBA \u7528\uFF09\uFF1A\u03A3 w\u1D62\xB7K\u1D62\xB7ln(P\u209C \xF7 E0\u1D62) \xF7 (t \u2212 i + 1)\uFF0Ci \u53D6\u8FC7\u53BB W \u5C0F\u65F6\uFF08\u9ED8\u8BA4 48\uFF09\u91CC\u7684\u6BCF\u4E00\u6839\uFF0Cw\u1D62 = 2^(\u2212\u8DDD\u4ECA\u5C0F\u65F6 \xF7 h) \u5F52\u4E00\u5316\uFF08\u6743\u91CD\u5408\u8BA1 1\uFF09\uFF1BK\u1D62 \u6216 E0\u1D62 \u4E3A\u7A7A\u7684\u90A3\u6839\u8FD9\u4E00\u9879\u8BB0 0" },
      { name: "bars", min: 1, max: 1, usage: "bars(h)", help: "\u6309\u5F53\u524D\u8BA1\u7B97\u5468\u671F\u628A\u5C0F\u65F6\u6570\u6362\u7B97\u4E3A\u6839\u6570\uFF0C\u4E0Eavg/sd/retain\u540C\u6837\u56DB\u820D\u4E94\u5165\u3001\u81F3\u5C111\u6839\uFF1Bh\u987B\u5927\u4E8E0\u3002" },
      { name: "full", min: 2, max: 2, usage: "full(x, n)", help: "\u6700\u8FD1 n \u6839\u5168\u90E8\u5B58\u5728\u4E14\u6709\u6548\u65F6\u8FD4\u56DE\u5F53\u6839 x\uFF0C\u5426\u5219\u8BB0\u7A7A\uFF08\u4E0D\u8865\u96F6\uFF09" },
      { name: "peak", min: 2, max: 2, usage: "peak(x, n)", help: "\u6700\u8FD1 n \u6839\u6700\u5927\u503C\uFF0C\u5FC5\u987B\u6EE1 n \u6839\u4E14\u6CA1\u6709\u7F3A\u503C" },
      { name: "wsum", min: 3, max: 3, usage: "wsum(x, h, n)", help: "\u65F6\u95F4\u8870\u51CF\u52A0\u6743\u548C\uFF1A\u6700\u8FD1 n \u6839\uFF08\u542B\u5F53\u6839\uFF09\uFF0C\u7B2C i \u6839\u6743\u91CD 2^(\u2212(t \u2212 i) \xF7 h)\uFF0Ch\u3001n \u90FD\u4EE5\u6839\u8BA1\uFF1B\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u4E00\u4E2A\u90FD\u6CA1\u6709\u8BB0\u7A7A" },
      { name: "rsum", min: 2, max: 2, usage: "rsum(x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\u7684\u548C\uFF08\u542B\u5F53\u6839\uFF09\uFF1A\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u4E00\u4E2A\u90FD\u6CA1\u6709\u8BB0\u7A7A" },
      { name: "median", min: 2, max: 2, usage: "median(x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\u7684\u4E2D\u4F4D\u6570\uFF08\u542B\u5F53\u6839\uFF09\uFF1A\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u4E00\u4E2A\u90FD\u6CA1\u6709\u8BB0\u7A7A" },
      { name: "mad", min: 2, max: 2, usage: "mad(x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\u7684\u4E2D\u4F4D\u6570\u7EDD\u5BF9\u504F\u5DEE median(|x \u2212 \u4E2D\u4F4D\u6570|)\uFF08\u542B\u5F53\u6839\uFF09\uFF1A\u7A7A\u503C\u8DF3\u8FC7\uFF1B\u7A33\u5065 z = (x \u2212 \u4E2D\u6027\u70B9) \xF7 (1.4826 \xD7 mad)" },
      { name: "rscale", min: 2, max: 2, usage: "rscale(x, h)", help: "\u7A33\u5065\u5C3A\u5EA6\uFF1A\u8FC7\u53BB h \u5C0F\u65F6\uFF08\u542B\u5F53\u6839\uFF09\u7684 1.4826 \xD7 MAD\uFF1B\u4E00\u534A\u4EE5\u4E0A\u7684\u503C\u76F8\u540C\u3001MAD = 0 \u65F6\u6539\u7528 1.2533 \xD7 \u5E73\u5747\u7EDD\u5BF9\u504F\u5DEE\uFF08\u79BB\u4E2D\u4F4D\u6570\uFF09\uFF1B\u7A33\u5065 z = (x \u2212 \u4E2D\u6027\u70B9) \xF7 rscale" },
      { name: "highest", min: 2, max: 2, usage: "highest(x, n)", help: "\u6700\u8FD1 n \u6839\uFF08\u542B\u5F53\u6839\uFF09\u7684\u6700\u5927\u503C\uFF1A\u7A7A\u503C\u8DF3\u8FC7" },
      { name: "lowest", min: 2, max: 2, usage: "lowest(x, n)", help: "\u6700\u8FD1 n \u6839\uFF08\u542B\u5F53\u6839\uFF09\u7684\u6700\u5C0F\u503C\uFF1A\u7A7A\u503C\u8DF3\u8FC7" },
      { name: "msum", min: 2, max: 2, usage: "msum(x, n)", help: "\u6700\u8FD1 n \u6839\uFF08\u542B\u5F53\u6839\uFF09\u7684\u548C\uFF1A\u7A7A\u503C\u8DF3\u8FC7\uFF0C\u4E00\u4E2A\u90FD\u6CA1\u6709\u8BB0\u7A7A\uFF08sum \u8981\u6C42 n \u6839\u90FD\u6709\u503C\uFF09" },
      { name: "beta", min: 3, max: 3, usage: "beta(y, x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\uFF08\u542B\u5F53\u6839\uFF09y \u5BF9 x \u7684\u56DE\u5F52\u659C\u7387\uFF1A\u4E24\u4E2A\u90FD\u6709\u503C\u7684\u6839\u624D\u7B97\uFF0C\u5C11\u4E8E 2 \u6839\u8BB0\u7A7A" },
      { name: "clip", min: 3, max: 3, usage: "clip(x, lo, hi)", help: "\u622A\u65AD\u5230 lo ~ hi" },
      { name: "atr", min: 4, max: 4, usage: "atr(H, L, C, n)", help: "\u5E73\u5747\u771F\u5B9E\u6CE2\u5E45\uFF1A\u771F\u5B9E\u6CE2\u5E45 = max(H \u2212 L, |H \u2212 \u524D\u6536|, |L \u2212 \u524D\u6536|)\uFF0CWilder \u5E73\u6ED1 n \u6839\uFF08\u524D n \u6839\u7684\u5E73\u5747\u8D77\u7B97\uFF0C\u4E0D\u6EE1 n \u6839\u8BB0\u7A7A\uFF09" },
      { name: "avg", min: 2, max: 2, usage: "avg(x, h)", help: "\u8FC7\u53BB h \u5C0F\u65F6\u7684\u5E73\u5747\uFF08\u542B\u5F53\u6839\uFF1Bh \u53EF\u5199 avgh = \u4E0A\u9762\u9009\u7684\u5E73\u5747\u65F6\u957F\uFF09\uFF1A\u6309 K \u7EBF\u5468\u671F\u6362\u7B97\u6210\u6839\u6570\uFF0C\u5468\u671F\u53D8\u4E86\u65F6\u957F\u4E0D\u53D8\uFF1Bx \u4E3A\u7A7A\u7684\u90A3\u6839\u8DF3\u8FC7\uFF1B\u5F00\u5934\u4E0D\u6EE1 h \u5C0F\u65F6\u7684\u7528\u5DF2\u6709\u7684" },
      { name: "sma", min: 2, max: 2, usage: "sma(x, n)", help: "\u6700\u8FD1 n \u6839\u7684\u5E73\u5747\uFF08\u4E0D\u6EE1 n \u6839\u8BB0\u7A7A\uFF09" },
      { name: "sum", min: 2, max: 2, usage: "sum(x, n)", help: "\u6700\u8FD1 n \u6839\u7684\u548C\uFF08\u4E0D\u6EE1 n \u6839\u8BB0\u7A7A\uFF09" },
      { name: "nz", min: 1, max: 2, usage: "nz(x, v)", help: "\u7A7A\u6362\u6210 v\uFF08\u9ED8\u8BA4 0\uFF09" },
      { name: "if", min: 3, max: 3, usage: "if(\u6761\u4EF6, a, b)", help: "\u6761\u4EF6\u6210\u7ACB\u53D6 a\uFF0C\u5426\u5219\u53D6 b" },
      { name: "has", min: 1, max: 1, usage: "has(x)", help: "x \u4E0D\u662F\u7A7A \u2192 1\uFF0C\u5426\u5219 0" }
    ];
    FUNCTIONS = ORIGINAL_FUNCTIONS.map((f) => {
      const original = FOCUS_BASE_ARITIES[f.name];
      if (!original) return f;
      const counts = [...original, ...original.map((n) => n + 2)];
      return { ...f, max: Math.max(...counts), counts, help: f.help + "\uFF1B\u53EF\u8FFD\u52A0 focus_h, focus_weight\uFF1A\u4FDD\u7559\u539F\u7A97\u53E3\uFF0C\u6700\u8FD1 focus_h \u5C0F\u65F6\u7684\u76F8\u5BF9\u6743\u91CD\u4E58 focus_weight\uFF08\u22651\uFF09\uFF1B\u6743\u91CD1\u7CBE\u786E\u6062\u590D\u539F\u8BA1\u7B97\u3002" };
    });
    FN = new Map(FUNCTIONS.map((f) => [f.name, f]));
    FormulaError = class extends Error {
      constructor(message, line) {
        super(`\u7B2C ${line} \u884C\uFF1A${message}`);
        this.line = line;
      }
    };
    NORMALIZE = { "\xD7": "*", "\xB7": "*", "\xF7": "/", "\u2212": "-", "\uFF08": "(", "\uFF09": ")", "\uFF0C": ",", "\uFF1B": ";", "\uFF1D": "=", "\uFF0B": "+", "\uFF1E": ">", "\uFF1C": "<" };
    KEYWORDS = { and: "and", or: "or", not: "not" };
    Parser = class {
      constructor(toks) {
        this.toks = toks;
      }
      i = 0;
      peek() {
        return this.toks[this.i];
      }
      next() {
        return this.toks[this.i++];
      }
      isOp(v) {
        const t = this.peek();
        return t.t === "op" && t.v === v;
      }
      expectOp(v) {
        const t = this.next();
        if (t.t !== "op" || t.v !== v) throw new FormulaError(`\u8FD9\u91CC\u5E94\u8BE5\u662F\u300C${v}\u300D`, t.line);
      }
      program() {
        const out = [];
        while (this.peek().t !== "end") {
          if (this.peek().t === "sep") {
            this.next();
            continue;
          }
          const start = this.peek();
          let name = null;
          const after = this.toks[this.i + 1];
          if (start.t === "id" && after?.t === "op" && after.v === "=") {
            name = start.v;
            this.i += 2;
          }
          const expr = this.or();
          const t = this.peek();
          if (t.t !== "sep" && t.t !== "end") throw new FormulaError(t.t === "op" && t.v === "=" ? "\u300C=\u300D\u5DE6\u8FB9\u53EA\u80FD\u662F\u4E00\u4E2A\u540D\u5B57" : "\u5F0F\u5B50\u6CA1\u5199\u5B8C\u6574\uFF0C\u6216\u5C11\u4E86\u8FD0\u7B97\u7B26", t.line);
          out.push({ name, expr, line: start.line });
        }
        return out;
      }
      or() {
        let a = this.and();
        while (this.isOp("or")) {
          this.next();
          a = { k: "bin", op: "or", a, b: this.and() };
        }
        return a;
      }
      and() {
        let a = this.not();
        while (this.isOp("and")) {
          this.next();
          a = { k: "bin", op: "and", a, b: this.not() };
        }
        return a;
      }
      not() {
        if (this.isOp("not")) {
          this.next();
          return { k: "un", op: "not", a: this.not() };
        }
        return this.cmp();
      }
      cmp() {
        const a = this.add();
        const t = this.peek();
        if (t.t === "op" && [">", "<", ">=", "<=", "==", "!="].includes(t.v)) {
          this.next();
          return { k: "bin", op: t.v, a, b: this.add() };
        }
        if (t.t === "op" && t.v === "=") throw new FormulaError("\u6BD4\u8F83\u76F8\u7B49\u8BF7\u5199\u300C==\u300D", t.line);
        return a;
      }
      add() {
        let a = this.mul();
        for (; ; ) {
          const t = this.peek();
          if (t.t === "op" && (t.v === "+" || t.v === "-")) {
            this.next();
            a = { k: "bin", op: t.v, a, b: this.mul() };
          } else return a;
        }
      }
      mul() {
        let a = this.unary();
        for (; ; ) {
          const t = this.peek();
          if (t.t === "op" && (t.v === "*" || t.v === "/")) {
            this.next();
            a = { k: "bin", op: t.v, a, b: this.unary() };
          } else return a;
        }
      }
      unary() {
        if (this.isOp("-")) {
          this.next();
          return { k: "un", op: "-", a: this.unary() };
        }
        if (this.isOp("+")) {
          this.next();
          return this.unary();
        }
        return this.pow();
      }
      pow() {
        const a = this.primary();
        if (this.isOp("^")) {
          this.next();
          return { k: "bin", op: "^", a, b: this.unary() };
        }
        return a;
      }
      primary() {
        const t = this.next();
        if (t.t === "num") return { k: "num", v: t.v };
        if (t.t === "id") {
          if (this.isOp("(")) {
            this.next();
            const args = [];
            if (!this.isOp(")")) {
              for (; ; ) {
                args.push(this.or());
                if (this.isOp(",")) {
                  this.next();
                  continue;
                }
                break;
              }
            }
            this.expectOp(")");
            return { k: "call", name: t.v, args, line: t.line };
          }
          return { k: "var", name: t.v, line: t.line };
        }
        if (t.t === "op" && t.v === "(") {
          const e = this.or();
          this.expectOp(")");
          return e;
        }
        if (t.t === "sep" || t.t === "end") throw new FormulaError("\u5F0F\u5B50\u6CA1\u5199\u5B8C\u6574", t.line);
        throw new FormulaError(`\u8FD9\u91CC\u4E0D\u5E94\u8BE5\u51FA\u73B0\u300C${t.t === "op" ? t.v : ""}\u300D`, t.line);
      }
    };
  }
});

// src/lib/cba2.ts
var CBA2_FORMULA, CBA2_DEFINITION, CBA2_STEPS, program;
var init_cba2 = __esm({
  "src/lib/cba2.ts"() {
    init_formula();
    CBA2_FORMULA = [
      "# CBA-2 = 100\xB7tanh(\u03A3 w\xB7F*\xB7G*\xB7R*)\uFF1B\u4EC5\u5DF2\u6536\u76D85\u5206\u949F\uFF0C48\u5C0F\u65F6\u6743\u91CD\u5408\u8BA11\uFF1B\u4E0D\u662F\u80DC\u7387",
      "# hl = \u65F6\u95F4\u6743\u91CD\u534A\u8870\u671F\uFF08\u5C0F\u65F6\uFF09\uFF1Bavgh = \u6210\u4EA4\u989D\u57FA\u7EBF\u65F6\u957F\u4E0E r\xB2 EWMA \u534A\u8870\u671F\uFF08\u5C0F\u65F6\uFF09\uFF1B\u4EE5\u4E0B\u4E3A\u53EF\u4FEE\u6539\u7684\u7814\u7A76\u9ED8\u8BA4\u503C",
      "alpha = 1",
      "epsilon = 0.000001",
      "m = 12",
      "dmax = 3",
      "V = if(Q > 0 and B >= 0 and S >= 0 and (not has(prev(T)) or T - prev(T) == 300000), Q, 0 / 0)",
      "price = if(V > 0 and E > 0, E, 0 / 0) # E=\u6210\u4EA4\u989D/\u6210\u4EA4\u6570\u91CF\uFF08VWAP\uFF09",
      "D = B - S # \u4E3B\u52A8\u6210\u4EA4\u51C0\u5DEE\u989D\uFF0C\u4E0D\u662F\u5E02\u573A\u51C0\u8D44\u91D1\u6D41\u5165",
      "r = ln(price / prev(price))",
      "Vbar = prev(if(has(full(V, avgh * 12)), avg(V, avgh), 0 / 0)) # \u53EA\u7528\u4E0A\u4E00\u6839\u53CA\u4EE5\u524D",
      "s = if(has(prev(full(r, avgh * 12))), sqrt(prev(ema(r ^ 2, avgh)) + epsilon ^ 2), 0 / 0)",
      "F = ln(1 + V / Vbar)",
      "G = 1 + alpha * abs(D) / V * (D * r > 0) # \u4E3B\u52A8\u4E70\u914D\u5408\u4E0A\u6DA8\u3001\u4E3B\u52A8\u5356\u914D\u5408\u4E0B\u8DCC\u5747\u653E\u5927",
      "R = r / s",
      "U = full(F * G * R, 576) # \u6EE148\u5C0F\u65F6\u4E14\u65E0\u7F3A\u503C\u624D\u8BA1\u7B97",
      "W = wsum(1, hl * 12, 576)",
      "score = wsum(F * G * R, hl * 12, 576) / W",
      "Ppeak = peak(C, m + 1) # \u542B\u5F53\u524D\u5171m+1\u4E2A\u6536\u76D8\u4EF7",
      "DD = ln(Ppeak / C) / s",
      "invalid = DD > dmax # \u72EC\u7ACB\u5931\u6548\u6807\u8BB0\uFF0C\u4E0D\u6E05\u96F6\u4E3B\u6307\u6807\uFF0C\u4E0D\u66FF\u4EE3\u6B62\u635F\uFF1B\u672A\u5931\u6548\u4E0D\u4EE3\u8868\u6EE1\u8DB3\u4E70\u5165\u6761\u4EF6",
      "CBA2 = if(has(U), 100 * tanh(score), 0 / 0)"
    ].join("\n");
    CBA2_DEFINITION = "CBA-2\uFF5C\u6210\u4EA4\u652F\u6301\u4E0B\u7684\u4EF7\u683C\u91CD\u5FC3\u8FC1\u79FB\u6307\u6807\uFF08\u2212100 ~ 100\uFF09\uFF1A\u6B63\u503C\u8868\u793A\u52A0\u6743\u4E0A\u884C\u53D8\u5316\u5360\u4F18\uFF0C\u8D1F\u503C\u8868\u793A\u52A0\u6743\u4E0B\u884C\u53D8\u5316\u5360\u4F18\uFF0C\u4E0D\u662F\u80DC\u7387\u3002\u4EC5\u5DF2\u7ED3\u675F\u76845\u5206\u949FK\u7EBF\uFF1B\u56DE\u64A4\u5931\u6548\u6807\u8BB0\u72EC\u7ACB\u8FD0\u884C\uFF0C\u4E0D\u6E05\u96F6\u4E3B\u6307\u6807\uFF0C\u4E5F\u4E0D\u66FF\u4EE3\u4EA4\u6613\u6B62\u635F\u3002";
    CBA2_STEPS = [
      "CBA-2\u209C = 100\xB7tanh(\u03A3 w\u1D62,\u209C\xB7F\u1D62*\xB7G\u1D62*\xB7R\u1D62*)\uFF0CW\u209C = \u622A\u81F3\u5F53\u524D\u768448\u5C0F\u65F6\u7A97\u53E3",
      "w\u1D62,\u209C = 2^(\u2212\u0394T\u1D62,\u209C/h) \xF7 \u03A3 2^(\u2212\u0394T\u2C7C,\u209C/h)\uFF0C\u65F6\u95F4\u4EE5\u5C0F\u65F6\u8BA1\uFF0C\u7A97\u53E3\u6743\u91CD\u5408\u8BA11",
      "V\u1D62 = B\u1D62 + S\u1D62\uFF1BD\u1D62 = B\u1D62 \u2212 S\u1D62\uFF1BB\u3001S\u4E3A\u4E3B\u52A8\u4E70\u5165/\u5356\u51FA\u6210\u4EA4\u989D\uFF08\u7EDF\u4E00\u8BA1\u4EF7\uFF09",
      "F\u1D62* = ln(1 + V\u1D62 / V\u0304\u1D62\u208B\u2081)\uFF0CV\u0304\u4E3A\u622A\u81F3\u4E0A\u4E00\u6839\u7684\u5386\u53F2\u5E38\u6001\u6210\u4EA4\u989D",
      "G\u1D62* = 1 + \u03B1\xB7|D\u1D62|/V\u1D62\xB71{D\u1D62r\u1D62 > 0}\uFF0C\u540C\u5411\u53D61\uFF0C\u5426\u5219\u53D60",
      "R\u1D62* = r\u1D62/s\u1D62\u208B\u2081\uFF1Br\u1D62 = ln(E\u1D62/E\u1D62\u208B\u2081)\uFF1BE\u1D62 = \u6210\u4EA4\u989D/\u6210\u4EA4\u6570\u91CF\uFF08VWAP\uFF09",
      "s\u1D62\u208B\u2081 = sqrt(EWMA\u1D62\u208B\u2081(r\xB2) + \u03B5\xB2)\uFF0C\u4EC5\u7528\u4E0A\u4E00\u6839\u53CA\u4EE5\u524D\u6570\u636E",
      "Ppeak = max(C\u209C\u208B\u2098,\u2026,C\u209C)\uFF1BDD = ln(Ppeak/C\u209C)/s\u209C\u208B\u2081\uFF1BDD > dmax \u6682\u505C\u8BA4\u5B9A\u4E3A\u6709\u6548\u505A\u591A\u5019\u9009",
      "\u7814\u7A76\u9ED8\u8BA4\u503C\uFF08\u539F\u56FE\u672A\u5B9A\uFF0C\u5C1A\u9700\u56DE\u6D4B\uFF09\uFF1Ah=6\u5C0F\u65F6\uFF0C\u6210\u4EA4\u989D\u57FA\u7EBF24\u5C0F\u65F6\u3001r\xB2 EWMA\u534A\u8870\u671F24\u5C0F\u65F6\uFF0C\u03B1=1\uFF0C\u03B5=0.000001\uFF0Cm=12\u6839\uFF0Cdmax=3\u3002EWMA\u4ECE\u9996\u4E2A\u6709\u6548r\xB2\u8D77\u7B97\uFF1B\u7F3A\u503C\u6216\u57FA\u7EBF/48\u5C0F\u65F6\u7A97\u53E3\u672A\u5C31\u7EEA\u7559\u7A7A\u3002",
      "\u672A\u89E6\u53D1\u5931\u6548\u4E0D\u7B49\u4E8E\u6EE1\u8DB3\u4E70\u5165\u6761\u4EF6\uFF1B\u8BFB\u6570\u4E0D\u80FD\u76F4\u63A5\u89E3\u91CA\u4E3A\u672A\u6765\u4E0A\u6DA8\u6982\u7387\u3002"
    ].join("\n");
    program = parseFormula(CBA2_FORMULA, /* @__PURE__ */ new Set(["Q", "B", "S", "E", "C", "T", "hl", "avgh"]));
  }
});

// src/lib/researchAverageFormula.ts
function appendResearchAverages(formula, names, series, hours = 24) {
  const extra = [];
  const quarter = hours / 4;
  if (!names.has(series.avg)) extra.push(`${series.avg} = avg(${series.core}, ${hours})`);
  if (!names.has(series.avg2)) {
    let helper = "_chart_m6";
    while (names.has(helper)) helper += "_";
    extra.push(`${helper} = avg(${series.core}, ${quarter})`, `${series.avg2} = (4 * ${helper} + 3 * ago(${helper}, ${quarter}) + 2 * ago(${helper}, ${2 * quarter}) + ago(${helper}, ${3 * quarter})) / 10`);
  }
  return [formula, ...extra].join("\n");
}
var init_researchAverageFormula = __esm({
  "src/lib/researchAverageFormula.ts"() {
  }
});

// src/lib/arrayLruCache.ts
var ArrayLruCache;
var init_arrayLruCache = __esm({
  "src/lib/arrayLruCache.ts"() {
    ArrayLruCache = class {
      constructor(maxItems, maxEntries = 48) {
        this.maxItems = maxItems;
        this.maxEntries = maxEntries;
      }
      values = /* @__PURE__ */ new Map();
      items = 0;
      get(key) {
        const value = this.values.get(key);
        if (value) {
          this.values.delete(key);
          this.values.set(key, value);
        }
        return value;
      }
      set(key, value) {
        const old = this.values.get(key);
        if (old) {
          this.items -= old.length;
          this.values.delete(key);
        }
        if (value.length > this.maxItems) return;
        this.values.set(key, value);
        this.items += value.length;
        while (this.items > this.maxItems || this.values.size > this.maxEntries) {
          const first = this.values.keys().next().value;
          this.items -= this.values.get(first).length;
          this.values.delete(first);
        }
      }
      clear() {
        this.values.clear();
        this.items = 0;
      }
      get itemCount() {
        return this.items;
      }
      get size() {
        return this.values.size;
      }
    };
  }
});

// src/lib/timeFormat.ts
var init_timeFormat = __esm({
  "src/lib/timeFormat.ts"() {
  }
});

// src/lib/binanceRateLimit.ts
var init_binanceRateLimit = __esm({
  "src/lib/binanceRateLimit.ts"() {
    init_timeFormat();
  }
});

// src/lib/turingCupSymbol.ts
var init_turingCupSymbol = __esm({
  "src/lib/turingCupSymbol.ts"() {
  }
});

// src/lib/turingCupReplayArchive.ts
var init_turingCupReplayArchive = __esm({
  "src/lib/turingCupReplayArchive.ts"() {
    init_userStoragePrefix();
  }
});

// src/lib/turingCupMarketData.ts
var init_turingCupMarketData = __esm({
  "src/lib/turingCupMarketData.ts"() {
    init_turingCupSymbol();
    init_turingCupReplayArchive();
  }
});

// src/lib/deepRsa/grouping.ts
var WINDOW_MS, FIVE_MINUTES_MS;
var init_grouping = __esm({
  "src/lib/deepRsa/grouping.ts"() {
    WINDOW_MS = 48 * 60 * 6e4;
    FIVE_MINUTES_MS = 5 * 6e4;
  }
});

// src/lib/deepRsa/window.ts
var BAR_MS, WINDOW_BARS;
var init_window = __esm({
  "src/lib/deepRsa/window.ts"() {
    init_turingCupReplayArchive();
    init_grouping();
    BAR_MS = 5 * 6e4;
    WINDOW_BARS = WINDOW_MS / BAR_MS;
  }
});

// src/lib/deepRsa/marketData.ts
function intervalMs(interval) {
  const n = Number.parseInt(interval, 10);
  const unit = interval.slice(String(n).length);
  return n * (unit === "m" ? 6e4 : unit === "h" ? 36e5 : 864e5);
}
var klineCache, fundingCache;
var init_marketData = __esm({
  "src/lib/deepRsa/marketData.ts"() {
    init_arrayLruCache();
    init_binanceRateLimit();
    init_turingCupMarketData();
    init_turingCupSymbol();
    init_window();
    klineCache = new ArrayLruCache(3e4);
    fundingCache = new ArrayLruCache(2e4);
  }
});

// src/lib/campaignB.ts
function resolveUnifiedMagicB(geometricB) {
  return geometricB != null && Number.isFinite(geometricB) ? geometricB : null;
}
function computeSettlementPayoffRatio(pnl, initialRisk) {
  if (pnl == null || initialRisk == null || !Number.isFinite(pnl) || !Number.isFinite(initialRisk) || initialRisk <= 0) return null;
  const ratio = pnl / initialRisk;
  return Number.isFinite(ratio) ? ratio : null;
}
var init_campaignB = __esm({
  "src/lib/campaignB.ts"() {
  }
});

// src/lib/fish/qualityDbl5Sell.ts
var DBL5_SELL_VERSION, DBL5_SELL_OR_VERSION, guardLines, impulseLines, DBL5_SELL_LINES, isDbl5Sell;
var init_qualityDbl5Sell = __esm({
  "src/lib/fish/qualityDbl5Sell.ts"() {
    init_features();
    init_qualityBoxStop();
    DBL5_SELL_VERSION = "sell-dbl5-line-v1";
    DBL5_SELL_OR_VERSION = "sell-dbl5-line-or-v2";
    guardLines = {
      "sell-dbl5-guard": "DBL-5 \u9632\u5B88\u7EBF\uFF08\u5B9E\u7EBF\u548C\u865A\u7EBF\uFF09",
      "sell-dbl5-guard-trend": "DBL-5 \u9632\u5B88\u7EBF\uFF08\u5B9E\u7EBF\uFF09",
      "sell-dbl5-guard-range": "DBL-5 \u9632\u5B88\u7EBF\uFF08\u865A\u7EBF\uFF09"
    };
    impulseLines = {
      "sell-dbl5-impulse": "DBL-5 \u6025\u62C9\u7EBF-1115\uFF08\u5B9E\u7EBF\uFF09",
      "sell-dbl5-impulse0": "DBL-5 \u6025\u62C9\u7EBF-0\uFF08\u865A\u7EBF\uFF09",
      "sell-dbl5-guard-plus": "DBL-5 \u9632\u5B88\u7EBF+\u6025\u62C9\u7EBF-1115"
    };
    DBL5_SELL_LINES = {
      ...guardLines,
      ...impulseLines,
      ...Object.fromEntries(Object.entries(guardLines).flatMap(([id2, label]) => [
        [id2 + "+impulse1115", label + " \u6216 \u6025\u62C9\u7EBF-1115\uFF08\u5B9E\u7EBF\uFF09"],
        [id2 + "+impulse0", label + " \u6216 \u6025\u62C9\u7EBF-0\uFF08\u865A\u7EBF\uFF09"]
      ]))
    };
    isDbl5Sell = (rule) => rule?.version === DBL5_SELL_VERSION || rule?.version === DBL5_SELL_OR_VERSION;
  }
});

// src/lib/fish/qualityStaticDrawdownSell.ts
function timedDrawdownPayoffPct(plan) {
  const initial = plan.router?.structure ?? plan;
  const rule = initial.rule?.version === TIMED_STATIC_DRAWDOWN_VERSION ? initial.rule : initial.combo?.after.rule.version === TIMED_STATIC_DRAWDOWN_VERSION ? initial.combo.after.rule : void 0;
  const bands = rule?.bandThresholds;
  return bands?.length === DRAWDOWN_BAND_STARTS.length && bands.every((value) => Number.isFinite(value) && value > 0 && value < 100) ? Math.max(...bands) : void 0;
}
function limitedDrawdownPct(rule) {
  return isStaticDrawdownSell(rule) && Number.isFinite(rule.threshold) && rule.threshold > 0 && rule.threshold < 100 ? rule.threshold : void 0;
}
function initialLimitedDrawdownPct(plan) {
  const initial = plan.router?.structure ?? plan, ordinary = limitedDrawdownPct(initial.rule);
  const hard = (initial.holdingVetoes ?? []).filter((v) => v.enabled && isLimitedStaticDrawdownVeto(v) && v.mirrorStage?.stage !== "after" && Number.isFinite(v.threshold) && v.threshold > 0 && v.threshold < 100).map((v) => v.threshold);
  return hard.length ? Math.min(...hard, ...ordinary != null ? [ordinary] : []) : ordinary;
}
function initialPayoffRiskThreshold(plan) {
  const initial = plan.router?.structure ?? plan, limited = initialLimitedDrawdownPct(initial);
  if (limited != null) return limited;
  const marked = [...initial.holdingVetoes ?? [], ...(initial.vetoStages ?? []).flatMap((s) => s.conditions)].some((v) => v.enabled && isLimitedStaticDrawdownVeto(v));
  return marked ? payoffStopL0Pct(initial.holdingVetoes) : void 0;
}
var STATIC_DRAWDOWN_SELL_VERSION, STATIC_DRAWDOWN_SELL_LABEL, STATIC_DRAWDOWN_SELL_METRIC, STATIC_DRAWDOWN_SELL_CHOICE, TIMED_STATIC_DRAWDOWN_VERSION, DRAWDOWN_BAND_STARTS, DRAWDOWN_BAND_LABELS, isStaticDrawdownSell, qualityExitThresholdText;
var init_qualityStaticDrawdownSell = __esm({
  "src/lib/fish/qualityStaticDrawdownSell.ts"() {
    init_features();
    init_qualityDbl5Sell();
    init_qualityVeto();
    STATIC_DRAWDOWN_SELL_VERSION = "sell-static-drawdown-v1";
    STATIC_DRAWDOWN_SELL_LABEL = "\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4";
    STATIC_DRAWDOWN_SELL_METRIC = "staticDrawdown";
    STATIC_DRAWDOWN_SELL_CHOICE = STATIC_DRAWDOWN_SELL_VERSION + ":" + STATIC_DRAWDOWN_SELL_METRIC;
    TIMED_STATIC_DRAWDOWN_VERSION = "sell-static-drawdown-timed-v2";
    DRAWDOWN_BAND_STARTS = [0, 5, 15, 30, 60];
    DRAWDOWN_BAND_LABELS = ["0\u20135", "5\u201315", "15\u201330", "30\u201360", "60 \u53CA\u4EE5\u540E"];
    isStaticDrawdownSell = (rule) => rule?.version === STATIC_DRAWDOWN_SELL_VERSION || rule?.version === TIMED_STATIC_DRAWDOWN_VERSION;
    qualityExitThresholdText = (rule) => isDbl5Sell(rule) ? rule.boxSell.channels ? `\u9632\u5B88\u7EBF ${rule.threshold} ATR \u6216\u6025\u62C9\u7EBF ${rule.boxSell.channels.impulse.rule.structure.buffer} ATR` : `\u5197\u4F59 ${rule.threshold} ATR` : isStaticDrawdownSell(rule) ? rule.bandThresholds ? rule.bandThresholds.map((value, i) => `${DRAWDOWN_BAND_LABELS[i]} \u5206\u949F \u2265 ${value}%`).join(" / ") : `\u2265 ${rule.threshold}%` : `${rule.direction} ${rule.threshold}`;
  }
});

// src/lib/fish/usdtLiveCampaign.ts
function findUsdtCampaignFollow(campaign, statuses) {
  const opening = campaign.fills[0];
  return opening && statuses.find((status) => (status.market ?? status.symbol.replace(/\//g, "")) === campaign.symbol && status.executions?.some((execution) => execution.actionId === "open" && execution.orderId === opening.orderId && execution.fills.some((fill) => fill.id === opening.id)));
}
function usdtCampaignAmounts(campaign) {
  let realized = 0;
  const fees = /* @__PURE__ */ new Map();
  for (const fill of campaign.fills) {
    realized += fill.realized;
    fees.set(fill.commissionAsset, (fees.get(fill.commissionAsset) ?? 0) + fill.commission);
  }
  return { realized, fees, net: [...fees].every(([asset, amount]) => asset === campaign.asset || amount === 0) ? realized - (fees.get(campaign.asset) ?? 0) : null };
}
var usdtLiveCampaignId, isUsdtLiveCampaignId;
var init_usdtLiveCampaign = __esm({
  "src/lib/fish/usdtLiveCampaign.ts"() {
    usdtLiveCampaignId = (campaign) => ["fish-instant-live", campaign.symbol, campaign.positionSide, campaign.direction, campaign.fills[0].id, campaign.fills[0].orderId].join("-");
    isUsdtLiveCampaignId = (id2) => /^fish-instant-live-[A-Z0-9_]+-(?:BOTH|LONG|SHORT)-(?:long|short)-\d+-\d+$/.test(id2 ?? "");
  }
});

// src/lib/fish/usdtLiveCampaignMetrics.ts
function measureFills(live) {
  const openingId = live.fills[0]?.orderId;
  const closingId = live.closedAt != null ? live.fills.at(-1)?.orderId : void 0;
  const additions = /* @__PURE__ */ new Set();
  const addFactors = /* @__PURE__ */ new Map();
  let openingSize = 0, openingNotional = 0, totalEntryNotional = 0, held = 0;
  let exitSize = 0, exitNotional = 0, firstCut = 0;
  let firstCutId;
  let valid = true;
  for (const fill of live.fills) {
    const qty = Number(fill.positionQuantity), price = Number(fill.price);
    if (!(qty > 0 && price > 0 && Number.isFinite(price * qty))) {
      valid = false;
      continue;
    }
    if (fill.action === "reduce") {
      if (fill.orderId === closingId) {
        exitSize += qty;
        exitNotional += qty * price;
      } else if (!additions.size) {
        firstCutId ??= fill.orderId;
        if (firstCutId === fill.orderId) firstCut += qty;
      }
      held -= qty;
    } else {
      totalEntryNotional += qty * price;
      if (fill.orderId === openingId) {
        openingSize += qty;
        openingNotional += qty * price;
      } else {
        additions.add(fill.orderId);
        addFactors.set(fill.orderId, (addFactors.get(fill.orderId) ?? 1) * (1 + qty / held));
      }
      held += qty;
    }
  }
  return {
    openingNotional: valid ? openingNotional : 0,
    openingSize: valid ? openingSize : 0,
    entryPrice: valid && openingSize > 0 ? openingNotional / openingSize : null,
    exitPrice: valid && exitSize > 0 ? exitNotional / exitSize : null,
    totalEntryNotional: valid ? totalEntryNotional : null,
    addCount: additions.size,
    addRatios: valid ? Array.from(addFactors.values(), (factor) => factor - 1) : null,
    earlyReduction: valid && openingSize > 0 ? firstCut / openingSize : null,
    ...usdtCampaignAmounts(live)
  };
}
function usdtLiveFillMetrics(live) {
  const cached = fillsCache.get(live);
  if (cached) return cached;
  const metrics = measureFills(live);
  fillsCache.set(live, metrics);
  return metrics;
}
function riskPercent(value) {
  return value != null && Number.isFinite(value) && value > 0 && value <= 100 ? value : void 0;
}
function usdtLiveRiskMetrics(campaign) {
  const live = campaign?.comparison?.liveUsdt;
  if (!live) return;
  const fills = usdtLiveFillMetrics(live);
  const managed = live.management;
  const firstSwitch = managed?.switches?.[0];
  const entryPlan = managed && managed.armedAt <= live.openedAt ? firstSwitch ? firstSwitch.from.plan : managed.monitor.plan : void 0;
  const opening = entryPlan?.router?.structure ?? entryPlan;
  const linked = campaign.comparison?.liveEntryRiskPct;
  const frozen = linked !== void 0 ? linked : opening && isSelectedL0(opening.payoffRiskVersion) ? riskPercent(opening.payoffRiskVersion === L0_DRAWDOWN ? initialLimitedDrawdownPct(opening) : firstSwitch ? firstSwitch.openingSelectedL0Pct : managed?.selectedL0Pct) ?? null : entryPlan && riskPercent(timedDrawdownPayoffPct(entryPlan) ?? initialPayoffRiskThreshold(entryPlan));
  const percent2 = frozen === null ? null : riskPercent(frozen) ?? 3;
  const loss = percent2 == null ? 0 : fills.openingNotional * (percent2 / 100);
  const settledNet = live.closedAt != null && live.asset === "USDT" ? fills.net : null;
  const payoff = computeSettlementPayoffRatio(settledNet, loss);
  return {
    ...fills,
    percent: percent2,
    frozen: frozen != null,
    loss,
    payoffRatio: payoff,
    payoffPercent: payoff == null ? null : payoff * 100,
    stop: fills.entryPrice == null || percent2 == null ? void 0 : fills.entryPrice * (1 + (live.direction === "long" ? -1 : 1) * percent2 / 100)
  };
}
var fillsCache;
var init_usdtLiveCampaignMetrics = __esm({
  "src/lib/fish/usdtLiveCampaignMetrics.ts"() {
    init_campaignB();
    init_qualityVeto();
    init_qualityStaticDrawdownSell();
    init_usdtLiveCampaign();
    fillsCache = /* @__PURE__ */ new WeakMap();
  }
});

// src/lib/fish/qualityCampaignRisk.ts
function qualityCampaignStaticRisk(campaign) {
  if (!campaign?.comparison) return;
  const live = usdtLiveRiskMetrics(campaign);
  if (live) return live.percent != null && live.loss > 0 && campaign.comparison.liveUsdt?.asset === "USDT" ? { percent: live.percent, notional: live.openingNotional, loss: live.loss, entry: live.entryPrice ?? void 0, stop: live.stop } : void 0;
  const evidence = campaign.comparison.sellEvidence;
  const stops = (evidence?.holdingVetoes ?? []).filter((v) => v.kind === "static-drawdown" && (v.direction === ">=" || v.direction === ">") && Number.isFinite(v.threshold) && v.threshold > 0 && v.threshold <= 100);
  const plan = campaign.comparison.monitorPlan;
  const limited = plan && (timedDrawdownPayoffPct(plan) ?? initialLimitedDrawdownPct(plan));
  const percent2 = evidence?.selectedL0Pct !== void 0 || isSelectedL0((plan?.router?.structure ?? plan)?.payoffRiskVersion) ? evidence?.selectedL0Pct : limited ?? (evidence?.dbl5SellerRiskPctV1 !== void 0 ? evidence.dbl5SellerRiskPctV1 : campaign.comparison.section === "instant" && !plan ? campaign.comparison.instant?.initialStaticStopPct : evidence && Object.prototype.hasOwnProperty.call(evidence, "initialStaticStopPct") ? evidence.initialStaticStopPct : stops.length ? Math.min(...stops.map((v) => v.threshold)) : void 0);
  if (!(percent2 > 0 && (evidence?.dbl5SellerRiskPctV1 != null || percent2 <= 100) && Number.isFinite(percent2))) return;
  const notional = campaign.comparison.holdingMetrics?.initialNotional ?? campaign.initial_main_size_usdt, entry = campaign.comparison.holdingMetrics?.entryPrice;
  if (!(notional > 0) || !Number.isFinite(notional)) return;
  return { percent: percent2, notional, loss: notional * percent2 / 100, entry: entry > 0 && Number.isFinite(entry) ? entry : void 0, stop: entry > 0 && Number.isFinite(entry) ? entry * (1 - percent2 / 100) : void 0 };
}
var init_qualityCampaignRisk = __esm({
  "src/lib/fish/qualityCampaignRisk.ts"() {
    init_qualityVeto();
    init_usdtLiveCampaignMetrics();
    init_qualityStaticDrawdownSell();
  }
});

// src/lib/campaignSections.ts
var isQualityCampaignId, isInstantCampaignId, isPaperCampaignId;
var init_campaignSections = __esm({
  "src/lib/campaignSections.ts"() {
    isQualityCampaignId = (id2) => /^fish-(sell|detect)-[\w-]+$/.test(id2 ?? "");
    isInstantCampaignId = (id2) => /^fish-instant-[\w-]+$/.test(id2 ?? "");
    isPaperCampaignId = (id2) => isQualityCampaignId(id2) || isInstantCampaignId(id2);
  }
});

// src/lib/strategyTemplates.ts
var MAIN_ADD_ROLES, INITIAL_HEDGE_SIZE_PCT, MIRROR_TP_REDUCTION_PCT, STRATEGY_TEMPLATES, LEG_ROLE_LABELS;
var init_strategyTemplates = __esm({
  "src/lib/strategyTemplates.ts"() {
    MAIN_ADD_ROLES = [
      "main_add_1",
      "main_add_2",
      "main_add_3",
      "main_add_4",
      "main_add_5",
      "main_add_6"
    ];
    INITIAL_HEDGE_SIZE_PCT = 50;
    MIRROR_TP_REDUCTION_PCT = 60;
    STRATEGY_TEMPLATES = {
      main_dual_hedge_mirror_tp: {
        name: "\u4E3B\u4ED3 + \u53CC\u5BF9\u51B2 + \u955C\u50CF\u6B62\u76C8",
        description: `\u5F00\u4E3B\u529B\u5355\u65F6\u540C\u65F6\u6302 2 \u4E2A ${INITIAL_HEDGE_SIZE_PCT}% \u5BF9\u51B2\u59D4\u6258 + 1 \u4E2A ${MIRROR_TP_REDUCTION_PCT}% \u955C\u50CF\u6B62\u76C8\u59D4\u6258\u3002\u955C\u50CF\u6B62\u76C8\u89E6\u53D1\u540E\u53D6\u6D88 1 \u5BF9\u51B2\uFF0C\u8FDB\u5165"\u5DF2\u9501\u5B9A\u4E0D\u4E8F"\u72B6\u6001\u3002`,
        expected_legs: [
          { role: "main_open", label: "\u4E3B\u529B\u5F00\u4ED3", required: true },
          { role: "hedge_initial_a", label: `\u521D\u59CB\u5BF9\u51B2 A\uFF08${INITIAL_HEDGE_SIZE_PCT}% \u4ED3\u4F4D\uFF09`, required: true },
          { role: "hedge_initial_b", label: `\u521D\u59CB\u5BF9\u51B2 B\uFF08${INITIAL_HEDGE_SIZE_PCT}% \u4ED3\u4F4D\uFF09`, required: true },
          { role: "mirror_tp", label: `\u955C\u50CF\u6B62\u76C8\u59D4\u6258\uFF08${MIRROR_TP_REDUCTION_PCT}% \u4ED3\u4F4D\uFF09`, required: true }
        ],
        rolling_roles: ["main_add_1", "main_add_2", "main_add_3", "hedge_rolling", "reentry_main", "reentry_hedge"]
      },
      rolling: {
        name: "\u6EDA\u4ED3",
        description: `\u4E0E\u300C\u4E3B\u4ED3 + \u53CC\u5BF9\u51B2 + \u955C\u50CF\u6B62\u76C8\u300D\u540C\u4E00\u5957 SOP\uFF1A\u5F00\u4E3B\u529B\u5355\u65F6\u6302 2 \u4E2A ${INITIAL_HEDGE_SIZE_PCT}% \u5BF9\u51B2 + 1 \u4E2A ${MIRROR_TP_REDUCTION_PCT}% \u955C\u50CF\u6B62\u76C8\uFF0C\u6309\u6EDA\u52A8\u89C4\u5219\u63A8\u8FDB\u3002`,
        expected_legs: [
          { role: "main_open", label: "\u4E3B\u529B\u5F00\u4ED3", required: true },
          { role: "hedge_initial_a", label: `\u521D\u59CB\u5BF9\u51B2 A\uFF08${INITIAL_HEDGE_SIZE_PCT}% \u4ED3\u4F4D\uFF09`, required: true },
          { role: "hedge_initial_b", label: `\u521D\u59CB\u5BF9\u51B2 B\uFF08${INITIAL_HEDGE_SIZE_PCT}% \u4ED3\u4F4D\uFF09`, required: true },
          { role: "mirror_tp", label: `\u955C\u50CF\u6B62\u76C8\u59D4\u6258\uFF08${MIRROR_TP_REDUCTION_PCT}% \u4ED3\u4F4D\uFF09`, required: true }
        ],
        rolling_roles: ["main_add_1", "main_add_2", "main_add_3", "hedge_rolling", "reentry_main", "reentry_hedge"]
      },
      main_only: {
        name: "\u7EAF\u4E3B\u4ED3",
        description: "\u53EA\u6709\u4E3B\u529B\u5355\uFF0C\u65E0\u5BF9\u51B2\u3001\u65E0\u955C\u50CF\u6B62\u76C8\u3002",
        expected_legs: [{ role: "main_open", label: "\u4E3B\u529B\u5F00\u4ED3", required: true }],
        rolling_roles: ["main_add_1", "main_add_2", "main_add_3", "main_add_4", "main_add_5", "main_add_6"]
      },
      custom: {
        name: "\u5176\u4ED6",
        description: "\u4E0D\u9884\u8BBE\u7ED3\u6784\uFF0C\u6BCF\u6761 leg \u7531\u7528\u6237\u624B\u52A8\u5F52\u7C7B\u3002",
        expected_legs: [],
        rolling_roles: []
      }
    };
    LEG_ROLE_LABELS = new Proxy({
      main_open: "\u4E3B\u529B\u5F00\u4ED3",
      main_add_1: "\u52A0\u4ED31",
      main_add_2: "\u52A0\u4ED32",
      main_add_3: "\u52A0\u4ED33",
      main_add_4: "\u52A0\u4ED34",
      main_add_5: "\u52A0\u4ED35",
      main_add_6: "\u52A0\u4ED36",
      hedge_initial_a: "\u521D\u59CB\u5BF9\u51B2 A",
      hedge_initial_b: "\u521D\u59CB\u5BF9\u51B2 B",
      hedge_rolling: "\u6EDA\u52A8\u5BF9\u51B2",
      mirror_tp: "\u955C\u50CF\u6B62\u76C8",
      reentry_main: "\u91CD\u65B0\u5165\u573A\u4E3B\u529B",
      reentry_hedge: "\u91CD\u65B0\u5165\u573A\u5BF9\u51B2",
      standalone: "\u72EC\u7ACB\u5355"
    }, { get(target, key) {
      return target[key] ?? (typeof key === "string" && /^main_add_\d+$/.test(key) ? "\u52A0\u4ED3" + key.slice(9) : void 0);
    } });
  }
});

// src/lib/canonicalTimePrice.ts
var init_canonicalTimePrice = __esm({
  "src/lib/canonicalTimePrice.ts"() {
    init_turingCupMarketData();
  }
});

// src/lib/objectiveOperationTime.ts
function safeTimeMs(value) {
  if (value == null || value === "") return null;
  const time = typeof value === "number" ? value : new Date(value).getTime();
  return Number.isFinite(time) && time > 0 ? time : null;
}
function tradeRecordOperationTime(record) {
  return safeTimeMs(record?.operationAt ?? record?.closedRealAt);
}
function recordRecency(record) {
  return safeTimeMs(record.closedRealAt) ?? safeTimeMs(record.closeTime) ?? 0;
}
function buildTradeRecordLookup(records) {
  const lookup = /* @__PURE__ */ new Map();
  const latestByFill = /* @__PURE__ */ new Map();
  const latestByPosition = /* @__PURE__ */ new Map();
  const newer = (candidate, current) => !current || recordRecency(candidate) > recordRecency(current);
  for (const record of records) {
    lookup.set(record.id, record);
    if (record.fillId && newer(record, latestByFill.get(record.fillId))) {
      latestByFill.set(record.fillId, record);
    }
    if (!record.positionId) continue;
    const current = latestByPosition.get(record.positionId);
    const isMainFill = record.fillId === record.positionId;
    const currentIsMainFill = current != null && current.fillId === current.positionId;
    if (current == null || isMainFill && !currentIsMainFill || isMainFill === currentIsMainFill && newer(record, current)) {
      latestByPosition.set(record.positionId, record);
    }
  }
  for (const [fillId, record] of latestByFill) {
    if (!lookup.has(fillId)) lookup.set(fillId, record);
  }
  for (const [positionId, record] of latestByPosition) {
    if (!lookup.has(positionId)) lookup.set(positionId, record);
  }
  return lookup;
}
function journalSimulatedCloseTime(journal) {
  return safeTimeMs(
    journal.post_simulated_close_time ?? (journal.source === "retroactive_from_record" ? journal.post_real_close_time : null)
  );
}
function journalOpenOperationTime(journal) {
  return journal.source === "live" ? safeTimeMs(journal.pre_real_time) : null;
}
function journalCloseOperationTime(journal, record) {
  const recordTime = tradeRecordOperationTime(record);
  if (recordTime != null) return recordTime;
  const journalTime = safeTimeMs(journal.post_real_close_time);
  if (journalTime == null) return null;
  if (journal.source !== "retroactive_from_record") return journalTime;
  const simulatedClose = journalSimulatedCloseTime(journal);
  if (simulatedClose == null || simulatedClose === journalTime) return null;
  return journalTime;
}
var init_objectiveOperationTime = __esm({
  "src/lib/objectiveOperationTime.ts"() {
  }
});

// src/data/binanceLeverageTiers.json
var binanceLeverageTiers_default;
var init_binanceLeverageTiers = __esm({
  "src/data/binanceLeverageTiers.json"() {
    binanceLeverageTiers_default = {
      fetchedAt: "2026-09-16T15:08:52.487Z",
      sources: { usdmBrackets: "https://www.binance.info/bapi/futures/v1/friendly/future/common/brackets", coinmBrackets: "https://www.binance.info/bapi/futures/v1/friendly/delivery/common/brackets", coinmExchangeInfo: "https://dapi.binance.com/dapi/v1/exchangeInfo", usdmVersion: "1789571332487_1789571332487", mode: "saved-snapshot" },
      usdm: {
        tables: [
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 20, 0.025, 50], [1e4, 2e4, 10, 0.05, 300], [2e4, 5e4, 5, 0.1, 1300], [5e4, 25e4, 4, 0.125, 2550], [25e4, 5e5, 3, 0.1667, 12975], [5e5, 75e5, 2, 0.25, 54625], [75e5, 125e5, 1, 0.5, 1929625]],
          [[0, 1e5, 20, 0.025, 0], [1e5, 5e5, 15, 0.0333, 830], [5e5, 2e6, 10, 0.05, 9180], [2e6, 5e6, 5, 0.1, 109180], [5e6, 1e7, 4, 0.125, 234180], [1e7, 25e6, 3, 0.1667, 651180], [25e6, 5e7, 2, 0.25, 2733680], [5e7, 1e8, 1, 0.5, 15233680]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 25e3, 20, 0.025, 75], [25e3, 62500, 10, 0.05, 700], [62500, 125e3, 5, 0.1, 3825], [125e3, 25e4, 4, 0.125, 6950], [25e4, 5e5, 3, 0.1667, 17375], [5e5, 75e5, 2, 0.25, 59025], [75e5, 125e5, 1, 0.5, 1934025]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 2e4, 10, 0.05, 275], [2e4, 5e4, 5, 0.1, 1275], [5e4, 1e5, 4, 0.125, 2525], [1e5, 25e4, 3, 0.1667, 6695], [25e4, 25e5, 2, 0.25, 27520], [25e5, 5e6, 1, 0.5, 652520]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 1e4, 10, 0.05, 125], [1e4, 5e4, 5, 0.1, 625], [5e4, 1e5, 4, 0.125, 1875], [1e5, 25e4, 3, 0.1667, 6045], [25e4, 25e5, 2, 0.25, 26870], [25e5, 5e6, 1, 0.5, 651870]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 25e3, 25, 0.02, 75], [25e3, 5e4, 20, 0.025, 200], [5e4, 125e3, 10, 0.05, 1450], [125e3, 25e4, 5, 0.1, 7700], [25e4, 5e5, 4, 0.125, 13950], [5e5, 1e6, 3, 0.1667, 34800], [1e6, 75e5, 2, 0.25, 118100], [75e5, 125e5, 1, 0.5, 1993100]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 25e4, 3, 0.1667, 4919], [25e4, 25e5, 2, 0.25, 25744], [25e5, 5e6, 1, 0.5, 650744]],
          [[0, 25e4, 25, 0.02, 0], [25e4, 1e6, 20, 0.025, 1250], [1e6, 2e6, 15, 0.0333, 9550], [2e6, 5e6, 10, 0.05, 42950], [5e6, 8e6, 5, 0.1, 292950], [8e6, 15e6, 4, 0.125, 492950], [15e6, 25e6, 3, 0.1667, 1118450], [25e6, 5e7, 2, 0.25, 3200950], [5e7, 2e8, 1, 0.5, 15700950]],
          [[0, 5e4, 50, 0.01, 0], [5e4, 375e3, 25, 0.02, 500], [375e3, 2e6, 10, 0.05, 11750], [2e6, 4e6, 5, 0.1, 111750], [4e6, 1e7, 4, 0.125, 211750], [1e7, 2e7, 3, 0.15, 461750], [2e7, 4e7, 2, 0.25, 2461750], [4e7, 12e7, 1, 0.5, 12461750]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 25e4, 3, 0.1667, 5920], [25e4, 25e5, 2, 0.25, 26745], [25e5, 5e6, 1, 0.5, 651745]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 1e4, 10, 0.05, 125], [1e4, 6e4, 5, 0.1, 625], [6e4, 7e4, 4, 0.125, 2125], [7e4, 25e4, 3, 0.1667, 5044], [25e4, 25e5, 2, 0.25, 25869], [25e5, 5e6, 1, 0.5, 650869]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 5e4, 25, 0.02, 75], [5e4, 1e5, 20, 0.025, 325], [1e5, 175e3, 15, 0.0333, 1155], [175e3, 25e4, 10, 0.05, 4077.5], [25e4, 75e4, 5, 0.1, 16577.5], [75e4, 15e5, 4, 0.125, 35327.5], [15e5, 45e5, 3, 0.1667, 97877.5], [45e5, 75e5, 2, 0.25, 472727.5], [75e5, 125e5, 1, 0.5, 23477275e-1]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 25e4, 3, 0.1667, 4919], [25e4, 5e5, 2, 0.25, 25744], [5e5, 8e5, 1, 0.5, 150744]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 25e3, 25, 0.02, 75], [25e3, 5e4, 20, 0.025, 200], [5e4, 125e3, 10, 0.05, 1450], [125e3, 25e4, 5, 0.1, 7700], [25e4, 5e5, 4, 0.125, 13950], [5e5, 45e5, 3, 0.1667, 34800], [45e5, 75e5, 2, 0.25, 409650], [75e5, 125e5, 1, 0.5, 2284650]],
          [[0, 375e3, 25, 0.02, 0], [375e3, 2e6, 10, 0.05, 11250], [2e6, 4e6, 5, 0.1, 111250], [4e6, 1e7, 4, 0.125, 211250], [1e7, 2e7, 3, 0.15, 461250], [2e7, 4e7, 2, 0.25, 2461250], [4e7, 4e8, 1, 0.5, 12461250]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 7e5, 3, 0.1667, 4919], [7e5, 25e5, 2, 0.25, 63229], [25e5, 5e6, 1, 0.5, 688229]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 5e4, 25, 0.02, 75], [5e4, 1e5, 20, 0.025, 325], [1e5, 175e3, 15, 0.0333, 1155], [175e3, 25e4, 10, 0.05, 4077.5], [25e4, 75e4, 5, 0.1, 16577.5], [75e4, 15e5, 4, 0.125, 35327.5], [15e5, 45e5, 3, 0.1667, 97877.5], [45e5, 75e5, 2, 0.25, 472727.5], [75e5, 12e6, 1, 0.5, 23477275e-1]],
          [[0, 5e3, 8, 0.02, 0], [5e3, 25e3, 7, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 15e5, 1, 0.5, 386900]],
          [[0, 5e4, 100, 5e-3, 0], [5e4, 4e5, 75, 65e-4, 75], [4e5, 1e6, 50, 0.01, 1475], [1e6, 4e6, 25, 0.02, 11475], [4e6, 8e6, 20, 0.025, 31475], [8e6, 4e7, 10, 0.05, 231475], [4e7, 8e7, 5, 0.1, 2231475], [8e7, 1e8, 4, 0.125, 4231475], [1e8, 2e8, 2, 0.25, 16731475], [2e8, 4e8, 1, 0.5, 66731475]],
          [[0, 5e3, 25, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 3e7, 1, 0.5, 386950]],
          [[0, 1e5, 25, 0.02, 0], [1e5, 2e5, 20, 0.025, 500], [2e5, 5e5, 15, 0.0333, 2160], [5e5, 2e6, 10, 0.05, 10510], [2e6, 5e6, 5, 0.1, 110510], [5e6, 1e7, 4, 0.125, 235510], [1e7, 25e6, 3, 0.1667, 652510], [25e6, 5e7, 2, 0.25, 2735010], [5e7, 1e8, 1, 0.5, 15235010]],
          [[0, 5e3, 20, 0.03, 0], [5e3, 1e4, 10, 0.05, 100], [1e4, 6e4, 5, 0.1, 600], [6e4, 7e4, 4, 0.125, 2100], [7e4, 25e4, 3, 0.1667, 5019], [25e4, 25e5, 2, 0.25, 25844], [25e5, 5e6, 1, 0.5, 650844]],
          [[0, 5e3, 40, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 2e4, 10, 0.05, 275], [2e4, 5e4, 5, 0.1, 1275], [5e4, 1e5, 4, 0.125, 2525], [1e5, 25e4, 3, 0.1667, 6695], [25e4, 25e5, 2, 0.25, 27520], [25e5, 5e6, 1, 0.5, 652520]],
          [[0, 7500, 75, 0.01, 0], [7500, 15e3, 50, 0.015, 37.5], [15e3, 75e3, 25, 0.02, 112.5], [75e3, 2e5, 20, 0.025, 487.5], [2e5, 35e4, 15, 0.0333, 2147.5], [35e4, 75e4, 10, 0.05, 7992.5], [75e4, 3e6, 5, 0.1, 45492.5], [3e6, 45e5, 4, 0.125, 120492.5], [45e5, 75e5, 3, 0.1667, 308142.5], [75e5, 12e6, 2, 0.25, 932892.5], [12e6, 18e6, 1, 0.5, 39328925e-1]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 25e4, 3, 0.1667, 5920], [25e4, 5e5, 2, 0.25, 26745], [5e5, 8e5, 1, 0.5, 151745]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 15e5, 4, 0.125, 11900], [15e5, 3e6, 2, 0.25, 199400], [3e6, 4e6, 1, 0.5, 949400]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 1e6, 25, 0.02, 1100], [1e6, 2e6, 20, 0.025, 6100], [2e6, 5e6, 10, 0.05, 56100], [5e6, 75e5, 5, 0.1, 306100], [75e5, 1e7, 4, 0.125, 493600], [1e7, 125e5, 2, 0.25, 1743600], [125e5, 15e6, 1, 0.5, 4868600]],
          [[0, 2e5, 10, 0.05, 0], [2e5, 2e6, 5, 0.1, 1e4], [2e6, 3e6, 4, 0.125, 6e4], [3e6, 5e6, 3, 0.1667, 185100], [5e6, 75e5, 2, 0.25, 601600], [75e5, 12e6, 1, 0.5, 2476600]],
          [[0, 5e4, 5, 0.1, 0], [5e4, 1e5, 4, 0.125, 1250], [1e5, 25e4, 3, 0.1667, 5420], [25e4, 5e5, 2, 0.25, 26245], [5e5, 8e5, 1, 0.5, 151245]],
          [[0, 5e4, 50, 0.01, 0], [5e4, 2e5, 40, 0.0125, 125], [2e5, 5e5, 25, 0.02, 1625], [5e5, 1e6, 20, 0.025, 4125], [1e6, 2e6, 15, 0.0333, 12425], [2e6, 5e6, 10, 0.05, 45825], [5e6, 8e6, 5, 0.1, 295825], [8e6, 2e7, 4, 0.125, 495825], [2e7, 5e7, 3, 0.1667, 1329825], [5e7, 1e8, 2, 0.25, 5494825], [1e8, 2e8, 1, 0.5, 30494825]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 15e5, 1, 0.5, 386900]],
          [[0, 2e3, 20, 0.025, 0], [2e3, 1e4, 10, 0.05, 50], [1e4, 6e4, 5, 0.1, 550], [6e4, 7e4, 4, 0.125, 2050], [7e4, 25e4, 3, 0.1667, 4969], [25e4, 25e5, 2, 0.25, 25794], [25e5, 5e6, 1, 0.5, 650794]],
          [[0, 5e4, 25, 0.02, 0], [5e4, 1e5, 20, 0.025, 250], [1e5, 5e5, 15, 0.0333, 1080], [5e5, 2e6, 10, 0.05, 9430], [2e6, 5e6, 5, 0.1, 109430], [5e6, 1e7, 4, 0.125, 234430], [1e7, 25e6, 3, 0.1667, 651430], [25e6, 5e7, 2, 0.25, 2733930], [5e7, 1e8, 1, 0.5, 15233930]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 25e4, 3, 0.1667, 5920], [25e4, 4e5, 2, 0.25, 26745], [4e5, 5e5, 1, 0.5, 126745]],
          [[0, 5e4, 50, 0.01, 0], [5e4, 2e5, 25, 0.02, 500], [2e5, 4e5, 20, 0.025, 1500], [4e5, 1e6, 15, 0.0333, 4820], [1e6, 5e6, 10, 0.05, 21520], [5e6, 15e6, 5, 0.1, 271520], [15e6, 2e7, 4, 0.125, 646520], [2e7, 3e7, 3, 0.1667, 1480520], [3e7, 5e7, 2, 0.25, 3979520], [5e7, 1e8, 1, 0.5, 16479520]],
          [[0, 5e3, 40, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 25e3, 10, 0.05, 275], [25e3, 5e4, 5, 0.1, 1525], [5e4, 1e5, 4, 0.125, 2775], [1e5, 25e4, 3, 0.1667, 6945], [25e4, 25e5, 2, 0.25, 27770], [25e5, 5e6, 1, 0.5, 652770]],
          [[0, 15e4, 25, 0.02, 0], [15e4, 3e5, 20, 0.025, 750], [3e5, 75e4, 15, 0.0333, 3240], [75e4, 3e6, 10, 0.05, 15765], [3e6, 1e7, 5, 0.1, 165765], [1e7, 15e6, 4, 0.125, 415765], [15e6, 25e6, 3, 0.1667, 1041265], [25e6, 5e7, 2, 0.25, 3123765], [5e7, 1e8, 1, 0.5, 15623765]],
          [[0, 1e4, 100, 5e-3, 0], [1e4, 5e4, 75, 65e-4, 15], [5e4, 2e5, 50, 0.01, 190], [2e5, 5e5, 40, 0.012, 590], [5e5, 1e6, 25, 0.02, 4590], [1e6, 2e6, 20, 0.025, 9590], [2e6, 4e6, 10, 0.05, 59590], [4e6, 8e6, 5, 0.1, 259590], [8e6, 12e6, 4, 0.125, 459590], [12e6, 2e7, 2, 0.25, 1959590], [2e7, 5e7, 1, 0.5, 6959590]],
          [[0, 15e3, 10, 0.05, 0], [15e3, 5e4, 5, 0.1, 750], [5e4, 15e4, 4, 0.125, 2e3], [15e4, 25e4, 3, 0.1667, 8255], [25e4, 25e5, 2, 0.25, 29080], [25e5, 5e6, 1, 0.5, 654080]],
          [[0, 5e3, 11, 0.02, 0], [5e3, 25e3, 10, 0.025, 25], [25e3, 1e5, 8, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 15e5, 1, 0.5, 386900]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 5e5, 2, 0.125, 11900], [5e5, 1e6, 1, 0.5, 199400]],
          [[0, 5e3, 50, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 3e7, 1, 0.5, 386950]],
          [[0, 5e3, 50, 0.01, 0], [5e3, 5e4, 25, 0.02, 50], [5e4, 6e5, 20, 0.025, 300], [6e5, 12e5, 10, 0.05, 15300], [12e5, 3e6, 5, 0.1, 75300], [3e6, 4e6, 4, 0.125, 150300], [4e6, 6e6, 2, 0.25, 650300], [6e6, 1e7, 1, 0.5, 2150300]],
          [[0, 5e3, 20, 0.02, 0], [5e3, 25e3, 15, 0.025, 25], [25e3, 2e5, 10, 0.05, 650], [2e5, 5e5, 5, 0.1, 10650], [5e5, 1e6, 4, 0.125, 23150], [1e6, 3e6, 2, 0.25, 148150], [3e6, 35e5, 1, 0.5, 898150]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 25e3, 25, 0.02, 75], [25e3, 5e4, 20, 0.025, 200], [5e4, 125e3, 10, 0.05, 1450], [125e3, 25e4, 5, 0.1, 7700], [25e4, 5e5, 4, 0.125, 13950], [5e5, 1e6, 3, 0.1667, 34800], [1e6, 75e5, 2, 0.25, 118100], [75e5, 12e6, 1, 0.5, 1993100]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 15e5, 4, 0.125, 11900], [15e5, 3e6, 2, 0.25, 199400], [3e6, 35e5, 1, 0.5, 949400]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 5e4, 50, 0.01, 50], [5e4, 2e5, 40, 0.015, 300], [2e5, 1e6, 25, 0.02, 1300], [1e6, 2e6, 20, 0.025, 6300], [2e6, 1e7, 10, 0.05, 56300], [1e7, 2e7, 5, 0.1, 556300], [2e7, 25e6, 4, 0.125, 1056300], [25e6, 5e7, 2, 0.25, 4181300], [5e7, 1e8, 1, 0.5, 16681300]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 25e3, 10, 0.05, 275], [25e3, 5e4, 5, 0.1, 1525], [5e4, 1e5, 4, 0.125, 2775], [1e5, 25e4, 3, 0.1667, 6945], [25e4, 5e5, 2, 0.25, 27770], [5e5, 8e5, 1, 0.5, 152770]],
          [[0, 25e3, 10, 0.05, 0], [25e3, 5e4, 5, 0.1, 1250], [5e4, 1e5, 4, 0.125, 2500], [1e5, 25e4, 3, 0.1667, 6670], [25e4, 5e5, 2, 0.25, 27495], [5e5, 8e5, 1, 0.5, 152495]],
          [[0, 1e5, 11, 0.025, 0], [1e5, 5e5, 10, 0.05, 2500], [5e5, 1e6, 5, 0.1, 27500], [1e6, 2e6, 3, 0.15, 77500], [2e6, 5e6, 2, 0.25, 277500], [5e6, 55e5, 1, 0.5, 1527500]],
          [[0, 2e4, 10, 0.05, 0], [2e4, 1e5, 8, 0.0625, 250], [1e5, 5e5, 5, 0.1, 4e3], [5e5, 15e5, 4, 0.125, 16500], [15e5, 3e6, 3, 0.1667, 79050], [3e6, 6e6, 2, 0.25, 328950], [6e6, 1e7, 1, 0.5, 1828950]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 25e3, 10, 0.05, 275], [25e3, 5e4, 5, 0.1, 1525], [5e4, 1e5, 4, 0.125, 2775], [1e5, 25e4, 3, 0.1667, 6945], [25e4, 25e5, 2, 0.25, 27770], [25e5, 5e6, 1, 0.5, 652770]],
          [[0, 5e3, 20, 4e-3, 0], [5e3, 25e3, 15, 5e-3, 5], [25e3, 1e5, 10, 0.01, 130], [1e5, 5e5, 7, 0.025, 1630], [5e5, 2e6, 6, 0.05, 14130], [2e6, 5e6, 5, 0.1, 114130], [5e6, 1e7, 4, 0.125, 239130], [1e7, 2e7, 3, 0.15, 489130], [2e7, 2147483647, 2, 0.25, 2489130]],
          [[0, 5e3, 20, 0.01, 0], [5e3, 25e3, 10, 0.025, 75], [25e3, 1e5, 8, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 3e6, 1, 0.5, 386950]],
          [[0, 1e4, 75, 65e-4, 0], [1e4, 5e4, 50, 0.01, 35], [5e4, 25e4, 25, 0.02, 535], [25e4, 1e6, 10, 0.05, 8035], [1e6, 2e6, 5, 0.1, 58035], [2e6, 5e6, 4, 0.125, 108035], [5e6, 1e7, 3, 0.15, 233035], [1e7, 2147483647, 2, 0.25, 1233035]],
          [[0, 25e4, 25, 0.02, 0], [25e4, 1e6, 10, 0.05, 7500], [1e6, 2e6, 5, 0.1, 57500], [2e6, 5e6, 4, 0.125, 107500], [5e6, 1e7, 3, 0.15, 232500], [1e7, 9223372036854776e3, 2, 0.25, 1232500]],
          [[0, 25e4, 25, 0.02, 0], [25e4, 1e6, 10, 0.05, 7500], [1e6, 2e6, 5, 0.1, 57500], [2e6, 5e6, 4, 0.125, 107500], [5e6, 1e7, 3, 0.15, 232500], [1e7, 2e7, 2, 0.25, 1232500], [2e7, 5e7, 1, 0.5, 6232500]],
          [[0, 375e3, 20, 0.02, 0], [375e3, 2e6, 10, 0.05, 11250], [2e6, 4e6, 5, 0.1, 111250], [4e6, 1e7, 4, 0.125, 211250], [1e7, 2e7, 3, 0.15, 461250], [2e7, 4e7, 2, 0.25, 2461250], [4e7, 4e8, 1, 0.5, 12461250]],
          [[0, 375e3, 25, 0.02, 0], [375e3, 2e6, 10, 0.05, 11250], [2e6, 4e6, 5, 0.1, 111250], [4e6, 1e7, 4, 0.125, 211250], [1e7, 2e7, 3, 0.15, 461250], [2e7, 4e7, 2, 0.25, 2461250], [4e7, 12e7, 1, 0.5, 12461250]],
          [[0, 5e3, 50, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 5e6, 1, 0.5, 386950]],
          [[0, 5e4, 50, 0.01, 0], [5e4, 15e4, 25, 0.02, 500], [15e4, 3e5, 20, 0.025, 1250], [3e5, 75e4, 15, 0.0333, 3740], [75e4, 3e6, 10, 0.05, 16265], [3e6, 1e7, 5, 0.1, 166265], [1e7, 15e6, 4, 0.125, 416265], [15e6, 25e6, 3, 0.1667, 1041765], [25e6, 5e7, 2, 0.25, 3124265], [5e7, 1e8, 1, 0.5, 15624265]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 2e6, 1, 0.5, 386900]],
          [[0, 1e4, 51, 6e-3, 0], [1e4, 25e3, 50, 7e-3, 10], [25e3, 6e5, 25, 0.01, 85], [6e5, 9e5, 20, 0.025, 9085], [9e5, 18e5, 10, 0.05, 31585], [18e5, 48e5, 5, 0.1, 121585], [48e5, 6e6, 4, 0.125, 241585], [6e6, 18e6, 2, 0.25, 991585], [18e6, 19e6, 1, 0.5, 5491585]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 25e3, 20, 0.025, 50], [25e3, 1e5, 10, 0.05, 675], [1e5, 2e5, 5, 0.1, 5675], [2e5, 5e5, 4, 0.125, 10675], [5e5, 1e6, 2, 0.25, 73175], [1e6, 2e6, 1, 0.5, 323175]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 25e4, 4, 0.125, 1750], [25e4, 5e5, 3, 0.1667, 12175], [5e5, 8e5, 2, 0.25, 53825], [8e5, 1e6, 1, 0.5, 253825]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 1e4, 50, 0.015, 25], [1e4, 5e4, 25, 0.02, 75], [5e4, 1e5, 20, 0.025, 325], [1e5, 175e3, 15, 0.03333, 1158], [175e3, 5e5, 10, 0.05, 4075.25], [5e5, 75e4, 5, 0.1, 29075.25], [75e4, 15e5, 4, 0.125, 47825.25], [15e5, 45e5, 3, 0.1667, 110375.25], [45e5, 75e5, 2, 0.25, 485225.25], [75e5, 125e5, 1, 0.5, 236022525e-2]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 7e4, 4, 0.125, 1750], [7e4, 25e4, 3, 0.1667, 4669], [25e4, 5e5, 2, 0.25, 25494], [5e5, 8e5, 1, 0.5, 150494]],
          [[0, 2e4, 10, 0.05, 0], [2e4, 5e4, 5, 0.1, 1e3], [5e4, 1e5, 4, 0.125, 2250], [1e5, 25e4, 3, 0.1667, 6420], [25e4, 5e5, 2, 0.25, 27245], [5e5, 8e5, 1, 0.5, 152245]],
          [[0, 5e3, 25, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 5e6, 1, 0.5, 386950]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 15e3, 10, 0.05, 125], [15e3, 5e4, 5, 0.1, 875], [5e4, 1e5, 4, 0.125, 2125], [1e5, 25e4, 3, 0.1667, 6295], [25e4, 25e5, 2, 0.25, 27120], [25e5, 5e6, 1, 0.5, 652120]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 25e4, 3, 0.1667, 5920], [25e4, 8e5, 2, 0.25, 26745], [8e5, 1e6, 1, 0.5, 226745]],
          [[0, 5e4, 75, 65e-4, 0], [5e4, 25e4, 50, 0.01, 175], [25e4, 5e5, 25, 0.02, 2675], [5e5, 15e5, 20, 0.025, 5175], [15e5, 5e6, 15, 0.0333, 17625], [5e6, 1e7, 10, 0.05, 101125], [1e7, 25e6, 5, 0.1, 601125], [25e6, 5e7, 4, 0.125, 1226125], [5e7, 1e8, 3, 0.1667, 3311125], [1e8, 2e8, 2, 0.25, 11641125], [2e8, 4e8, 1, 0.5, 61641125]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 25e3, 20, 0.025, 75], [25e3, 62500, 10, 0.05, 700], [62500, 125e3, 5, 0.1, 3825], [125e3, 25e4, 4, 0.125, 6950], [25e4, 5e5, 3, 0.1667, 17375], [5e5, 75e5, 2, 0.25, 59025], [75e5, 12e6, 1, 0.5, 1934025]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 1e5, 50, 0.015, 50], [1e5, 5e5, 25, 0.02, 550], [5e5, 1e6, 20, 0.025, 3050], [1e6, 5e6, 10, 0.05, 28050], [5e6, 1e7, 5, 0.1, 278050], [1e7, 125e5, 4, 0.125, 528050], [125e5, 25e6, 2, 0.25, 2090550], [25e6, 5e7, 1, 0.5, 8340550]],
          [[0, 1e4, 75, 6e-3, 0], [1e4, 5e4, 50, 0.01, 40], [5e4, 1e5, 40, 0.015, 290], [1e5, 5e5, 25, 0.02, 790], [5e5, 1e6, 20, 0.025, 3290], [1e6, 5e6, 10, 0.05, 28290], [5e6, 1e7, 5, 0.1, 278290], [1e7, 125e5, 4, 0.125, 528290], [125e5, 25e6, 2, 0.25, 2090790], [25e6, 5e7, 1, 0.5, 8340790]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 5e4, 20, 0.025, 75], [5e4, 12e5, 10, 0.05, 1325], [12e5, 3e6, 5, 0.1, 61325], [3e6, 36e5, 4, 0.125, 136325], [36e5, 9e6, 2, 0.25, 586325], [9e6, 15e6, 1, 0.5, 2836325]],
          [[0, 2e4, 75, 65e-4, 0], [2e4, 2e5, 50, 0.01, 70], [2e5, 3e5, 40, 0.015, 1070], [3e5, 15e5, 25, 0.02, 2570], [15e5, 3e6, 20, 0.025, 10070], [3e6, 15e6, 10, 0.05, 85070], [15e6, 2e7, 5, 0.1, 835070], [2e7, 25e6, 4, 0.125, 1335070], [25e6, 3e7, 2, 0.25, 4460070], [3e7, 35e6, 1, 0.5, 11960070]],
          [[0, 5e3, 50, 65e-4, 0], [5e3, 25e3, 40, 75e-4, 5], [25e3, 15e4, 25, 0.01, 67.5], [15e4, 6e5, 20, 0.025, 2317.5], [6e5, 15e5, 10, 0.05, 17317.5], [15e5, 3e6, 5, 0.1, 92317.5], [3e6, 5e6, 4, 0.125, 167317.5], [5e6, 9e6, 2, 0.25, 792317.5], [9e6, 3e7, 1, 0.5, 30423175e-1]],
          [[0, 25e3, 75, 65e-4, 0], [25e3, 15e4, 50, 0.01, 87.5], [15e4, 2e5, 40, 0.015, 837.5], [2e5, 8e5, 25, 0.02, 1837.5], [8e5, 16e5, 20, 0.025, 5837.5], [16e5, 3e6, 10, 0.05, 45837.5], [3e6, 5e6, 5, 0.1, 195837.5], [5e6, 6e6, 4, 0.125, 320837.5], [6e6, 7e6, 2, 0.25, 10708375e-1], [7e6, 8e6, 1, 0.5, 28208375e-1]],
          [[0, 4e4, 5, 0.1, 0], [4e4, 1e5, 4, 0.125, 1e3], [1e5, 25e4, 3, 0.1667, 5170], [25e4, 5e5, 2, 0.25, 25995], [5e5, 8e5, 1, 0.5, 150995]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 2e5, 3, 0.1667, 5920], [2e5, 3e5, 2, 0.25, 22580], [3e5, 35e4, 1, 0.5, 97580]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 6e4, 50, 0.015, 50], [6e4, 3e5, 25, 0.02, 350], [3e5, 6e5, 20, 0.025, 1850], [6e5, 3e6, 10, 0.05, 16850], [3e6, 6e6, 5, 0.1, 166850], [6e6, 75e5, 4, 0.125, 316850], [75e5, 15e6, 2, 0.25, 1254350], [15e6, 3e7, 1, 0.5, 5004350]],
          [[0, 5e4, 75, 0.01, 0], [5e4, 15e4, 50, 0.015, 250], [15e4, 5e5, 25, 0.02, 1e3], [5e5, 6e5, 20, 0.025, 3500], [6e5, 3e6, 10, 0.05, 18500], [3e6, 6e6, 5, 0.1, 168500], [6e6, 75e5, 4, 0.125, 318500], [75e5, 15e6, 2, 0.25, 1256e3], [15e6, 3e7, 1, 0.5, 5006e3]],
          [[0, 1e3, 20, 0.04, 0], [1e3, 1e4, 10, 0.05, 10], [1e4, 6e4, 5, 0.1, 510], [6e4, 7e4, 4, 0.125, 2010], [7e4, 2e5, 3, 0.1667, 4929], [2e5, 8e5, 2, 0.25, 21589], [8e5, 1e6, 1, 0.5, 221589]],
          [[0, 1e5, 10, 0.025, 0], [1e5, 5e5, 8, 0.05, 2500], [5e5, 1e6, 5, 0.1, 27500], [1e6, 2e6, 3, 0.15, 77500], [2e6, 5e6, 2, 0.25, 277500], [5e6, 55e5, 1, 0.5, 1527500]],
          [[0, 1e4, 25, 0.01, 0], [1e4, 2e4, 20, 0.015, 50], [2e4, 6e4, 15, 0.02, 150], [6e4, 12e4, 10, 0.025, 450], [12e4, 6e5, 8, 0.05, 3450], [6e5, 12e5, 5, 0.1, 33450], [12e5, 15e5, 4, 0.125, 63450], [15e5, 3e6, 2, 0.25, 250950], [3e6, 6e6, 1, 0.5, 1000950]],
          [[0, 4e4, 7, 0.025, 0], [4e4, 2e5, 6, 0.05, 1e3], [2e5, 4e5, 5, 0.1, 11e3], [4e5, 5e5, 4, 0.125, 21e3], [5e5, 6e5, 2, 0.25, 83500], [6e5, 7e5, 1, 0.5, 233500]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 3e4, 5, 0.1, 500], [3e4, 8e4, 4, 0.125, 1250], [8e4, 15e4, 3, 0.1667, 4586], [15e4, 5e5, 2, 0.25, 17081], [5e5, 8e5, 1, 0.5, 142081]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 25e3, 20, 0.025, 25], [25e3, 6e5, 10, 0.05, 650], [6e5, 16e5, 5, 0.1, 30650], [16e5, 2e6, 4, 0.125, 70650], [2e6, 6e6, 2, 0.25, 320650], [6e6, 65e5, 1, 0.5, 1820650]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 20, 0.025, 50], [1e4, 2e4, 10, 0.05, 300], [2e4, 5e4, 5, 0.1, 1300], [5e4, 25e4, 4, 0.125, 2550], [25e4, 1e6, 3, 0.1667, 12975], [1e6, 75e5, 2, 0.25, 96275], [75e5, 125e5, 1, 0.5, 1971275]],
          [[0, 3e3, 20, 0.03, 0], [3e3, 15e3, 10, 0.05, 60], [15e3, 5e4, 5, 0.1, 810], [5e4, 15e4, 4, 0.125, 2060], [15e4, 1e6, 3, 0.1667, 8315], [1e6, 25e5, 2, 0.25, 91615], [25e5, 5e6, 1, 0.5, 716615]],
          [[0, 5e3, 50, 0.012, 0], [5e3, 25e3, 20, 0.025, 65], [25e3, 1e5, 10, 0.05, 690], [1e5, 25e4, 5, 0.1, 5690], [25e4, 1e6, 2, 0.125, 11940], [1e6, 3e7, 1, 0.5, 386940]],
          [[0, 1e5, 5, 0.08, 0], [1e5, 2e5, 4, 0.1, 2e3], [2e5, 4e5, 3, 0.125, 7e3], [4e5, 5e5, 2, 0.25, 57e3], [5e5, 55e4, 1, 0.5, 182e3]],
          [[0, 25e3, 8, 0.025, 0], [25e3, 2e5, 6, 0.05, 625], [2e5, 5e5, 5, 0.1, 10625], [5e5, 6e5, 4, 0.125, 23125], [6e5, 7e5, 2, 0.25, 98125], [7e5, 1e6, 1, 0.5, 273125]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 25e3, 20, 0.025, 50], [25e3, 1e5, 10, 0.05, 675], [1e5, 25e4, 5, 0.1, 5675], [25e4, 1e6, 2, 0.125, 11925], [1e6, 15e5, 1, 0.5, 386925]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 12e5, 1, 0.5, 386900]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 1e5, 50, 0.015, 50], [1e5, 9e5, 25, 0.02, 550], [9e5, 11e5, 20, 0.025, 5050], [11e5, 5e6, 10, 0.05, 32550], [5e6, 7e6, 5, 0.1, 282550], [7e6, 8e6, 4, 0.125, 457550], [8e6, 9e6, 2, 0.25, 1457550], [9e6, 1e7, 1, 0.5, 3707550]],
          [[0, 5e3, 50, 6e-3, 0], [5e3, 5e4, 25, 0.01, 20], [5e4, 6e5, 20, 0.025, 770], [6e5, 12e5, 10, 0.05, 15770], [12e5, 3e6, 5, 0.1, 75770], [3e6, 5e6, 4, 0.125, 150770], [5e6, 12e6, 2, 0.25, 775770], [12e6, 2e7, 1, 0.5, 3775770]],
          [[0, 5e3, 75, 6e-3, 0], [5e3, 5e4, 50, 0.01, 20], [5e4, 1e5, 25, 0.015, 270], [1e5, 5e5, 20, 0.02, 770], [5e5, 1e6, 10, 0.025, 3270], [1e6, 5e6, 5, 0.05, 28270], [5e6, 6e6, 4, 0.1, 278270], [6e6, 7e6, 3, 0.125, 428270], [7e6, 8e6, 2, 0.25, 1303270], [8e6, 9e6, 1, 0.5, 3303270]],
          [[0, 6e3, 10, 0.05, 0], [6e3, 5e4, 5, 0.1, 300], [5e4, 1e5, 4, 0.125, 1550], [1e5, 3e5, 3, 0.1667, 5720], [3e5, 1e6, 2, 0.25, 30710], [1e6, 2e6, 1, 0.5, 280710]],
          [[0, 1e4, 50, 0.015, 0], [1e4, 5e4, 25, 0.02, 50], [5e4, 1e5, 20, 0.025, 300], [1e5, 125e3, 15, 0.0333, 1130], [125e3, 25e4, 10, 0.05, 3217.5], [25e4, 75e4, 5, 0.1, 15717.5], [75e4, 15e5, 4, 0.125, 34467.5], [15e5, 25e5, 3, 0.1667, 97017.5], [25e5, 5e6, 2, 0.25, 305267.5], [5e6, 75e5, 1, 0.5, 15552675e-1]],
          [[0, 1e4, 75, 6e-3, 0], [1e4, 5e4, 50, 0.01, 40], [5e4, 8e4, 40, 0.015, 290], [8e4, 2e5, 25, 0.02, 690], [2e5, 6e5, 20, 0.025, 1690], [6e5, 2e6, 10, 0.05, 16690], [2e6, 4e6, 5, 0.1, 116690], [4e6, 5e6, 4, 0.125, 216690], [5e6, 12e6, 2, 0.25, 841690], [12e6, 2e7, 1, 0.5, 3841690]],
          [[0, 5e3, 20, 0.02, 0], [5e3, 25e3, 10, 0.025, 25], [25e3, 1e5, 8, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 15e5, 1, 0.5, 386900]],
          [[0, 5e3, 8, 0.02, 0], [5e3, 25e3, 7, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 15e5, 4, 0.125, 11900], [15e5, 3e6, 2, 0.25, 199400], [3e6, 4e6, 1, 0.5, 949400]],
          [[0, 5e3, 75, 5e-3, 0], [5e3, 1e4, 50, 65e-4, 7.5], [1e4, 25e3, 40, 75e-4, 17.5], [25e3, 5e4, 25, 0.01, 80], [5e4, 25e4, 20, 0.025, 830], [25e4, 1e6, 10, 0.05, 7080], [1e6, 2e6, 5, 0.1, 57080], [2e6, 5e6, 4, 0.125, 107080], [5e6, 2e7, 2, 0.25, 732080], [2e7, 5e7, 1, 0.5, 5732080]],
          [[0, 25e3, 75, 5e-3, 0], [25e3, 8e4, 50, 0.01, 125], [8e4, 16e4, 40, 0.015, 525], [16e4, 8e5, 25, 0.02, 1325], [8e5, 16e5, 20, 0.025, 5325], [16e5, 8e6, 10, 0.05, 45325], [8e6, 16e6, 5, 0.1, 445325], [16e6, 2e7, 4, 0.125, 845325], [2e7, 4e7, 2, 0.25, 3345325], [4e7, 8e7, 1, 0.5, 13345325]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 25e4, 3, 0.1667, 5920], [25e4, 3e5, 2, 0.25, 26745], [3e5, 5e5, 1, 0.5, 101745]],
          [[0, 5e3, 10, 0.015, 0], [5e3, 25e3, 8, 0.025, 50], [25e3, 1e5, 6, 0.05, 675], [1e5, 2e5, 5, 0.1, 5675], [2e5, 5e5, 4, 0.125, 10675], [5e5, 1e6, 2, 0.25, 73175], [1e6, 2e6, 1, 0.5, 323175]],
          [[0, 5e3, 10, 0.01, 0], [5e3, 25e3, 8, 0.025, 75], [25e3, 1e5, 6, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 15e5, 1, 0.5, 386950]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 20, 0.025, 50], [1e4, 2e4, 10, 0.05, 300], [2e4, 5e4, 5, 0.1, 1300], [5e4, 1e5, 4, 0.125, 2550], [1e5, 25e4, 3, 0.1667, 6720], [25e4, 25e5, 2, 0.25, 27545], [25e5, 5e6, 1, 0.5, 652545]],
          [[0, 5e3, 75, 5e-3, 0], [5e3, 1e4, 50, 65e-4, 7.5], [1e4, 5e4, 40, 0.01, 42.5], [5e4, 5e5, 25, 0.02, 542.5], [5e5, 2e6, 10, 0.05, 15542.5], [2e6, 4e6, 5, 0.1, 115542.5], [4e6, 8e6, 4, 0.125, 215542.5], [8e6, 15e6, 3, 0.15, 415542.5], [15e6, 2e7, 2, 0.25, 19155425e-1], [2e7, 5e7, 1, 0.5, 69155425e-1]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 1e5, 50, 0.01, 50], [1e5, 16e4, 40, 0.015, 550], [16e4, 8e5, 25, 0.02, 1350], [8e5, 16e5, 20, 0.025, 5350], [16e5, 8e6, 10, 0.05, 45350], [8e6, 16e6, 5, 0.1, 445350], [16e6, 2e7, 4, 0.125, 845350], [2e7, 4e7, 2, 0.25, 3345350], [4e7, 8e7, 1, 0.5, 13345350]],
          [[0, 1e4, 10, 0.09, 0], [1e4, 5e4, 5, 0.1, 100], [5e4, 1e5, 4, 0.125, 1350], [1e5, 25e4, 3, 0.1667, 5520], [25e4, 5e5, 2, 0.25, 26345], [5e5, 8e5, 1, 0.5, 151345]],
          [[0, 5e3, 11, 0.01, 0], [5e3, 25e3, 10, 0.025, 75], [25e3, 1e5, 8, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 15e5, 1, 0.5, 386950]],
          [[0, 25e3, 10, 0.025, 0], [25e3, 1e5, 6, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 1e6, 4, 0.125, 11875], [1e6, 13e5, 2, 0.25, 136875], [13e5, 15e5, 1, 0.5, 461875]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 2e5, 50, 6e-3, 10], [2e5, 4e5, 40, 0.01, 810], [4e5, 15e5, 25, 0.02, 4810], [15e5, 3e6, 20, 0.025, 12310], [3e6, 15e6, 10, 0.05, 87310], [15e6, 3e7, 5, 0.1, 837310], [3e7, 375e5, 4, 0.125, 1587310], [375e5, 75e6, 2, 0.25, 6274810], [75e6, 15e7, 1, 0.5, 25024810]],
          [[0, 1e6, 5, 0.05, 0], [1e6, 2e6, 4, 0.1, 5e4], [2e6, 22e5, 3, 0.125, 1e5], [22e5, 23e5, 2, 0.25, 375e3], [23e5, 24e5, 1, 0.5, 95e4]],
          [[0, 25e3, 8, 0.025, 0], [25e3, 25e4, 6, 0.05, 625], [25e4, 5e5, 5, 0.1, 13125], [5e5, 1e6, 4, 0.125, 25625], [1e6, 15e5, 2, 0.25, 150625], [15e5, 2e6, 1, 0.5, 525625]],
          [[0, 5e3, 10, 0.015, 0], [5e3, 1e4, 8, 0.025, 50], [1e4, 1e5, 6, 0.05, 300], [1e5, 2e5, 5, 0.1, 5300], [2e5, 5e5, 4, 0.125, 10300], [5e5, 1e6, 2, 0.25, 72800], [1e6, 2e6, 1, 0.5, 322800]],
          [[0, 5e4, 30, 4e-3, 0], [5e4, 25e4, 25, 5e-3, 50], [25e4, 1e6, 20, 0.01, 1300], [1e6, 75e5, 15, 0.025, 16300], [75e5, 4e7, 10, 0.05, 203800], [4e7, 1e8, 5, 0.1, 2203800], [1e8, 2e8, 4, 0.125, 4703800], [2e8, 4e8, 3, 0.15, 9703800], [4e8, 6e8, 2, 0.25, 49703800], [6e8, 6005e5, 1, 0.5, 199703800]],
          [[0, 5e3, 25, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 9223372036854776e3, 1, 0.5, 386950]],
          [[0, 15e3, 100, 5e-3, 0], [15e3, 75e3, 75, 65e-4, 22.5], [75e3, 3e5, 50, 0.01, 285], [3e5, 75e4, 40, 0.012, 885], [75e4, 15e5, 25, 0.02, 6885], [15e5, 3e6, 20, 0.025, 14385], [3e6, 6e6, 10, 0.05, 89385], [6e6, 12e6, 5, 0.1, 389385], [12e6, 2e7, 4, 0.125, 689385], [2e7, 3e7, 2, 0.25, 3189385], [3e7, 6e7, 1, 0.5, 10689385]],
          [[0, 5e4, 125, 4e-3, 0], [5e4, 5e5, 100, 5e-3, 50], [5e5, 1e7, 50, 0.01, 2550], [1e7, 8e7, 20, 0.025, 152550], [8e7, 15e7, 10, 0.05, 2152550], [15e7, 3e8, 5, 0.1, 9652550], [3e8, 45e7, 4, 0.125, 17152550], [45e7, 6e8, 3, 0.15, 28402550], [6e8, 8e8, 2, 0.25, 88402550], [8e8, 1e9, 1, 0.5, 288402550]],
          [[0, 3e5, 150, 4e-3, 0], [3e5, 8e5, 100, 5e-3, 300], [8e5, 3e6, 75, 65e-4, 1500], [3e6, 12e6, 50, 0.01, 12e3], [12e6, 7e7, 25, 0.02, 132e3], [7e7, 1e8, 20, 0.025, 482e3], [1e8, 23e7, 10, 0.05, 2982e3], [23e7, 48e7, 5, 0.1, 14482e3], [48e7, 6e8, 4, 0.125, 26482e3], [6e8, 8e8, 3, 0.15, 41482e3], [8e8, 12e8, 2, 0.25, 121482e3], [12e8, 18e8, 1, 0.5, 421482e3]],
          [[0, 5e3, 10, 0.05, 0], [5e3, 4e4, 5, 0.1, 250], [4e4, 8e4, 4, 0.125, 1250], [8e4, 2e5, 3, 0.1667, 4586], [2e5, 2e6, 2, 0.25, 21246], [2e6, 5e6, 1, 0.5, 521246]],
          [[0, 5e3, 10, 0.05, 0], [5e3, 1e4, 5, 0.1, 250], [1e4, 1e5, 4, 0.125, 500], [1e5, 5e5, 3, 0.1667, 4670], [5e5, 8e6, 2, 0.25, 46320], [8e6, 15e6, 1, 0.5, 2046320]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 7e5, 3, 0.1667, 4919], [7e5, 75e5, 2, 0.25, 63229], [75e5, 125e5, 1, 0.5, 1938229]],
          [[0, 25e3, 7, 0.025, 0], [25e3, 2e5, 6, 0.05, 625], [2e5, 4e5, 5, 0.1, 10625], [4e5, 5e5, 4, 0.125, 20625], [5e5, 6e5, 3, 0.25, 83125], [6e5, 7e5, 1, 0.5, 233125]],
          [[0, 1e4, 5, 0.1, 0], [1e4, 5e4, 4, 0.125, 250], [5e4, 5e5, 3, 0.1667, 2335], [5e5, 6e5, 2, 0.25, 43985], [6e5, 65e4, 1, 0.5, 193985]],
          [[0, 5e4, 25, 0.01, 0], [5e4, 15e4, 20, 0.025, 750], [15e4, 25e4, 10, 0.05, 4500], [25e4, 5e5, 5, 0.1, 17e3], [5e5, 1e6, 4, 0.125, 29500], [1e6, 3e6, 2, 0.25, 154500], [3e6, 5e6, 1, 0.5, 904500]],
          [[0, 1e4, 75, 65e-4, 0], [1e4, 5e4, 50, 0.01, 35], [5e4, 8e4, 40, 0.015, 285], [8e4, 3e5, 25, 0.02, 685], [3e5, 6e5, 20, 0.025, 2185], [6e5, 3e6, 10, 0.05, 17185], [3e6, 6e6, 5, 0.1, 167185], [6e6, 75e5, 4, 0.125, 317185], [75e5, 15e6, 2, 0.25, 1254685], [15e6, 3e7, 1, 0.5, 5004685]],
          [[0, 5e3, 10, 0.05, 0], [5e3, 1e4, 8, 0.0625, 62.5], [1e4, 5e4, 5, 0.1, 437.5], [5e4, 1e5, 4, 0.125, 1687.5], [1e5, 25e4, 3, 0.1667, 5857.5], [25e4, 25e5, 2, 0.25, 26682.5], [25e5, 5e6, 1, 0.5, 651682.5]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 2e4, 15, 0.0333, 83], [2e4, 4e4, 10, 0.05, 417], [4e4, 1e5, 5, 0.1, 2417], [1e5, 2e5, 4, 0.125, 4917], [2e5, 4e5, 3, 0.1667, 13257], [4e5, 25e5, 2, 0.25, 46577], [25e5, 5e6, 1, 0.5, 671577]],
          [[0, 1e4, 5, 0.1, 0], [1e4, 5e4, 4, 0.125, 250], [5e4, 25e4, 3, 0.1667, 2335], [25e4, 3e5, 2, 0.25, 23160], [3e5, 5e5, 1, 0.5, 98160]],
          [[0, 25e3, 10, 0.025, 0], [25e3, 1e5, 8, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 1e6, 2, 0.125, 11875], [1e6, 2e6, 1, 0.5, 386875]],
          [[0, 25e3, 20, 0.025, 0], [25e3, 1e5, 10, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 1e6, 2, 0.125, 11875], [1e6, 2e6, 1, 0.5, 386875]],
          [[0, 1e4, 50, 0.01, 0], [1e4, 2e4, 25, 0.015, 50], [2e4, 1e5, 20, 0.02, 150], [1e5, 2e5, 15, 0.025, 650], [2e5, 1e6, 10, 0.05, 5650], [1e6, 15e5, 5, 0.1, 55650], [15e5, 2e6, 4, 0.125, 93150], [2e6, 25e5, 2, 0.25, 343150], [25e5, 3e6, 1, 0.5, 968150]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 25e3, 10, 0.05, 150], [25e3, 1e5, 5, 0.1, 1400], [1e5, 25e4, 4, 0.125, 3900], [25e4, 1e6, 2, 0.25, 35150], [1e6, 2147483647, 1, 0.5, 285150]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 2e5, 3, 0.1667, 4919], [2e5, 5e5, 2, 0.25, 21579], [5e5, 8e5, 1, 0.5, 146579]],
          [[0, 15e3, 10, 0.05, 0], [15e3, 8e4, 5, 0.1, 750], [8e4, 2e5, 4, 0.125, 2750], [2e5, 3e5, 3, 0.1667, 11090], [3e5, 5e5, 2, 0.25, 36080], [5e5, 8e5, 1, 0.5, 161080]],
          [[0, 25e3, 8, 0.025, 0], [25e3, 1e5, 6, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 1e6, 2, 0.125, 11875], [1e6, 12e5, 1, 0.5, 386875]],
          [[0, 1e5, 10, 0.025, 0], [1e5, 5e5, 8, 0.05, 2500], [5e5, 1e6, 5, 0.1, 27500], [1e6, 2e6, 3, 0.15, 77500], [2e6, 5e6, 2, 0.25, 277500], [5e6, 52e5, 1, 0.5, 1527500]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 5e4, 50, 7e-3, 20], [5e4, 75e4, 40, 0.01, 170], [75e4, 1e6, 25, 0.02, 7670], [1e6, 2e6, 20, 0.025, 12670], [2e6, 1e7, 10, 0.05, 62670], [1e7, 2e7, 5, 0.1, 562670], [2e7, 25e6, 4, 0.125, 1062670], [25e6, 5e7, 2, 0.25, 4187670], [5e7, 1e8, 1, 0.5, 16687670]],
          [[0, 8e4, 75, 65e-4, 0], [8e4, 15e4, 50, 0.01, 280], [15e4, 75e4, 40, 0.0125, 655], [75e4, 2e6, 25, 0.02, 6280], [2e6, 4e6, 20, 0.025, 16280], [4e6, 2e7, 10, 0.05, 116280], [2e7, 4e7, 5, 0.1, 1116280], [4e7, 5e7, 4, 0.125, 2116280], [5e7, 1e8, 2, 0.25, 8366280], [1e8, 2e8, 1, 0.5, 33366280]],
          [[0, 5e3, 20, 0.012, 0], [5e3, 25e3, 10, 0.025, 65], [25e3, 1e5, 5, 0.05, 690], [1e5, 25e4, 4, 0.1, 5690], [25e4, 1e6, 2, 0.125, 11940], [1e6, 2147483647, 1, 0.5, 386940]],
          [[0, 1e4, 75, 65e-4, 0], [1e4, 5e4, 50, 0.01, 35], [5e4, 1e5, 40, 0.015, 285], [1e5, 5e5, 25, 0.02, 785], [5e5, 8e5, 20, 0.025, 3285], [8e5, 4e6, 10, 0.05, 23285], [4e6, 8e6, 5, 0.1, 223285], [8e6, 1e7, 4, 0.125, 423285], [1e7, 3e7, 2, 0.25, 1673285], [3e7, 5e7, 1, 0.5, 9173285]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 1e4, 10, 0.05, 50], [1e4, 3e4, 5, 0.1, 550], [3e4, 2e5, 4, 0.125, 1300], [2e5, 5e5, 3, 0.1667, 9640], [5e5, 6e5, 2, 0.25, 51290], [6e5, 65e4, 1, 0.5, 201290]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 16e4, 50, 0.015, 100], [16e4, 8e5, 25, 0.02, 900], [8e5, 16e5, 20, 0.025, 4900], [16e5, 8e6, 10, 0.05, 44900], [8e6, 16e6, 5, 0.1, 444900], [16e6, 2e7, 4, 0.125, 844900], [2e7, 4e7, 2, 0.25, 3344900], [4e7, 8e7, 1, 0.5, 13344900]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 5e4, 20, 0.025, 75], [5e4, 125e3, 10, 0.05, 1325], [125e3, 25e4, 5, 0.1, 7575], [25e4, 5e5, 4, 0.125, 13825], [5e5, 15e5, 3, 0.1667, 34675], [15e5, 25e5, 2, 0.25, 159625], [25e5, 4e6, 1, 0.5, 784625]],
          [[0, 1e4, 5, 0.1, 0], [1e4, 5e4, 4, 0.125, 250], [5e4, 25e4, 3, 0.1667, 2335], [25e4, 3e5, 2, 0.25, 23160], [3e5, 35e4, 1, 0.5, 98160]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 5e4, 50, 0.01, 50], [5e4, 8e4, 40, 0.015, 300], [8e4, 4e5, 25, 0.02, 700], [4e5, 8e5, 20, 0.025, 2700], [8e5, 3e6, 10, 0.05, 22700], [3e6, 5e6, 5, 0.1, 172700], [5e6, 7e6, 4, 0.125, 297700], [7e6, 8e6, 2, 0.25, 1172700], [8e6, 9e6, 1, 0.5, 3172700]],
          [[0, 5, 100, 5e-3, 0], [5, 10, 75, 6e-3, 5e-3], [10, 100, 50, 0.01, 0.045], [100, 400, 20, 0.02, 1.045], [400, 800, 10, 0.025, 3.045], [800, 1500, 8, 0.05, 23.045], [1500, 2e3, 5, 0.1, 98.045], [2e3, 3e3, 4, 0.125, 148.045], [3e3, 5e3, 2, 0.25, 523.045], [5e3, 1e4, 1, 0.5, 1773.045]],
          [[0, 5e4, 30, 4e-3, 0], [5e4, 1e5, 25, 5e-3, 50], [1e5, 1e6, 20, 0.01, 550], [1e6, 5e6, 15, 0.025, 15550], [5e6, 1e7, 10, 0.05, 140550], [1e7, 2e7, 5, 0.1, 640550], [2e7, 4e7, 4, 0.125, 1140550], [4e7, 8e7, 3, 0.15, 2140550], [8e7, 15e7, 2, 0.25, 10140550], [15e7, 16e7, 1, 0.5, 47640550]],
          [[0, 5e4, 125, 4e-3, 0], [5e4, 5e5, 100, 5e-3, 50], [5e5, 1e6, 75, 65e-4, 800], [1e6, 5e6, 50, 0.01, 4300], [5e6, 5e7, 20, 0.02, 54300], [5e7, 1e8, 10, 0.05, 1554300], [1e8, 15e7, 5, 0.1, 6554300], [15e7, 3e8, 4, 0.125, 10304300], [3e8, 4e8, 3, 0.15, 17804300], [4e8, 5e8, 2, 0.25, 57804300], [5e8, 8e8, 1, 0.5, 182804300]],
          [[0, 3e5, 150, 4e-3, 0], [3e5, 8e5, 100, 5e-3, 300], [8e5, 3e6, 75, 65e-4, 1500], [3e6, 12e6, 50, 0.01, 12e3], [12e6, 5e7, 25, 0.02, 132e3], [5e7, 65e6, 20, 0.025, 382e3], [65e6, 15e7, 10, 0.05, 2007e3], [15e7, 32e7, 5, 0.1, 9507e3], [32e7, 4e8, 4, 0.125, 17507e3], [4e8, 53e7, 3, 0.15, 27507e3], [53e7, 8e8, 2, 0.25, 80507e3], [8e8, 12e8, 1, 0.5, 280507e3]],
          [[0, 5e3, 8, 0.02, 0], [5e3, 25e3, 7, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 2e6, 1, 0.5, 386900]],
          [[0, 5e4, 75, 6e-3, 0], [5e4, 25e4, 40, 0.01, 200], [25e4, 6e5, 20, 0.02, 2700], [6e5, 12e5, 10, 0.05, 20700], [12e5, 3e6, 5, 0.1, 80700], [3e6, 6e6, 4, 0.125, 155700], [6e6, 1e7, 3, 0.165, 395700], [1e7, 2e7, 2, 0.25, 1245700], [2e7, 3e7, 1, 0.5, 6245700]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 4e5, 25, 0.02, 1100], [4e5, 8e5, 20, 0.025, 3100], [8e5, 3e6, 10, 0.05, 23100], [3e6, 75e5, 5, 0.1, 173100], [75e5, 1e7, 4, 0.125, 360600], [1e7, 125e5, 2, 0.25, 1610600], [125e5, 15e6, 1, 0.5, 4735600]],
          [[0, 15e3, 10, 0.05, 0], [15e3, 5e4, 5, 0.1, 750], [5e4, 1e5, 4, 0.125, 2e3], [1e5, 25e4, 3, 0.1667, 6170], [25e4, 5e5, 2, 0.25, 26995], [5e5, 8e5, 1, 0.5, 151995]],
          [[0, 5e4, 10, 0.05, 0], [5e4, 2e5, 5, 0.1, 2500], [2e5, 4e5, 4, 0.125, 7500], [4e5, 5e5, 3, 0.1667, 24180], [5e5, 8e5, 2, 0.25, 65830], [8e5, 1e6, 1, 0.5, 265830]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 1e4, 10, 0.05, 50], [1e4, 5e4, 5, 0.1, 550], [5e4, 1e5, 4, 0.125, 1800], [1e5, 25e4, 3, 0.1667, 5970], [25e4, 5e5, 2, 0.25, 26795], [5e5, 8e5, 1, 0.5, 151795]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 25e3, 20, 0.025, 50], [25e3, 2e5, 10, 0.05, 675], [2e5, 5e5, 5, 0.1, 10675], [5e5, 1e6, 4, 0.125, 23175], [1e6, 3e6, 2, 0.25, 148175], [3e6, 35e5, 1, 0.5, 898175]],
          [[0, 5e3, 10, 6e-3, 0], [5e3, 5e4, 9, 0.01, 20], [5e4, 8e4, 8, 0.015, 270], [8e4, 3e5, 7, 0.02, 670], [3e5, 6e5, 6, 0.025, 2170], [6e5, 3e6, 5, 0.05, 17170], [3e6, 6e6, 4, 0.1, 167170], [6e6, 7e6, 3, 0.125, 317170], [7e6, 72e5, 2, 0.25, 1192170], [72e5, 75e5, 1, 0.5, 2992170]],
          [[0, 15e3, 8, 0.025, 0], [15e3, 5e4, 6, 0.05, 375], [5e4, 2e5, 5, 0.1, 2875], [2e5, 5e5, 3, 0.15, 12875], [5e5, 8e5, 2, 0.25, 62875], [8e5, 15e5, 1, 0.5, 262875]],
          [[0, 15e3, 8, 0.025, 0], [15e3, 5e4, 6, 0.05, 375], [5e4, 2e5, 5, 0.1, 2875], [2e5, 8e5, 2, 0.125, 7875], [8e5, 15e5, 1, 0.5, 307875]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 15e3, 10, 0.05, 125], [15e3, 5e4, 5, 0.1, 875], [5e4, 1e5, 4, 0.125, 2125], [1e5, 25e4, 3, 0.1667, 6295], [25e4, 5e5, 2, 0.25, 27120], [5e5, 8e5, 1, 0.5, 152120]],
          [[0, 5e3, 11, 0.02, 0], [5e3, 25e3, 10, 0.025, 25], [25e3, 1e5, 8, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 3e6, 1, 0.5, 386900]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 25e3, 20, 0.025, 75], [25e3, 62500, 10, 0.05, 700], [62500, 125e3, 5, 0.1, 3825], [125e3, 25e4, 4, 0.125, 6950], [25e4, 45e5, 3, 0.1667, 17375], [45e5, 75e5, 2, 0.25, 392225], [75e5, 125e5, 1, 0.5, 2267225]],
          [[0, 1e4, 20, 0.03, 0], [1e4, 2e5, 10, 0.05, 200], [2e5, 5e5, 5, 0.1, 10200], [5e5, 1e6, 4, 0.125, 22700], [1e6, 3e6, 2, 0.25, 147700], [3e6, 35e5, 1, 0.5, 897700]],
          [[0, 5e3, 10, 0.08, 0], [5e3, 3e4, 5, 0.1, 100], [3e4, 5e4, 4, 0.125, 850], [5e4, 1e5, 3, 0.1667, 2935], [1e5, 1e6, 2, 0.25, 11265], [1e6, 15e5, 1, 0.5, 261265]],
          [[0, 5e3, 25, 0.01, 0], [5e3, 1e4, 20, 0.015, 25], [1e4, 3e4, 15, 0.02, 75], [3e4, 6e4, 10, 0.025, 225], [6e4, 3e5, 8, 0.05, 1725], [3e5, 6e5, 5, 0.1, 16725], [6e5, 75e4, 4, 0.125, 31725], [75e4, 15e5, 2, 0.25, 125475], [15e5, 3e6, 1, 0.5, 500475]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 8e4, 50, 0.015, 50], [8e4, 4e5, 25, 0.02, 450], [4e5, 8e5, 20, 0.025, 2450], [8e5, 4e6, 10, 0.05, 22450], [4e6, 8e6, 5, 0.1, 222450], [8e6, 1e7, 4, 0.125, 422450], [1e7, 2e7, 2, 0.25, 1672450], [2e7, 4e7, 1, 0.5, 6672450]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 1e5, 4, 0.125, 1750], [1e5, 5e5, 3, 0.1667, 5920], [5e5, 6e5, 2, 0.25, 47570], [6e5, 8e5, 1, 0.5, 197570]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 3e5, 6, 0.05, 650], [3e5, 8e5, 5, 0.1, 15650], [8e5, 1e6, 4, 0.125, 35650], [1e6, 15e5, 2, 0.25, 160650], [15e5, 2e6, 1, 0.5, 535650]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 3e5, 3, 0.1667, 4919], [3e5, 5e5, 2, 0.25, 29909], [5e5, 8e5, 1, 0.5, 154909]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 2e5, 3, 0.1667, 4919], [2e5, 15e5, 2, 0.25, 21579], [15e5, 2e6, 1, 0.5, 396579]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 8e4, 50, 0.015, 50], [8e4, 4e5, 25, 0.02, 450], [4e5, 8e5, 20, 0.025, 2450], [8e5, 4e6, 10, 0.05, 22450], [4e6, 5e6, 5, 0.1, 222450], [5e6, 6e6, 4, 0.125, 347450], [6e6, 7e6, 2, 0.25, 1097450], [7e6, 8e6, 1, 0.5, 2847450]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 2e4, 20, 0.025, 25], [2e4, 6e4, 10, 0.05, 525], [6e4, 15e4, 5, 0.1, 3525], [15e4, 3e5, 4, 0.125, 7275], [3e5, 5e5, 3, 0.1667, 19785], [5e5, 8e5, 2, 0.25, 61435], [8e5, 1e6, 1, 0.5, 261435]],
          [[0, 2e4, 25, 0.02, 0], [2e4, 6e4, 20, 0.025, 100], [6e4, 1e5, 15, 0.0333, 598], [1e5, 2e5, 10, 0.05, 2268], [2e5, 5e5, 5, 0.1, 12268], [5e5, 1e6, 4, 0.125, 24768], [1e6, 12e5, 3, 0.1667, 66468], [12e5, 15e5, 2, 0.25, 166428], [15e5, 2e6, 1, 0.5, 541428]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 15e3, 10, 0.05, 50], [15e3, 5e4, 5, 0.1, 800], [5e4, 1e5, 4, 0.125, 2050], [1e5, 2e5, 3, 0.1667, 6220], [2e5, 25e5, 2, 0.25, 22880], [25e5, 5e6, 1, 0.5, 647880]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 7e4, 5, 0.1, 500], [7e4, 8e4, 4, 0.125, 2250], [8e4, 8e5, 3, 0.1667, 5586], [8e5, 1e6, 2, 0.25, 72226], [1e6, 15e5, 1, 0.5, 322226]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 2e5, 6, 0.05, 650], [2e5, 5e5, 5, 0.1, 10650], [5e5, 1e6, 4, 0.125, 23150], [1e6, 2e6, 2, 0.25, 148150], [2e6, 25e5, 1, 0.5, 648150]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 5e4, 20, 0.025, 50], [5e4, 4e5, 10, 0.05, 1300], [4e5, 1e6, 5, 0.1, 21300], [1e6, 2e6, 4, 0.125, 46300], [2e6, 6e6, 2, 0.25, 296300], [6e6, 1e7, 1, 0.5, 1796300]],
          [[0, 5e3, 75, 6e-3, 0], [5e3, 5e4, 50, 0.01, 20], [5e4, 8e4, 40, 0.015, 270], [8e4, 2e5, 25, 0.02, 670], [2e5, 4e5, 20, 0.025, 1670], [4e5, 2e6, 10, 0.05, 11670], [2e6, 4e6, 5, 0.1, 111670], [4e6, 5e6, 4, 0.125, 211670], [5e6, 75e5, 3, 0.1667, 420170], [75e5, 12e6, 2, 0.25, 1044920], [12e6, 2e7, 1, 0.5, 4044920]],
          [[0, 5e3, 50, 0.01, 0], [5e3, 25e3, 20, 0.025, 75], [25e3, 1e5, 10, 0.05, 700], [1e5, 25e4, 5, 0.1, 5700], [25e4, 1e6, 2, 0.125, 11950], [1e6, 2147483647, 1, 0.5, 386950]],
          [[0, 5e3, 8, 0.023, 0], [5e3, 25e3, 7, 0.025, 10], [25e3, 1e5, 6, 0.05, 635], [1e5, 25e4, 5, 0.1, 5635], [25e4, 1e6, 2, 0.125, 11885], [1e6, 15e5, 1, 0.5, 386885]],
          [[0, 200, 20, 0.025, 0], [200, 500, 10, 0.05, 5], [500, 5e4, 5, 0.1, 30], [5e4, 1e5, 4, 0.125, 1280], [1e5, 25e4, 3, 0.1667, 5450], [25e4, 5e5, 2, 0.25, 26275], [5e5, 8e5, 1, 0.5, 151275]],
          [[0, 25e3, 7, 0.025, 0], [25e3, 4e5, 6, 0.05, 625], [4e5, 5e5, 5, 0.1, 20625], [5e5, 6e5, 4, 0.125, 33125], [6e5, 7e5, 2, 0.25, 108125], [7e5, 8e5, 1, 0.5, 283125]],
          [[0, 5e3, 75, 5e-3, 0], [5e3, 1e4, 50, 6e-3, 5], [1e4, 5e4, 40, 0.01, 45], [5e4, 25e4, 25, 0.02, 545], [25e4, 1e6, 10, 0.05, 8045], [1e6, 5e6, 5, 0.1, 58045], [5e6, 1e7, 4, 0.125, 183045], [1e7, 2e7, 3, 0.15, 433045], [2e7, 3e7, 2, 0.25, 2433045], [3e7, 5e7, 1, 0.5, 9933045]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 2e5, 50, 0.01, 50], [2e5, 4e5, 40, 0.015, 1050], [4e5, 8e5, 25, 0.02, 3050], [8e5, 16e5, 20, 0.025, 7050], [16e5, 8e6, 10, 0.05, 47050], [8e6, 16e6, 5, 0.1, 447050], [16e6, 2e7, 4, 0.125, 847050], [2e7, 4e7, 2, 0.25, 3347050], [4e7, 8e7, 1, 0.5, 13347050]],
          [[0, 5e3, 10, 0.015, 0], [5e3, 2e4, 8, 0.02, 25], [2e4, 25e3, 6, 0.025, 125], [25e3, 2e5, 5, 0.05, 750], [2e5, 4e5, 4, 0.1, 10750], [4e5, 5e5, 3, 0.125, 20750], [5e5, 52e4, 2, 0.25, 83250], [52e4, 55e4, 1, 0.5, 213250]],
          [[0, 5e3, 40, 0.02, 0], [5e3, 1e4, 20, 0.025, 25], [1e4, 25e3, 10, 0.05, 275], [25e3, 5e4, 5, 0.1, 1525], [5e4, 1e5, 4, 0.125, 2775], [1e5, 25e4, 3, 0.1667, 6945], [25e4, 5e5, 2, 0.25, 27770], [5e5, 8e5, 1, 0.5, 152770]],
          [[0, 25e3, 10, 0.03, 0], [25e3, 2e5, 8, 0.05, 500], [2e5, 5e5, 5, 0.1, 10500], [5e5, 1e6, 4, 0.125, 23e3], [1e6, 15e5, 2, 0.25, 148e3], [15e5, 2e6, 1, 0.5, 523e3]],
          [[0, 1e4, 20, 0.03, 0], [1e4, 2e4, 10, 0.05, 200], [2e4, 8e4, 5, 0.1, 1200], [8e4, 2e5, 4, 0.125, 3200], [2e5, 3e5, 3, 0.1667, 11540], [3e5, 5e5, 2, 0.25, 36530], [5e5, 8e5, 1, 0.5, 161530]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 15e5, 4, 0.125, 11900], [15e5, 3e6, 2, 0.25, 199400], [3e6, 32e5, 1, 0.5, 949400]],
          [[0, 5e3, 75, 5e-3, 0], [5e3, 1e4, 50, 6e-3, 5], [1e4, 5e4, 40, 0.01, 45], [5e4, 75e4, 25, 0.02, 545], [75e4, 3e6, 10, 0.05, 23045], [3e6, 1e7, 5, 0.1, 173045], [1e7, 12e6, 4, 0.125, 423045], [12e6, 2e7, 3, 0.15, 723045], [2e7, 3e7, 2, 0.25, 2723045], [3e7, 5e7, 1, 0.5, 10223045]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 5e4, 50, 0.01, 50], [5e4, 16e4, 40, 0.015, 300], [16e4, 8e5, 25, 0.02, 1100], [8e5, 16e5, 20, 0.025, 5100], [16e5, 8e6, 10, 0.05, 45100], [8e6, 16e6, 5, 0.1, 445100], [16e6, 2e7, 4, 0.125, 845100], [2e7, 4e7, 2, 0.25, 3345100], [4e7, 8e7, 1, 0.5, 13345100]],
          [[0, 1e4, 8, 0.025, 0], [1e4, 5e4, 7, 0.05, 250], [5e4, 2e5, 6, 0.08, 1750], [2e5, 4e5, 5, 0.1, 5750], [4e5, 1e6, 4, 0.125, 15750], [1e6, 2e6, 3, 0.1665, 57250], [2e6, 3e6, 2, 0.25, 224250], [3e6, 1e7, 1, 0.5, 974250]],
          [[0, 5e4, 8, 0.01, 0], [5e4, 25e4, 7, 0.02, 500], [25e4, 1e6, 6, 0.05, 8e3], [1e6, 2e6, 5, 0.1, 58e3], [2e6, 5e6, 4, 0.125, 108e3], [5e6, 1e7, 3, 0.1665, 315500], [1e7, 15e6, 2, 0.25, 1150500], [15e6, 5e7, 1, 0.5, 4900500]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 2e4, 20, 0.025, 75], [2e4, 4e4, 10, 0.05, 575], [4e4, 5e4, 5, 0.1, 2575], [5e4, 1e5, 4, 0.125, 3825], [1e5, 25e4, 3, 0.1667, 7995], [25e4, 25e5, 2, 0.25, 28820], [25e5, 5e6, 1, 0.5, 653820]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 25e3, 20, 0.025, 25], [25e3, 2e5, 10, 0.05, 650], [2e5, 5e5, 5, 0.1, 10650], [5e5, 75e4, 4, 0.125, 23150], [75e4, 15e5, 2, 0.25, 116900], [15e5, 3e6, 1, 0.5, 491900]],
          [[0, 2e3, 20, 0.025, 0], [2e3, 5e3, 10, 0.05, 50], [5e3, 5e4, 5, 0.1, 300], [5e4, 1e5, 4, 0.125, 1550], [1e5, 25e4, 3, 0.1667, 5720], [25e4, 5e5, 2, 0.25, 26545], [5e5, 8e5, 1, 0.5, 151545]],
          [[0, 5e3, 20, 0.02, 0], [5e3, 25e3, 15, 0.025, 25], [25e3, 1e5, 10, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 5e6, 1, 0.5, 386900]],
          [[0, 5e3, 75, 6e-3, 0], [5e3, 25e3, 50, 0.01, 20], [25e3, 8e4, 40, 0.015, 145], [8e4, 4e5, 25, 0.02, 545], [4e5, 8e5, 20, 0.025, 2545], [8e5, 4e6, 10, 0.05, 22545], [4e6, 8e6, 5, 0.1, 222545], [8e6, 1e7, 4, 0.125, 422545], [1e7, 12e6, 2, 0.25, 1672545], [12e6, 14e6, 1, 0.5, 4672545]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 7e4, 4, 0.125, 2e3], [7e4, 7e5, 3, 0.1667, 4919], [7e5, 5e6, 2, 0.25, 63229], [5e6, 95e5, 1, 0.5, 1313229]],
          [[0, 5e3, 8, 0.02, 0], [5e3, 25e3, 7, 0.025, 25], [25e3, 1e5, 6, 0.05, 650], [1e5, 25e4, 5, 0.1, 5650], [25e4, 1e6, 2, 0.125, 11900], [1e6, 3e6, 1, 0.5, 386900]],
          [[0, 1e4, 50, 0.015, 0], [1e4, 25e4, 20, 0.025, 100], [25e4, 75e4, 15, 0.03, 1350], [75e4, 15e5, 10, 0.05, 16350], [15e5, 4e6, 5, 0.1, 91350], [4e6, 5e6, 4, 0.125, 191350], [5e6, 12e6, 2, 0.25, 816350], [12e6, 2e7, 1, 0.5, 3816350]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 1e6, 25, 0.02, 1100], [1e6, 2e6, 20, 0.025, 6100], [2e6, 1e7, 10, 0.05, 56100], [1e7, 2e7, 5, 0.1, 556100], [2e7, 25e6, 4, 0.125, 1056100], [25e6, 3e7, 2, 0.25, 4181100], [3e7, 35e6, 1, 0.5, 11681100]],
          [[0, 3e4, 5, 0.1, 0], [3e4, 4e4, 4, 0.125, 750], [4e4, 2e5, 3, 0.1667, 2418], [2e5, 5e5, 2, 0.25, 19078], [5e5, 8e5, 1, 0.5, 144078]],
          [[0, 5e4, 5, 0.1, 0], [5e4, 7e4, 4, 0.125, 1250], [7e4, 25e4, 3, 0.1667, 4169], [25e4, 5e5, 2, 0.25, 24994], [5e5, 8e5, 1, 0.5, 149994]],
          [[0, 5e3, 10, 0.01, 0], [5e3, 1e4, 9, 0.015, 25], [1e4, 2e4, 8, 0.02, 75], [2e4, 4e4, 7, 0.025, 175], [4e4, 2e5, 6, 0.05, 1175], [2e5, 3e5, 5, 0.1, 11175], [3e5, 4e5, 4, 0.125, 18675], [4e5, 5e5, 2, 0.25, 68675], [5e5, 6e5, 1, 0.5, 193675]],
          [[0, 5e4, 50, 0.01, 0], [5e4, 25e4, 25, 0.02, 500], [25e4, 1e6, 20, 0.025, 1750], [1e6, 2e6, 15, 0.0333, 10050], [2e6, 5e6, 10, 0.05, 43450], [5e6, 8e6, 5, 0.1, 293450], [8e6, 15e6, 4, 0.125, 493450], [15e6, 25e6, 3, 0.1667, 1118950], [25e6, 5e7, 2, 0.25, 3201450], [5e7, 2e8, 1, 0.5, 15701450]],
          [[0, 5e3, 25, 0.02, 0], [5e3, 25e3, 20, 0.025, 25], [25e3, 2e5, 10, 0.05, 650], [2e5, 5e5, 5, 0.1, 10650], [5e5, 1e6, 2, 0.125, 23150], [1e6, 2e6, 1, 0.5, 398150]],
          [[0, 5e3, 10, 0.015, 0], [5e3, 5e4, 8, 0.025, 50], [5e4, 9e5, 6, 0.05, 1300], [9e5, 2e6, 5, 0.1, 46300], [2e6, 21e5, 4, 0.125, 96300], [21e5, 22e5, 2, 0.25, 358800], [22e5, 23e5, 1, 0.5, 908800]],
          [[0, 2e3, 20, 0.03, 0], [2e3, 15e3, 10, 0.05, 40], [15e3, 6e4, 5, 0.1, 790], [6e4, 15e4, 4, 0.125, 2290], [15e4, 3e5, 3, 0.1667, 8545], [3e5, 1e6, 2, 0.25, 33535], [1e6, 15e5, 1, 0.5, 283535]],
          [[0, 2e3, 75, 0.01, 0], [2e3, 5e3, 50, 0.015, 10], [5e3, 1e4, 25, 0.02, 35], [1e4, 25e3, 20, 0.025, 85], [25e3, 62500, 10, 0.05, 710], [62500, 125e3, 5, 0.1, 3835], [125e3, 25e4, 4, 0.125, 6960], [25e4, 5e5, 3, 0.1667, 17385], [5e5, 75e5, 2, 0.25, 59035], [75e5, 125e5, 1, 0.5, 1934035]],
          [[0, 1e4, 75, 6e-3, 0], [1e4, 5e4, 50, 0.01, 40], [5e4, 8e4, 40, 0.015, 290], [8e4, 3e5, 25, 0.02, 690], [3e5, 6e5, 20, 0.025, 2190], [6e5, 3e6, 10, 0.05, 17190], [3e6, 6e6, 5, 0.1, 167190], [6e6, 75e5, 4, 0.125, 317190], [75e5, 18e6, 2, 0.25, 1254690], [18e6, 3e7, 1, 0.5, 5754690]],
          [[0, 5e3, 10, 0.01, 0], [5e3, 1e4, 9, 0.015, 25], [1e4, 3e4, 8, 0.02, 75], [3e4, 6e4, 7, 0.025, 225], [6e4, 3e5, 6, 0.05, 1725], [3e5, 6e5, 5, 0.1, 16725], [6e5, 75e4, 4, 0.125, 31725], [75e4, 9e5, 2, 0.25, 125475], [9e5, 1e6, 1, 0.5, 350475]],
          [[0, 5e3, 20, 0.035, 0], [5e3, 15e3, 10, 0.05, 75], [15e3, 3e4, 5, 0.1, 825], [3e4, 1e5, 4, 0.125, 1575], [1e5, 25e4, 3, 0.1667, 5745], [25e4, 5e5, 2, 0.25, 26570], [5e5, 8e5, 1, 0.5, 151570]],
          [[0, 3e3, 75, 0.01, 0], [3e3, 5e3, 50, 0.015, 15], [5e3, 1e4, 25, 0.02, 40], [1e4, 25e3, 20, 0.025, 90], [25e3, 62500, 10, 0.05, 715], [62500, 125e3, 5, 0.1, 3840], [125e3, 25e4, 4, 0.125, 6965], [25e4, 5e5, 3, 0.1667, 17390], [5e5, 75e5, 2, 0.25, 59040], [75e5, 125e5, 1, 0.5, 1934040]],
          [[0, 1e3, 20, 0.03, 0], [1e3, 1e4, 10, 0.05, 20], [1e4, 5e4, 5, 0.1, 520], [5e4, 25e4, 4, 0.125, 1770], [25e4, 1e6, 3, 0.1667, 12195], [1e6, 2e6, 2, 0.25, 95495], [2e6, 5e6, 1, 0.5, 595495]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 1e4, 10, 0.05, 50], [1e4, 6e4, 5, 0.1, 550], [6e4, 7e4, 4, 0.125, 2050], [7e4, 25e4, 3, 0.1667, 4969], [25e4, 25e5, 2, 0.25, 25794], [25e5, 5e6, 1, 0.5, 650794]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 4e4, 5, 0.1, 500], [4e4, 8e4, 4, 0.125, 1500], [8e4, 25e4, 3, 0.1667, 4836], [25e4, 5e5, 2, 0.25, 25661], [5e5, 8e5, 1, 0.5, 150661]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 1e4, 15, 0.033, 40], [1e4, 25e3, 10, 0.05, 210], [25e3, 5e4, 5, 0.1, 1460], [5e4, 1e5, 4, 0.125, 2710], [1e5, 25e4, 3, 0.1667, 6880], [25e4, 5e5, 2, 0.25, 27705], [5e5, 8e5, 1, 0.5, 152705]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 2e4, 10, 0.05, 250], [2e4, 5e4, 5, 0.1, 1250], [5e4, 1e5, 4, 0.125, 2500], [1e5, 25e4, 3, 0.1667, 6670], [25e4, 25e5, 2, 0.25, 27495], [25e5, 5e6, 1, 0.5, 652495]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 1e4, 10, 0.05, 50], [1e4, 5e4, 5, 0.1, 550], [5e4, 1e5, 4, 0.125, 1800], [1e5, 25e4, 3, 0.1667, 5970], [25e4, 25e5, 2, 0.25, 26795], [25e5, 5e6, 1, 0.5, 651795]],
          [[0, 5e3, 20, 0.03, 0], [5e3, 1e4, 10, 0.05, 100], [1e4, 6e4, 5, 0.1, 600], [6e4, 7e4, 4, 0.125, 2100], [7e4, 25e4, 3, 0.1667, 5019], [25e4, 5e5, 2, 0.25, 25844], [5e5, 8e5, 1, 0.5, 150844]],
          [[0, 2e4, 10, 0.02, 0], [2e4, 25e3, 8, 0.025, 100], [25e3, 2e5, 6, 0.05, 725], [2e5, 4e5, 5, 0.1, 10725], [4e5, 5e5, 4, 0.125, 20725], [5e5, 6e5, 2, 0.25, 83225], [6e5, 65e4, 1, 0.5, 233225]],
          [[0, 5e3, 16, 0.015, 0], [5e3, 5e4, 15, 0.025, 50], [5e4, 6e5, 10, 0.05, 1300], [6e5, 1e6, 5, 0.1, 31300], [1e6, 15e5, 4, 0.125, 56300], [15e5, 2e6, 2, 0.25, 243800], [2e6, 21e5, 1, 0.5, 743800]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 20, 0.025, 50], [1e4, 2e4, 10, 0.05, 300], [2e4, 5e4, 5, 0.1, 1300], [5e4, 25e4, 4, 0.125, 2550], [25e4, 5e5, 3, 0.1667, 12975], [5e5, 25e5, 2, 0.25, 54625], [25e5, 5e6, 1, 0.5, 679625]],
          [[0, 5e3, 26, 0.015, 0], [5e3, 5e4, 25, 0.02, 25], [5e4, 1e5, 20, 0.025, 275], [1e5, 1e6, 10, 0.05, 2775], [1e6, 2e6, 5, 0.1, 52775], [2e6, 25e5, 4, 0.125, 102775], [25e5, 5e6, 2, 0.25, 415275], [5e6, 6e6, 1, 0.5, 1665275]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 25e3, 50, 0.015, 25], [25e3, 4e5, 25, 0.02, 150], [4e5, 8e5, 20, 0.025, 2150], [8e5, 4e6, 10, 0.05, 22150], [4e6, 8e6, 5, 0.1, 222150], [8e6, 1e7, 4, 0.125, 422150], [1e7, 12e6, 2, 0.25, 1672150], [12e6, 14e6, 1, 0.5, 4672150]],
          [[0, 2e4, 5, 0.1, 0], [2e4, 5e4, 4, 0.125, 500], [5e4, 15e4, 3, 0.1667, 2585], [15e4, 25e5, 2, 0.25, 15080], [25e5, 5e6, 1, 0.5, 640080]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 25e3, 20, 0.025, 50], [25e3, 1e5, 10, 0.05, 675], [1e5, 2e5, 5, 0.1, 5675], [2e5, 5e5, 4, 0.125, 10675], [5e5, 1e6, 2, 0.25, 73175], [1e6, 15e5, 1, 0.5, 323175]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 5e4, 15, 0.0333, 83], [5e4, 2e5, 10, 0.05, 918], [2e5, 5e5, 5, 0.1, 10918], [5e5, 1e6, 4, 0.125, 23418], [1e6, 25e5, 3, 0.1667, 65118], [25e5, 5e6, 2, 0.25, 273368], [5e6, 2e7, 1, 0.5, 1523368]],
          [[0, 5e4, 10, 0.02, 0], [5e4, 1e5, 8, 0.025, 250], [1e5, 5e5, 6, 0.05, 2750], [5e5, 1e6, 5, 0.1, 27750], [1e6, 2e6, 3, 0.15, 77750], [2e6, 5e6, 2, 0.25, 277750], [5e6, 55e5, 1, 0.5, 1527750]],
          [[0, 1e4, 100, 5e-3, 0], [1e4, 5e4, 75, 65e-4, 15], [5e4, 2e5, 50, 0.01, 190], [2e5, 5e5, 40, 0.012, 590], [5e5, 1e6, 25, 0.02, 4590], [1e6, 2e6, 20, 0.025, 9590], [2e6, 5e6, 10, 0.05, 59590], [5e6, 15e6, 5, 0.1, 309590], [15e6, 2e7, 4, 0.125, 684590], [2e7, 5e7, 2, 0.25, 3184590], [5e7, 1e8, 1, 0.5, 15684590]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 12e3, 20, 0.025, 50], [12e3, 25e3, 10, 0.05, 350], [25e3, 7e4, 5, 0.1, 1600], [7e4, 25e4, 4, 0.125, 3350], [25e4, 5e5, 3, 0.1667, 13775], [5e5, 75e5, 2, 0.25, 55425], [75e5, 125e5, 1, 0.5, 1930425]],
          [[0, 5e4, 5, 0.1, 0], [5e4, 15e4, 4, 0.125, 1250], [15e4, 5e5, 3, 0.1667, 7505], [5e5, 2e6, 2, 0.25, 49155], [2e6, 5e6, 1, 0.5, 549155]],
          [[0, 15e3, 8, 0.025, 0], [15e3, 5e4, 6, 0.05, 375], [5e4, 2e5, 5, 0.1, 2875], [2e5, 1e6, 2, 0.125, 7875], [1e6, 15e5, 1, 0.5, 382875]],
          [[0, 5e3, 10, 0.05, 0], [5e3, 3e4, 5, 0.1, 250], [3e4, 5e4, 4, 0.125, 1e3], [5e4, 25e4, 3, 0.1667, 3085], [25e4, 25e5, 2, 0.25, 23910], [25e5, 5e6, 1, 0.5, 648910]],
          [[0, 25e3, 8, 0.025, 0], [25e3, 1e5, 6, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 5e5, 2, 0.125, 11875], [5e5, 1e6, 1, 0.5, 199375]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 25e3, 20, 0.025, 50], [25e3, 15e4, 10, 0.05, 675], [15e4, 3e5, 5, 0.1, 8175], [3e5, 75e4, 4, 0.125, 15675], [75e4, 15e5, 2, 0.25, 109425], [15e5, 2e6, 1, 0.5, 484425]],
          [[0, 25e3, 11, 0.03, 0], [25e3, 2e5, 10, 0.05, 500], [2e5, 5e5, 5, 0.1, 10500], [5e5, 1e6, 4, 0.125, 23e3], [1e6, 3e6, 2, 0.25, 148e3], [3e6, 35e5, 1, 0.5, 898e3]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 1e6, 25, 0.02, 1100], [1e6, 2e6, 20, 0.025, 6100], [2e6, 1e7, 10, 0.05, 56100], [1e7, 2e7, 5, 0.1, 556100], [2e7, 25e6, 4, 0.125, 1056100], [25e6, 5e7, 2, 0.25, 4181100], [5e7, 1e8, 1, 0.5, 16681100]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 5e4, 5, 0.1, 500], [5e4, 2e5, 4, 0.125, 1750], [2e5, 5e5, 3, 0.1667, 10090], [5e5, 8e5, 2, 0.25, 51740], [8e5, 1e6, 1, 0.5, 251740]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 8e4, 4, 0.125, 2e3], [8e4, 25e4, 3, 0.1667, 5336], [25e4, 5e5, 2, 0.25, 26161], [5e5, 8e5, 1, 0.5, 151161]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 15e3, 10, 0.05, 125], [15e3, 4e4, 5, 0.1, 875], [4e4, 12e4, 4, 0.125, 1875], [12e4, 25e4, 3, 0.1667, 6879], [25e4, 25e5, 2, 0.25, 27704], [25e5, 5e6, 1, 0.5, 652704]],
          [[0, 15e3, 10, 0.05, 0], [15e3, 5e4, 5, 0.1, 750], [5e4, 1e5, 4, 0.125, 2e3], [1e5, 25e4, 3, 0.1667, 6170], [25e4, 25e5, 2, 0.25, 26995], [25e5, 5e6, 1, 0.5, 651995]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 1e5, 50, 0.015, 50], [1e5, 5e5, 25, 0.02, 550], [5e5, 1e6, 20, 0.025, 3050], [1e6, 5e6, 10, 0.05, 28050], [5e6, 6e6, 5, 0.1, 278050], [6e6, 7e6, 4, 0.125, 428050], [7e6, 8e6, 2, 0.25, 1303050], [8e6, 9e6, 1, 0.5, 3303050]],
          [[0, 5e4, 8, 0.025, 0], [5e4, 6e5, 6, 0.05, 1250], [6e5, 128e4, 5, 0.1, 31250], [128e4, 16e5, 4, 0.125, 63250], [16e5, 48e5, 2, 0.25, 263250], [48e5, 5e6, 1, 0.5, 1463250]],
          [[0, 1e4, 75, 0.01, 0], [1e4, 8e4, 50, 0.015, 50], [8e4, 4e5, 25, 0.02, 450], [4e5, 8e5, 20, 0.025, 2450], [8e5, 3e6, 10, 0.05, 22450], [3e6, 5e6, 5, 0.1, 172450], [5e6, 6e6, 4, 0.125, 297450], [6e6, 7e6, 2, 0.25, 1047450], [7e6, 8e6, 1, 0.5, 2797450]],
          [[0, 5e3, 20, 0.04, 0], [5e3, 1e4, 10, 0.05, 50], [1e4, 5e4, 5, 0.1, 550], [5e4, 1e5, 4, 0.125, 1800], [1e5, 2e5, 3, 0.1667, 5970], [2e5, 1e6, 2, 0.25, 22630], [1e6, 12e5, 1, 0.5, 272630]],
          [[0, 1e4, 10, 0.01, 0], [1e4, 2e4, 9, 0.015, 50], [2e4, 1e5, 8, 0.02, 150], [1e5, 2e5, 7, 0.025, 650], [2e5, 1e6, 6, 0.05, 5650], [1e6, 2e6, 5, 0.1, 55650], [2e6, 21e5, 4, 0.125, 105650], [21e5, 22e5, 2, 0.25, 368150], [22e5, 23e5, 1, 0.5, 918150]],
          [[0, 1e4, 25, 0.01, 0], [1e4, 2e4, 20, 0.015, 50], [2e4, 1e5, 15, 0.02, 150], [1e5, 2e5, 10, 0.025, 650], [2e5, 5e5, 8, 0.05, 5650], [5e5, 1e6, 5, 0.1, 30650], [1e6, 15e5, 4, 0.125, 55650], [15e5, 2e6, 2, 0.25, 243150], [2e6, 3e6, 1, 0.5, 743150]],
          [[0, 5e3, 75, 0.01, 0], [5e3, 2e4, 50, 0.015, 25], [2e4, 125e3, 25, 0.02, 125], [125e3, 2e5, 20, 0.025, 750], [2e5, 1e6, 10, 0.05, 5750], [1e6, 2e6, 5, 0.1, 55750], [2e6, 25e5, 4, 0.125, 105750], [25e5, 375e4, 3, 0.1667, 21e4], [375e4, 5e6, 2, 0.25, 522375], [5e6, 6e6, 1, 0.5, 1772375]],
          [[0, 1e4, 75, 65e-4, 0], [1e4, 9e4, 50, 0.01, 35], [9e4, 12e4, 40, 0.015, 485], [12e4, 65e4, 25, 0.02, 1085], [65e4, 8e5, 20, 0.025, 4335], [8e5, 3e6, 10, 0.05, 24335], [3e6, 6e6, 5, 0.1, 174335], [6e6, 12e6, 4, 0.125, 324335], [12e6, 2e7, 2, 0.25, 1824335], [2e7, 3e7, 1, 0.5, 6824335]],
          [[0, 25e3, 11, 0.025, 0], [25e3, 1e5, 10, 0.05, 625], [1e5, 25e4, 5, 0.1, 5625], [25e4, 1e6, 4, 0.125, 11875], [1e6, 15e5, 2, 0.25, 136875], [15e5, 3e6, 1, 0.5, 511875]],
          [[0, 5e3, 50, 6e-3, 0], [5e3, 5e4, 25, 0.01, 20], [5e4, 9e5, 20, 0.025, 770], [9e5, 18e5, 10, 0.05, 23270], [18e5, 48e5, 5, 0.1, 113270], [48e5, 6e6, 4, 0.125, 233270], [6e6, 18e6, 2, 0.25, 983270], [18e6, 3e7, 1, 0.5, 5483270]],
          [[0, 5e4, 5, 0.1, 0], [5e4, 1e5, 4, 0.125, 1250], [1e5, 5e5, 3, 0.1667, 5420], [5e5, 1e6, 2, 0.25, 47070], [1e6, 2e6, 1, 0.5, 297070]],
          [[0, 1e3, 20, 0.04, 0], [1e3, 1e4, 10, 0.05, 10], [1e4, 6e4, 5, 0.1, 510], [6e4, 7e4, 4, 0.125, 2010], [7e4, 25e4, 3, 0.1667, 4929], [25e4, 5e5, 2, 0.25, 25754], [5e5, 8e5, 1, 0.5, 150754]],
          [[0, 5e3, 75, 6e-3, 0], [5e3, 25e3, 50, 0.01, 20], [25e3, 4e4, 40, 0.015, 145], [4e4, 2e5, 25, 0.02, 345], [2e5, 4e5, 20, 0.025, 1345], [4e5, 1e6, 10, 0.05, 11345], [1e6, 15e5, 5, 0.1, 61345], [15e5, 2e6, 4, 0.125, 98845], [2e6, 25e5, 2, 0.25, 348845], [25e5, 3e6, 1, 0.5, 973845]],
          [[0, 6e4, 5, 0.1, 0], [6e4, 7e4, 4, 0.125, 1500], [7e4, 25e4, 3, 0.1667, 4419], [25e4, 5e5, 2, 0.25, 25244], [5e5, 8e5, 1, 0.5, 150244]],
          [[0, 16e4, 7, 0.025, 0], [16e4, 5e5, 6, 0.05, 4e3], [5e5, 6e5, 5, 0.1, 29e3], [6e5, 7e5, 4, 0.125, 44e3], [7e5, 8e5, 2, 0.25, 131500], [8e5, 9e5, 1, 0.5, 331500]],
          [[0, 5e3, 20, 0.045, 0], [5e3, 1e4, 10, 0.05, 25], [1e4, 5e4, 5, 0.1, 525], [5e4, 1e5, 4, 0.125, 1775], [1e5, 25e4, 3, 0.1667, 5945], [25e4, 5e5, 2, 0.25, 26770], [5e5, 8e5, 1, 0.5, 151770]],
          [[0, 5e3, 21, 0.015, 0], [5e3, 5e4, 20, 0.025, 50], [5e4, 45e4, 10, 0.05, 1300], [45e4, 12e5, 5, 0.1, 23800], [12e5, 15e5, 4, 0.125, 53800], [15e5, 3e6, 2, 0.25, 241300], [3e6, 35e5, 1, 0.5, 991300]],
          [[0, 2e5, 20, 0.025, 0], [2e5, 4e5, 10, 0.05, 5e3], [4e5, 1e6, 5, 0.1, 25e3], [1e6, 15e5, 4, 0.125, 5e4], [15e5, 5e6, 3, 0.1667, 112550], [5e6, 75e5, 2, 0.25, 529050], [75e5, 125e5, 1, 0.5, 2404050]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 25e3, 25, 0.02, 25], [25e3, 8e4, 20, 0.025, 150], [8e4, 8e5, 10, 0.05, 2150], [8e5, 16e5, 5, 0.1, 42150], [16e5, 2e6, 4, 0.125, 82150], [2e6, 4e6, 2, 0.25, 332150], [4e6, 8e6, 1, 0.5, 1332150]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 1e6, 25, 0.02, 1100], [1e6, 2e6, 20, 0.025, 6100], [2e6, 5e6, 10, 0.05, 56100], [5e6, 75e5, 5, 0.1, 306100], [75e5, 1e7, 4, 0.125, 493600], [1e7, 125e5, 2, 0.25, 1743600], [125e5, 5e7, 1, 0.5, 4868600]],
          [[0, 3e4, 10, 0.05, 0], [3e4, 5e4, 5, 0.1, 1500], [5e4, 2e5, 4, 0.125, 2750], [2e5, 3e5, 3, 0.1667, 11090], [3e5, 5e5, 2, 0.25, 36080], [5e5, 8e5, 1, 0.5, 161080]],
          [[0, 5e3, 10, 0.02, 0], [5e3, 25e3, 8, 0.025, 25], [25e3, 4e5, 6, 0.05, 650], [4e5, 1e6, 5, 0.1, 20650], [1e6, 2e6, 4, 0.125, 45650], [2e6, 21e5, 2, 0.25, 295650], [21e5, 22e5, 1, 0.5, 820650]],
          [[0, 1e4, 75, 5e-3, 0], [1e4, 5e4, 50, 0.01, 50], [5e4, 1e5, 40, 0.015, 300], [1e5, 75e4, 25, 0.02, 800], [75e4, 1e6, 20, 0.025, 4550], [1e6, 5e6, 10, 0.05, 29550], [5e6, 1e7, 5, 0.1, 279550], [1e7, 125e5, 4, 0.125, 529550], [125e5, 25e6, 2, 0.25, 2092050], [25e6, 5e7, 1, 0.5, 8342050]],
          [[0, 4e4, 100, 5e-3, 0], [4e4, 8e4, 75, 6e-3, 40], [8e4, 15e4, 50, 0.01, 360], [15e4, 4e5, 40, 0.0125, 735], [4e5, 1e6, 25, 0.02, 3735], [1e6, 2e6, 20, 0.025, 8735], [2e6, 1e7, 10, 0.05, 58735], [1e7, 2e7, 5, 0.1, 558735], [2e7, 25e6, 4, 0.125, 1058735], [25e6, 5e7, 2, 0.25, 4183735], [5e7, 1e8, 1, 0.5, 16683735]],
          [[0, 5e3, 50, 0.015, 0], [5e3, 1e4, 25, 0.02, 25], [1e4, 25e3, 20, 0.025, 75], [25e3, 62500, 10, 0.05, 700], [62500, 12e4, 5, 0.1, 3825], [12e4, 25e4, 4, 0.125, 6825], [25e4, 5e5, 3, 0.1667, 17250], [5e5, 75e5, 2, 0.25, 58900], [75e5, 125e5, 1, 0.5, 1933900]],
          [[0, 2e4, 5, 0.1, 0], [2e4, 1e5, 4, 0.125, 500], [1e5, 25e4, 3, 0.1667, 4670], [25e4, 5e5, 2, 0.25, 25495], [5e5, 8e5, 1, 0.5, 150495]],
          [[0, 2e4, 75, 0.01, 0], [2e4, 2e5, 50, 0.015, 100], [2e5, 1e6, 25, 0.02, 1100], [1e6, 2e6, 20, 0.025, 6100], [2e6, 5e6, 10, 0.05, 56100], [5e6, 75e5, 5, 0.1, 306100], [75e5, 1e7, 4, 0.125, 493600], [1e7, 2e7, 2, 0.25, 1743600], [2e7, 4e7, 1, 0.5, 6743600]],
          [[0, 15e3, 10, 0.05, 0], [15e3, 6e4, 5, 0.1, 750], [6e4, 25e4, 4, 0.125, 2250], [25e4, 5e5, 3, 0.1667, 12675], [5e5, 2e6, 2, 0.25, 54325], [2e6, 3e6, 1, 0.5, 554325]],
          [[0, 5e3, 10, 0.05, 0], [5e3, 4e4, 5, 0.1, 250], [4e4, 1e5, 4, 0.125, 1250], [1e5, 25e4, 3, 0.1667, 5420], [25e4, 4e5, 2, 0.25, 26245], [4e5, 5e5, 1, 0.5, 126245]],
          [[0, 25e4, 3, 0.1667, 0], [25e4, 25e5, 2, 0.25, 20825], [25e5, 5e6, 1, 0.5, 645825]],
          [[0, 1e4, 10, 0.05, 0], [1e4, 6e4, 5, 0.1, 500], [6e4, 12e4, 4, 0.125, 2e3], [12e4, 3e5, 3, 0.1667, 7004], [3e5, 1e6, 2, 0.25, 31994], [1e6, 3e6, 1, 0.5, 281994]]
        ],
        symbols: {
          "0GUSDT": 2,
          "1000000BOBUSDT": 15,
          "1000000MOGUSDT": 0,
          "1000BONKUSDC": 13,
          "1000BONKUSDT": 23,
          "1000BTTCUSDT": 19,
          "1000CATUSDT": 10,
          "1000CHEEMSUSDT": 3,
          "1000FLOKIUSDT": 11,
          "1000LUNCBUSD": 30,
          "1000LUNCUSDT": 5,
          "1000PEPEUSDC": 75,
          "1000PEPEUSDT": 76,
          "1000RATSUSDT": 35,
          "1000SATSUSDT": 3,
          "1000SHIBBUSD": 45,
          "1000SHIBUSDC": 77,
          "1000SHIBUSDT": 78,
          "1000WHYUSDT": 79,
          "1000XECUSDT": 5,
          "1000XUSDT": 15,
          "1INCHUSDT": 5,
          "1MBABYDOGEUSDT": 2,
          "2ZUSDT": 2,
          "42USDT": 80,
          "4USDT": 10,
          A2ZUSDT: 12,
          AAOIUSDT: 1,
          AAPLUSDT: 20,
          AAVEUSDC: 81,
          AAVEUSDT: 82,
          ACEUSDT: 10,
          ACHUSDT: 2,
          ACTUSDT: 6,
          ACUUSDT: 9,
          ACXUSDT: 83,
          ADABUSD: 84,
          ADAUSDC: 85,
          ADAUSDT: 46,
          ADBEUSDT: 1,
          AERGOUSDTSETTLED: 86,
          AERGOUSDTSETTLEDSETTLED: 87,
          AEROUSDT: 11,
          AEVOUSDT: 0,
          AGIXBUSD: 30,
          AGIXUSDT: 88,
          AGLDUSDT: 3,
          AGTUSDT: 9,
          AI16ZUSDT: 89,
          AIAUSDT: 4,
          AIAUSDTSETTLED: 90,
          AIGENSYNUSDT: 3,
          AINUSDT: 6,
          AIOTUSDT: 21,
          AIOUSDT: 0,
          AIUSDT: 24,
          AIXBTUSDT: 0,
          AKEUSDT: 9,
          AKROUSDT: 91,
          AKTUSDT: 2,
          ALABUSDT: 1,
          ALCHUSDT: 6,
          ALGOUSDT: 11,
          ALICEUSDT: 0,
          ALLOUSDT: 3,
          ALLUSDT: 16,
          ALPACAUSDT: 92,
          ALPHAUSDT: 47,
          ALPINEUSDT: 6,
          ALTUSDT: 2,
          AMATUSDT: 1,
          AMBBUSD: 17,
          AMBUSDT: 93,
          AMDUSDT: 36,
          AMZNUSDT: 1,
          ANCBUSD: 17,
          ANCUSDT: 19,
          ANIMEUSDT: 10,
          ANKRUSDT: 2,
          ANTHROPICUSDT: 1,
          ANTUSDT: 94,
          APEBUSD: 95,
          APEUSDT: 2,
          API3USDT: 0,
          APPUSDT: 7,
          APRUSDT: 0,
          APTBUSD: 25,
          APTUSDT: 96,
          ARBUSDC: 97,
          ARBUSDT: 98,
          ARCUSDT: 31,
          ARIAUSDT: 99,
          ARKMUSDT: 0,
          ARKUSDT: 35,
          ARMUSDT: 1,
          ARPAUSDT: 0,
          ARUSDT: 5,
          ARXUSDT: 4,
          ASMLUSDT: 1,
          ASRUSDT: 15,
          ASTERUSDT: 26,
          ASTRUSDT: 2,
          ASTSUSDT: 1,
          ATAUSDT: 12,
          ATHUSDT: 100,
          ATOMUSDT: 101,
          ATUSDT: 0,
          AUCTIONBUSD: 17,
          AUCTIONUSDT: 0,
          AUDIOUSDT: 102,
          AUSDT: 16,
          AVAAIUSDT: 21,
          AVAUSDT: 3,
          AVAXBUSD: 103,
          AVAXUSDC: 104,
          AVAXUSDT: 105,
          AVGOUSDT: 1,
          AVNTUSDT: 2,
          AWEUSDT: 35,
          AXLUSDT: 0,
          AXSUSDT: 5,
          AXTIUSDT: 1,
          AZTECUSDT: 3,
          B2USDT: 0,
          B3USDT: 106,
          BABAUSDT: 1,
          BABYUSDT: 2,
          BADGERUSDT: 107,
          BAKEUSDT: 48,
          BALUSDT: 108,
          BANANAS31USDT: 3,
          BANANAUSDT: 3,
          BANDUSDT: 2,
          BANKUSDT: 109,
          BANUSDT: 3,
          BARDUSDT: 3,
          BASEDUSDT: 3,
          BASUSDT: 6,
          BATUSDT: 2,
          BBUSDT: 0,
          BBXUSDT: 1,
          BCHUSDC: 110,
          BCHUSDT: 111,
          BDXNUSDTSETTLED: 112,
          BEAMXUSDT: 0,
          BEATUSDT: 6,
          BELUSDT: 15,
          BERAUSDT: 2,
          BEUSDT: 32,
          BICOUSDT: 10,
          BIDUSDT: 9,
          BIGTIMEUSDT: 0,
          BILLUSDT: 4,
          BIOUSDC: 13,
          BIOUSDT: 2,
          BIRBUSDT: 0,
          BITOUSDT: 7,
          BLESSUSDT: 22,
          BLUAIUSDT: 15,
          BLUEBIRDUSDT: 113,
          BLURUSDT: 0,
          BLZUSDT: 114,
          BMNRUSDT: 32,
          BMTUSDT: 10,
          BNBBUSD: 49,
          BNBUSDC: 46,
          BNBUSDT: 115,
          BNCUSDT: 50,
          BNTUSDT: 0,
          BNXUSDT: 116,
          BNXUSDTSETTLED: 117,
          BOBUSDT: 33,
          BOMEUSDC: 13,
          BOMEUSDT: 0,
          BONDUSDT: 118,
          BOTUSDT: 27,
          BRETTUSDT: 0,
          BREVUSDT: 0,
          BRKBUSDT: 1,
          BROCCOLI714USDT: 51,
          BROCCOLIF3BUSDT: 9,
          BRUSDT: 51,
          BSBUSDT: 9,
          BSPUSDT: 27,
          BSVUSDT: 5,
          BSWUSDT: 47,
          BTCBUSD: 119,
          BTCBUSD_210129: 52,
          BTCBUSD_210226: 52,
          BTCDOMUSDT: 53,
          BTCSTUSDTSETTLED: 120,
          BTCU: 37,
          BTCUSD1: 121,
          BTCUSDC: 122,
          BTCUSDT: 123,
          BTCUSDT_210326: 54,
          BTCUSDT_210625: 55,
          BTCUSDT_210924: 56,
          BTCUSDT_211231: 14,
          BTCUSDT_220325: 14,
          BTCUSDT_220624: 14,
          BTCUSDT_220930: 14,
          BTCUSDT_221230: 57,
          BTCUSDT_230331: 14,
          BTCUSDT_230630: 14,
          BTCUSDT_230929: 58,
          BTCUSDT_231229: 8,
          BTCUSDT_240329: 8,
          BTCUSDT_240628: 8,
          BTCUSDT_240927: 8,
          BTCUSDT_241227: 8,
          BTCUSDT_250328: 8,
          BTCUSDT_250627: 8,
          BTCUSDT_250926: 8,
          BTCUSDT_251226: 8,
          BTCUSDT_260327: 8,
          BTCUSDT_260626: 8,
          BTCUSDT_260925: 8,
          BTCUSDT_261225: 8,
          BTRUSDT: 124,
          BTSUSDT: 59,
          BTTUSDT: 19,
          BTWUSDT: 38,
          BULLAUSDT: 9,
          BUSDT: 31,
          BXUSDT: 1,
          BYDUSDT: 4,
          BZRXUSDT: 19,
          BZUSDT: 18,
          C98USDT: 0,
          CAKEUSDT: 11,
          CAPUSDT: 9,
          CARVUSDT: 0,
          CATIUSDT: 0,
          CATUSDT: 7,
          CBRSUSDT: 20,
          CBRSUSDTSETTLED: 125,
          CCUSDT: 13,
          CELOUSDT: 2,
          CELRUSDT: 3,
          CETUSUSDT: 0,
          CFGUSDT: 2,
          CFXUSDT: 16,
          CGPTUSDT: 0,
          CHESSUSDT: 28,
          CHILLGUYUSDT: 15,
          CHIPUSDT: 2,
          CHRUSDT: 3,
          CHZUSDT: 5,
          CIENUSDT: 1,
          CKBUSDT: 2,
          CLANKERUSDT: 3,
          CLOUSDT: 6,
          CLUSDT: 18,
          COAIUSDT: 126,
          COCOSUSDT: 17,
          COHRUSDT: 20,
          COINUSDT: 1,
          COLLECTUSDT: 4,
          COMBOUSDT: 127,
          COMMONUSDT: 128,
          COMPUSDT: 16,
          COOKIEUSDT: 10,
          COPPERUSDT: 18,
          COSTUSDT: 1,
          COSUSDT: 24,
          COTIUSDT: 2,
          COWUSDT: 2,
          CRCLUSDT: 60,
          CRDOUSDT: 1,
          CRMUSDT: 1,
          CROSSUSDT: 22,
          CRVUSDC: 129,
          CRVUSDT: 130,
          CRWDUSDT: 32,
          CRWVUSDT: 20,
          CSCOUSDT: 1,
          CSOPSAMSUNG2LUSDT: 131,
          CSOPSKHYNIX2LUSDT: 132,
          CTKUSDT: 3,
          CTKUSDTSETTLED: 39,
          CTRUSDT: 4,
          CTSIUSDT: 0,
          CUDISUSDT: 133,
          CUSDT: 0,
          CVCUSDT: 0,
          CVCUSDTSETTLED: 134,
          CVXBUSD: 40,
          CVXUSDT: 5,
          CVXUSDTSETTLED: 135,
          CXMTUSDT: 4,
          CYBERUSDT: 0,
          CYSUSDT: 4,
          DAMUSDT: 33,
          DARUSDT: 136,
          DASHUSDT: 11,
          DATAIPUSDC: 4,
          DATAIPUSDT: 4,
          DDOGUSDT: 4,
          DEEPUSDT: 2,
          DEFAULT_BRACKETS: 137,
          DEFIUSDT: 53,
          DEGENUSDT: 33,
          DEGOUSDT: 138,
          DELLUSDT: 1,
          DENTUSDT: 139,
          DEXEUSDT: 10,
          DFUSDT: 28,
          DGBUSDT: 39,
          DIAUSDT: 3,
          DISUSDT: 1,
          DJTUSDT: 4,
          DKNGUSDT: 1,
          DMCUSDT: 9,
          DODOBUSD: 140,
          DODOUSDT: 41,
          DODOXUSDT: 3,
          DOGEBUSD: 141,
          DOGEUSDC: 142,
          DOGEUSDT: 143,
          DOGSUSDT: 0,
          DOLOUSDT: 6,
          DOODUSDT: 3,
          DOSUSDT: 4,
          DOTBUSD: 25,
          DOTECOUSDT: 144,
          DOTUSDT: 145,
          DRAMUSDT: 34,
          DRIFTUSDT: 146,
          DUSDT: 12,
          DUSKUSDT: 0,
          DYDXUSDT: 5,
          DYMUSDT: 6,
          EBAYUSDT: 1,
          EDENUSDT: 10,
          EDGEUSDT: 2,
          EDUUSDT: 2,
          EGLDUSDT: 5,
          EIGENUSDT: 5,
          ELSAUSDT: 4,
          ENAUSDC: 42,
          ENAUSDT: 147,
          ENJUSDT: 2,
          ENSOUSDT: 0,
          ENSUSDT: 11,
          EOSUSDT: 148,
          EPICUSDT: 10,
          EPTUSDT: 149,
          ERAUSDT: 3,
          ESPORTSUSDT: 6,
          ESPUSDT: 3,
          ETCBUSD: 17,
          ETCUSDT: 150,
          ETHBTC: 151,
          ETHBUSD: 152,
          ETHFIUSDC: 13,
          ETHFIUSDT: 11,
          ETHU: 37,
          ETHUSD1: 37,
          ETHUSDC: 153,
          ETHUSDT: 154,
          ETHUSDT_210326: 54,
          ETHUSDT_210625: 55,
          ETHUSDT_210924: 56,
          ETHUSDT_211231: 14,
          ETHUSDT_220325: 14,
          ETHUSDT_220624: 14,
          ETHUSDT_220930: 14,
          ETHUSDT_221230: 57,
          ETHUSDT_230331: 14,
          ETHUSDT_230630: 14,
          ETHUSDT_230929: 58,
          ETHUSDT_231229: 8,
          ETHUSDT_240329: 8,
          ETHUSDT_240628: 8,
          ETHUSDT_240927: 8,
          ETHUSDT_241227: 8,
          ETHUSDT_250328: 8,
          ETHUSDT_250627: 8,
          ETHUSDT_250926: 8,
          ETHUSDT_251226: 8,
          ETHUSDT_260327: 8,
          ETHUSDT_260626: 8,
          ETHUSDT_260925: 8,
          ETHUSDT_261225: 8,
          ETHWUSDT: 0,
          EULUSDT: 3,
          EVAAUSDT: 9,
          EWJUSDT: 1,
          EWTUSDT: 1,
          EWYUSDT: 34,
          EWZUSDT: 1,
          FARTCOINUSDT: 5,
          FETUSDT: 16,
          FFUSDT: 10,
          FHEUSDT: 9,
          FIDAUSDT: 3,
          FIGHTUSDT: 4,
          FILBUSD: 155,
          FILUSDC: 156,
          FILUSDT: 157,
          FIOUSDT: 24,
          FISUSDT: 9,
          FLEXUSDT: 7,
          FLMUSDT: 158,
          FLNCUSDT: 1,
          FLOCKUSDT: 0,
          FLOWUSDT: 159,
          FLUIDUSDT: 5,
          FLUXUSDT: 0,
          FOGOUSDT: 2,
          FOLKSUSDT: 0,
          FOOTBALLUSDT: 39,
          FORMUSDT: 2,
          FORTHUSDT: 160,
          FRAXUSDT: 0,
          FRONTUSDT: 161,
          FTMBUSD: 25,
          FTMUSDT: 162,
          FTTBUSD: 163,
          FTTUSDT: 164,
          FUNUSDT: 165,
          FUSDT: 0,
          FWDIUSDT: 50,
          FXSUSDT: 38,
          GAIBUSDT: 22,
          GALABUSD: 61,
          GALAUSDT: 5,
          GALBUSD: 40,
          GALUSDT: 166,
          GASUSDT: 2,
          GDXUSDT: 4,
          GENIUSUSDT: 0,
          GEVUSDT: 7,
          GHSTUSDT: 28,
          GIGADEVUSDT: 4,
          GIGGLEUSDT: 167,
          GLMRUSDT: 168,
          GLMUSDT: 2,
          GLWUSDT: 1,
          GMEUSDT: 1,
          GMTBUSD: 17,
          GMTUSDT: 0,
          GMXUSDT: 2,
          GOATUSDT: 3,
          GOOGLUSDT: 34,
          GPROUSDT: 4,
          GPSUSDT: 2,
          GRAMUSDT: 2,
          GRASSUSDT: 5,
          GRIFFAINUSDT: 10,
          GRTUSDT: 5,
          GRVTUSDT: 3,
          GSUSDT: 4,
          GTCUSDT: 6,
          GTLBUSDT: 4,
          GUAUSDT: 169,
          GUNUSDT: 6,
          GUSDT: 0,
          GWEIUSDT: 2,
          HAEDALUSDT: 6,
          HANAUSDT: 9,
          HANMIUSDT: 4,
          HBARUSDC: 170,
          HBARUSDT: 171,
          HDUSDT: 1,
          HEIUSDT: 6,
          HEMIUSDT: 10,
          HFTUSDT: 12,
          HIFIUSDT: 48,
          HIGHUSDT: 12,
          HIMSUSDT: 1,
          HIPPOUSDT: 172,
          HIVEUSDT: 3,
          HK0625USDT: 4,
          HK0700USDT: 7,
          HK0992USDT: 4,
          HK1810USDT: 7,
          HMSTRUSDT: 6,
          HNTUSDT: 173,
          HOLOUSDT: 0,
          HOMEUSDT: 0,
          HOODUSDT: 1,
          HOOKUSDT: 174,
          HOTUSDT: 2,
          HPEUSDT: 1,
          HUMAUSDT: 3,
          HUSDT: 175,
          HYPERUSDT: 2,
          HYPEUSDT: 26,
          HYUNDAIUSDT: 7,
          IBMUSDT: 1,
          ICNTUSDT: 0,
          ICPBUSD: 30,
          ICPUSDT: 16,
          ICPUSDT_SETTLED: 41,
          ICXUSDT: 12,
          IDEXUSDT: 43,
          IDOLUSDT: 3,
          IDUSDT: 2,
          ILVUSDT: 0,
          IMXUSDT: 11,
          INITUSDT: 3,
          INJUSDT: 176,
          INTCUSDT: 7,
          INTWUSDT: 7,
          INUSDT: 3,
          INXUSDT: 3,
          IONQUSDT: 4,
          IOSTUSDT: 0,
          IOTAUSDT: 5,
          IOTXUSDT: 2,
          IOUSDT: 0,
          IPUSDC: 177,
          IPUSDT: 178,
          IRENUSDT: 32,
          IRUSDT: 33,
          IRYSUSDT: 4,
          IWMUSDT: 1,
          JASMYUSDT: 5,
          JCTUSDT: 179,
          JELLYJELLYUSDT: 3,
          JOEUSDT: 3,
          JPMUSDT: 1,
          JSTUSDT: 5,
          JTOUSDT: 5,
          JUPUSDT: 16,
          KAIAUSDT: 5,
          KAITOUSDC: 13,
          KAITOUSDT: 5,
          KASUSDT: 11,
          KATUSDT: 3,
          KAVAUSDT: 2,
          KDAUSDT: 180,
          KEEPUSDT: 19,
          KERNELUSDT: 3,
          KEYUSDT: 181,
          KGENUSDT: 0,
          KITEUSDT: 6,
          KLACUSDT: 1,
          KLAYUSDT: 182,
          KMNOUSDT: 2,
          KNCUSDT: 2,
          KODEX200USDT: 4,
          KOMAUSDT: 9,
          KORUUSDT: 7,
          KOUSDT: 4,
          KSMUSDT: 2,
          KSTRUSDT: 7,
          KUAISHOUUSDT: 4,
          LABUSDT: 6,
          LAUSDT: 3,
          LAYERUSDT: 0,
          LDOBUSD: 61,
          LDOUSDT: 183,
          LENDUSDT: 184,
          LEVERBUSD: 185,
          LEVERUSDT: 186,
          LGELECTRONICSUSDT: 4,
          LIGHTUSDT: 6,
          LINAUSDT: 187,
          LINEAUSDT: 2,
          LINKBUSD: 25,
          LINKUSDC: 188,
          LINKUSDT: 189,
          LISTAUSDT: 2,
          LITEUSDT: 20,
          LITUSDT: 5,
          LITUSDTSETTLED: 190,
          LLYUSDT: 1,
          LOKAUSDT: 191,
          LOOMUSDT: 192,
          LPTUSDT: 0,
          LQTYUSDT: 0,
          LRCUSDT: 193,
          LRCXUSDT: 1,
          LSKUSDT: 0,
          LTCBUSD: 194,
          LTCUSDC: 195,
          LTCUSDT: 196,
          LUMIAUSDT: 6,
          LUNA2BUSD: 30,
          LUNA2USDT: 2,
          LUNABUSD: 197,
          LUNAUSDT: 198,
          LYNUSDT: 6,
          LYTEUSDT: 4,
          MAGICUSDT: 0,
          MAGMAUSDT: 4,
          MANAUSDT: 5,
          MANTAUSDT: 199,
          MANTRAUSDT: 2,
          MARAUSDT: 4,
          MARSCOINUSDT: 4,
          MASKUSDT: 0,
          MATICBUSD: 45,
          MATICUSDC: 62,
          MATICUSDT: 62,
          MAVIAUSDT: 6,
          MAVIAUSDTSETTLED: 200,
          MAVUSDT: 6,
          MBLUSDT: 63,
          MBOXUSDT: 12,
          MDBUSDT: 4,
          MDTUSDT: 43,
          MEGAUSDT: 0,
          MEITUANUSDT: 4,
          MELANIAUSDT: 5,
          MEMEFIUSDT: 201,
          MEMEUSDT: 0,
          MERLUSDT: 0,
          METAUSDT: 1,
          METISUSDT: 0,
          METUSDT: 0,
          MEUSDT: 2,
          MEWUSDT: 2,
          MILKUSDT: 64,
          MINAUSDT: 0,
          MINAUSDTSETTLED: 202,
          MINIMAXUSDT: 7,
          MIRAUSDT: 0,
          MITOUSDT: 6,
          MKRUSDT: 203,
          MLNUSDT: 12,
          MMTUSDT: 2,
          MOCAUSDT: 2,
          MONUSDT: 11,
          MOODENGUSDT: 2,
          MORPHOUSDT: 5,
          MOVEUSDT: 3,
          MOVRUSDT: 0,
          MRKUSDT: 4,
          MRNAUSDT: 4,
          MRVLUSDT: 29,
          MSFTUSDT: 1,
          MSTRUSDT: 60,
          MTLUSDT: 0,
          MUBARAKUSDT: 3,
          MUSDT: 6,
          MUUSDT: 29,
          MUUUSDT: 7,
          MVLLUSDT: 1,
          MYROUSDT: 15,
          MYXUSDT: 204,
          NAORISUSDT: 6,
          NATGASUSDT: 18,
          NAVERUSDT: 4,
          NBISUSDT: 20,
          NEARBUSD: 205,
          NEARUSDC: 206,
          NEARUSDT: 207,
          NEIROETHUSDT: 28,
          NEIROUSDT: 0,
          NEOUSDC: 13,
          NEOUSDT: 5,
          NETUSDT: 4,
          NEWTUSDT: 3,
          NFLXUSDT: 1,
          NFPUSDT: 208,
          NIGHTUSDT: 0,
          NILUSDT: 0,
          NKNUSDT: 209,
          NMRUSDT: 0,
          NOKUSDT: 1,
          NOMUSDT: 6,
          NOTUSDT: 0,
          NOWUSDT: 1,
          NTRNUSDT: 12,
          NULSUSDT: 210,
          NUUSDT: 19,
          NVDAUSDT: 211,
          NVDLUSDT: 4,
          NVOUSDT: 1,
          NXPCUSDT: 0,
          OBOLUSDT: 64,
          OCEANUSDT: 212,
          OGNUSDT: 3,
          OGUSDT: 3,
          OLUSDT: 12,
          OMGUSDT: 213,
          OMNIUSDT: 13,
          OMUSDT: 214,
          ONDOUSDT: 23,
          ONDSUSDT: 1,
          ONEUSDT: 0,
          ONGUSDT: 0,
          ONTUSDT: 0,
          ONUSDT: 0,
          OPENAIUSDT: 1,
          OPENUSDT: 215,
          OPGUSDT: 4,
          OPNUSDT: 3,
          OPUSDT: 216,
          ORBSUSDT: 217,
          ORCAUSDT: 2,
          ORCLUSDT: 1,
          ORDERUSDT: 0,
          ORDIUSDC: 13,
          ORDIUSDT: 2,
          OUSDT: 9,
          OXTUSDT: 218,
          PANWUSDT: 7,
          PARTIUSDT: 3,
          PAXGUSDT: 65,
          PAYPUSDT: 1,
          PDDUSDT: 4,
          PENDLEUSDT: 16,
          PENGUSDT: 27,
          PENGUUSDC: 13,
          PENGUUSDT: 26,
          PEOPLEUSDT: 0,
          PERPUSDT: 24,
          PHAROSUSDT: 4,
          PHAUSDT: 0,
          PHBBUSD: 17,
          PHBUSDT: 12,
          PIEVERSEUSDT: 31,
          PIPPINUSDT: 3,
          PIXELUSDT: 3,
          PLAYUSDT: 6,
          PLTRUSDT: 1,
          PLUMEUSDT: 219,
          PNUTUSDC: 13,
          PNUTUSDT: 0,
          POLUSDT: 23,
          POLYXUSDT: 2,
          PONKEUSDT: 66,
          PONSUSDT: 4,
          POPCATUSDT: 0,
          POPMARTUSDT: 7,
          PORT3USDT: 220,
          PORTALUSDT: 6,
          POWERUSDT: 4,
          POWRUSDT: 0,
          PRLUSDT: 4,
          PROMPTUSDT: 22,
          PROMUSDT: 2,
          PROVEUSDT: 44,
          PTBUSDT: 221,
          PUFFERUSDT: 222,
          PUMPBTCUSDT: 9,
          PUMPUSDT: 26,
          PUMPUSDTSETTLED: 223,
          PUNDIXUSDT: 0,
          PYPLUSDT: 4,
          PYTHUSDT: 23,
          QCOMUSDT: 1,
          QNTUSDT: 5,
          QNTXUSDT: 27,
          QQQUSDT: 36,
          QTUMUSDT: 5,
          QUICKUSDT: 67,
          QUSDT: 224,
          RADUSDT: 43,
          RAMUSDT: 4,
          RAREUSDT: 3,
          RAVEUSDT: 225,
          RAYSOLUSDT: 5,
          RAYUSDT: 68,
          RDDTUSDT: 4,
          RDNTUSDT: 226,
          RECALLUSDT: 22,
          REDUSDT: 2,
          REEFUSDT: 227,
          REIUSDT: 9,
          RENDERUSDT: 11,
          RENUSDT: 228,
          RESOLVUSDT: 6,
          REUSDT: 2,
          REZUSDT: 0,
          RIFUSDT: 0,
          RIVERUSDT: 229,
          RIVNUSDT: 1,
          RKLBUSDT: 1,
          RLCUSDT: 0,
          RLSUSDT: 24,
          RNDRUSDT: 230,
          ROBOUSDT: 69,
          RONINUSDT: 0,
          ROSEUSDT: 0,
          RPLUSDT: 2,
          RSRUSDT: 5,
          RUNEUSDT: 5,
          RVNUSDT: 2,
          RVVUSDT: 28,
          SAFEUSDT: 0,
          SAGAUSDT: 10,
          SAHARAUSDT: 3,
          SAMSUNGEMUSDT: 4,
          SAMSUNGUSDT: 7,
          SANDBUSD: 17,
          SANDUSDT: 11,
          SANTOSUSDT: 6,
          SAPIENUSDT: 3,
          SCRTUSDT: 12,
          SCRUSDT: 6,
          SCUSDT: 59,
          SEIUSDT: 23,
          SENTUSDT: 5,
          SFPUSDT: 5,
          SHAZUSDT: 27,
          SHELLUSDT: 6,
          SHOPUSDT: 4,
          SIGNUSDT: 3,
          SIRENUSDT: 6,
          SKATEUSDT: 70,
          SKDDUSDT: 4,
          SKHYNIXUSDT: 29,
          SKHYUSDT: 29,
          SKLUSDT: 2,
          SKRUSDT: 4,
          SKUUUSDT: 4,
          SKYAIUSDT: 6,
          SKYUSDT: 231,
          SLERFUSDT: 232,
          SLPUSDT: 0,
          SLPUSDTSETTLED: 233,
          SLXUSDT: 3,
          SMCIUSDT: 1,
          SMHUSDT: 234,
          SNDKUSDT: 71,
          SNOWUSDT: 7,
          SNTUSDT: 63,
          SNXUSDT: 5,
          SNXXUSDT: 7,
          SOFIUSDT: 7,
          SOLBUSD: 235,
          SOLUSDC: 236,
          SOLUSDT: 18,
          SOLVUSDT: 21,
          SOMIUSDT: 0,
          SONICUSDT: 15,
          SONYUSDT: 1,
          SOONUSDT: 0,
          SOPHUSDT: 3,
          SOXLUSDT: 29,
          SOXSUSDT: 7,
          SPACEUSDT: 237,
          SPCXUSD1: 7,
          SPCXUSDT: 71,
          SPCXUSDTSETTLED: 238,
          SPELLUSDT: 0,
          SPKUSDT: 72,
          SPORTFUNUSDT: 6,
          SPXUSDT: 11,
          SPYUSDT: 34,
          SQDUSDT: 0,
          SQQQUSDT: 1,
          SRMUSDT: 239,
          SSVUSDT: 2,
          STABLEUSDT: 5,
          STARUSDT: 240,
          STBLUSDT: 0,
          STEEMUSDT: 3,
          STGUSDT: 0,
          STMXUSDT: 241,
          STORJUSDT: 12,
          STOUSDT: 69,
          STPTUSDT: 242,
          STRAXUSDT: 243,
          STRCUSDT: 7,
          STRKUSDT: 11,
          STXUSDT: 5,
          STXXUSDT: 1,
          SUIUSDC: 42,
          SUIUSDT: 244,
          SUNUSDT: 2,
          SUPERUSDT: 2,
          SUSDT: 44,
          SUSHIUSDT: 44,
          SWARMSUSDT: 21,
          SWELLUSDT: 66,
          SXPUSDTSETTLED: 245,
          SXTUSDT: 3,
          SYNUSDT: 15,
          SYRUPUSDT: 3,
          SYSUSDT: 246,
          TACUSDT: 15,
          TAGUSDT: 3,
          TAIKOUSDT: 247,
          TAKEUSDT: 6,
          TANSSIUSDT: 9,
          TAOUSDT: 73,
          TAUSDT: 248,
          TBTUSDT: 7,
          TEAMUSDT: 4,
          TEMUSDT: 4,
          TENCENTUSDT: 7,
          TERUSDT: 7,
          THETAUSDT: 16,
          THEUSDT: 6,
          TIAUSDC: 42,
          TIAUSDT: 249,
          TLMBUSD: 17,
          TLMUSDT: 10,
          TLMUSDTSETTLED: 68,
          TMFUSDT: 7,
          TNSRUSDT: 3,
          TOKENUSDT: 70,
          TOMOUSDT: 250,
          TONUSDT: 251,
          TOSHIUSDT: 0,
          TOWNSUSDT: 6,
          TQQQUSDT: 1,
          TRADOORUSDT: 252,
          TRBUSDT: 72,
          TREEUSDT: 6,
          TRIAUSDT: 0,
          TROYUSDT: 253,
          TRUMPUSDC: 254,
          TRUMPUSDT: 255,
          TRUSTUSDT: 6,
          TRUTHUSDT: 31,
          TRUUSDT: 12,
          TRXBUSD: 25,
          TRXUSDT: 256,
          TSLAUSDT: 36,
          TSLLUSDT: 4,
          TSMUSDT: 1,
          TSTUSDT: 21,
          TTWOUSDT: 7,
          TURBOUSDT: 2,
          TURTLEUSDT: 10,
          TUSDT: 2,
          TUTUSDT: 6,
          TWTUSDT: 5,
          TXNUSDT: 7,
          TZAUSDT: 7,
          UAIUSDT: 0,
          UBERUSDT: 1,
          UBUSDT: 0,
          UMAUSDT: 2,
          UNFIUSDT: 257,
          UNIBUSD: 17,
          UNITREEUSDT: 4,
          UNIUSDC: 74,
          UNIUSDT: 74,
          URNMUSDT: 1,
          USARUSDT: 1,
          USDCUSDT: 258,
          USELESSUSDT: 0,
          USTCUSDT: 0,
          USUALUSDT: 0,
          USUSDT: 6,
          UVXYUSDT: 1,
          UXLINKUSDT: 259,
          VANAUSDT: 2,
          VANRYUSDT: 260,
          VELODROMEUSDT: 0,
          VELVETUSDT: 6,
          VETUSDT: 261,
          VFYUSDT: 262,
          VICUSDT: 12,
          VIDTUSDT: 263,
          VINEUSDT: 264,
          VIRTUALUSDT: 16,
          VOXELUSDT: 9,
          VRTUSDT: 7,
          VSTUSDT: 4,
          VTHOUSDT: 2,
          VUSDT: 1,
          VVVUSDT: 3,
          WALUSDT: 5,
          WAVESBUSD: 40,
          WAVESUSDT: 265,
          WAXPUSDT: 3,
          WCTUSDT: 3,
          WDCUSDT: 1,
          WENUSDT: 266,
          WETUSDT: 0,
          WIFUSDC: 267,
          WIFUSDT: 11,
          WLDUSDC: 13,
          WLDUSDT: 26,
          WLFIUSDC: 13,
          WLFIUSDT: 268,
          WMTUSDT: 1,
          WOOUSDT: 2,
          WUSDT: 2,
          XAGUSDT: 18,
          XAIUSDT: 3,
          XANUSDT: 0,
          XAUTUSDT: 65,
          XAUUSDT: 18,
          XBIUSDT: 7,
          XCNUSDT: 269,
          XEMUSDT: 270,
          XLEUSDT: 1,
          XLMUSDT: 73,
          XMRUSDT: 11,
          XNYUSDT: 15,
          XPDUSDT: 18,
          XPINUSDT: 0,
          XPLUSDT: 11,
          XPTUSDT: 18,
          XRPBUSD: 49,
          XRPUSDC: 271,
          XRPUSDT: 272,
          XTZUSDT: 16,
          XVGUSDT: 273,
          XVSUSDT: 0,
          YALAUSDT: 274,
          YBUSDT: 10,
          YFIIUSDT: 41,
          YFIUSDT: 5,
          YGGUSDT: 0,
          ZAMAUSDT: 0,
          ZBTUSDT: 0,
          ZECUSDC: 5,
          ZECUSDT: 275,
          ZENUSDT: 5,
          ZEREBROUSDT: 276,
          ZESTUSDT: 38,
          ZETAUSDT: 0,
          ZHIPUUSDT: 7,
          ZHONGJIUSDT: 4,
          ZILUSDT: 3,
          ZKCUSDT: 3,
          ZKJUSDT: 277,
          ZKPUSDT: 22,
          ZKUSDT: 5,
          ZMUSDT: 1,
          ZORAUSDT: 0,
          ZRCUSDT: 67,
          ZROUSDT: 5,
          ZRXUSDT: 0,
          ZSUSDT: 4,
          \u54C8\u57FA\u7C73USDT: 278,
          \u5E01\u5B89\u4EBA\u751FUSDT: 279,
          \u6211\u8E0F\u9A6C\u6765\u4E86USDT: 21,
          \u725B\u6765USDT: 9,
          \u9F99\u867EUSDT: 9
        }
      },
      coinm: {
        tables: [
          [[0, 1e3, 20, 0.025, 0], [1e3, 2e3, 10, 0.05, 25], [2e3, 5e3, 7, 0.05, 25], [5e3, 1e4, 6, 0.05, 25], [1e4, 2e4, 5, 0.1, 525], [2e4, 3e4, 4, 0.125, 1025], [3e4, 4e4, 3, 0.15, 1775], [4e4, 5e4, 2, 0.25, 5775], [5e4, 1e5, 1, 0.5, 18275]],
          [[0, 10, 50, 0.01, 0], [10, 50, 20, 0.025, 0.15], [50, 100, 10, 0.05, 1.4], [100, 200, 5, 0.1, 6.4], [200, 400, 4, 0.125, 11.4], [400, 800, 3, 0.15, 21.4], [800, 1500, 2, 0.25, 101.4], [1500, 5e3, 1, 0.5, 476.4]],
          [[0, 100, 50, 0.01, 0], [100, 500, 20, 0.025, 1.5], [500, 1e3, 10, 0.05, 14], [1e3, 2e3, 5, 0.1, 64], [2e3, 3e3, 4, 0.125, 114], [3e3, 5e3, 3, 0.15, 189], [5e3, 1e4, 2, 0.25, 689], [1e4, 5e4, 1, 0.5, 3189]],
          [[0, 2e3, 20, 0.025, 0], [2e3, 4e3, 10, 0.05, 50], [4e3, 8e3, 5, 0.1, 250], [8e3, 1e4, 4, 0.125, 450], [1e4, 2e4, 2, 0.25, 1700], [2e4, 4e4, 1, 0.5, 6700]],
          [[0, 5e5, 20, 0.025, 0], [5e5, 1e6, 10, 0.05, 12500], [1e6, 15e5, 7, 0.05, 12500], [15e5, 2e6, 6, 0.05, 12500], [2e6, 3e6, 5, 0.1, 112500], [3e6, 5e6, 4, 0.125, 187500], [5e6, 1e7, 3, 0.15, 312500], [1e7, 2e7, 2, 0.25, 1312500], [2e7, 4e7, 1, 0.5, 6312500]],
          [[0, 500, 20, 0.025, 0], [500, 750, 10, 0.05, 12.5], [750, 1500, 5, 0.1, 50], [1500, 3e3, 4, 0.125, 87.5], [3e3, 5e3, 2, 0.25, 462.5], [5e3, 1e5, 1, 0.5, 1712.5]],
          [[0, 25e4, 20, 0.025, 0], [25e4, 5e5, 10, 0.0498, 6200], [5e5, 1e6, 7, 0.0499, 6250], [1e6, 2e6, 6, 0.05, 6350], [2e6, 3e6, 5, 0.1, 106350], [3e6, 4e6, 4, 0.125, 181350], [4e6, 5e6, 3, 0.15, 281350], [5e6, 1e7, 2, 0.25, 781350], [1e7, 15e6, 1, 0.5, 3281350]],
          [[0, 1e3, 20, 0.025, 0], [1e3, 1e4, 10, 0.05, 25], [1e4, 2e4, 5, 0.1, 525], [2e4, 25e3, 4, 0.125, 1025], [25e3, 5e4, 2, 0.25, 4150], [5e4, 1e5, 1, 0.5, 16650]],
          [[0, 500, 20, 0.025, 0], [500, 1500, 10, 0.05, 12.5], [1500, 2e3, 7, 0.05, 12.5], [2e3, 3e3, 6, 0.05, 12.5], [3e3, 5e3, 5, 0.1, 162.5], [5e3, 7500, 4, 0.125, 287.5], [7500, 1e4, 3, 0.15, 475], [1e4, 3e4, 2, 0.25, 1475], [3e4, 6e4, 1, 0.5, 8975]],
          [[0, 2e3, 20, 0.025, 0], [2e3, 4e3, 10, 0.05, 50], [4e3, 1e4, 7, 0.05, 50], [1e4, 2e4, 6, 0.05, 50], [2e4, 4e4, 5, 0.1, 1050], [4e4, 6e4, 4, 0.125, 2050], [6e4, 1e5, 3, 0.15, 3550], [1e5, 15e4, 2, 0.25, 13550], [15e4, 25e4, 1, 0.5, 51050]],
          [[0, 5, 125, 4e-3, 0], [5, 10, 100, 5e-3, 5e-3], [10, 25, 50, 0.01, 0.055], [25, 150, 20, 0.025, 0.43], [150, 400, 10, 0.05, 4.18], [400, 950, 5, 0.1, 24.18], [950, 1200, 4, 0.125, 47.93], [1200, 1600, 3, 0.15, 77.93], [1600, 2400, 2, 0.25, 237.93], [2400, 3500, 1, 0.5, 837.93]],
          [[0, 5e5, 25, 0.012, 0], [5e5, 25e5, 20, 0.025, 6500], [25e5, 5e6, 10, 0.05, 69e3], [5e6, 1e7, 5, 0.1, 319e3], [1e7, 2e7, 4, 0.125, 569e3], [2e7, 5e7, 2, 0.25, 3069e3], [5e7, 75e6, 1, 0.5, 15569e3]],
          [[0, 25e3, 20, 0.025, 0], [25e3, 5e4, 10, 0.05, 625], [5e4, 7e4, 7, 0.05, 625], [7e4, 8e4, 6, 0.05, 625], [8e4, 1e5, 5, 0.1, 4625], [1e5, 15e4, 4, 0.125, 7125], [15e4, 25e4, 3, 0.15, 10875], [25e4, 5e5, 2, 0.25, 35875], [5e5, 25e5, 1, 0.5, 160875]],
          [[0, 25e3, 20, 0.025, 0], [25e3, 5e4, 10, 0.05, 625], [5e4, 1e5, 7, 0.05, 625], [1e5, 25e4, 6, 0.05, 625], [25e4, 5e5, 5, 0.1, 13125], [5e5, 75e4, 4, 0.125, 25625], [75e4, 1e6, 3, 0.15, 44375], [1e6, 16e5, 2, 0.25, 144375], [16e5, 25e5, 1, 0.5, 544375]],
          [[0, 15, 100, 5e-3, 0], [15, 100, 75, 65e-4, 0.0225], [100, 400, 50, 0.01, 0.3725], [400, 1500, 20, 0.025, 6.3725], [1500, 5e3, 10, 0.05, 43.8725], [5e3, 14e3, 5, 0.1, 293.8725], [14e3, 18e3, 4, 0.125, 643.8725], [18e3, 24e3, 3, 0.15, 1093.8725], [24e3, 36e3, 2, 0.25, 3493.8725], [36e3, 55e3, 1, 0.5, 12493.8725]],
          [[0, 5e3, 20, 0.025, 0], [5e3, 15e3, 10, 0.05, 125], [15e3, 2e4, 6, 0.05, 125], [2e4, 3e4, 5, 0.1, 1125], [3e4, 5e4, 4, 0.125, 1875], [5e4, 75e3, 3, 0.15, 3125], [75e3, 5e5, 2, 0.25, 10625], [5e5, 1e6, 1, 0.5, 135625]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 2e4, 10, 0.05, 250], [2e4, 4e4, 7, 0.05, 250], [4e4, 6e4, 6, 0.05, 250], [6e4, 8e4, 5, 0.1, 3250], [8e4, 1e5, 4, 0.125, 5250], [1e5, 15e4, 3, 0.15, 7750], [15e4, 2e6, 2, 0.25, 22750], [2e6, 3e6, 1, 0.5, 522750]],
          [[0, 2500, 20, 0.025, 0], [2500, 5e3, 10, 0.05, 62.5], [5e3, 1e4, 7, 0.05, 62.5], [1e4, 25e3, 6, 0.05, 62.5], [25e3, 5e4, 5, 0.1, 1312.5], [5e4, 75e3, 4, 0.125, 2562.5], [75e3, 1e5, 3, 0.15, 4437.5], [1e5, 125e3, 2, 0.25, 14437.5], [125e3, 2e5, 1, 0.5, 45687.5]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 2e4, 10, 0.05, 250], [2e4, 4e4, 5, 0.1, 1250], [4e4, 7e4, 4, 0.125, 2250], [7e4, 1e5, 2, 0.25, 11e3], [1e5, 2e5, 1, 0.5, 36e3]],
          [[0, 400, 50, 0.01, 0], [400, 2300, 25, 0.02, 4], [2300, 4600, 20, 0.025, 15.5], [4600, 23400, 10, 0.05, 130.5], [23400, 37400, 5, 0.1, 1300.5], [37400, 46800, 4, 0.125, 2235.5], [46800, 56100, 3, 0.1667, 4187.06], [56100, 93600, 2, 0.25, 8860.19], [93600, 187200, 1, 0.5, 32260.19]],
          [[0, 2e4, 20, 0.025, 0], [2e4, 2e5, 10, 0.05, 500], [2e5, 4e5, 5, 0.1, 10500], [4e5, 5e5, 4, 0.125, 20500], [5e5, 1e6, 2, 0.25, 83e3], [1e6, 2e6, 1, 0.5, 333e3]],
          [[0, 5e6, 20, 0.025, 0], [5e6, 1e7, 10, 0.05, 125e3], [1e7, 2e7, 7, 0.05, 125e3], [2e7, 5e7, 6, 0.05, 125e3], [5e7, 1e8, 5, 0.1, 2625e3], [1e8, 2e8, 4, 0.125, 5125e3], [2e8, 3e8, 3, 0.15, 10125e3], [3e8, 4e8, 2, 0.25, 40125e3], [4e8, 6e8, 1, 0.5, 140125e3]],
          [[0, 1e4, 20, 0.025, 0], [1e4, 2e4, 10, 0.05, 250], [2e4, 3e4, 5, 0.1, 1250], [3e4, 5e4, 4, 0.125, 2e3], [5e4, 8e4, 3, 0.15, 3250], [8e4, 1e5, 2, 0.25, 11250], [1e5, 2e5, 1, 0.5, 36250]],
          [[0, 2e5, 20, 0.025, 0], [2e5, 4e5, 10, 0.05, 5e3], [4e5, 6e5, 5, 0.1, 25e3], [6e5, 1e6, 4, 0.125, 4e4], [1e6, 15e5, 3, 0.15, 65e3], [15e5, 2e6, 2, 0.25, 215e3], [2e6, 3e7, 1, 0.5, 715e3]],
          [[0, 33100, 50, 0.01, 0], [33100, 165600, 25, 0.02, 331], [165600, 5e5, 20, 0.025, 1159], [5e5, 2e6, 10, 0.05, 13659], [2e6, 3e6, 5, 0.1, 113659], [3e6, 5e6, 4, 0.125, 188659], [5e6, 1e7, 3, 0.15, 313659], [1e7, 2e7, 2, 0.25, 1313659], [2e7, 4e7, 1, 0.5, 6313659]]
        ],
        symbols: {
          AAVEUSD_PERP: 5,
          ADAUSD_PERP: 6,
          AVAXUSD_PERP: 7,
          BCHUSD_PERP: 8,
          BNBUSD_260626: 0,
          BNBUSD_260925: 0,
          BNBUSD_261225: 0,
          BNBUSD_PERP: 9,
          BTCUSD_260626: 1,
          BTCUSD_260925: 1,
          BTCUSD_261225: 1,
          BTCUSD_PERP: 10,
          DOGEUSD_PERP: 11,
          DOTUSD_PERP: 12,
          ETCUSD_PERP: 13,
          ETHUSD_260626: 2,
          ETHUSD_260925: 2,
          ETHUSD_261225: 2,
          ETHUSD_PERP: 14,
          FILUSD_PERP: 15,
          LINKUSD_PERP: 16,
          LTCUSD_PERP: 17,
          NEARUSD_PERP: 18,
          SOLUSD_260626: 3,
          SOLUSD_260925: 3,
          SOLUSD_261225: 3,
          SOLUSD_PERP: 19,
          SUIUSD_PERP: 20,
          TRXUSD_PERP: 21,
          UNIUSD_PERP: 22,
          XLMUSD_PERP: 23,
          XRPUSD_260626: 4,
          XRPUSD_260925: 4,
          XRPUSD_261225: 4,
          XRPUSD_PERP: 24
        },
        contractSizeUsd: { AAVEUSD: 10, ADAUSD: 10, AVAXUSD: 10, BCHUSD: 10, BNBUSD: 10, BTCUSD: 100, DOGEUSD: 10, DOTUSD: 10, ETCUSD: 10, ETHUSD: 10, FILUSD: 10, LINKUSD: 10, LTCUSD: 10, NEARUSD: 10, SOLUSD: 10, SUIUSD: 10, TRXUSD: 10, UNIUSD: 10, XLMUSD: 10, XRPUSD: 10 }
      },
      fallbackUsdmTable: 0
    };
  }
});

// src/lib/leverageTierData.ts
function listedCoinContractSizeUsd(baseAsset) {
  const value = LEVERAGE_TIER_DATA.coinm.contractSizeUsd[`${String(baseAsset || "").toUpperCase()}USD`];
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : null;
}
function isListedBaseAsset(baseAsset) {
  const base = String(baseAsset || "").toUpperCase();
  if (!base) return false;
  return LEVERAGE_TIER_DATA.usdm.symbols[`${base}USDT`] != null || LEVERAGE_TIER_DATA.coinm.contractSizeUsd[`${base}USD`] != null;
}
var LEVERAGE_TIER_DATA, LEVERAGE_TIER_SNAPSHOT_DATE;
var init_leverageTierData = __esm({
  "src/lib/leverageTierData.ts"() {
    init_binanceLeverageTiers();
    LEVERAGE_TIER_DATA = binanceLeverageTiers_default;
    LEVERAGE_TIER_SNAPSHOT_DATE = String(LEVERAGE_TIER_DATA.fetchedAt).slice(0, 10);
  }
});

// src/lib/coinMargined.ts
function getSettlementAsset(symbol2) {
  const normalized = (symbol2 || "BTCUSDT").toUpperCase().replace(/[-_/]/g, "").replace(/PERP$/, "");
  const bases2 = QUOTE_ASSETS.filter((quote) => normalized.endsWith(quote)).map((quote) => normalized.slice(0, -quote.length)).sort((a, b) => b.length - a.length);
  const stripped = bases2.find((base) => base && isListedBaseAsset(base)) ?? bases2[bases2.length - 1] ?? normalized;
  return stripped || "BTC";
}
function getCoinMarginedContractSizeUsd(symbol2) {
  return listedCoinContractSizeUsd(getSettlementAsset(symbol2)) ?? SYNTHETIC_COIN_CONTRACT_SIZE_USD;
}
function getCoinContractSizeUsd(symbol2, item) {
  const value = Number(item?.contractSizeUsd);
  return Number.isFinite(value) && value > 0 ? value : getCoinMarginedContractSizeUsd(symbol2);
}
function roundCoinContracts(value) {
  return Number.isFinite(value) && value > 0 ? Math.max(1, Math.round(value)) : 0;
}
function getCoinContracts(item) {
  return roundCoinContracts(Number(item?.contracts ?? item?.quantity ?? 0));
}
function coinNotionalUsd(contracts, contractSizeUsd) {
  return getCoinContracts({ contracts }) * contractSizeUsd;
}
var QUOTE_ASSETS, SYNTHETIC_COIN_CONTRACT_SIZE_USD;
var init_coinMargined = __esm({
  "src/lib/coinMargined.ts"() {
    init_leverageTierData();
    QUOTE_ASSETS = ["USDT", "USDC", "BUSD", "USD"];
    SYNTHETIC_COIN_CONTRACT_SIZE_USD = 10;
  }
});

// src/lib/leverageTiers.ts
var init_leverageTiers = __esm({
  "src/lib/leverageTiers.ts"() {
    init_leverageTierData();
    init_coinMargined();
  }
});

// src/lib/positionLimitMode.ts
var UNLIMITED_MAX_LEVERAGE, POSITION_LIMIT_MODE_LABEL, POSITION_LIMIT_MODE_HINT, POSITION_LIMIT_MODE_SWITCH_LINE;
var init_positionLimitMode = __esm({
  "src/lib/positionLimitMode.ts"() {
    init_leverageTiers();
    UNLIMITED_MAX_LEVERAGE = 150;
    POSITION_LIMIT_MODE_LABEL = Object.freeze({
      unlimited: "\u65E0\u9650\u5236",
      binance: "\u5E01\u5B89\u6807\u51C6"
    });
    POSITION_LIMIT_MODE_HINT = Object.freeze({
      unlimited: `\u65E0\u9650\u5236\uFF1A\u4EFB\u4F55\u5E01\u79CD\u6760\u6746 1\u2013${UNLIMITED_MAX_LEVERAGE}x\uFF0C\u4E0D\u8BBE\u6301\u4ED3\u4E0A\u9650\u3001\u4E0D\u8BBE\u5355\u7B14\u4E0B\u5355\u4E0A\u9650\uFF0C\u65B0\u4ED3\u7EF4\u6301\u4FDD\u8BC1\u91D1\u56FA\u5B9A 0.4%`,
      binance: "\u5E01\u5B89\u6807\u51C6\uFF1A\u6309\u5E01\u5B89\u5404\u5E01\u79CD\u6760\u6746\u5206\u5C42\u3001\u6301\u4ED3\u4E0A\u9650\u3001\u5355\u7B14\u5E02\u4EF7 / \u9650\u4EF7\u4E0A\u9650\u4E0E\u5206\u5C42\u7EF4\u6301\u4FDD\u8BC1\u91D1"
    });
    POSITION_LIMIT_MODE_SWITCH_LINE = Object.freeze({
      unlimited: `\u6760\u6746 1\u2013${UNLIMITED_MAX_LEVERAGE}x\uFF0C\u4E0D\u8BBE\u6301\u4ED3\u4E0E\u5355\u7B14\u4E0A\u9650\uFF0C\u65B0\u4ED3\u6309 0.4% \u8BA1\u7EF4\u6301\u4FDD\u8BC1\u91D1`,
      binance: "\u6309\u5E01\u5B89\u6760\u6746\u5206\u5C42\u3001\u6301\u4ED3\u4E0A\u9650\u4E0E\u5355\u7B14\u4E0A\u9650\uFF0C\u65B0\u4ED3\u6309\u5206\u5C42\u8BA1\u7EF4\u6301\u4FDD\u8BC1\u91D1"
    });
  }
});

// src/lib/positionRiskModel.ts
var TIERED_RISK_MODEL, LEGACY_HEDGE_RISK_MODEL, ORDER_RISK_STAMP, ORDER_LEGACY_HEDGE_STAMP;
var init_positionRiskModel = __esm({
  "src/lib/positionRiskModel.ts"() {
    init_positionLimitMode();
    init_coinMargined();
    init_leverageTiers();
    TIERED_RISK_MODEL = "binance-tiers-v1";
    LEGACY_HEDGE_RISK_MODEL = "legacy-hedge-v1";
    ORDER_RISK_STAMP = Object.freeze({ riskModel: TIERED_RISK_MODEL });
    ORDER_LEGACY_HEDGE_STAMP = Object.freeze({ riskModel: LEGACY_HEDGE_RISK_MODEL });
  }
});

// src/types/trading.ts
var init_trading = __esm({
  "src/types/trading.ts"() {
    init_positionRiskModel();
  }
});

// src/lib/tradingSettlement.ts
function isCoinSettled(item) {
  return item?.settlementMode === "coin";
}
function getPositionNotionalUsd(symbol2, item, price) {
  if (isCoinSettled(item)) {
    return coinNotionalUsd(getCoinContracts(item), getCoinContractSizeUsd(symbol2, item));
  }
  const px = Number(price ?? item.entryPrice ?? 0);
  return Number(item.quantity ?? 0) * px;
}
var init_tradingSettlement = __esm({
  "src/lib/tradingSettlement.ts"() {
    init_trading();
    init_coinMargined();
    init_positionRiskModel();
  }
});

// src/lib/liquidationRecord.ts
function isLiquidationRecord(record) {
  if (!record) return false;
  return record.action === "LIQUIDATION" || record.exit_method === "liquidation";
}
function isBankruptcySettlement(record) {
  return isLiquidationRecord(record) && record?.liquidationSettlement === "bankruptcy";
}
function liquidationPnlFloorUsd(record) {
  if (!record || !isBankruptcySettlement(record)) return null;
  if (Number.isFinite(record.pnl)) return Number(record.pnl);
  const notional = getPositionNotionalUsd(record.symbol, record, record.entryPrice);
  const leverage = Number(record.leverage);
  const margin = Number.isFinite(notional) && notional > 0 && leverage > 0 ? notional / leverage : null;
  return margin != null && margin > 0 ? -margin : null;
}
var init_liquidationRecord = __esm({
  "src/lib/liquidationRecord.ts"() {
    init_tradingSettlement();
  }
});

// src/lib/campaignLegExecution.ts
function safeTimeMs2(value) {
  if (!value) return null;
  const ms = typeof value === "number" ? value : new Date(value).getTime();
  return Number.isFinite(ms) ? ms : null;
}
function resolveLegExecution(leg, record, exitCorrections = {}) {
  const exitCorrection = exitCorrections[leg.id] ?? null;
  const openTime = record?.openTime ?? safeTimeMs2(leg.pre_simulated_time);
  const qualityMirror = isQualityCampaignId(leg.campaign_id ?? void 0) && record?.exit_reason_text === "\u955C\u50CF\u6B62\u76C8" && leg.trade_record_id === record.positionId;
  const closeTime = qualityMirror ? journalSimulatedCloseTime(leg) : record?.closeTime ?? journalSimulatedCloseTime(leg);
  const entryPrice = record?.entryPrice ?? leg.pre_entry_price ?? null;
  const rawExitPrice = qualityMirror ? leg.post_exit_price_snapshot ?? null : record?.exitPrice ?? leg.post_exit_price_snapshot ?? null;
  const exitPrice = qualityMirror && closeTime == null ? null : isLiquidationRecord(record) ? rawExitPrice : exitCorrection?.exitPrice ?? rawExitPrice;
  return {
    record,
    openTime,
    closeTime,
    entryPrice,
    exitPrice,
    exitCorrection
  };
}
function tradeRecordNotionalAt(record, price = record.entryPrice) {
  return getPositionNotionalUsd(record.symbol, record, price || record.entryPrice);
}
function tradeRecordGrossPnlAtExit(record, exitPrice) {
  if (!Number.isFinite(record.entryPrice) || record.entryPrice <= 0 || !Number.isFinite(exitPrice) || exitPrice <= 0) {
    return 0;
  }
  if (record.settlementMode === "coin") {
    const contracts = Math.max(0, Number(record.contracts ?? record.quantity ?? 0));
    const contractSizeUsd = Math.max(0, Number(record.contractSizeUsd ?? 10));
    const notionalUsd = contracts * contractSizeUsd;
    if (!(notionalUsd > 0)) return 0;
    return record.side === "LONG" ? notionalUsd * (exitPrice / record.entryPrice - 1) : notionalUsd * (1 - exitPrice / record.entryPrice);
  }
  const quantity2 = Math.max(0, Number(record.quantity ?? 0));
  if (!(quantity2 > 0)) return 0;
  return record.side === "LONG" ? (exitPrice - record.entryPrice) * quantity2 : (record.entryPrice - exitPrice) * quantity2;
}
function buildTradeRecordPnlCorrection(record, exitCorrection) {
  if (!Number.isFinite(record.pnl)) return null;
  if (isLiquidationRecord(record)) return null;
  const originalGrossPnl = tradeRecordGrossPnlAtExit(record, exitCorrection.originalExitPrice);
  const correctedGrossPnl = tradeRecordGrossPnlAtExit(record, exitCorrection.exitPrice);
  const pnlDelta = correctedGrossPnl - originalGrossPnl;
  if (!Number.isFinite(pnlDelta)) return null;
  return {
    recordId: record.id,
    originalNetPnl: Number(record.pnl),
    correctedNetPnl: Number(record.pnl) + pnlDelta,
    pnlDelta,
    originalExitPrice: exitCorrection.originalExitPrice,
    correctedExitPrice: exitCorrection.exitPrice
  };
}
var init_campaignLegExecution = __esm({
  "src/lib/campaignLegExecution.ts"() {
    init_campaignSections();
    init_canonicalTimePrice();
    init_objectiveOperationTime();
    init_liquidationRecord();
    init_tradingSettlement();
  }
});

// src/types/journal.ts
function isHistoricalCampaign(campaign) {
  return (campaign.actual_evolution ?? []).some(
    (event) => event.event_type === "historical_classification_created" || event.event_type === "historical_leg_attached"
  );
}
var EMOTION_TAG_META, PAIN_TAG_LABELS;
var init_journal = __esm({
  "src/types/journal.ts"() {
    EMOTION_TAG_META = {
      // ===== 正向情绪 · 帮助执行规则（可放行，但不能替代规则）=====
      calm: { label: "\u51B7\u9759", valence: "positive", coreMeaning: "\u60C5\u7EEA\u7A33\u5B9A\uFF0C\u80FD\u6309\u8BA1\u5212\u4EA4\u6613", behaviorTendency: "\u65E0\u660E\u663E\u5931\u63A7\u503E\u5411" },
      focused: { label: "\u4E13\u6CE8", valence: "positive", coreMeaning: "\u6CE8\u610F\u529B\u96C6\u4E2D\uFF0C\u53EA\u505A\u8BA1\u5212\u5185\u673A\u4F1A", behaviorTendency: "\u65E0\u660E\u663E\u5931\u63A7\u503E\u5411" },
      patient: { label: "\u8010\u5FC3", valence: "positive", coreMeaning: "\u80FD\u7B49\u5F85\u89E6\u53D1\uFF0C\u4E0D\u88AB\u566A\u97F3\u8BF1\u5BFC", behaviorTendency: "\u65E0\u660E\u663E\u5931\u63A7\u503E\u5411" },
      // ===== 中性情绪 · 本身不坏，但必须校准 =====
      fear_of_loss: { label: "\u5BB3\u6015\u4E8F\u635F / \u6050\u60E7", valence: "neutral", coreMeaning: "\u5BF9\u4E8F\u635F\u6216\u98CE\u9669\u654F\u611F\uFF0C\u8F7B\u5EA6\u662F\u98CE\u63A7\u610F\u8BC6\uFF0C\u8FC7\u5EA6\u4F1A\u53D8\u6210\u9003\u907F", behaviorTendency: "\u63D0\u524D\u6B62\u76C8\u3001\u9891\u7E41\u4EA4\u6613" },
      fear_giveback: { label: "\u5BB3\u6015\u56DE\u5410\u5229\u6DA6", valence: "neutral", coreMeaning: "\u4E00\u6709\u6D6E\u76C8\u5C31\u6015\u5229\u6DA6\u6D88\u5931", behaviorTendency: "\u63D0\u524D\u6B62\u76C8" },
      hesitation: { label: "\u72B9\u8C6B", valence: "neutral", coreMeaning: "\u4FE1\u53F7\u51FA\u73B0\u540E\u8FDF\u8FDF\u4E0D\u6562\u6267\u884C", behaviorTendency: "\u63D0\u524D\u6B62\u76C8\u3001\u9891\u7E41\u4EA4\u6613" },
      unease: { label: "\u4E0D\u5B89 / \u6000\u7591", valence: "neutral", coreMeaning: "\u76F4\u89C9\u611F\u5230\u98CE\u9669\u3001\u4E0D\u786E\u5B9A\u6216\u4FE1\u606F\u4E0D\u5B8C\u6574", behaviorTendency: "\u62D2\u7EDD\u6267\u884C\u3001\u9891\u7E41\u786E\u8BA4\u3001\u9519\u8FC7\u673A\u4F1A" },
      confusion: { label: "\u56F0\u60D1", valence: "neutral", coreMeaning: "\u9762\u5BF9\u590D\u6742\u884C\u60C5\u65F6\u4E0D\u77E5\u9053\u5982\u4F55\u89E3\u91CA", behaviorTendency: "\u8FC7\u65E9\u4E0B\u7ED3\u8BBA\u3001\u9891\u7E41\u4EA4\u6613" },
      regret: { label: "\u540E\u6094 / \u61CA\u6094", valence: "neutral", coreMeaning: "\u5BF9\u9519\u8FC7\u673A\u4F1A\u6216\u9519\u8BEF\u64CD\u4F5C\u4EA7\u751F\u8865\u507F\u51B2\u52A8", behaviorTendency: "\u8FFD\u5355\u3001\u9891\u7E41\u4EA4\u6613\u3001\u52A0\u4ED3" },
      odds_excitement: { label: "\u5174\u594B / \u8D54\u7387\u5174\u594B", valence: "neutral", coreMeaning: "\u770B\u5230\u5927\u673A\u4F1A\u3001\u5927\u6CE2\u52A8\u6216\u9AD8\u8D54\u7387\u65F6\u60C5\u7EEA\u4E0A\u5347", behaviorTendency: "\u8FFD\u5355\u3001\u52A0\u4ED3\u3001\u53D6\u6D88\u6B62\u635F" },
      fatigue: { label: "\u75B2\u60EB", valence: "neutral", coreMeaning: "\u6CE8\u610F\u529B\u548C\u6267\u884C\u8D28\u91CF\u4E0B\u964D", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u53D6\u6D88\u6B62\u635F\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      distracted: { label: "\u5206\u5FC3", valence: "neutral", coreMeaning: "\u6CE8\u610F\u529B\u4E0D\u5B8C\u6574\uFF0C\u65E0\u6CD5\u7A33\u5B9A\u76D1\u63A7\u4EA4\u6613", behaviorTendency: "\u53D6\u6D88\u6B62\u635F\u3001\u9891\u7E41\u4EA4\u6613" },
      // ===== 负向情绪 · 默认黄灯或红灯 =====
      fomo: { label: "FOMO / \u9519\u5931\u6050\u60E7 / \u8E0F\u7A7A\u7126\u8651", valence: "negative", coreMeaning: "\u5BB3\u6015\u522B\u4EBA\u6B63\u5728\u8D5A\u94B1\uFF0C\u800C\u81EA\u5DF1\u6B63\u5728\u9519\u8FC7", behaviorTendency: "\u8FFD\u5355\u3001\u9891\u7E41\u4EA4\u6613\u3001\u52A0\u4ED3" },
      revenge: { label: "\u590D\u4EC7\u4EA4\u6613", valence: "negative", coreMeaning: "\u60F3\u628A\u4E0A\u4E00\u7B14\u4E8F\u635F\u7ACB\u523B\u8D5A\u56DE\u6765", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u52A0\u4ED3\u3001\u8FFD\u5355" },
      prove_self: { label: "\u8BC1\u660E\u81EA\u5DF1", valence: "negative", coreMeaning: "\u4EA4\u6613\u4E0D\u662F\u4E3A\u4E86\u673A\u4F1A\uFF0C\u800C\u662F\u4E3A\u4E86\u8BC1\u660E\u5224\u65AD\u6CA1\u9519", behaviorTendency: "\u625B\u5355\u3001\u52A0\u4ED3\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      impatience: { label: "\u6025\u8E81 / \u51B2\u52A8", valence: "negative", coreMeaning: "\u7B49\u4E0D\u4E86\u786E\u8BA4\u4FE1\u53F7\uFF0C\u60F3\u9A6C\u4E0A\u505A\u70B9\u4EC0\u4E48", behaviorTendency: "\u8FFD\u5355\u3001\u9891\u7E41\u4EA4\u6613" },
      boredom: { label: "\u65E0\u804A\u4EA4\u6613", valence: "negative", coreMeaning: "\u4E0D\u662F\u5E02\u573A\u6709\u673A\u4F1A\uFF0C\u800C\u662F\u81EA\u5DF1\u60F3\u627E\u523A\u6FC0", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u8FFD\u5355" },
      anxiety: { label: "\u7126\u8651", valence: "negative", coreMeaning: "\u9762\u5BF9\u4E0D\u786E\u5B9A\u3001\u8D26\u6237\u6CE2\u52A8\u6216\u793E\u4EA4\u538B\u529B\u65F6\u6301\u7EED\u4E0D\u5B89", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u8FFD\u5355\u3001\u63D0\u524D\u6B62\u76C8" },
      greed: { label: "\u8D2A\u5A6A", valence: "negative", coreMeaning: "\u5DF2\u6709\u6536\u76CA\u540E\u8FD8\u60F3\u8981\u66F4\u591A\uFF0C\u5FFD\u89C6\u98CE\u9669\u8FB9\u754C", behaviorTendency: "\u52A0\u4ED3\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD\u3001\u53D6\u6D88\u6B62\u635F" },
      overconfidence: { label: "\u8FC7\u5EA6\u81EA\u4FE1 / \u81EA\u89C6\u8FC7\u9AD8 / \u9A84\u50B2", valence: "negative", coreMeaning: "\u9AD8\u4F30\u81EA\u5DF1\u7684\u5224\u65AD\u529B\u3001\u80DC\u7387\u548C\u63A7\u5236\u529B", behaviorTendency: "\u52A0\u4ED3\u3001\u8FFD\u5355\u3001\u53D6\u6D88\u6B62\u635F" },
      optimism: { label: "\u8FC7\u5EA6\u4E50\u89C2", valence: "negative", coreMeaning: "\u9AD8\u4F30\u597D\u7ED3\u679C\uFF0C\u4F4E\u4F30\u574F\u7ED3\u679C", behaviorTendency: "\u52A0\u4ED3\u3001\u53D6\u6D88\u6B62\u635F\u3001\u4F4E\u4F30\u5C3E\u90E8\u98CE\u9669" },
      jackpot_fantasy: { label: "\u66B4\u5BCC\u5E7B\u60F3 / \u72C2\u70ED / \u8E81\u72C2", valence: "negative", coreMeaning: "\u628A\u4E00\u7B14\u4EA4\u6613\u60F3\u8C61\u6210\u4EBA\u751F\u7FFB\u8EAB\u70B9", behaviorTendency: "\u52A0\u4ED3\u3001\u625B\u5355\u3001\u53D6\u6D88\u6B62\u635F" },
      unwilling: { label: "\u4E0D\u7518\u5FC3", valence: "negative", coreMeaning: "\u4E8F\u635F\u540E\u89C9\u5F97\u4E0D\u80FD\u5C31\u8FD9\u4E48\u8D70", behaviorTendency: "\u625B\u5355\u3001\u53D6\u6D88\u6B62\u635F\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      sunk_cost: { label: "\u6C89\u6CA1\u6210\u672C\u75DB", valence: "negative", coreMeaning: "\u56E0\u4E3A\u5DF2\u7ECF\u6295\u5165\u6216\u5DF2\u7ECF\u4E8F\u635F\uFF0C\u6240\u4EE5\u820D\u4E0D\u5F97\u9000\u51FA", behaviorTendency: "\u625B\u5355\u3001\u52A0\u4ED3\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      deprivation: { label: "\u88AB\u5265\u593A\u611F", valence: "negative", coreMeaning: "\u611F\u89C9\u5DF2\u6709\u6536\u76CA\u3001\u5DEE\u70B9\u5230\u624B\u7684\u6536\u76CA\u6216\u673A\u4F1A\u88AB\u593A\u8D70", behaviorTendency: "\u590D\u4EC7\u4EA4\u6613\u3001\u8FFD\u5355\u3001\u52A0\u4ED3" },
      wishful: { label: "\u4FA5\u5E78 / \u62D6\u5EF6\u89C2\u671B", valence: "negative", coreMeaning: "\u660E\u77E5\u7ED3\u6784\u4E0D\u5BF9\uFF0C\u4F46\u5E0C\u671B\u884C\u60C5\u6551\u56DE\u6765", behaviorTendency: "\u625B\u5355\u3001\u53D6\u6D88\u6B62\u635F\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      denial: { label: "\u5FC3\u7406\u5426\u8BA4", valence: "negative", coreMeaning: "\u5E02\u573A\u5DF2\u7ECF\u53CD\u9988\u9519\u8BEF\uFF0C\u4F46\u5927\u8111\u62D2\u7EDD\u627F\u8BA4", behaviorTendency: "\u625B\u5355\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD\u3001\u53D6\u6D88\u6B62\u635F" },
      stubborn_hold: { label: "\u6B7B\u625B", valence: "negative", coreMeaning: "\u4E0D\u518D\u57FA\u4E8E\u7B56\u7565\uFF0C\u800C\u662F\u9760\u5FCD\u8010\u6301\u4ED3", behaviorTendency: "\u625B\u5355\u3001\u53D6\u6D88\u6B62\u635F\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      confirmation: { label: "\u786E\u8BA4\u504F\u8BEF", valence: "negative", coreMeaning: "\u53EA\u5BFB\u627E\u652F\u6301\u81EA\u5DF1\u4ED3\u4F4D\u7684\u4FE1\u606F", behaviorTendency: "\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD\u3001\u625B\u5355" },
      narrative: { label: "\u53D9\u4E8B\u4E0A\u5934", valence: "negative", coreMeaning: "\u88AB\u5B8F\u5927\u6545\u4E8B\u5E26\u8D70\uFF0C\u4E0D\u770B\u4EF7\u683C\u7ED3\u6784", behaviorTendency: "\u625B\u5355\u3001\u52A0\u4ED3\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      anchoring: { label: "\u951A\u5B9A", valence: "negative", coreMeaning: "\u88AB\u5F00\u4ED3\u4EF7\u3001\u524D\u9AD8\u3001\u6700\u9AD8\u6D6E\u76C8\u7ED1\u67B6", behaviorTendency: "\u625B\u5355\u3001\u63D0\u524D\u6B62\u76C8\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      envy: { label: "\u5AC9\u5992 / \u6BD4\u8F83", valence: "negative", coreMeaning: "\u770B\u5230\u522B\u4EBA\u8D5A\u94B1\u540E\u5FC3\u6001\u5931\u8861", behaviorTendency: "\u8FFD\u5355\u3001\u52A0\u4ED3\u3001\u9891\u7E41\u4EA4\u6613" },
      anger: { label: "\u6124\u6012 / \u59D4\u5C48 / \u654C\u610F", valence: "negative", coreMeaning: '\u89C9\u5F97\u5E02\u573A\u3001\u5BF9\u624B\u6216\u89C4\u5219"\u4E0D\u516C\u5E73"\uFF0C\u60F3\u53CD\u51FB', behaviorTendency: "\u590D\u4EC7\u4EA4\u6613\u3001\u52A0\u4ED3\u3001\u9891\u7E41\u4EA4\u6613" },
      panic: { label: "\u6050\u614C / \u60CA\u614C", valence: "negative", coreMeaning: "\u5267\u70C8\u6CE2\u52A8\u65F6\u7406\u6027\u7CFB\u7EDF\u5D29\u6E83", behaviorTendency: "\u63D0\u524D\u6B62\u76C8\u3001\u53D6\u6D88\u6B62\u635F\u3001\u9891\u7E41\u4EA4\u6613" },
      despair: { label: "\u6781\u5EA6\u60B2\u89C2 / \u7EDD\u671B", valence: "negative", coreMeaning: "\u8BA4\u4E3A\u574F\u60C5\u51B5\u4F1A\u6C38\u4E45\u6301\u7EED", behaviorTendency: "\u6050\u614C\u5272\u8089\u3001\u62D2\u7EDD\u91CD\u65B0\u8BC4\u4F30\u673A\u4F1A" },
      frustration: { label: "\u6CAE\u4E27 / \u632B\u8D25", valence: "negative", coreMeaning: "\u8FDE\u7EED\u5931\u8D25\u540E\u4EA7\u751F\u65E0\u529B\u611F", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u653E\u5F03\u89C4\u5219\u3001\u6D88\u6781\u6267\u884C" },
      self_pity: { label: "\u81EA\u601C", valence: "negative", coreMeaning: '\u628A\u4E8F\u635F\u89E3\u91CA\u6210"\u6211\u603B\u662F\u5012\u9709"', behaviorTendency: "\u62D2\u7EDD\u590D\u76D8\u3001\u9003\u907F\u8D23\u4EFB" },
      shame: { label: "\u7F9E\u803B", valence: "negative", coreMeaning: "\u56E0\u4E8F\u635F\u3001\u5931\u8BEF\u6216\u8D1F\u9762\u60C5\u7EEA\u611F\u5230\u4E22\u8138", behaviorTendency: "\u9690\u7792\u9519\u8BEF\u3001\u62D2\u7EDD\u590D\u76D8" },
      numbness: { label: "\u9EBB\u6728 / \u51B7\u6F20", valence: "negative", coreMeaning: '\u5BF9\u98CE\u9669\u5931\u53BB\u611F\u89C9\uFF0C\u6216\u8005\u7528"\u4E0D\u5728\u4E4E"\u9003\u907F\u73B0\u5B9E', behaviorTendency: "\u52A0\u4ED3\u3001\u53D6\u6D88\u6B62\u635F\u3001\u9891\u7E41\u4EA4\u6613" },
      stress_overload: { label: "\u538B\u529B\u8FC7\u8F7D", valence: "negative", coreMeaning: "\u8D26\u6237\u538B\u529B\u3001\u751F\u6D3B\u538B\u529B\u3001\u60C5\u7EEA\u538B\u529B\u53E0\u52A0", behaviorTendency: "\u52A0\u4ED3\u3001\u625B\u5355\u3001\u9891\u7E41\u4EA4\u6613\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      infatuation: { label: "\u76F2\u76EE\u70ED\u7231 / \u60C5\u611F\u4F9D\u604B", valence: "negative", coreMeaning: "\u7231\u4E0A\u67D0\u53EA\u80A1\u7968\u3001\u67D0\u4E2A\u5E01\u6216\u67D0\u4E2A\u4EA4\u6613\u903B\u8F91", behaviorTendency: "\u5FFD\u7565\u8D1F\u9762\u4FE1\u606F\u3001\u7528\u611F\u60C5\u6301\u4ED3" },
      aversion: { label: "\u538C\u6076 / \u6392\u65A5 / \u975E\u7406\u6027\u618E\u6068", valence: "negative", coreMeaning: "\u56E0\u8FC7\u53BB\u4E8F\u635F\u6216\u4E2A\u4EBA\u53CD\u611F\u800C\u62D2\u7EDD\u5BA2\u89C2\u5206\u6790", behaviorTendency: "\u9519\u8FC7\u673A\u4F1A\u3001\u5224\u65AD\u5931\u771F" },
      false_safety: { label: "\u865A\u5047\u5B89\u5FC3 / \u76F2\u4ECE\u5B89\u5168\u611F", valence: "negative", coreMeaning: "\u56E0\u4E3A\u5927\u5BB6\u90FD\u8FD9\u4E48\u505A\uFF0C\u6240\u4EE5\u89C9\u5F97\u5B89\u5168", behaviorTendency: "\u8DDF\u5355\u3001\u8FFD\u5355\u3001\u964D\u4F4E\u9A8C\u8BC1\u6807\u51C6" },
      false_control: { label: "\u865A\u5047\u638C\u63A7\u611F", valence: "negative", coreMeaning: "\u901A\u8FC7\u9891\u7E41\u64CD\u4F5C\u6765\u5B89\u629A\u7126\u8651\uFF0C\u8BEF\u4EE5\u4E3A\u81EA\u5DF1\u5728\u638C\u63A7\u5C40\u9762", behaviorTendency: "\u9891\u7E41\u4EA4\u6613\u3001\u8FC7\u5EA6\u64CD\u4F5C" },
      rationalization: { label: "\u5408\u7406\u5316\u5E73\u9759", valence: "negative", coreMeaning: "\u72AF\u9519\u540E\u7528\u4E00\u5806\u7406\u7531\u5B89\u629A\u81EA\u5DF1\uFF0C\u7EF4\u6301\u539F\u5224\u65AD", behaviorTendency: "\u625B\u5355\u3001\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD" },
      obsessive_focus: { label: "\u504F\u6267\u4E13\u6CE8", valence: "negative", coreMeaning: "\u9AD8\u5EA6\u4E13\u6CE8\u4E8E\u5BFB\u627E\u652F\u6301\u4ED3\u4F4D\u7684\u4FE1\u606F", behaviorTendency: "\u62D2\u7EDD\u66F4\u65B0\u5224\u65AD\u3001\u625B\u5355" }
    };
    PAIN_TAG_LABELS = Object.fromEntries(
      Object.entries(EMOTION_TAG_META).map(([tag, meta]) => [tag, meta.label])
    );
  }
});

// src/lib/campaignRealizedPnl.ts
function isSettlementRecord(record) {
  return record.action === "CLOSE" || record.action === "LIQUIDATION";
}
function recordRecency2(record) {
  return record.closeTime || record.openTime || 0;
}
function finite(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function claimRecordsByLeg(legs, tradeRecords) {
  const settlement = tradeRecords.filter(isSettlementRecord);
  const claimed = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const leg of legs) {
    const ref = leg.trade_record_id;
    const exact = ref ? settlement.filter((r) => r.id === ref) : [];
    for (const r of exact) claimed.add(r.id);
    result.set(leg.id, exact);
  }
  for (const leg of legs) {
    if ((result.get(leg.id) ?? []).length > 0) continue;
    const ref = leg.trade_record_id;
    if (!ref) continue;
    const byFill = settlement.filter((r) => r.fillId === ref && r.positionId !== ref && !claimed.has(r.id));
    if (byFill.length === 0) continue;
    for (const r of byFill) claimed.add(r.id);
    result.set(leg.id, byFill);
  }
  for (const leg of legs) {
    if ((result.get(leg.id) ?? []).length > 0) continue;
    const ref = leg.trade_record_id;
    if (!ref) continue;
    const byPosition = settlement.filter((r) => r.positionId === ref && !claimed.has(r.id));
    for (const r of byPosition) claimed.add(r.id);
    result.set(leg.id, byPosition);
  }
  return result;
}
function closingSettlementRecord(claimed) {
  if (claimed.length === 0) return null;
  return claimed.reduce((latest, r) => recordRecency2(r) > recordRecency2(latest) ? r : latest, claimed[0]);
}
function legExitPriceCorrectionDelta(claimed, correction) {
  const closing = closingSettlementRecord(claimed);
  if (!correction || !closing) return 0;
  const delta2 = buildTradeRecordPnlCorrection(closing, correction);
  return delta2 ? delta2.pnlDelta : 0;
}
function claimCampaignRecordsByLeg(legs, tradeRecords) {
  return claimRecordsByLeg(legs, tradeRecords);
}
function pnlFromEvents(campaign) {
  const seen = /* @__PURE__ */ new Set();
  let total = null;
  for (const event of campaign.actual_evolution ?? []) {
    const pnl = finite(event.realized_pnl);
    if (pnl == null || seen.has(event.id)) continue;
    seen.add(event.id);
    total = (total ?? 0) + pnl;
  }
  return total;
}
function computeCampaignRealizedPnl(campaign, legs, tradeRecords, exitPriceCorrections = {}) {
  const stored = finite(campaign.final_realized_pnl);
  const recordsByLeg = claimRecordsByLeg(legs, tradeRecords);
  const byLeg = /* @__PURE__ */ new Map();
  let fromRecords = 0;
  let fromSnapshots = 0;
  let total = null;
  for (const leg of legs) {
    const claimed = recordsByLeg.get(leg.id) ?? [];
    if (claimed.length > 0) {
      let sum = 0;
      for (const record of claimed) sum += finite(record.pnl) ?? 0;
      const correction = exitPriceCorrections[leg.id];
      if (correction) sum += legExitPriceCorrectionDelta(claimed, correction);
      byLeg.set(leg.id, sum);
      total = (total ?? 0) + sum;
      fromRecords += 1;
      continue;
    }
    const snapshot = finite(leg.post_realized_pnl);
    byLeg.set(leg.id, snapshot);
    if (snapshot != null) {
      total = (total ?? 0) + snapshot;
      fromSnapshots += 1;
    }
  }
  let basis;
  if (fromRecords > 0 && fromSnapshots > 0) {
    basis = "mixed";
  } else if (fromRecords > 0) {
    basis = "records";
  } else if (fromSnapshots > 0) {
    basis = "leg_snapshots";
  } else {
    total = pnlFromEvents(campaign);
    basis = total != null ? "events" : "none";
    if (total == null && stored != null) {
      total = stored;
      basis = "campaign_summary";
    }
  }
  const settled = campaign.comparison?.holdingMetrics?.status !== "open" && legs.length > 0 && legs.every((leg) => byLeg.get(leg.id) != null);
  return {
    total,
    byLeg,
    recordsByLeg,
    basis,
    settled,
    stored,
    drift: stored == null || total == null ? null : stored - total
  };
}
var init_campaignRealizedPnl = __esm({
  "src/lib/campaignRealizedPnl.ts"() {
    init_campaignLegExecution();
  }
});

// src/lib/campaignPrimaryMainLeg.ts
function toMs(value) {
  if (!value) return Number.MAX_SAFE_INTEGER;
  const ms = new Date(value).getTime();
  return Number.isFinite(ms) ? ms : Number.MAX_SAFE_INTEGER;
}
function legNotionalUsd(leg) {
  const size = leg.pre_position_size;
  return typeof size === "number" && Number.isFinite(size) && size > 0 ? size : null;
}
function pickPrimaryMainLeg(legs) {
  for (const role of PRIMARY_ROLES) {
    const candidates = legs.filter((leg) => leg.leg_role === role);
    if (candidates.length === 0) continue;
    return [...candidates].sort((a, b) => {
      const na = legNotionalUsd(a);
      const nb = legNotionalUsd(b);
      if (na != null && nb != null && na !== nb) return nb - na;
      if (na != null && nb == null) return -1;
      if (na == null && nb != null) return 1;
      return toMs(a.pre_simulated_time) - toMs(b.pre_simulated_time);
    })[0] ?? null;
  }
  return null;
}
var PRIMARY_ROLES;
var init_campaignPrimaryMainLeg = __esm({
  "src/lib/campaignPrimaryMainLeg.ts"() {
    PRIMARY_ROLES = ["main_open", "reentry_main"];
  }
});

// src/lib/campaignReverseOrderAttribution.ts
function sequence(leg) {
  return leg.leg_sequence ?? Number.MAX_SAFE_INTEGER;
}
function isMainLeg(leg) {
  return leg.leg_role === "main_open" || leg.leg_role === "reentry_main" || Boolean(leg.leg_role?.startsWith("main_add_")) || leg.order_kind === "main" && leg.leg_role !== "mirror_tp";
}
function timeMs(value) {
  if (value == null) return null;
  const result = typeof value === "number" ? value : new Date(value).getTime();
  return Number.isFinite(result) && result > 0 ? result : null;
}
function defaultWindow(leg) {
  return {
    openMs: timeMs(leg.pre_simulated_time),
    // 没有记录可查时只能开口朝右。宁可宽，也不要凭空造一个平仓时刻。
    closeMs: timeMs(leg.post_simulated_close_time)
  };
}
function windowContains(w, t) {
  if (w.openMs == null) return false;
  if (t < w.openMs - PRE_MAIN_LOOKBACK_MS) return false;
  return w.closeMs == null || t < w.closeMs;
}
function createMainLegOwnerResolver(legs, options = {}) {
  const windowFor = options.legWindow ?? defaultWindow;
  const tieBreak = options.tieBreak ?? "size";
  const orderedMainLegs = legs.filter(isMainLeg).sort((a, b) => sequence(a) - sequence(b));
  const windows2 = new Map(orderedMainLegs.map((leg) => [leg.id, windowFor(leg)]));
  const fallbackOwner = pickPrimaryMainLeg(orderedMainLegs) ?? orderedMainLegs[0] ?? null;
  return (createdAtMs) => {
    const t = timeMs(createdAtMs);
    if (t == null) return fallbackOwner;
    const containing = orderedMainLegs.filter((leg) => windowContains(windows2.get(leg.id), t));
    if (containing.length > 0) {
      if (tieBreak === "nearest-open") {
        return [...containing].sort((a, b) => {
          const da = Math.abs((windows2.get(a.id).openMs ?? Number.MAX_SAFE_INTEGER) - t);
          const db = Math.abs((windows2.get(b.id).openMs ?? Number.MAX_SAFE_INTEGER) - t);
          if (da !== db) return da - db;
          return sequence(a) - sequence(b);
        })[0];
      }
      return pickPrimaryMainLeg(containing) ?? containing[0];
    }
    const forward = orderedMainLegs.map((leg) => ({ leg, open: windows2.get(leg.id).openMs })).filter((x) => x.open != null && x.open > t).sort((a, b) => a.open - b.open)[0];
    if (forward) return forward.leg;
    const backward = orderedMainLegs.map((leg) => ({ leg, close: windows2.get(leg.id).closeMs })).filter((x) => x.close != null && x.close <= t).sort((a, b) => b.close - a.close)[0];
    if (backward) return backward.leg;
    return fallbackOwner;
  };
}
var PRE_MAIN_LOOKBACK_MS;
var init_campaignReverseOrderAttribution = __esm({
  "src/lib/campaignReverseOrderAttribution.ts"() {
    init_campaignPrimaryMainLeg();
    init_campaignLegExecution();
    PRE_MAIN_LOOKBACK_MS = 5 * 6e4;
  }
});

// src/lib/unblendMainEntry.ts
function unblendMainEntryPriceByNotional(input) {
  const { blendedEntryPrice: E, totalNotionalUsd: N } = input;
  const adds = (input.adds ?? []).filter((a) => positive(a.entryPrice) && positive(a.notionalUsd));
  if (adds.length === 0) return { ok: false, reason: "no-adds" };
  if (!positive(E) || !positive(N)) return { ok: false, reason: "invalid-input" };
  const addNotional = adds.reduce((s, a) => s + a.notionalUsd, 0);
  const mainNotional = N - addNotional;
  if (!(mainNotional > N * 1e-9)) return { ok: false, reason: "adds-exceed" };
  const mainSize = N / E - adds.reduce((s, a) => s + a.notionalUsd / a.entryPrice, 0);
  const entryPrice = mainNotional / mainSize;
  if (!positive(mainSize) || !positive(entryPrice)) return { ok: false, reason: "not-blended" };
  return { ok: true, entryPrice, mainUnits: mainSize, addUnits: N / E - mainSize };
}
var positive;
var init_unblendMainEntry = __esm({
  "src/lib/unblendMainEntry.ts"() {
    positive = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
  }
});

// src/lib/campaignMainEntryUnblend.ts
function resolveUnblendedMainEntry(input) {
  if (input.recordFillId) return { ok: false, reason: "already-per-fill" };
  const adds = (input.mergedSiblings ?? []).filter((a) => positive2(a.entryPrice) && positive2(a.notionalUsd));
  if (adds.length === 0) return { ok: false, reason: "no-adds" };
  if (!positive2(input.mainNotionalUsd)) return { ok: false, reason: "main-size-unknown" };
  if (!positive2(input.blendedEntryPrice) || !positive2(input.totalNotionalUsd)) {
    return { ok: false, reason: "not-a-merge" };
  }
  const addNotional = adds.reduce((s, a) => s + a.notionalUsd, 0);
  const expected = input.mainNotionalUsd + addNotional;
  const drift = Math.abs(input.totalNotionalUsd - expected) / input.totalNotionalUsd;
  if (!(drift <= MERGE_TOLERANCE)) return { ok: false, reason: "not-a-merge" };
  const solved = unblendMainEntryPriceByNotional({
    blendedEntryPrice: input.blendedEntryPrice,
    totalNotionalUsd: input.totalNotionalUsd,
    adds: adds.map((a) => ({ entryPrice: a.entryPrice, notionalUsd: a.notionalUsd }))
  });
  if (!solved.ok) return { ok: false, reason: "unsolvable" };
  const prices = [input.blendedEntryPrice, ...adds.map((a) => a.entryPrice)];
  const lo = Math.min(...prices) * 0.5;
  const hi = Math.max(...prices) * 2;
  if (!(solved.entryPrice >= lo && solved.entryPrice <= hi)) {
    return { ok: false, reason: "unsolvable" };
  }
  return { ok: true, entryPrice: solved.entryPrice, mainNotionalUsd: input.totalNotionalUsd - addNotional };
}
var MERGE_TOLERANCE, positive2;
var init_campaignMainEntryUnblend = __esm({
  "src/lib/campaignMainEntryUnblend.ts"() {
    init_unblendMainEntry();
    MERGE_TOLERANCE = 0.02;
    positive2 = (v) => typeof v === "number" && Number.isFinite(v) && v > 0;
  }
});

// src/lib/campaignAnalysis.ts
function findTradeRecord(leg, tradeRecords) {
  if (!leg.trade_record_id) return null;
  return buildTradeRecordLookup(tradeRecords).get(leg.trade_record_id) ?? null;
}
function tradeRecordNotionalUsd(record, price = record.entryPrice) {
  return getPositionNotionalUsd(record.symbol, record, price || record.entryPrice);
}
function unblendedMainEntryPrice(campaign, mainLeg, mainRecord, legs, tradeRecords) {
  if (mainRecord == null || !positiveOrNull(mainRecord.entryPrice)) return null;
  const mainDirection = campaignMainDirection(campaign);
  const siblings = legs.filter((leg) => leg.id !== mainLeg?.id).filter((leg) => leg.leg_role === "mirror_tp" || leg.leg_role != null && String(leg.leg_role).startsWith("main_add")).filter((leg) => leg.direction == null || leg.direction === mainDirection).filter((leg) => {
    const rec = findTradeRecord(leg, tradeRecords);
    return rec == null || rec.positionId == null || rec.positionId === mainRecord.positionId;
  }).map((leg) => {
    const rec = findTradeRecord(leg, tradeRecords);
    const own = rec != null && rec.id !== mainRecord.id ? rec : null;
    const entryPrice = firstPositiveNumber(leg.pre_entry_price, own?.entryPrice);
    const notionalUsd = firstPositiveNumber(
      leg.pre_position_size,
      own ? tradeRecordNotionalUsd(own, own.entryPrice) : null
    );
    return entryPrice != null && notionalUsd != null ? { entryPrice, notionalUsd } : null;
  }).filter((x) => x != null);
  const solved = resolveUnblendedMainEntry({
    blendedEntryPrice: mainRecord.entryPrice,
    totalNotionalUsd: tradeRecordNotionalUsd(mainRecord, mainRecord.entryPrice),
    recordFillId: mainRecord.fillId ?? null,
    mainNotionalUsd: firstPositiveNumber(mainLeg?.pre_position_size, campaign.initial_main_size_usdt),
    mergedSiblings: siblings
  });
  return solved.ok ? solved.entryPrice : null;
}
function positiveOrNull(v) {
  return typeof v === "number" && Number.isFinite(v) && v > 0;
}
function settlementSlicesFor(ref, settlement) {
  const exact = settlement.filter((r) => r.id === ref);
  if (exact.length > 0) {
    const fills = new Set(exact.map((r) => r.fillId).filter((x) => Boolean(x)));
    return fills.size > 0 ? settlement.filter((r) => r.id === ref || r.fillId != null && fills.has(r.fillId)) : exact;
  }
  const byFill = settlement.filter((r) => r.fillId === ref);
  if (byFill.length > 0) return byFill;
  return settlement.filter((r) => r.positionId === ref);
}
function openingNotionalUsd(ref, settlement) {
  if (!ref) return null;
  const slices = settlementSlicesFor(ref, settlement);
  if (slices.length === 0) return null;
  const total = slices.reduce((sum, r) => sum + tradeRecordNotionalUsd(r, r.entryPrice), 0);
  return total > EPSILON ? total : null;
}
function groupLegsByOpeningFill(initialLegs, settlement) {
  const groups = [];
  for (const leg of initialLegs) {
    const slices = leg.trade_record_id ? settlementSlicesFor(leg.trade_record_id, settlement) : [];
    const hits = groups.filter((group) => slices.some((slice) => group.slices.has(slice.id)));
    const target = hits[0] ?? { legs: [], slices: /* @__PURE__ */ new Map() };
    if (hits.length === 0) groups.push(target);
    for (const extra of hits.slice(1)) {
      target.legs.push(...extra.legs);
      for (const [id2, slice] of extra.slices) target.slices.set(id2, slice);
      groups.splice(groups.indexOf(extra), 1);
    }
    target.legs.push(leg);
    for (const slice of slices) target.slices.set(slice.id, slice);
  }
  return groups.map((group) => {
    const total = Array.from(group.slices.values()).reduce((sum, record) => sum + tradeRecordNotionalUsd(record, record.entryPrice), 0);
    return {
      legs: group.legs,
      notional: total > EPSILON ? total : null,
      sliceIds: new Set(group.slices.keys())
    };
  });
}
function groupOwnerLeg(group) {
  return group.legs.find((leg) => leg.leg_role === "main_open") ?? group.legs[0];
}
function settlementRecordsOf(tradeRecords) {
  return tradeRecords.filter((r) => r.action !== "FUNDING");
}
function firstPositiveNumber(...values) {
  const value = values.find((candidate) => Number.isFinite(candidate) && Number(candidate) > EPSILON);
  return value == null ? null : Number(value);
}
function uniquePrices(prices, limit = INITIAL_HEDGE_ROLES.length) {
  const result = [];
  for (const price of prices) {
    const duplicate = result.some(
      (existing) => Math.abs(existing - price) <= Math.max(EPSILON, Math.abs(existing) * 1e-6)
    );
    if (!duplicate) result.push(price);
    if (result.length >= limit) break;
  }
  return result;
}
function resolveInitialReverseHedgePrices(campaign, reverseHedgeOrders, mainOpenedAt, roleHedgePrices) {
  const expectedSide = campaign.direction === "main_long" ? "SHORT" : "LONG";
  const eligibleOrders = [...reverseHedgeOrders].filter((order) => order.side === expectedSide && firstPositiveNumber(order.price) != null).sort((a, b) => a.createdAt - b.createdAt);
  if (eligibleOrders.length === 0) return [];
  const initialOrderIds = new Set(
    (campaign.actual_evolution ?? []).filter(
      (event) => event.pending_order_id != null && event.leg_role != null && INITIAL_HEDGE_ROLES.includes(event.leg_role)
    ).map((event) => event.pending_order_id)
  );
  const roleMatchedPrices = eligibleOrders.filter((order) => initialOrderIds.has(order.id)).map((order) => order.price);
  if (roleMatchedPrices.length > 0) return uniquePrices(roleMatchedPrices);
  const cohortStart = mainOpenedAt == null ? eligibleOrders[0].createdAt : mainOpenedAt - INITIAL_REVERSE_ORDER_COHORT_MS;
  const cohortEnd = mainOpenedAt == null ? eligibleOrders[0].createdAt + INITIAL_REVERSE_ORDER_COHORT_MS : mainOpenedAt + INITIAL_REVERSE_ORDER_COHORT_MS;
  const openingCohortPrices = uniquePrices(
    eligibleOrders.filter((order) => order.createdAt >= cohortStart && order.createdAt <= cohortEnd).map((order) => order.price)
  );
  if (openingCohortPrices.length > 0) return openingCohortPrices;
  const fillMatchedPrices = eligibleOrders.filter((order) => {
    const fillPrice = firstPositiveNumber(order.fillPrice);
    if (fillPrice == null) return false;
    return roleHedgePrices.some(
      (rolePrice) => Math.abs(rolePrice - fillPrice) <= Math.max(EPSILON, Math.abs(rolePrice) * 1e-6)
    );
  }).map((order) => order.price);
  if (fillMatchedPrices.length > 0) return uniquePrices(fillMatchedPrices);
  if (roleHedgePrices.length === 0) {
    const legacyCohortEnd = eligibleOrders[0].createdAt + INITIAL_REVERSE_ORDER_COHORT_MS;
    return uniquePrices(
      eligibleOrders.filter((order) => order.createdAt <= legacyCohortEnd).map((order) => order.price)
    );
  }
  return [];
}
function findInitialMainLeg(legs) {
  return pickPrimaryMainLeg(legs.filter((leg) => leg.leg_role === "main_open"));
}
function campaignMainDirection(campaign) {
  return campaign.direction === "main_short" ? "short" : "long";
}
function isInitialMainExposurePosition(campaign, role, direction) {
  if (role == null || !INITIAL_MAIN_EXPOSURE_ROLES.includes(role)) return false;
  if (direction === "long" || direction === "short") {
    return direction === campaignMainDirection(campaign);
  }
  return true;
}
function resolvedRecordIdentity(record) {
  return record ? `record:${record.id}` : null;
}
function positionIdentityAliases(record, recordReference, journalId, fallback) {
  const keys = [
    resolvedRecordIdentity(record),
    recordReference ? `record-ref:${recordReference}` : null,
    // 记录自带的 id 也要登记：腿按 ref 找到它、事件按 record.id 找到它，两边要能对上。
    record?.id ? `record-ref:${record.id}` : null,
    journalId ? `journal:${journalId}` : null
  ].filter((k) => Boolean(k));
  return keys.length > 0 ? keys : [fallback];
}
function sameNotional(a, b) {
  return Math.abs(a - b) <= Math.max(1, Math.abs(a) * NOTIONAL_MATCH_TOLERANCE);
}
function claimPosition(claimed, aliases, role, notional, allowContentMatch) {
  const existingById = claimed.find((item) => aliases.some((key) => item.aliases.has(key)));
  if (existingById) {
    for (const key of aliases) existingById.aliases.add(key);
    return false;
  }
  if (allowContentMatch && role) {
    const existingByShape = claimed.find((item) => item.role === role && sameNotional(item.notional, notional));
    if (existingByShape) {
      for (const key of aliases) existingByShape.aliases.add(key);
      return false;
    }
  }
  claimed.push({ aliases: new Set(aliases), role: role ?? "", notional });
  return true;
}
function resolveInitialMainExposureNotional(campaign, legs, tradeRecords, mainLeg, mainRecord, mainEvent) {
  const recordLookup = buildTradeRecordLookup(tradeRecords);
  const settlement = settlementRecordsOf(tradeRecords);
  const collect = (entries, role) => entries.filter((item) => item.role === role).reduce((sum, item) => sum + item.notional, 0);
  const initialExposureLegs = legs.filter((leg) => isInitialMainExposurePosition(campaign, leg.leg_role, leg.direction));
  const legEntries = [];
  const rolesCoveredByLegs = /* @__PURE__ */ new Set();
  const sliceIdsCountedByLegs = /* @__PURE__ */ new Set();
  for (const group of groupLegsByOpeningFill(initialExposureLegs, settlement)) {
    const owner = groupOwnerLeg(group);
    const notional = group.notional ?? firstPositiveNumber(...group.legs.map((leg) => leg.pre_position_size));
    if (notional == null || !owner.leg_role) continue;
    for (const leg of group.legs) if (leg.leg_role) rolesCoveredByLegs.add(leg.leg_role);
    for (const sliceId of group.sliceIds) sliceIdsCountedByLegs.add(sliceId);
    legEntries.push({ role: owner.leg_role, notional });
  }
  const eventClaimed = [];
  const eventEntries = [];
  for (const event of [...campaign.actual_evolution ?? []].sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp))) {
    if (!POSITION_ENTRY_EVENT_TYPES.has(event.event_type)) continue;
    if (!isInitialMainExposurePosition(campaign, event.leg_role, event.direction)) continue;
    if (event.trade_record_id && sliceIdsCountedByLegs.has(event.trade_record_id)) continue;
    const record = event.trade_record_id ? recordLookup.get(event.trade_record_id) ?? null : null;
    const notional = firstPositiveNumber(
      record ? tradeRecordNotionalUsd(record, record.entryPrice) : null,
      event.size_usdt
    );
    if (notional == null || !event.leg_role) continue;
    const aliases = positionIdentityAliases(
      record,
      event.trade_record_id,
      event.journal_id,
      `event:${event.id}`
    );
    if (!claimPosition(eventClaimed, aliases, event.leg_role, notional, true)) continue;
    eventEntries.push({ role: event.leg_role, notional });
  }
  let total = 0;
  for (const role of INITIAL_MAIN_EXPOSURE_ROLES) {
    total += rolesCoveredByLegs.has(role) ? collect(legEntries, role) : collect(eventEntries, role);
  }
  const mainRole = mainLeg?.leg_role ?? "main_open";
  const hasMain = collect(legEntries, mainRole) > EPSILON || collect(eventEntries, mainRole) > EPSILON;
  if (!hasMain) {
    const fallback = firstPositiveNumber(
      openingNotionalUsd(mainLeg?.trade_record_id, settlement),
      mainLeg?.pre_position_size,
      mainEvent?.size_usdt,
      mainRecord ? tradeRecordNotionalUsd(mainRecord, mainRecord.entryPrice) : null,
      campaign.initial_main_size_usdt
    );
    if (fallback != null) total += fallback;
  }
  return total > EPSILON ? total : null;
}
function groupInitialMainExposure(campaign, legs, tradeRecords, mainLegs, ownerAt) {
  const recordLookup = buildTradeRecordLookup(tradeRecords);
  const settlement = settlementRecordsOf(tradeRecords);
  const claimed = [];
  const groups = /* @__PURE__ */ new Map();
  const earliestKey = mainLegs[0]?.id ?? null;
  const add = (ownerId, notional) => {
    const key = ownerId ?? earliestKey;
    if (key == null) return;
    groups.set(key, (groups.get(key) ?? 0) + notional);
  };
  const initialExposureLegs = legs.filter((leg) => isInitialMainExposurePosition(campaign, leg.leg_role, leg.direction));
  const rolesWithLegs = /* @__PURE__ */ new Set();
  const sliceIdsCountedByLegs = /* @__PURE__ */ new Set();
  for (const group of groupLegsByOpeningFill(initialExposureLegs, settlement)) {
    const ownerLeg = groupOwnerLeg(group);
    const notional = group.notional ?? firstPositiveNumber(...group.legs.map((leg) => leg.pre_position_size));
    if (notional == null || !ownerLeg.leg_role) continue;
    for (const leg of group.legs) if (leg.leg_role) rolesWithLegs.add(leg.leg_role);
    for (const sliceId of group.sliceIds) sliceIdsCountedByLegs.add(sliceId);
    const record = ownerLeg.trade_record_id ? recordLookup.get(ownerLeg.trade_record_id) ?? null : null;
    const owner = ownerLeg.leg_role === "main_open" ? ownerLeg : ownerAt(firstPositiveNumber(record?.openTime, toMs2(ownerLeg.pre_simulated_time)));
    add(owner?.id ?? null, notional);
  }
  for (const event of [...campaign.actual_evolution ?? []].sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp))) {
    if (!POSITION_ENTRY_EVENT_TYPES.has(event.event_type)) continue;
    if (!isInitialMainExposurePosition(campaign, event.leg_role, event.direction)) continue;
    if (!event.leg_role || rolesWithLegs.has(event.leg_role)) continue;
    if (event.trade_record_id && sliceIdsCountedByLegs.has(event.trade_record_id)) continue;
    const record = event.trade_record_id ? recordLookup.get(event.trade_record_id) ?? null : null;
    const notional = firstPositiveNumber(
      record ? tradeRecordNotionalUsd(record, record.entryPrice) : null,
      event.size_usdt
    );
    if (notional == null) continue;
    if (!claimPosition(
      claimed,
      positionIdentityAliases(record, event.trade_record_id, event.journal_id, `event:${event.id}`),
      event.leg_role,
      notional,
      true
    )) continue;
    const owner = ownerAt(firstPositiveNumber(record?.openTime, toMs2(event.timestamp)));
    add(owner?.id ?? null, notional);
  }
  const earliest = mainLegs[0];
  if (earliest && !(groups.get(earliest.id) ?? 0)) {
    const fallback = firstPositiveNumber(campaign.initial_main_size_usdt);
    if (fallback != null) groups.set(earliest.id, fallback);
  }
  return groups;
}
function computeInitialMainExposureNotional(campaign, legs, tradeRecords) {
  const mainLeg = findInitialMainLeg(legs);
  const mainRecord = mainLeg ? findTradeRecord(mainLeg, tradeRecords) : null;
  const mainEvent = (campaign.actual_evolution ?? []).find(
    (event) => event.leg_role === "main_open" && firstPositiveNumber(event.entry_price, event.price) != null
  ) ?? null;
  return resolveInitialMainExposureNotional(
    campaign,
    legs,
    tradeRecords,
    mainLeg,
    mainRecord,
    mainEvent
  ) ?? 0;
}
function resolveInitialExposureLegAttribution(campaign, legs, tradeRecords) {
  const settlement = settlementRecordsOf(tradeRecords);
  const shares = /* @__PURE__ */ new Map();
  const excludedLegIds = /* @__PURE__ */ new Set();
  const initialExposureLegs = [];
  for (const leg of legs) {
    if (isInitialMainExposurePosition(campaign, leg.leg_role, leg.direction)) initialExposureLegs.push(leg);
    else if (leg.leg_role != null && INITIAL_MAIN_EXPOSURE_ROLES.includes(leg.leg_role)) excludedLegIds.add(leg.id);
  }
  groupLegsByOpeningFill(initialExposureLegs, settlement).forEach((group, index) => {
    if (group.notional == null) return;
    const weights = group.legs.map((leg) => openingNotionalUsd(leg.trade_record_id, settlement) ?? 0);
    const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
    group.legs.forEach((leg, legIndex) => {
      const notional = group.notional;
      shares.set(leg.id, {
        notionalUsd: group.legs.length === 1 ? notional : totalWeight > EPSILON ? notional * weights[legIndex] / totalWeight : notional / group.legs.length,
        groupKey: `exposure-group-${index + 1}`,
        groupSize: group.legs.length
      });
    });
  });
  return { shares, excludedLegIds };
}
function resolveInitialRiskAnchor(campaign, legs, tradeRecords, reverseHedgeOrders = []) {
  const mainLeg = findInitialMainLeg(legs);
  const mainRecord = mainLeg ? findTradeRecord(mainLeg, tradeRecords) : null;
  const mainEvent = (campaign.actual_evolution ?? []).find(
    (event) => event.leg_role === "main_open" && firstPositiveNumber(event.entry_price, event.price) != null
  ) ?? null;
  const entryPrice = firstPositiveNumber(
    unblendedMainEntryPrice(campaign, mainLeg, mainRecord, legs, tradeRecords),
    mainRecord?.entryPrice,
    mainLeg?.pre_entry_price,
    mainEvent?.entry_price,
    mainEvent?.price
  );
  const initialMainExposureNotional = resolveInitialMainExposureNotional(
    campaign,
    legs,
    tradeRecords,
    mainLeg,
    mainRecord,
    mainEvent
  );
  if (entryPrice == null || initialMainExposureNotional == null) return null;
  const historical = isHistoricalCampaign(campaign);
  const roleHedgePrices = INITIAL_HEDGE_ROLES.flatMap((role) => {
    const roleLegs = legs.filter((leg) => leg.leg_role === role).sort((a, b) => toMs2(a.pre_simulated_time) - toMs2(b.pre_simulated_time));
    const plannedLeg = roleLegs.find((leg) => firstPositiveNumber(leg.pre_entry_price) != null) ?? null;
    const plannedPrice = firstPositiveNumber(plannedLeg?.pre_entry_price);
    if (plannedPrice != null) return [plannedPrice];
    const recordLeg = roleLegs.find((leg) => findTradeRecord(leg, tradeRecords) != null) ?? null;
    const recordPrice = recordLeg ? firstPositiveNumber(findTradeRecord(recordLeg, tradeRecords)?.entryPrice) : null;
    if (recordPrice != null) return [recordPrice];
    const event = (campaign.actual_evolution ?? []).filter((item) => item.leg_role === role).sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp)).find((item) => firstPositiveNumber(item.entry_price, item.price) != null);
    const eventPrice = firstPositiveNumber(event?.entry_price, event?.price);
    return eventPrice == null ? [] : [eventPrice];
  });
  const mainOpenedAt = firstPositiveNumber(
    mainRecord?.openTime,
    mainLeg ? toMs2(mainLeg.pre_simulated_time) : null,
    mainEvent ? toMs2(mainEvent.timestamp) : null,
    toMs2(campaign.opened_at)
  );
  const initialReversePrices = resolveInitialReverseHedgePrices(
    campaign,
    reverseHedgeOrders,
    mainOpenedAt,
    roleHedgePrices
  );
  const hedgePrices = historical && initialReversePrices.length > 0 ? [...initialReversePrices] : [...roleHedgePrices];
  if (hedgePrices.length < INITIAL_HEDGE_ROLES.length && !historical) {
    for (const price of initialReversePrices) {
      const duplicate = hedgePrices.some(
        (existing) => Math.abs(existing - price) <= Math.max(EPSILON, Math.abs(existing) * 1e-6)
      );
      if (!duplicate) hedgePrices.push(price);
      if (hedgePrices.length >= INITIAL_HEDGE_ROLES.length) break;
    }
  }
  if (hedgePrices.length === 0) return null;
  return {
    initialMainExposureNotional,
    entryPrice,
    stopPrice: campaign.direction === "main_long" ? hedgePrices.filter((price) => price < entryPrice).sort((a, b) => a - b)[0] ?? null : hedgePrices.filter((price) => price > entryPrice).sort((a, b) => b - a)[0] ?? null,
    drawdownFraction: Math.max(...hedgePrices.map((price) => Math.abs(price - entryPrice) / entryPrice))
  };
}
function computeInitialExpectedMaxDrawdownPct(campaign, legs, tradeRecords, reverseHedgeOrders = []) {
  const risk = resolveMainRiskAnchors(campaign, legs, tradeRecords, reverseHedgeOrders);
  if (risk.fullExposureNotional <= EPSILON) return 0;
  return risk.expectedMaxLoss / risk.fullExposureNotional * 100;
}
function resolveMainRiskAnchors(campaign, legs, tradeRecords, reverseHedgeOrders = []) {
  const paperRisk = qualityCampaignStaticRisk(campaign);
  if (!paperRisk && (campaign.comparison?.sellEvidence?.selectedL0Pct !== void 0 || campaign.comparison?.sellEvidence?.dbl5SellerRiskPctV1 !== void 0)) {
    const exposure = campaign.comparison.holdingMetrics?.initialNotional ?? campaign.initial_main_size_usdt;
    return { anchors: [], expectedMaxLoss: 0, anchoredExposureNotional: 0, unanchoredExposureNotional: exposure, fullExposureNotional: exposure };
  }
  if (paperRisk) return { anchors: [{ mainLegId: legs.find((l) => l.leg_role === "main_open")?.id ?? legs[0]?.id ?? "", entryPrice: paperRisk.entry, stopPrice: paperRisk.stop, exposureNotional: paperRisk.notional, drawdownFraction: paperRisk.percent / 100, expectedMaxLoss: paperRisk.loss }], expectedMaxLoss: paperRisk.loss, anchoredExposureNotional: paperRisk.notional, unanchoredExposureNotional: 0, fullExposureNotional: paperRisk.notional };
  const mainLegs = legs.filter((leg) => leg.leg_role === "main_open").sort((a, b) => toMs2(a.pre_simulated_time) - toMs2(b.pre_simulated_time));
  if (mainLegs.length <= 1) {
    const anchor = resolveInitialRiskAnchor(campaign, legs, tradeRecords, reverseHedgeOrders);
    if (anchor == null) {
      return {
        anchors: [],
        expectedMaxLoss: 0,
        anchoredExposureNotional: 0,
        unanchoredExposureNotional: 0,
        fullExposureNotional: 0
      };
    }
    return {
      anchors: [{
        mainLegId: mainLegs[0]?.id ?? "",
        entryPrice: anchor.entryPrice,
        stopPrice: anchor.stopPrice,
        exposureNotional: anchor.initialMainExposureNotional,
        drawdownFraction: anchor.drawdownFraction,
        expectedMaxLoss: anchor.drawdownFraction * anchor.initialMainExposureNotional
      }],
      expectedMaxLoss: anchor.drawdownFraction * anchor.initialMainExposureNotional,
      anchoredExposureNotional: anchor.initialMainExposureNotional,
      unanchoredExposureNotional: 0,
      fullExposureNotional: anchor.initialMainExposureNotional
    };
  }
  const legWindow = (leg) => {
    const rec = findTradeRecord(leg, tradeRecords);
    const exec = resolveLegExecution(leg, rec);
    return { openMs: exec.openTime ?? null, closeMs: exec.closeTime ?? null };
  };
  const ownerForOrder = createMainLegOwnerResolver(legs, { legWindow });
  const ownerForLeg = createMainLegOwnerResolver(legs, { legWindow, tieBreak: "nearest-open" });
  const exposureByMain = groupInitialMainExposure(campaign, legs, tradeRecords, mainLegs, ownerForLeg);
  const historical = isHistoricalCampaign(campaign);
  const expectedSide = campaign.direction === "main_long" ? "SHORT" : "LONG";
  const anchors = [];
  for (const [index, mainLeg] of mainLegs.entries()) {
    const mainRecord = findTradeRecord(mainLeg, tradeRecords);
    const mainEvent = (campaign.actual_evolution ?? []).filter((event) => event.leg_role === "main_open").filter((event) => event.journal_id === mainLeg.id || ownerForLeg(toMs2(event.timestamp))?.id === mainLeg.id).sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp)).find((event) => firstPositiveNumber(event.entry_price, event.price) != null) ?? null;
    const entryPrice = firstPositiveNumber(
      unblendedMainEntryPrice(campaign, mainLeg, mainRecord, legs, tradeRecords),
      mainRecord?.entryPrice,
      mainLeg.pre_entry_price,
      mainEvent?.entry_price,
      mainEvent?.price
    );
    const exposureNotional = exposureByMain.get(mainLeg.id) ?? 0;
    const openedAtMs = firstPositiveNumber(
      mainRecord?.openTime,
      toMs2(mainLeg.pre_simulated_time),
      mainEvent ? toMs2(mainEvent.timestamp) : null,
      // campaign.opened_at 只对**最早**那笔主力有意义
      index === 0 ? toMs2(campaign.opened_at) : null
    );
    const ownOrders = reverseHedgeOrders.filter(
      (order) => order.side === expectedSide && ownerForOrder(order.createdAt)?.id === mainLeg.id
    );
    const roleHedgePrices = INITIAL_HEDGE_ROLES.flatMap((role) => {
      const roleLegs = legs.filter((leg) => leg.leg_role === role).filter((leg) => ownerForLeg(firstPositiveNumber(
        findTradeRecord(leg, tradeRecords)?.openTime,
        toMs2(leg.pre_simulated_time)
      ))?.id === mainLeg.id).sort((a, b) => toMs2(a.pre_simulated_time) - toMs2(b.pre_simulated_time));
      const plannedPrice = firstPositiveNumber(
        roleLegs.find((leg) => firstPositiveNumber(leg.pre_entry_price) != null)?.pre_entry_price
      );
      if (plannedPrice != null) return [plannedPrice];
      const recordLeg = roleLegs.find((leg) => findTradeRecord(leg, tradeRecords) != null) ?? null;
      const recordPrice = recordLeg ? firstPositiveNumber(findTradeRecord(recordLeg, tradeRecords)?.entryPrice) : null;
      if (recordPrice != null) return [recordPrice];
      const event = (campaign.actual_evolution ?? []).filter((item) => item.leg_role === role).filter((item) => ownerForLeg(toMs2(item.timestamp))?.id === mainLeg.id).sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp)).find((item) => firstPositiveNumber(item.entry_price, item.price) != null);
      const eventPrice = firstPositiveNumber(event?.entry_price, event?.price);
      return eventPrice == null ? [] : [eventPrice];
    });
    const initialReversePrices = resolveInitialReverseHedgePrices(
      campaign,
      ownOrders,
      openedAtMs,
      roleHedgePrices
    );
    const hedgePrices = historical && initialReversePrices.length > 0 ? [...initialReversePrices] : [...roleHedgePrices];
    if (hedgePrices.length < INITIAL_HEDGE_ROLES.length && !historical) {
      for (const price of initialReversePrices) {
        const duplicate = hedgePrices.some((existing) => Math.abs(existing - price) <= Math.max(EPSILON, Math.abs(existing) * 1e-6));
        if (!duplicate) hedgePrices.push(price);
        if (hedgePrices.length >= INITIAL_HEDGE_ROLES.length) break;
      }
    }
    const lossSideFractions = entryPrice != null ? hedgePrices.map((price) => (campaign.direction === "main_long" ? entryPrice - price : price - entryPrice) / entryPrice).filter((fraction) => fraction > 0) : [];
    const resolvable = entryPrice != null && exposureNotional > EPSILON && lossSideFractions.length > 0;
    const drawdownFraction = resolvable ? Math.max(...lossSideFractions) : null;
    anchors.push({
      mainLegId: mainLeg.id,
      entryPrice: entryPrice ?? void 0,
      stopPrice: drawdownFraction == null || entryPrice == null ? null : campaign.direction === "main_long" ? Math.min(...hedgePrices.filter((price) => price < entryPrice)) : Math.max(...hedgePrices.filter((price) => price > entryPrice)),
      exposureNotional,
      drawdownFraction,
      // 锚不出来就记 0,绝不借用别的腿的跌幅——那等于凭空发明一条从未挂过的止损。
      expectedMaxLoss: drawdownFraction == null ? 0 : drawdownFraction * exposureNotional
    });
  }
  const anchoredExposureNotional = anchors.filter((a) => a.drawdownFraction != null).reduce((sum, a) => sum + a.exposureNotional, 0);
  const expectedMaxLoss = anchors.reduce((sum, a) => sum + a.expectedMaxLoss, 0);
  const fullExposure = computeInitialMainExposureNotional(campaign, legs, tradeRecords);
  const unanchoredExposureNotional = Math.max(0, fullExposure - anchoredExposureNotional);
  return {
    anchors,
    expectedMaxLoss,
    anchoredExposureNotional,
    unanchoredExposureNotional,
    fullExposureNotional: fullExposure
  };
}
function computeInitialExpectedMaxLoss(campaign, legs, tradeRecords, reverseHedgeOrders = []) {
  return resolveMainRiskAnchors(campaign, legs, tradeRecords, reverseHedgeOrders).expectedMaxLoss;
}
function eventTradeRecord(event, tradeRecords, journalRecordIds) {
  const recordId = event.trade_record_id ?? (event.journal_id ? journalRecordIds.get(event.journal_id) ?? null : null);
  if (!recordId) return null;
  return buildTradeRecordLookup(tradeRecords).get(recordId) ?? null;
}
function isCanonicalSyntheticEvent(event, leg) {
  if (!leg?.leg_role) return false;
  if (leg.leg_role === "mirror_tp") return event.event_type === "mirror_tp_triggered";
  if (HEDGE_ROLES.includes(leg.leg_role)) return event.event_type === "hedge_triggered";
  if (MAIN_ROLES.includes(leg.leg_role)) {
    return event.event_type === "main_partial_closed" || event.event_type === "main_fully_closed";
  }
  return false;
}
function normalizeEventSnapshotFromRecord(event, record) {
  const openIso = toIso(record.openTime);
  const closeIso = toIso(record.closeTime);
  const next = {
    ...event,
    trade_record_id: record.id,
    direction: record.side === "SHORT" ? "short" : "long",
    leverage: record.leverage,
    open_time: openIso,
    close_time: closeIso,
    entry_price: record.entryPrice,
    exit_price: record.exitPrice,
    realized_pnl: record.pnl
  };
  if (event.event_type === "main_partial_closed" || event.event_type === "main_fully_closed" || event.event_type === "mirror_tp_triggered") {
    next.timestamp = closeIso;
    next.price = record.exitPrice;
    next.size_usdt = tradeRecordNotionalUsd(record, record.exitPrice);
  } else if (event.event_type === "hedge_triggered") {
    next.timestamp = openIso;
    next.price = record.entryPrice;
    next.size_usdt = tradeRecordNotionalUsd(record, record.entryPrice);
  }
  if (next.timeline_id == null) {
    const isCloseEvent = event.event_type === "main_partial_closed" || event.event_type === "main_fully_closed" || event.event_type === "mirror_tp_triggered";
    const timelineId = isCloseEvent ? record.closedTimelineId : event.event_type === "hedge_triggered" ? record.openedTimelineId : record.openedTimelineId ?? record.closedTimelineId;
    if (timelineId) next.timeline_id = timelineId;
  }
  return next;
}
function buildCampaignEventStream(campaign, legs, tradeRecords) {
  if (isQualityCampaignId(campaign.id) && campaign.comparison?.sellEvidence?.mirrorFill) {
    const events2 = (campaign.actual_evolution ?? []).map((event) => ({ ...event }));
    if (campaign.closed_at && !events2.some((event) => event.event_type === "campaign_closed")) events2.push({
      id: `synthetic-${campaign.id}-closed`,
      timestamp: campaign.closed_at,
      event_type: "campaign_closed",
      leg_role: null,
      journal_id: null,
      trade_record_id: null,
      pending_order_id: null,
      price: null,
      size_usdt: null,
      notes: campaign.notes,
      recorded_at: campaign.closed_at
    });
    return events2.sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp));
  }
  const legByJournalId = new Map(legs.map((leg) => [leg.id, leg]));
  const legByRecordId = new Map(
    legs.filter((leg) => Boolean(leg.trade_record_id)).map((leg) => [leg.trade_record_id, leg])
  );
  const journalRecordIds = new Map(
    legs.filter((leg) => Boolean(leg.trade_record_id)).map((leg) => [leg.id, leg.trade_record_id])
  );
  const events = [...campaign.actual_evolution ?? []].flatMap((event) => {
    const record = eventTradeRecord(event, tradeRecords, journalRecordIds);
    if (!record) return [{ ...event }];
    const leg = (event.journal_id ? legByJournalId.get(event.journal_id) : void 0) ?? legByRecordId.get(record.id) ?? null;
    const normalized = normalizeEventSnapshotFromRecord(event, record);
    return isCanonicalSyntheticEvent(normalized, leg) ? [] : [normalized];
  });
  for (const leg of legs) {
    const tradeRecord = findTradeRecord(leg, tradeRecords);
    if (!tradeRecord) continue;
    if (leg.leg_role === "mirror_tp") {
      events.push({
        id: `synthetic-${leg.id}-mirror-tp`,
        timestamp: new Date(tradeRecord.closeTime).toISOString(),
        event_type: "mirror_tp_triggered",
        leg_role: leg.leg_role,
        journal_id: leg.id,
        trade_record_id: tradeRecord.id,
        pending_order_id: null,
        price: tradeRecord.exitPrice,
        size_usdt: tradeRecordNotionalUsd(tradeRecord, tradeRecord.exitPrice),
        notes: null,
        recorded_at: new Date(tradeRecord.closeTime).toISOString(),
        ...tradeRecord.closedTimelineId ? { timeline_id: tradeRecord.closedTimelineId } : {}
      });
      continue;
    }
    if (leg.leg_role && HEDGE_ROLES.includes(leg.leg_role)) {
      events.push({
        id: `synthetic-${leg.id}-hedge-triggered`,
        timestamp: new Date(tradeRecord.openTime).toISOString(),
        event_type: "hedge_triggered",
        leg_role: leg.leg_role,
        journal_id: leg.id,
        trade_record_id: tradeRecord.id,
        pending_order_id: null,
        price: tradeRecord.entryPrice,
        size_usdt: tradeRecordNotionalUsd(tradeRecord, tradeRecord.entryPrice),
        notes: null,
        recorded_at: new Date(tradeRecord.openTime).toISOString(),
        ...tradeRecord.openedTimelineId ? { timeline_id: tradeRecord.openedTimelineId } : {}
      });
      continue;
    }
    if (leg.leg_role && MAIN_ROLES.includes(leg.leg_role)) {
      const mainSize = leg.pre_position_size ?? tradeRecordNotionalUsd(tradeRecord, tradeRecord.entryPrice);
      const closedNotional = tradeRecordNotionalUsd(tradeRecord, tradeRecord.exitPrice);
      const isPartial = mainSize > EPSILON && closedNotional < mainSize * 0.95;
      events.push({
        id: `synthetic-${leg.id}-${isPartial ? "main-partial" : "main-full"}`,
        timestamp: new Date(tradeRecord.closeTime).toISOString(),
        event_type: isPartial ? "main_partial_closed" : "main_fully_closed",
        leg_role: leg.leg_role,
        journal_id: leg.id,
        trade_record_id: tradeRecord.id,
        pending_order_id: null,
        price: tradeRecord.exitPrice,
        size_usdt: closedNotional,
        notes: null,
        recorded_at: new Date(tradeRecord.closeTime).toISOString(),
        ...tradeRecord.closedTimelineId ? { timeline_id: tradeRecord.closedTimelineId } : {}
      });
    }
  }
  if (campaign.closed_at && !events.some((event) => event.event_type === "campaign_closed")) {
    events.push({
      id: `synthetic-${campaign.id}-closed`,
      timestamp: campaign.closed_at,
      event_type: "campaign_closed",
      leg_role: null,
      journal_id: null,
      trade_record_id: null,
      pending_order_id: null,
      price: null,
      size_usdt: null,
      notes: campaign.notes ?? null,
      recorded_at: campaign.closed_at
    });
  }
  return events.sort((a, b) => toMs2(a.timestamp) - toMs2(b.timestamp));
}
function campaignEndMs(campaign, tradeRecords) {
  const latestRecord = tradeRecords.reduce((max, record) => Math.max(max, record.closeTime, record.openTime), 0);
  const valuedAt = isQualityCampaignId(campaign.id) || campaign.comparison?.instant?.openPosition ? campaign.comparison?.valuedAt ?? 0 : 0;
  return campaign.closed_at ? toMs2(campaign.closed_at) : Math.max(latestRecord, toMs2(campaign.opened_at), valuedAt);
}
function recordActiveLeg(leg, record, endMs, realizedPnl) {
  return {
    id: record.id,
    journalId: leg.id,
    role: leg.leg_role,
    side: record.side,
    quantity: record.quantity,
    entryPrice: record.entryPrice,
    startMs: record.openTime,
    endMs: record.closeTime || endMs,
    realizedPnl,
    settlementMode: record.settlementMode ?? "usdt",
    contractSizeUsd: Number.isFinite(record.contractSizeUsd) ? Number(record.contractSizeUsd) : null,
    contracts: Number.isFinite(record.contracts) ? Number(record.contracts) : null,
    // 逐仓爆仓的那一片按它自己结算掉的那笔钱封顶（各片相加 = −整仓保证金）；
    // 全仓强平与普通平仓为 null，与此前逐字节相同。
    pnlFloorUsd: liquidationPnlFloorUsd(record),
    ...record.closeTime ? {} : { endIsCampaignEnd: true }
  };
}
function recordActiveLegs(leg, lookupRecord, claimed, endMs, exitPriceCorrections) {
  const correction = exitPriceCorrections[leg.id];
  const pnlOf = (record, delta3) => {
    if (!Number.isFinite(record.pnl)) return null;
    return correction ? Number(record.pnl) + delta3 : Number(record.pnl);
  };
  if (claimed.length === 0) {
    return [recordActiveLeg(leg, lookupRecord, endMs, pnlOf(lookupRecord, 0))];
  }
  const closing = closingSettlementRecord(claimed);
  const delta2 = correction ? legExitPriceCorrectionDelta(claimed, correction) : 0;
  return claimed.map((record) => recordActiveLeg(leg, record, endMs, pnlOf(record, record === closing ? delta2 : 0)));
}
function buildActiveLegs(campaign, legs, tradeRecords, exitPriceCorrections = {}, unfilledOrderIds = NO_UNFILLED_ORDER_IDS) {
  const recordedEndMs = campaignEndMs(campaign, tradeRecords);
  const activeLegs = buildActiveLegsUntil(campaign, legs, tradeRecords, exitPriceCorrections, unfilledOrderIds, recordedEndMs);
  if (!campaign.closed_at) return { activeLegs, endMs: recordedEndMs };
  let latestClose = Number.NEGATIVE_INFINITY;
  for (const leg of activeLegs) {
    if (!leg.endIsCampaignEnd && Number.isFinite(leg.endMs)) latestClose = Math.max(latestClose, leg.endMs);
  }
  for (const record of tradeRecords) {
    if (record.action !== "FUNDING" && Number.isFinite(record.closeTime) && record.closeTime > 0) {
      latestClose = Math.max(latestClose, record.closeTime);
    }
  }
  if (!(latestClose > recordedEndMs)) return { activeLegs, endMs: recordedEndMs };
  return {
    activeLegs: activeLegs.map((leg) => leg.endIsCampaignEnd ? { ...leg, endMs: latestClose } : leg),
    endMs: latestClose
  };
}
function buildActiveLegsUntil(campaign, legs, tradeRecords, exitPriceCorrections, unfilledOrderIds, endMs) {
  const syntheticEvents = buildCampaignEventStream(campaign, legs, tradeRecords);
  const claimedByLeg = claimCampaignRecordsByLeg(legs, tradeRecords);
  const claimOwner = /* @__PURE__ */ new Map();
  for (const [legId, records] of claimedByLeg) {
    for (const record of records) claimOwner.set(record.id, legId);
  }
  const placeholders = /* @__PURE__ */ new Set();
  const candidates = legs.flatMap((leg) => {
    const record = findTradeRecord(leg, tradeRecords);
    if (record) {
      const claimed = claimedByLeg.get(leg.id) ?? [];
      const owner = claimOwner.get(record.id);
      if (claimed.length === 0 && owner != null && owner !== leg.id) {
        const placeholder = recordActiveLeg(leg, record, endMs, Number.isFinite(record.pnl) ? Number(record.pnl) : null);
        placeholders.add(placeholder);
        return [placeholder];
      }
      const slices = recordActiveLegs(leg, record, claimed, endMs, exitPriceCorrections);
      const instant = campaign.comparison?.instant?.openPosition;
      if (instant && !campaign.closed_at && leg.leg_role?.startsWith("main_") && leg.pre_entry_price && leg.pre_position_size) {
        const sold = claimed.reduce((total, trade) => total + (trade.action === "CLOSE" ? trade.quantity : 0), 0);
        const remaining = leg.pre_position_size / leg.pre_entry_price - sold;
        if (remaining > 1e-9) slices.push({
          id: `${leg.id}-remaining`,
          journalId: leg.id,
          role: leg.leg_role,
          side: "LONG",
          quantity: remaining,
          entryPrice: leg.pre_entry_price,
          startMs: toMs2(leg.pre_simulated_time),
          endMs,
          realizedPnl: null,
          settlementMode: "usdt",
          contractSizeUsd: null,
          contracts: null,
          endIsCampaignEnd: true
        });
      }
      const fill = campaign.comparison?.sellEvidence?.mirrorFill;
      if (isQualityCampaignId(campaign.id) && !campaign.closed_at && fill && fill.fraction < 1 && leg.leg_role === "main_open" && leg.pre_entry_price != null && leg.pre_entry_price > 0 && leg.pre_position_size != null) {
        slices.push({
          id: `${leg.id}-remaining`,
          journalId: leg.id,
          role: leg.leg_role,
          side: "LONG",
          quantity: leg.pre_position_size / leg.pre_entry_price * (1 - fill.fraction),
          entryPrice: leg.pre_entry_price,
          startMs: toMs2(leg.pre_simulated_time),
          endMs,
          realizedPnl: null,
          settlementMode: "usdt",
          contractSizeUsd: null,
          contracts: null,
          endIsCampaignEnd: true
        });
      }
      return slices;
    }
    if (leg.leg_role && (MAIN_ROLES.includes(leg.leg_role) || leg.leg_role === "mirror_tp") && leg.pre_entry_price != null && leg.pre_position_size != null) {
      const closeMs = leg.post_simulated_close_time ? toMs2(leg.post_simulated_close_time) : endMs;
      const settlementMode = leg.pre_settlement_mode ?? "usdt";
      const contracts = Number.isFinite(leg.pre_contracts) ? Number(leg.pre_contracts) : null;
      return [{
        id: `open-${leg.id}`,
        journalId: leg.id,
        role: leg.leg_role,
        side: leg.direction === "short" ? "SHORT" : "LONG",
        quantity: settlementMode === "coin" && contracts != null ? contracts : leg.pre_position_size / leg.pre_entry_price,
        entryPrice: leg.pre_entry_price,
        startMs: toMs2(leg.pre_simulated_time),
        endMs: Number.isFinite(closeMs) ? closeMs : endMs,
        realizedPnl: Number.isFinite(leg.post_realized_pnl) ? Number(leg.post_realized_pnl) : null,
        settlementMode,
        contractSizeUsd: Number.isFinite(leg.pre_contract_size_usd) ? Number(leg.pre_contract_size_usd) : null,
        contracts,
        rebuiltFrom: "snapshot",
        endIsCampaignEnd: !Number.isFinite(closeMs) || !leg.post_simulated_close_time
      }];
    }
    if (leg.leg_role && HEDGE_ROLES.includes(leg.leg_role) && leg.pre_entry_price != null && leg.pre_position_size != null) {
      const triggerEvent = syntheticEvents.find(
        (event) => event.journal_id === leg.id && event.event_type === "hedge_triggered"
      );
      if (!triggerEvent) return [];
      const side = campaign.direction === "main_long" ? "SHORT" : "LONG";
      const cancelEvent = syntheticEvents.find(
        (event) => event.journal_id === leg.id && event.event_type === "hedge_cancelled" && toMs2(event.timestamp) >= toMs2(triggerEvent.timestamp)
      );
      const closeMs = leg.post_simulated_close_time ? toMs2(leg.post_simulated_close_time) : cancelEvent ? toMs2(cancelEvent.timestamp) : endMs;
      const settlementMode = leg.pre_settlement_mode ?? "usdt";
      const contracts = Number.isFinite(leg.pre_contracts) ? Number(leg.pre_contracts) : null;
      return [{
        id: `synthetic-hedge-${leg.id}`,
        journalId: leg.id,
        role: leg.leg_role,
        side,
        quantity: settlementMode === "coin" && contracts != null ? contracts : leg.pre_position_size / leg.pre_entry_price,
        entryPrice: leg.pre_entry_price,
        startMs: toMs2(triggerEvent.timestamp),
        endMs: Number.isFinite(closeMs) ? closeMs : endMs,
        realizedPnl: Number.isFinite(leg.post_realized_pnl) ? Number(leg.post_realized_pnl) : null,
        settlementMode,
        contractSizeUsd: Number.isFinite(leg.pre_contract_size_usd) ? Number(leg.pre_contract_size_usd) : null,
        contracts,
        rebuiltFrom: "trigger",
        endIsCampaignEnd: !Number.isFinite(closeMs) || !leg.post_simulated_close_time && !cancelEvent
      }];
    }
    return [];
  });
  const byIdentity = /* @__PURE__ */ new Map();
  for (const candidate of candidates) {
    if (placeholders.has(candidate) && byIdentity.has(candidate.id)) continue;
    byIdentity.set(candidate.id, candidate);
  }
  const representedJournalIds = new Set(candidates.map((leg) => leg.journalId));
  const representedRecordIds = new Set(candidates.map((leg) => leg.id));
  const legById = new Map(legs.map((leg) => [leg.id, leg]));
  const unrepresentedLegByRecordId = /* @__PURE__ */ new Map();
  for (const leg of legs) {
    if (!leg.trade_record_id) continue;
    if (representedJournalIds.has(leg.id)) representedRecordIds.add(leg.trade_record_id);
    else if (!unrepresentedLegByRecordId.has(leg.trade_record_id)) unrepresentedLegByRecordId.set(leg.trade_record_id, leg);
  }
  for (const event of syntheticEvents) {
    if (event.event_type !== "historical_leg_attached" || event.leg_role == null) continue;
    if (event.journal_id && representedJournalIds.has(event.journal_id)) continue;
    if (event.trade_record_id && representedRecordIds.has(event.trade_record_id)) continue;
    const filledId = Boolean(event.trade_record_id) && !unfilledOrderIds.has(event.trade_record_id);
    if (!filledId && !Number.isFinite(event.realized_pnl)) continue;
    const entryPrice = firstPositiveNumber(event.entry_price, event.price);
    const notional = firstPositiveNumber(event.size_usdt);
    const start = event.open_time ? toMs2(event.open_time) : toMs2(event.timestamp);
    const ownerLeg = (event.journal_id ? legById.get(event.journal_id) : void 0) ?? (event.trade_record_id ? unrepresentedLegByRecordId.get(event.trade_record_id) : void 0);
    const legCloseMs = ownerLeg?.post_simulated_close_time ? toMs2(ownerLeg.post_simulated_close_time) : Number.NaN;
    const legRealized = ownerLeg != null && Number.isFinite(ownerLeg.post_realized_pnl) ? Number(ownerLeg.post_realized_pnl) : null;
    const close = Number.isFinite(legCloseMs) ? legCloseMs : event.close_time ? toMs2(event.close_time) : endMs;
    if (entryPrice == null || notional == null || !Number.isFinite(start)) continue;
    const identity2 = event.trade_record_id ?? event.journal_id ?? event.id;
    const fallbackSide = HEDGE_ROLES.includes(event.leg_role) || event.leg_role === "reentry_hedge" ? campaign.direction === "main_long" ? "SHORT" : "LONG" : campaign.direction === "main_long" ? "LONG" : "SHORT";
    byIdentity.set(identity2, {
      id: identity2,
      journalId: ownerLeg?.id ?? event.journal_id ?? event.id,
      role: event.leg_role,
      side: event.direction === "short" ? "SHORT" : event.direction === "long" ? "LONG" : fallbackSide,
      quantity: notional / entryPrice,
      entryPrice,
      startMs: start,
      endMs: Number.isFinite(close) ? close : endMs,
      realizedPnl: legRealized ?? (Number.isFinite(event.realized_pnl) ? Number(event.realized_pnl) : null),
      settlementMode: "usdt",
      contractSizeUsd: null,
      contracts: null,
      rebuiltFrom: "event",
      endIsCampaignEnd: !Number.isFinite(legCloseMs) && !event.close_time || !Number.isFinite(close)
    });
  }
  return Array.from(byIdentity.values());
}
function resolveCampaignEquityPathLegFacts(campaign, legs, tradeRecords, localOrders = {}) {
  const unfilledOrderIds = localOrders.unfilledOrderIds ?? NO_UNFILLED_ORDER_IDS;
  const heldStartMsByLeg = /* @__PURE__ */ new Map();
  const heldWithoutRecordByLeg = /* @__PURE__ */ new Map();
  const path = buildActiveLegs(campaign, legs, tradeRecords, {}, unfilledOrderIds);
  for (const active of path.activeLegs) {
    const current = heldStartMsByLeg.get(active.journalId);
    if (current == null || active.startMs < current) heldStartMsByLeg.set(active.journalId, active.startMs);
    if (active.rebuiltFrom) {
      heldWithoutRecordByLeg.set(active.journalId, {
        endMs: active.endIsCampaignEnd ? null : active.endMs,
        eventFill: active.rebuiltFrom === "event" ? { entryPrice: active.entryPrice, quantity: active.quantity } : null
      });
    }
  }
  const unfilledLegIds = /* @__PURE__ */ new Set();
  const offPathLegIds = /* @__PURE__ */ new Set();
  for (const leg of legs) {
    if (heldStartMsByLeg.has(leg.id)) continue;
    const filledId = Boolean(leg.trade_record_id) && !unfilledOrderIds.has(leg.trade_record_id);
    if (filledId || Number.isFinite(leg.post_realized_pnl)) offPathLegIds.add(leg.id);
    else unfilledLegIds.add(leg.id);
  }
  return { heldStartMsByLeg, heldWithoutRecordByLeg, unfilledLegIds, offPathLegIds, analysisEndMs: path.endMs };
}
var HEDGE_ROLES, INITIAL_HEDGE_ROLES, MAIN_ROLES, INITIAL_MAIN_EXPOSURE_ROLES, POSITION_ENTRY_EVENT_TYPES, EPSILON, INITIAL_REVERSE_ORDER_COHORT_MS, toMs2, toIso, NOTIONAL_MATCH_TOLERANCE, NO_UNFILLED_ORDER_IDS;
var init_campaignAnalysis = __esm({
  "src/lib/campaignAnalysis.ts"() {
    init_qualityCampaignRisk();
    init_campaignSections();
    init_strategyTemplates();
    init_campaignLegExecution();
    init_tradingSettlement();
    init_liquidationRecord();
    init_objectiveOperationTime();
    init_campaignLegExecution();
    init_journal();
    init_campaignRealizedPnl();
    init_campaignPrimaryMainLeg();
    init_campaignReverseOrderAttribution();
    init_campaignMainEntryUnblend();
    HEDGE_ROLES = ["hedge_initial_a", "hedge_initial_b", "hedge_rolling"];
    INITIAL_HEDGE_ROLES = ["hedge_initial_a", "hedge_initial_b"];
    MAIN_ROLES = ["main_open", ...MAIN_ADD_ROLES, "reentry_main"];
    INITIAL_MAIN_EXPOSURE_ROLES = ["main_open", "mirror_tp"];
    POSITION_ENTRY_EVENT_TYPES = /* @__PURE__ */ new Set([
      "historical_leg_attached",
      "main_opened",
      "mirror_tp_placed"
    ]);
    EPSILON = 1e-4;
    INITIAL_REVERSE_ORDER_COHORT_MS = 5 * 60 * 1e3;
    toMs2 = (value) => new Date(value).getTime();
    toIso = (value) => new Date(value).toISOString();
    NOTIONAL_MATCH_TOLERANCE = 1e-3;
    NO_UNFILLED_ORDER_IDS = /* @__PURE__ */ new Set();
  }
});

// src/lib/addSizing.ts
function fin(v) {
  return typeof v === "number" && Number.isFinite(v);
}
function attributeAddExcess(args) {
  const { plan, fillPrice, coinsAt, limitAt, fitsAt } = args;
  if (![plan.s2Ref, plan.s2Fill, fillPrice].every((v) => fin(v) && v > 0)) return null;
  const planOrderPrice = plan.orderKind === "limit" ? plan.s2Fill : plan.s2Ref;
  const orderPrice = fin(plan.s2AtOrder) && plan.s2AtOrder > 0 ? plan.s2AtOrder : planOrderPrice;
  const anchorPrice = orderPrice * (plan.s2Fill / planOrderPrice);
  const coinsAtPlan = coinsAt(plan.s2Fill);
  const limitAtPlan = limitAt(plan.s2Fill);
  const plannedMax = fin(plan.addCoinsMax) && plan.addCoinsMax > 0 ? plan.addCoinsMax : null;
  const withinPlanLimit = plannedMax != null ? coinsAtPlan <= plannedMax * (1 + 1e-6) : fitsAt(plan.s2Fill);
  let cause;
  if (fitsAt(anchorPrice)) cause = withinPlanLimit ? "slippage" : "oversize";
  else if (fitsAt(plan.s2Fill)) cause = "price_drift";
  else if (plannedMax != null && withinPlanLimit) cause = "inputs";
  else cause = "oversize";
  const overshootBase = plannedMax ?? limitAtPlan;
  return {
    cause,
    planOrderPrice,
    planPrice: plan.s2Fill,
    orderPrice,
    anchorPrice,
    fillPrice,
    priceDriftPct: (orderPrice / planOrderPrice - 1) * 100,
    fillSlippagePct: (fillPrice / orderPrice - 1) * 100,
    unexpectedSlippagePct: (fillPrice / anchorPrice - 1) * 100,
    planOvershootPct: overshootBase > 0 ? (coinsAtPlan / overshootBase - 1) * 100 : Number.POSITIVE_INFINITY,
    limitAtAnchor: limitAt(anchorPrice),
    limitAtPlan,
    coinsAtPlan,
    withinPlanLimit
  };
}
function evaluatePostAddCostLine(args) {
  const { side, sBar, s1, s2, x1, addCoins } = args;
  if (![s1, s2, addCoins].every((v) => fin(v) && v > 0)) return null;
  if (!fin(x1) || x1 < 0 || x1 > 0 && !(fin(sBar) && sBar > 0)) return null;
  const total = x1 + addCoins;
  if (!(total > 0)) return null;
  const blendedCost = ((x1 > 0 ? x1 * sBar : 0) + addCoins * s2) / total;
  const d = side === "SHORT" ? -1 : 1;
  const overshoot = (blendedCost - s1) * d;
  return {
    blendedCost,
    pastStop: overshoot > 0,
    overshootPct: overshoot > 0 ? overshoot / s1 * 100 : 0
  };
}
var init_addSizing = __esm({
  "src/lib/addSizing.ts"() {
    init_trading();
    init_coinMargined();
    init_tradingSettlement();
  }
});

// src/lib/addPositionCoverage.ts
function calculateAddRiskBudget(oldCushion, bankedProfit, riskPerCoin) {
  if (![oldCushion, bankedProfit, riskPerCoin].every(Number.isFinite) || riskPerCoin <= 0) return null;
  const available = oldCushion + bankedProfit;
  const oldLoss = Math.max(0, -oldCushion);
  const baseCoins = Math.max(0, oldCushion + Math.min(0, bankedProfit)) / riskPerCoin;
  const bankedCoins = Math.max(0, bankedProfit - oldLoss) / riskPerCoin;
  return {
    available,
    oldLoss,
    shortfall: Math.max(0, -available),
    baseCoins,
    bankedCoins,
    maxAddCoins: baseCoins + bankedCoins
  };
}
var init_addPositionCoverage = __esm({
  "src/lib/addPositionCoverage.ts"() {
  }
});

// src/lib/campaignAddSizingCheck.ts
function isMainSideRole(role) {
  return role === "main_open" || role === "reentry_main" || role === "mirror_tp" || (role ?? "").startsWith("main_add_");
}
function isHedgeRole(role) {
  return (role ?? "").startsWith("hedge_") || role === "reentry_hedge";
}
function positive3(value) {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}
function finite2(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function realTime(value) {
  const time = finite2(value);
  return time != null && time > 0 ? time : null;
}
function sequence2(leg) {
  return leg.leg_sequence ?? Number.MAX_SAFE_INTEGER;
}
function recordRecency3(record) {
  return record.closeTime || record.openTime || 0;
}
function orderEnd(order) {
  if (order.status === "triggered") return order.triggeredAt ?? order.cancelledAt ?? null;
  return order.cancelledAt ?? null;
}
function unknown(reason, partial = {}) {
  return {
    s1: null,
    s2: null,
    x1Coins: null,
    x2Coins: null,
    cushion: null,
    banked: null,
    hedgeBanked: null,
    consumedByHeld: null,
    maxLoss: null,
    required: null,
    riskPerCoin: null,
    maxAllowedCoins: null,
    maxAllowedNotional: null,
    shortfall: null,
    blendedCost: null,
    costLineShortfall: null,
    snapshot: null,
    snapshotLimitAtRef: null,
    fillSlippagePct: null,
    slippageOvershootPct: null,
    excess: null,
    withinSnapshotLimit: null,
    ...partial,
    status: "unknown",
    reason
  };
}
function buildLedger(leg, execution, records, snapshotUsd, corrections) {
  const open = execution.openTime;
  const recordOpenTimes = records.map((record) => realTime(record.openedRealAt));
  const openOperationTime = records.length > 0 && recordOpenTimes.every((time) => time != null) ? Math.min(...recordOpenTimes) : journalOpenOperationTime(leg);
  const entry = execution.entryPrice;
  const coins = positive3(entry) && positive3(leg.pre_position_size) ? leg.pre_position_size / entry : null;
  const journalClose = resolveLegExecution(leg, null, corrections).closeTime;
  if (records.length === 0) {
    const close = execution.closeTime;
    return {
      leg,
      positionIds: [],
      open,
      openOperationTime,
      entry,
      coins,
      journalClose,
      cuts: close == null ? [] : [{
        time: close,
        positionId: null,
        operationTime: journalCloseOperationTime(leg),
        coins,
        usd: snapshotUsd
      }]
    };
  }
  const correction = corrections[leg.id];
  const closing = records.reduce((latest, r) => recordRecency3(r) > recordRecency3(latest) ? r : latest, records[0]);
  const cuts = records.map((record) => {
    const coinSettled = (record.settlementMode ?? leg.pre_settlement_mode) === "coin";
    const sized = coinSettled && !record.settlementMode ? { ...record, settlementMode: "coin" } : record;
    const closedCoins = positive3(record.entryPrice) ? tradeRecordNotionalAt(sized) / record.entryPrice : null;
    let usd = finite2(record.pnl);
    const delta2 = correction && record === closing ? buildTradeRecordPnlCorrection(sized, correction) : null;
    if (delta2 && usd != null) usd += delta2.pnlDelta;
    return {
      time: record.closeTime,
      positionId: record.positionId ?? null,
      operationTime: realTime(record.closedRealAt),
      coins: finite2(closedCoins),
      usd
    };
  }).sort((a, b) => a.time - b.time);
  return { leg, positionIds: [...new Set(records.map((record) => record.positionId).filter((id2) => !!id2))], open, openOperationTime, entry, coins, cuts, journalClose };
}
function cutClosedBy(cut, t, operationTime) {
  return cut.time <= t && !(operationTime != null && cut.operationTime != null && cut.operationTime > operationTime);
}
function closedCoinsBy(ledger, t, operationTime) {
  let sum = 0;
  for (const cut of ledger.cuts) {
    if (cut.time > t) break;
    if (!cutClosedBy(cut, t, operationTime)) continue;
    if (cut.coins == null) return null;
    sum += cut.coins;
  }
  return sum;
}
function closedBy(ledger, t, operationTime) {
  if (ledger.cuts.length === 0 || ledger.cuts.some((cut) => !cutClosedBy(cut, t, operationTime))) return false;
  if (ledger.journalClose != null && ledger.journalClose <= t) return true;
  const closed = closedCoinsBy(ledger, t, operationTime);
  if (ledger.coins == null || closed == null) return true;
  return ledger.coins - closed <= ledger.coins * CLOSED_DUST_RATIO;
}
function resolveStopLine(orders, hedgeSide, t, s2, d) {
  const candidates = orders.filter((order) => {
    if (order.side !== hedgeSide || !Number.isFinite(order.createdAt)) return false;
    if (!positive3(order.price) || (s2 - order.price) * d <= 0) return false;
    if (order.createdAt > t) return order.createdAt <= t + PRE_MAIN_LOOKBACK_MS;
    const end = orderEnd(order);
    return end == null || end > t;
  });
  if (candidates.length === 0) return null;
  return candidates.reduce((best, order) => (order.price - best) * d > 0 ? order.price : best, candidates[0].price);
}
function evaluateCampaignAddSizing(input) {
  const { legs, tradeRecords } = input;
  const corrections = input.legExitPriceCorrections ?? {};
  const orders = input.reverseHedgeOrders ?? [];
  const result = /* @__PURE__ */ new Map();
  const addLegs = legs.filter((leg) => (leg.leg_role ?? "").startsWith("main_add_"));
  if (addLegs.length === 0) return result;
  const recordMap = buildTradeRecordLookup(tradeRecords);
  const settlement = computeCampaignRealizedPnl(
    { final_realized_pnl: null, actual_evolution: [] },
    legs,
    tradeRecords,
    corrections
  );
  const executions = new Map(legs.map((leg) => {
    const record = leg.trade_record_id ? recordMap.get(leg.trade_record_id) ?? null : null;
    return [leg.id, resolveLegExecution(leg, record, corrections)];
  }));
  const ledgers = new Map(legs.filter((leg) => isMainSideRole(leg.leg_role)).flatMap((leg) => {
    const records = settlement.recordsByLeg.get(leg.id) ?? [];
    const snapshotUsd = settlement.byLeg.get(leg.id) ?? null;
    if (leg.leg_role === "mirror_tp" && !leg.trade_record_id && records.length === 0 && snapshotUsd == null) return [];
    return [[leg.id, buildLedger(leg, executions.get(leg.id), records, snapshotUsd, corrections)]];
  }));
  const hedgeLedgers = legs.filter((leg) => isHedgeRole(leg.leg_role)).map((leg) => buildLedger(
    leg,
    executions.get(leg.id),
    settlement.recordsByLeg.get(leg.id) ?? [],
    settlement.byLeg.get(leg.id) ?? null,
    corrections
  ));
  for (const add of addLegs) {
    if (add.direction !== "long" && add.direction !== "short") {
      result.set(add.id, unknown("no_direction"));
      continue;
    }
    const d = add.direction === "short" ? -1 : 1;
    const execution = executions.get(add.id);
    const t = execution.openTime;
    const s2 = execution.entryPrice;
    if (t == null || !Number.isFinite(t)) {
      result.set(add.id, unknown("no_open_time"));
      continue;
    }
    if (!positive3(s2)) {
      result.set(add.id, unknown("no_entry_price"));
      continue;
    }
    if (!positive3(add.pre_position_size)) {
      result.set(add.id, unknown("no_position_size", { s2 }));
      continue;
    }
    const x2Coins = add.pre_position_size / s2;
    const paper = isPaperCampaignId(add.campaign_id ?? void 0), fill = paper ? add.quality_addition_fill : void 0;
    const support = fill?.sizing?.support;
    const frozenSupport = fill && fill.at === t && fill.price === s2 && positive3(support) ? support : null;
    const s1 = frozenSupport ?? resolveStopLine(orders, d > 0 ? "SHORT" : "LONG", t, s2, d);
    if (s1 == null) {
      result.set(add.id, unknown("no_stop_line", { s2, x2Coins }));
      continue;
    }
    const addOperationTime = paper ? null : realTime(execution.record?.openedRealAt) ?? journalOpenOperationTime(add);
    const sameSide = [...ledgers.values()].filter((ledger) => ledger.leg.id !== add.id && ledger.leg.direction === add.direction && !(addOperationTime != null && ledger.openOperationTime != null && ledger.openOperationTime > addOperationTime));
    let holdingStart = t;
    for (let extended = true; extended; ) {
      extended = false;
      for (const ledger of sameSide) {
        if (ledger.open != null && ledger.open < holdingStart && !closedBy(ledger, holdingStart, addOperationTime)) {
          holdingStart = ledger.open;
          extended = true;
        }
      }
    }
    const heldAtAdd = sameSide.filter((ledger) => {
      if (ledger.open == null) return false;
      const openedBefore = ledger.open < t || ledger.open === t && sequence2(ledger.leg) < sequence2(add);
      return openedBefore && !closedBy(ledger, t, addOperationTime);
    });
    const heldPositionIds = new Set(heldAtAdd.flatMap((ledger) => ledger.positionIds));
    const heldOperationTimes = heldAtAdd.map((ledger) => ledger.openOperationTime);
    const holdingStartOperation = heldOperationTimes.length > 0 && heldOperationTimes.every((time) => time != null) ? Math.min(...heldOperationTimes) : null;
    let x1Coins = 0;
    let cushion = 0;
    let costBasis = 0;
    let consumedByHeld = 0;
    let banked = 0;
    let incomplete = false;
    for (const ledger of sameSide) {
      for (const cut of ledger.cuts) {
        if (cut.time < holdingStart || !cutClosedBy(cut, t, addOperationTime)) continue;
        if (holdingStartOperation != null) {
          const samePosition = cut.positionId != null && heldPositionIds.has(cut.positionId);
          if (!samePosition && (cut.operationTime == null || cut.operationTime < holdingStartOperation)) continue;
        }
        if (cut.usd == null) incomplete = true;
        else banked += cut.usd;
      }
      if (ledger.open == null) {
        if (!closedBy(ledger, t, addOperationTime)) incomplete = true;
        continue;
      }
      const openedBefore = ledger.open < t || ledger.open === t && sequence2(ledger.leg) < sequence2(add);
      if (!openedBefore || closedBy(ledger, t, addOperationTime)) continue;
      const closed = closedCoinsBy(ledger, t, addOperationTime);
      if (!positive3(ledger.entry) || ledger.coins == null || closed == null) {
        incomplete = true;
        continue;
      }
      const coins = Math.max(0, ledger.coins - closed);
      const pnlAtS1 = coins * (s1 - ledger.entry) * d;
      x1Coins += coins;
      costBasis += coins * ledger.entry;
      cushion += pnlAtS1;
      consumedByHeld += Math.max(0, -pnlAtS1);
    }
    let hedgeBanked = 0;
    for (const ledger of hedgeLedgers) {
      if (ledger.leg.direction === add.direction) continue;
      for (const cut of ledger.cuts) {
        if (cut.time < holdingStart || !cutClosedBy(cut, t, addOperationTime)) continue;
        if (holdingStartOperation != null && (cut.operationTime == null || cut.operationTime < holdingStartOperation)) continue;
        if (cut.usd == null) incomplete = true;
        else {
          banked += cut.usd;
          hedgeBanked += cut.usd;
        }
      }
    }
    const frozen = fill && (fill.positionVersion === HOLDING_LEDGER_ADDITION_VERSION || fill.sizing?.profitFloor != null) && fill.at === t && fill.price === s2 ? fill.ledger : void 0;
    const frozenCoins = fill?.sizing?.coinsBefore;
    if (frozen && positive3(frozenCoins) && Number.isFinite(frozen.costBefore) && frozen.costBefore >= 0 && Number.isFinite(frozen.realizedBefore)) {
      x1Coins = frozenCoins;
      costBasis = frozen.costBefore;
      cushion = (x1Coins * s1 - costBasis) * d;
      banked = frozen.realizedBefore;
      hedgeBanked = 0;
      consumedByHeld = Math.max(0, -cushion);
      incomplete = false;
    }
    const riskPerCoin = Math.max(0, (s2 - s1) * d);
    const maxLoss = Math.max(0, x2Coins * riskPerCoin);
    const budget = calculateAddRiskBudget(cushion, banked, riskPerCoin);
    const required = budget?.available ?? Number.NaN;
    const maxAllowedCoins = budget?.maxAddCoins ?? null;
    const maxAllowedNotional = maxAllowedCoins == null ? null : maxAllowedCoins * s2;
    const post = evaluatePostAddCostLine({
      side: d > 0 ? "LONG" : "SHORT",
      sBar: x1Coins > 0 ? costBasis / x1Coins : Number.NaN,
      s1,
      s2,
      x1: x1Coins,
      addCoins: x2Coins
    });
    const blendedCost = post?.blendedCost ?? Number.NaN;
    const costLineGap = post ? (x1Coins + x2Coins) * (post.blendedCost - s1) * d - banked : Number.NaN;
    const tolerance = Math.max(0.01, 1e-6 * Math.max(Math.abs(required), maxLoss));
    const qualificationTolerance = tolerance + Math.max(0, required) * 0.01;
    const ledgerGap = maxLoss - required;
    const costLineShortfall = costLineGap > tolerance ? costLineGap : 0;
    const snapshot = execution.record?.addSizingSnapshot ?? null;
    const usableSnapshot = snapshot && snapshot.side === (d > 0 ? "LONG" : "SHORT") && positive3(snapshot.s2Ref) && positive3(snapshot.s2Fill) ? snapshot : null;
    const addCoinSettled = (execution.record?.settlementMode ?? add.pre_settlement_mode) === "coin";
    const coinsAt = (px) => addCoinSettled ? add.pre_position_size / px : x2Coins;
    const riskAt = (px) => Math.max(0, (px - s1) * d);
    const limitAt = (px) => riskAt(px) > 0 ? Math.max(0, required) / riskAt(px) : Number.POSITIVE_INFINITY;
    const fitsAt = (px) => coinsAt(px) * riskAt(px) - required <= tolerance;
    const snapshotRefRisk = usableSnapshot ? riskAt(usableSnapshot.s2Ref) : 0;
    const snapshotLimitAtRef = usableSnapshot && snapshotRefRisk > 0 ? Math.max(0, required) / snapshotRefRisk : null;
    const slippageOvershootPct = snapshotLimitAtRef != null && maxAllowedCoins != null && maxAllowedCoins > 0 ? (snapshotLimitAtRef / maxAllowedCoins - 1) * 100 : null;
    const failing = !(required >= maxLoss - tolerance);
    const excess = usableSnapshot && failing ? attributeAddExcess({ plan: usableSnapshot, fillPrice: s2, coinsAt, limitAt, fitsAt }) : null;
    const snapshotOrderPrice = usableSnapshot ? positive3(usableSnapshot.s2AtOrder) ? usableSnapshot.s2AtOrder : usableSnapshot.orderKind === "limit" ? usableSnapshot.s2Fill : usableSnapshot.s2Ref : null;
    const fillSlippagePct = snapshotOrderPrice != null ? (s2 / snapshotOrderPrice - 1) * 100 : null;
    const withinSnapshotLimit = usableSnapshot && failing ? excess?.cause === "slippage" : null;
    const partial = {
      s1,
      s2,
      x1Coins,
      x2Coins,
      cushion,
      banked,
      hedgeBanked,
      consumedByHeld,
      maxLoss,
      required,
      riskPerCoin,
      maxAllowedCoins,
      maxAllowedNotional,
      blendedCost,
      costLineShortfall,
      snapshot: usableSnapshot,
      snapshotLimitAtRef,
      fillSlippagePct,
      slippageOvershootPct,
      excess,
      withinSnapshotLimit
    };
    if (incomplete) {
      result.set(add.id, unknown("old_leg_incomplete", partial));
      continue;
    }
    if (![x1Coins, cushion, banked, consumedByHeld, maxLoss, required, riskPerCoin, maxAllowedCoins, maxAllowedNotional, blendedCost, costLineGap].every(Number.isFinite)) {
      result.set(add.id, unknown("non_finite", partial));
      continue;
    }
    if (!(Math.abs(ledgerGap - costLineGap) <= tolerance)) {
      result.set(add.id, unknown("self_check_mismatch", { ...partial, shortfall: ledgerGap > tolerance ? ledgerGap : 0 }));
      continue;
    }
    if (required >= maxLoss - qualificationTolerance) {
      const under = maxAllowedCoins != null && maxAllowedCoins > 0 && x2Coins < maxAllowedCoins * (1 - UNDER_ADD_TOLERANCE);
      result.set(add.id, { status: "ok", underAdded: under, ...partial, shortfall: ledgerGap > tolerance ? ledgerGap : 0 });
    } else {
      result.set(add.id, { status: "fail", ...partial, shortfall: ledgerGap });
    }
  }
  return result;
}
function resolveCampaignAddQuantitySteps(input) {
  const corrections = input.legExitPriceCorrections ?? {};
  const records = buildTradeRecordLookup(input.tradeRecords);
  const settlement = computeCampaignRealizedPnl({ final_realized_pnl: null, actual_evolution: [] }, input.legs, input.tradeRecords, corrections);
  const executions = new Map(input.legs.map((leg) => [leg.id, resolveLegExecution(leg, leg.trade_record_id ? records.get(leg.trade_record_id) ?? null : null, corrections)]));
  const ledgers = input.legs.filter((leg) => isMainSideRole(leg.leg_role)).flatMap((leg) => {
    const cuts = settlement.recordsByLeg.get(leg.id) ?? [];
    const snapshot = settlement.byLeg.get(leg.id) ?? null;
    if (leg.leg_role === "mirror_tp" && !leg.trade_record_id && !cuts.length && snapshot == null) return [];
    return [buildLedger(leg, executions.get(leg.id), cuts, snapshot, corrections)];
  });
  const openingCoins = (direction) => {
    const opening = ledgers.filter(({ leg }) => leg.direction === direction && (leg.leg_role === "main_open" || leg.leg_role === "mirror_tp"));
    if (!opening.length || opening.some((row) => row.open == null)) return null;
    const first = Math.min(...opening.map((row) => row.open));
    const batch = opening.filter((row) => row.open === first);
    if (!batch.some((row) => row.leg.leg_role === "main_open") || batch.some((row) => row.coins == null)) return null;
    return batch.reduce((sum, row) => sum + row.coins, 0);
  };
  return input.legs.filter((leg) => (leg.leg_role ?? "").startsWith("main_add_") && (!!leg.trade_record_id || leg.post_realized_pnl != null || !!leg.post_real_close_time || !!leg.post_simulated_close_time)).map((add) => {
    const execution = executions.get(add.id);
    const t = execution.openTime;
    const operation = realTime(execution.record?.openedRealAt) ?? journalOpenOperationTime(add);
    let beforeCoins = t == null ? null : 0;
    if (t != null) for (const ledger of ledgers) {
      if (ledger.leg.id === add.id || ledger.leg.direction !== add.direction) continue;
      if (operation != null && ledger.openOperationTime != null && ledger.openOperationTime > operation) continue;
      if (ledger.open == null) {
        if (!closedBy(ledger, t, operation)) beforeCoins = null;
        continue;
      }
      const earlier = ledger.open < t || ledger.open === t && sequence2(ledger.leg) < sequence2(add);
      if (!earlier || closedBy(ledger, t, operation)) continue;
      const closed = closedCoinsBy(ledger, t, operation);
      if (ledger.coins == null || closed == null) beforeCoins = null;
      else if (beforeCoins != null) beforeCoins += Math.max(0, ledger.coins - closed);
    }
    const fill = isPaperCampaignId(add.campaign_id ?? void 0) ? add.quality_addition_fill : void 0;
    if (fill && fill.at === t && fill.price === execution.entryPrice && fill.notional === add.pre_position_size && positive3(fill.quantity) && positive3(fill.sizing?.coinsBefore)) {
      beforeCoins = fill.sizing.coinsBefore;
    }
    return {
      legId: add.id,
      openTime: t ?? Number.NaN,
      initialCoins: openingCoins(add.direction),
      beforeCoins,
      addCoins: positive3(execution.entryPrice) && positive3(add.pre_position_size) ? add.pre_position_size / execution.entryPrice : null
    };
  }).sort((a, b) => a.openTime - b.openTime || sequence2(input.legs.find((leg) => leg.id === a.legId)) - sequence2(input.legs.find((leg) => leg.id === b.legId)));
}
var CLOSED_DUST_RATIO, UNDER_ADD_TOLERANCE;
var init_campaignAddSizingCheck = __esm({
  "src/lib/campaignAddSizingCheck.ts"() {
    init_campaignSections();
    init_qualityHoldingLedger();
    init_addSizing();
    init_addPositionCoverage();
    init_campaignLegExecution();
    init_campaignRealizedPnl();
    init_campaignReverseOrderAttribution();
    init_objectiveOperationTime();
    CLOSED_DUST_RATIO = 0.01;
    UNDER_ADD_TOLERANCE = 0.01;
  }
});

// src/lib/campaignLegPhases.ts
var MIN_VISIBLE_PHASE_DURATION_MS;
var init_campaignLegPhases = __esm({
  "src/lib/campaignLegPhases.ts"() {
    MIN_VISIBLE_PHASE_DURATION_MS = 6e4;
  }
});

// src/lib/legPriceChange.ts
function usablePrice(value) {
  return typeof value === "number" && Number.isFinite(value);
}
function computeLegPriceChangePct(entryPrice, exitPrice, side) {
  if (!usablePrice(entryPrice) || !usablePrice(exitPrice) || entryPrice <= 0) return null;
  const move = side === "short" ? entryPrice - exitPrice : exitPrice - entryPrice;
  const pct = move / entryPrice * 100;
  return Number.isFinite(pct) ? pct : null;
}
var init_legPriceChange = __esm({
  "src/lib/legPriceChange.ts"() {
  }
});

// src/lib/campaignMainPriceChange.ts
function usable(value) {
  return typeof value === "number" && Number.isFinite(value);
}
function mainLegsOf(legs) {
  for (const role of PRIMARY_MAIN_ROLES) {
    const found = legs.filter((leg) => leg.role === role);
    if (found.length > 0) return found;
  }
  return [];
}
function computeCampaignPriceChange(inputs) {
  const mains = mainLegsOf(inputs);
  if (mains.length === 0) return NO_PRICE_CHANGE;
  const side = mains[0].side;
  const better = (a, b) => side === "long" ? a < b : a > b;
  const entries = mains.filter((leg) => usable(leg.entryPrice) && leg.entryPrice > 0);
  if (entries.length === 0) return { ...NO_PRICE_CHANGE, side };
  const entryLeg = entries.reduce((best, leg) => {
    if (better(leg.entryPrice, best.entryPrice)) return leg;
    if (leg.entryPrice === best.entryPrice && (leg.openTime ?? Infinity) < (best.openTime ?? Infinity)) return leg;
    return best;
  });
  const entryPrice = entryLeg.entryPrice;
  const closed = mains.filter((leg) => usable(leg.exitPrice) && leg.exitPrice > 0);
  if (closed.length === 0) return { ...NO_PRICE_CHANGE, side, entryPrice, entryLegId: entryLeg.id, entryOpenTime: entryLeg.openTime };
  const timed = closed.filter((leg) => usable(leg.closeTime));
  const mainCloseTime = timed.length > 0 ? Math.max(...timed.map((leg) => leg.closeTime)) : null;
  const finalMains = mainCloseTime == null ? closed : timed.filter((leg) => leg.closeTime === mainCloseTime);
  const exitLeg = finalMains.reduce((best, leg) => (side === "long" ? leg.exitPrice > best.exitPrice : leg.exitPrice < best.exitPrice) ? leg : best);
  const locks = (leg, closeAt) => {
    const closedInTime = usable(leg.closeTime) && leg.closeTime > leg.openTime;
    if (ROLLING_HEDGE_ROLES.includes(leg.role)) {
      if (usable(leg.closeTime)) return closedInTime && leg.closeTime >= closeAt - SAME_CLOSE_TOLERANCE_MS;
      return leg.exitPrice == null;
    }
    return closedInTime && Math.abs(leg.closeTime - closeAt) <= SAME_CLOSE_TOLERANCE_MS;
  };
  const lockingHedges = mainCloseTime == null ? [] : inputs.filter((leg) => isLockingHedgeRole(leg.role) && leg.side !== side && usable(leg.entryPrice) && leg.entryPrice > 0 && usable(leg.openTime) && leg.openTime < mainCloseTime && locks(leg, mainCloseTime)).sort((a, b) => a.openTime - b.openTime || a.id.localeCompare(b.id));
  const lockingHedge = lockingHedges[0] ?? null;
  const exitPrice = lockingHedge ? lockingHedge.entryPrice : exitLeg.exitPrice;
  return {
    pct: computeLegPriceChangePct(entryPrice, exitPrice, side),
    side,
    entryPrice,
    entryLegId: entryLeg.id,
    entryOpenTime: entryLeg.openTime,
    exitPrice,
    exitSource: lockingHedge ? EXIT_SOURCE_BY_HEDGE_ROLE[lockingHedge.role] : "main",
    exitLegId: lockingHedge ? lockingHedge.id : exitLeg.id,
    mainCloseTime,
    lockingLegIds: lockingHedges.map((leg) => leg.id)
  };
}
function isLockingHedgeRole(role) {
  return [...ROLLING_HEDGE_ROLES, ...SAME_CLOSE_HEDGE_ROLES].includes(role);
}
function isPriceChangeRole(role) {
  return isLockingHedgeRole(role) || PRIMARY_MAIN_ROLES.includes(role ?? "");
}
function campaignPriceChangeLegInputs(campaign, legs, tradeRecords, corrections = {}, localOrders = {}) {
  const live = campaign.comparison?.liveUsdt;
  if (live) {
    const { entryPrice, exitPrice } = usdtLiveFillMetrics(live);
    return [{ id: campaign.id, role: "main_open", side: live.direction, entryPrice, exitPrice, openTime: live.openedAt, closeTime: live.closedAt ?? null }];
  }
  const mirrorOnly = isQualityCampaignId(campaign.id) && campaign.comparison?.sellEvidence?.mirrorFill?.fraction === 1 && !legs.some((leg) => leg.leg_role === "main_open");
  const lookup = buildTradeRecordLookup(tradeRecords);
  const facts = resolveCampaignEquityPathLegFacts(campaign, legs, tradeRecords, localOrders);
  return legs.filter((leg) => (isPriceChangeRole(leg.leg_role) || mirrorOnly && leg.leg_role === "mirror_tp") && !facts.unfilledLegIds.has(leg.id)).map((leg) => {
    const record = leg.trade_record_id ? lookup.get(leg.trade_record_id) ?? null : null;
    const execution = resolveLegExecution(leg, record, corrections);
    return {
      id: leg.id,
      role: mirrorOnly && leg.leg_role === "mirror_tp" ? "main_open" : leg.leg_role,
      side: leg.direction === "short" ? "short" : "long",
      entryPrice: execution.entryPrice,
      exitPrice: execution.exitPrice,
      // 没有成交记录的腿按权益路径的持有起点（触发时刻）；有记录的按记录。
      // 成交过、成交时刻却不知道的锁价对冲（权益路径不持有：换了设备、本地查不到成交记录或委托快照）：
      // 读不出它何时在手，不参与锁价——挂出时刻不是成交时刻（与峰值浮盈同一份事实）
      openTime: record ? execution.openTime : facts.heldStartMsByLeg.get(leg.id) ?? (isLockingHedgeRole(leg.leg_role) && facts.offPathLegIds.has(leg.id) ? null : execution.openTime),
      // 没有平仓价的腿：有成交记录的就是还没平；没有记录的读权益路径在哪一刻放下它
      // （触发后撤单、快照里只记了平仓时间）——撤掉的对冲不再在手
      closeTime: execution.exitPrice != null ? execution.closeTime : record ? null : facts.heldWithoutRecordByLeg.get(leg.id)?.endMs ?? null
    };
  });
}
function campaignPriceChange(campaign, legs, tradeRecords, corrections = {}, localOrders = {}) {
  return computeCampaignPriceChange(campaignPriceChangeLegInputs(campaign, legs, tradeRecords, corrections, localOrders));
}
function computeMainPriceEfficiency(mainPriceChangePct, expectedMaxDrawdownPct) {
  if (mainPriceChangePct == null || !Number.isFinite(mainPriceChangePct)) return null;
  if (expectedMaxDrawdownPct == null || !Number.isFinite(expectedMaxDrawdownPct) || !(expectedMaxDrawdownPct > 0)) return null;
  const value = mainPriceChangePct / expectedMaxDrawdownPct;
  return Number.isFinite(value) ? value : null;
}
function computeAddEfficiency(payoffRatio, mainPriceEfficiency) {
  if (payoffRatio == null || !Number.isFinite(payoffRatio)) return null;
  if (mainPriceEfficiency == null || !Number.isFinite(mainPriceEfficiency)) return null;
  if (Number(mainPriceEfficiency.toFixed(2)) === 0) return null;
  const value = payoffRatio / Math.abs(mainPriceEfficiency);
  return Number.isFinite(value) ? value : null;
}
function isMainAddRole(role) {
  return !!role && role.startsWith("main_add");
}
function isFilledMainAdd(leg) {
  return isMainAddRole(leg.leg_role) && (!!leg.trade_record_id || leg.post_realized_pnl != null && Number.isFinite(Number(leg.post_realized_pnl)) || !!leg.post_real_close_time || !!leg.post_simulated_close_time);
}
function campaignMainAddCount(legs) {
  return legs.filter(isFilledMainAdd).length;
}
var PRIMARY_MAIN_ROLES, ROLLING_HEDGE_ROLES, SAME_CLOSE_HEDGE_ROLES, SAME_CLOSE_TOLERANCE_MS, EXIT_SOURCE_BY_HEDGE_ROLE, EMPTY_CAMPAIGN_PRICE_CHANGE, NO_PRICE_CHANGE;
var init_campaignMainPriceChange = __esm({
  "src/lib/campaignMainPriceChange.ts"() {
    init_usdtLiveCampaignMetrics();
    init_campaignSections();
    init_campaignAnalysis();
    init_campaignLegExecution();
    init_campaignLegPhases();
    init_legPriceChange();
    init_objectiveOperationTime();
    PRIMARY_MAIN_ROLES = ["main_open", "reentry_main"];
    ROLLING_HEDGE_ROLES = ["hedge_rolling", "hedge_initial_a", "hedge_initial_b"];
    SAME_CLOSE_HEDGE_ROLES = ["reentry_hedge"];
    SAME_CLOSE_TOLERANCE_MS = MIN_VISIBLE_PHASE_DURATION_MS;
    EXIT_SOURCE_BY_HEDGE_ROLE = {
      hedge_rolling: "rolling_hedge",
      hedge_initial_a: "initial_hedge_a",
      hedge_initial_b: "initial_hedge_b",
      reentry_hedge: "reentry_hedge"
    };
    EMPTY_CAMPAIGN_PRICE_CHANGE = Object.freeze({
      pct: null,
      side: null,
      entryPrice: null,
      entryLegId: null,
      entryOpenTime: null,
      exitPrice: null,
      exitSource: null,
      exitLegId: null,
      mainCloseTime: null
    });
    NO_PRICE_CHANGE = EMPTY_CAMPAIGN_PRICE_CHANGE;
  }
});

// src/lib/campaignLegGeometricFactor.ts
function buildCampaignLegTheoreticalFactors(input, verdicts) {
  const checks = verdicts ?? evaluateCampaignAddSizing(input);
  const firstDirections = /* @__PURE__ */ new Set();
  const hedgeSeen = /* @__PURE__ */ new Map();
  return new Map(resolveCampaignAddQuantitySteps(input).map((step) => {
    const leg = input.legs.find((item) => item.id === step.legId);
    const firstAdd = !firstDirections.has(leg.direction ?? "long");
    firstDirections.add(leg.direction ?? "long");
    const v = checks.get(step.legId), d = leg.direction === "short" ? -1 : 1;
    const Q = step.beforeCoins, K = v?.s1, T = v?.s2, Y = v?.cushion;
    const direction = leg.direction ?? "long";
    const hedgeTotal = v?.hedgeBanked ?? 0;
    const G = firstAdd ? v?.banked : hedgeTotal - (hedgeSeen.get(direction) ?? 0);
    if (Number.isFinite(hedgeTotal)) hedgeSeen.set(direction, hedgeTotal);
    if (!v || v.status === "unknown" || Q == null || !(Q > 0) || K == null || T == null || Y == null || G == null || ![Q, K, T, Y, G].every(Number.isFinite) || (T - K) * d <= 0) return [step.legId, null];
    const costLine = K - Y / (Q * d), adjustedSupport = K + d * G / Q;
    const alpha = Math.max(0, (adjustedSupport - costLine) * d) / ((T - K) * d), multiple = 1 + alpha;
    if (![costLine, adjustedSupport, alpha, multiple, Q * alpha].every(Number.isFinite) || costLine <= 0) return [step.legId, null];
    return [step.legId, { beforeCoins: Q, addCoins: Q * alpha, multiple, costLine, support: K, adjustedSupport, addPrice: T, bankedProfit: G, firstAdd, alpha }];
  }));
}
var init_campaignLegGeometricFactor = __esm({
  "src/lib/campaignLegGeometricFactor.ts"() {
    init_campaignAddSizingCheck();
  }
});

// src/lib/campaignExecutionWear.ts
function recordCoins(record, leg) {
  if (!(record.entryPrice > 0)) return 0;
  const sized = !record.settlementMode && leg.pre_settlement_mode === "coin" ? { ...record, settlementMode: "coin" } : record;
  const coins = tradeRecordNotionalAt(sized) / record.entryPrice;
  return Number.isFinite(coins) && coins > 0 ? coins : 0;
}
function computeCampaignExecutionWear(input) {
  const { legs, executions, settlement, corrections, orders, finalExitPrice: F, initialExpectedMaxLoss } = input;
  const byLeg = {};
  const components = { hedge: null, exit: null, slippage: null, sizing: null };
  const add = (legId, part, value) => {
    if (!Number.isFinite(value)) return;
    const row = byLeg[legId] ??= { hedge: null, exit: null, slippage: null, sizing: null, total: 0 };
    row[part] = (row[part] ?? 0) + value;
    row.total += value;
    components[part] = (components[part] ?? 0) + value;
  };
  const lockingIds = new Set(input.lockingLegIds);
  const closesOf = (leg) => {
    const records = settlement.recordsByLeg.get(leg.id) ?? [];
    const last = Math.max(...records.map((record) => record.closeTime));
    return records.map((record) => {
      const corrected = record.closeTime === last && corrections[leg.id] ? corrections[leg.id].exitPrice : null;
      return { record, coins: recordCoins(record, leg), price: corrected ?? record.exitPrice };
    }).filter((close) => close.coins > 0 && close.price > 0);
  };
  for (const leg of legs) {
    if (!isHedgeLeg(leg) || lockingIds.has(leg.id)) continue;
    const pnl = settlement.byLeg.get(leg.id);
    if (finite3(pnl)) {
      add(leg.id, "hedge", pnl);
      byLeg[leg.id].detail = { kind: "midHedge", pnl };
    }
  }
  const lockers = legs.filter((leg) => lockingIds.has(leg.id) && isHedgeLeg(leg)).sort((a, b) => (executions.get(a.id)?.openTime ?? Infinity) - (executions.get(b.id)?.openTime ?? Infinity));
  if (lockers.length && finite3(F) && F > 0) {
    const lockOpen = executions.get(lockers[0].id)?.openTime ?? null;
    let longCoins = 0, longValue = 0;
    if (lockOpen != null) {
      for (const leg of legs) {
        if (!isMainSideLeg(leg)) continue;
        for (const close of closesOf(leg)) {
          if (!(close.record.closeTime >= lockOpen)) continue;
          longCoins += close.coins;
          longValue += close.coins * close.price;
        }
      }
    }
    const longExit = longCoins > 0 ? longValue / longCoins : null;
    let hedgeCoins = 0;
    const finalDetails = [];
    for (const leg of lockers) {
      const closes = closesOf(leg);
      const record = leg.trade_record_id ? input.lookup.get(leg.trade_record_id) : void 0;
      const coins = closes.length ? closes.reduce((sum, close) => sum + close.coins, 0) : record ? recordCoins(record, leg) : 0;
      if (!(coins > 0)) continue;
      hedgeCoins += coins;
      const entry = executions.get(leg.id)?.entryPrice ?? closes[0]?.record.entryPrice ?? null;
      if (longExit != null && closes.length) {
        const shortExit2 = closes.reduce((sum, close) => sum + close.coins * close.price, 0) / coins;
        add(leg.id, "exit", coins * (longExit - shortExit2) + (finite3(entry) ? coins * (entry - F) : 0));
      }
      const recordIds = new Set([leg.trade_record_id, ...closes.map((close) => close.record.id)].filter(Boolean));
      const order = orders.find((item) => item.status === "triggered" && item.tradeRecordId != null && recordIds.has(item.tradeRecordId));
      const fill = finite3(entry) && entry > 0 ? entry : order?.fillPrice ?? null;
      const hasOrder = order != null && finite3(order.price) && order.price > 0 && finite3(fill) && fill > 0;
      if (hasOrder) add(leg.id, "slippage", coins * (fill - order.price));
      const shortExit = closes.length ? closes.reduce((sum, close) => sum + close.coins * close.price, 0) / coins : null;
      finalDetails.push({
        legId: leg.id,
        kind: "finalHedge",
        coins,
        entry: finite3(entry) ? entry : null,
        shortExit,
        finalExitPrice: F,
        longExit,
        longCoins,
        hedgeCoinsTotal: 0,
        sizingOwner: leg.id === lockers[0].id,
        orderPrice: hasOrder ? order.price : null,
        fillPrice: hasOrder ? fill : null
      });
    }
    if (longExit != null && hedgeCoins > 0) add(lockers[0].id, "sizing", (longCoins - hedgeCoins) * (longExit - F));
    for (const { legId, ...detail } of finalDetails) {
      if (byLeg[legId]) byLeg[legId].detail = { ...detail, hedgeCoinsTotal: hedgeCoins };
    }
  }
  const present = EXECUTION_WEAR_COMPONENTS.map((part) => components[part]).filter(finite3);
  const usd = present.length ? present.reduce((sum, value) => sum + value, 0) : null;
  const r = usd != null && initialExpectedMaxLoss > 0 ? usd / initialExpectedMaxLoss : null;
  return { usd, r: r != null && Number.isFinite(r) ? r : null, components, byLeg, initialExpectedMaxLoss: initialExpectedMaxLoss > 0 ? initialExpectedMaxLoss : null };
}
var EXECUTION_WEAR_COMPONENTS, isHedgeLeg, isMainSideLeg, finite3;
var init_campaignExecutionWear = __esm({
  "src/lib/campaignExecutionWear.ts"() {
    init_campaignLegExecution();
    EXECUTION_WEAR_COMPONENTS = ["hedge", "exit", "slippage", "sizing"];
    isHedgeLeg = (leg) => leg.direction === "short" && ((leg.leg_role ?? "").startsWith("hedge_") || leg.leg_role === "reentry_hedge");
    isMainSideLeg = (leg) => leg.direction === "long" && (leg.leg_role === "main_open" || leg.leg_role === "mirror_tp" || (leg.leg_role ?? "").startsWith("main_add_"));
    finite3 = (value) => value != null && Number.isFinite(value);
  }
});

// src/lib/campaignGeometricMetrics.ts
function positionGeometricMultiple(ratios, reduction = 0) {
  if (ratios == null || reduction == null || !Number.isFinite(reduction) || reduction < 0 || reduction > 1 || ratios.some((ratio) => !Number.isFinite(ratio) || ratio < 0)) return null;
  const value = ratios.reduce((product, ratio) => product * (1 + ratio), 1 - reduction);
  return Number.isFinite(value) ? value : null;
}
function geometricFirstAddBasis(verdict) {
  if (!verdict || verdict.status === "unknown") return null;
  const { x1Coins: Q, x2Coins: addCoins, s1: K, s2: T, cushion: Y, banked: G } = verdict;
  if (Q == null || !(Q > 0) || addCoins == null || !(addCoins > 0) || K == null || T == null || !(T > K) || Y == null || G == null || ![Q, addCoins, K, T, Y, G].every(Number.isFinite)) return null;
  const costLine = K - Y / Q;
  const breakevenLine = costLine - G / Q;
  const allowedRatio = Math.max(0, K - breakevenLine) / (T - K);
  if (![costLine, breakevenLine, allowedRatio].every(Number.isFinite)) return null;
  const afterCoins = Q + addCoins;
  const afterCostLine = (Q * costLine + addCoins * T) / afterCoins;
  return {
    beforeCoins: Q,
    addCoins,
    costLine,
    breakevenLine,
    bankedProfit: G,
    afterCoins,
    afterCostLine,
    afterBreakevenLine: afterCostLine - G / afterCoins,
    support: K,
    addPrice: T,
    actualRatio: addCoins / Q,
    allowedRatio
  };
}
function effectivePriceChangePct(exitPrice, stopLine, initialEntryPrice, initialStopPrice) {
  if (exitPrice == null || stopLine == null || initialEntryPrice == null || initialStopPrice == null || ![exitPrice, stopLine, initialEntryPrice, initialStopPrice].every(Number.isFinite) || exitPrice <= 0 || stopLine <= 0 || initialEntryPrice <= 0 || initialStopPrice <= 0 || initialEntryPrice <= initialStopPrice) return null;
  const value = (exitPrice - stopLine) / (initialEntryPrice - initialStopPrice) * 100;
  return Number.isFinite(value) ? value : null;
}
function computeEffectivePriceChangeMultiple(risePct, drawdownPct) {
  if (risePct == null || drawdownPct == null || !Number.isFinite(risePct) || !Number.isFinite(drawdownPct) || drawdownPct <= 0) return null;
  const value = risePct / drawdownPct;
  return Number.isFinite(value) ? value : null;
}
function computeMagicB(risePct, positionMultiple) {
  if (risePct == null || positionMultiple == null || ![risePct, positionMultiple].every(Number.isFinite) || positionMultiple < 0) return null;
  const value = positionMultiple * (risePct / 100);
  return Number.isFinite(value) ? value : null;
}
function computeUnitRise(exitPrice, stopLine) {
  if (exitPrice == null || stopLine == null || !Number.isFinite(exitPrice) || !Number.isFinite(stopLine) || exitPrice <= 0 || stopLine <= 0) return null;
  const value = exitPrice - stopLine;
  return Number.isFinite(value) ? value : null;
}
function computeUnitProfit(initialCoins, unitRise) {
  if (initialCoins == null || unitRise == null || !Number.isFinite(initialCoins) || !Number.isFinite(unitRise) || initialCoins <= 0) return null;
  const value = initialCoins * unitRise;
  return Number.isFinite(value) ? value : null;
}
function computePositionProfit(unitProfit, positionMultiple) {
  if (unitProfit == null || positionMultiple == null || !Number.isFinite(unitProfit) || !Number.isFinite(positionMultiple) || positionMultiple < 0) return null;
  const value = unitProfit * positionMultiple;
  return Number.isFinite(value) ? value : null;
}
function computeCampaignGeometricMetrics(campaign, legs, tradeRecords, orders = [], corrections = {}, localOrders = {}) {
  const empty = {
    effectivePriceChangePct: null,
    effectivePriceChangeMultiple: null,
    positionGeometricMultiple: null,
    magicB: null,
    unitRise: null,
    unitProfit: null,
    positionProfit: null,
    positionProfitTheoretical: null,
    geometricMetricBasis: { initialCoins: null, initialEntryPrice: null, initialStopPrice: null, earlyReductionFraction: null, addRatios: null, finalExitPrice: null, lastSupport: null }
  };
  const live = usdtLiveRiskMetrics(campaign);
  if (live) {
    const multiple2 = positionGeometricMultiple(live.addRatios, live.earlyReduction);
    return {
      ...empty,
      positionGeometricMultiple: multiple2,
      positionGeometricMultipleTheoretical: live.addCount ? null : multiple2,
      geometricMetricBasis: {
        initialCoins: live.openingSize || null,
        initialEntryPrice: live.entryPrice,
        initialStopPrice: live.stop,
        earlyReductionFraction: live.earlyReduction,
        addRatios: live.addRatios,
        finalExitPrice: live.exitPrice,
        lastSupport: null
      }
    };
  }
  if (campaign.direction !== "main_long") return empty;
  const lookup = buildTradeRecordLookup(tradeRecords);
  if (localOrders.unfilledOrderIds?.size) {
    legs = legs.filter((leg) => !leg.leg_role?.startsWith("main_add_") || !leg.trade_record_id || !localOrders.unfilledOrderIds.has(leg.trade_record_id) || lookup.has(leg.trade_record_id));
  }
  const executions = new Map(legs.map((leg) => [leg.id, resolveLegExecution(leg, leg.trade_record_id ? lookup.get(leg.trade_record_id) ?? null : null, corrections)]));
  const initialCandidates = legs.filter((leg) => leg.direction === "long" && (leg.leg_role === "main_open" || leg.leg_role === "mirror_tp"));
  const firstOpen = Math.min(...initialCandidates.flatMap((leg) => executions.get(leg.id)?.openTime == null ? [] : [executions.get(leg.id).openTime]));
  const initial = initialCandidates.filter((leg) => executions.get(leg.id)?.openTime === firstOpen);
  const attribution = resolveInitialExposureLegAttribution(campaign, initial, tradeRecords);
  let initialCoins = 0;
  let initialNotional = 0;
  if (attribution.shares.size) {
    for (const [id2, share] of attribution.shares) {
      const entry2 = executions.get(id2)?.entryPrice;
      if (entry2 == null || entry2 <= 0) {
        initialCoins = null;
        break;
      }
      initialCoins += share.notionalUsd / entry2;
      initialNotional += share.notionalUsd;
    }
  } else {
    const mains = initial.filter((leg) => leg.leg_role === "main_open");
    const entry2 = mains.length === 1 ? executions.get(mains[0].id)?.entryPrice : null;
    const exposure = computeInitialMainExposureNotional(campaign, legs, tradeRecords);
    initialCoins = entry2 != null && entry2 > 0 && exposure > 0 ? exposure / entry2 : null;
    initialNotional = exposure;
  }
  if (initialCoins == null || !Number.isFinite(initialCoins) || initialCoins <= 0) initialCoins = null;
  if (initialCandidates.some((leg) => executions.get(leg.id)?.openTime == null)) initialCoins = null;
  const entry = initialCoins != null ? initialNotional / initialCoins : null;
  const initialEntryPrice = entry != null && Number.isFinite(entry) && entry > 0 ? entry : null;
  const initialMainIds = new Set(initial.filter((leg) => leg.leg_role === "main_open").map((leg) => leg.id));
  const initialAnchors = resolveMainRiskAnchors(campaign, legs, tradeRecords, orders).anchors.filter((anchor) => initialMainIds.has(anchor.mainLegId));
  const validInitialStops = initialAnchors.length > 0 && initialAnchors.length === initialMainIds.size && initialAnchors.every((anchor) => anchor.stopPrice != null && anchor.stopPrice > 0 && anchor.entryPrice != null && anchor.entryPrice > anchor.stopPrice && anchor.exposureNotional > 0);
  const anchorCoins = validInitialStops ? initialAnchors.reduce((sum, anchor) => sum + anchor.exposureNotional / anchor.entryPrice, 0) : 0;
  const initialStopPrice = anchorCoins > 0 ? initialAnchors.reduce((sum, anchor) => sum + anchor.stopPrice * anchor.exposureNotional / anchor.entryPrice, 0) / anchorCoins : null;
  const input = { legs, tradeRecords, reverseHedgeOrders: orders, legExitPriceCorrections: corrections };
  const steps = resolveCampaignAddQuantitySteps(input).filter((step) => legs.find((leg) => leg.id === step.legId)?.direction === "long");
  const validSteps = steps.every((step) => Number.isFinite(step.openTime) && step.beforeCoins != null && step.beforeCoins > 0 && step.addCoins != null && step.addCoins > 0);
  const addRatios = validSteps ? steps.map((step) => step.addCoins / step.beforeCoins) : null;
  const settlement = computeCampaignRealizedPnl(campaign, legs, tradeRecords, corrections);
  const mainSide = legs.filter((leg) => leg.direction === "long" && (leg.leg_role === "main_open" || leg.leg_role === "mirror_tp" || (leg.leg_role ?? "").startsWith("main_add_")));
  const claimed = /* @__PURE__ */ new Set();
  const closes = [];
  for (const leg of mainSide) {
    const records = settlement.recordsByLeg.get(leg.id) ?? [];
    const last = Math.max(...records.map((record) => record.closeTime));
    for (const record of records) {
      if (claimed.has(record.id) || !(record.closeTime > 0) || !(record.entryPrice > 0)) continue;
      claimed.add(record.id);
      const sized = !record.settlementMode && leg.pre_settlement_mode === "coin" ? { ...record, settlementMode: "coin" } : record;
      const coins = tradeRecordNotionalAt(sized) / record.entryPrice;
      const price = record.closeTime === last && corrections[leg.id] ? corrections[leg.id].exitPrice : record.exitPrice;
      if (coins > 0 && price > 0) closes.push({ time: record.closeTime, operationTime: record.closedRealAt ?? null, legId: leg.id, mirror: leg.leg_role === "mirror_tp", coins, price });
    }
    if (!records.length) {
      const execution = executions.get(leg.id);
      const coins = execution.entryPrice != null && execution.entryPrice > 0 && leg.pre_position_size != null ? leg.pre_position_size / execution.entryPrice : 0;
      if (execution.closeTime != null && execution.exitPrice != null && coins > 0) closes.push({ time: execution.closeTime, operationTime: leg.post_real_close_time ? Date.parse(leg.post_real_close_time) : null, legId: leg.id, mirror: leg.leg_role === "mirror_tp", coins, price: execution.exitPrice });
    }
  }
  const resolved = ["closed_profit", "closed_loss", "closed_breakeven"].includes(campaign.status);
  const finalTime = closes.length ? Math.max(...closes.map((close) => close.time)) : null;
  const priceChange = campaignPriceChange(campaign, legs, tradeRecords, corrections, localOrders);
  const finalExitPrice = priceChange.exitPrice;
  const lockingIds = new Set(priceChange.lockingLegIds ?? []);
  const hedgeLegs = legs.filter((leg) => leg.direction === "short" && !lockingIds.has(leg.id) && ((leg.leg_role ?? "").startsWith("hedge_") || leg.leg_role === "reentry_hedge"));
  const hedgePnls = hedgeLegs.map((leg) => settlement.byLeg.get(leg.id)).filter((pnl) => pnl != null && Number.isFinite(pnl));
  const hedgeWearUsd = hedgePnls.length ? hedgePnls.reduce((sum, pnl) => sum + pnl, 0) : null;
  const initialExpectedMaxLoss = computeInitialExpectedMaxLoss(campaign, legs, tradeRecords, orders);
  const hedgeWearR = hedgeWearUsd != null && initialExpectedMaxLoss > 0 ? hedgeWearUsd / initialExpectedMaxLoss : null;
  let reduction = null;
  const initialReductionFactors = [];
  if (initialCoins != null) {
    const firstReductionFraction = (cuts) => {
      if (!cuts.length) return 0;
      const firstTime = Math.min(...cuts.map((cut) => cut.time));
      const batch = cuts.filter((cut) => cut.time === firstTime);
      const quantities = /* @__PURE__ */ new Map();
      for (const cut of batch) quantities.set(cut.legId, (quantities.get(cut.legId) ?? 0) + cut.coins);
      let before = initialCoins;
      for (const [legId, removed] of [...quantities.entries()].sort(([a], [b]) => a.localeCompare(b))) {
        if (before > 0 && removed > 0 && removed <= before + 1e-8) {
          initialReductionFactors.push({
            legId,
            kind: "reduction",
            beforeCoins: before,
            addCoins: removed,
            multiple: Math.max(0, 1 - removed / before)
          });
        }
        before -= removed;
      }
      return batch.reduce((sum, cut) => sum + cut.coins, 0) / initialCoins;
    };
    const initialIds = new Set(initial.map((leg) => leg.id));
    const firstAdd2 = steps[0];
    const firstLeg = firstAdd2 ? legs.find((leg) => leg.id === firstAdd2.legId) : null;
    const firstOperation = firstLeg ? executions.get(firstLeg.id)?.record?.openedRealAt ?? (firstLeg.pre_real_time ? Date.parse(firstLeg.pre_real_time) : null) : null;
    if (firstAdd2 && Number.isFinite(firstAdd2.openTime)) reduction = firstReductionFraction(
      closes.filter((close) => initialIds.has(close.legId) && close.time <= firstAdd2.openTime && !(firstOperation != null && close.operationTime != null && close.operationTime > firstOperation))
    );
    else if (!steps.length && resolved && finalTime != null) reduction = firstReductionFraction(closes.filter((close) => initialIds.has(close.legId) && (close.mirror || close.time < finalTime - 6e4)));
    else if (!steps.length) reduction = 0;
    if (reduction != null && (reduction < -1e-8 || reduction > 1 + 1e-8)) reduction = null;
    else if (reduction != null) reduction = Math.max(0, Math.min(1, reduction));
  }
  const lastAdd = steps.at(-1);
  const verdicts = steps.length ? evaluateCampaignAddSizing(input) : null;
  const verdict = lastAdd ? verdicts?.get(lastAdd.legId) : null;
  const lastLeg = lastAdd ? legs.find((leg) => leg.id === lastAdd.legId) : null;
  const snapshotStop = lastLeg?.trade_record_id ? lookup.get(lastLeg.trade_record_id)?.addSizingSnapshot?.s1 : null;
  const stop = verdict?.s1 ?? snapshotStop ?? null;
  const lastSupport = stop != null && Number.isFinite(stop) && stop > 0 ? stop : null;
  const rise = effectivePriceChangePct(finalExitPrice, lastSupport, initialEntryPrice, initialStopPrice);
  const drawdownPct = computeInitialExpectedMaxDrawdownPct(campaign, legs, tradeRecords, orders);
  const riseMultiple = computeEffectivePriceChangeMultiple(rise, drawdownPct);
  const multiple = !steps.length && initialCoins == null ? null : positionGeometricMultiple(addRatios, reduction);
  const theoreticalMap = buildCampaignLegTheoreticalFactors(input, verdicts ?? void 0);
  const theoreticalFactors = steps.map((step) => theoreticalMap.get(step.legId) ?? null);
  const theoreticalRatios = theoreticalFactors.every(Boolean) ? theoreticalFactors.map((factor) => factor.alpha) : null;
  const theoreticalMultiple = !steps.length && initialCoins == null ? null : positionGeometricMultiple(theoreticalRatios, reduction);
  const firstAdd = steps[0] ? geometricFirstAddBasis(verdicts?.get(steps[0].legId)) : null;
  const executionWear = computeCampaignExecutionWear({
    legs,
    executions,
    lookup,
    settlement,
    corrections,
    orders,
    finalExitPrice,
    lockingLegIds: priceChange.lockingLegIds ?? [],
    initialExpectedMaxLoss
  });
  const unitRise = computeUnitRise(finalExitPrice, lastSupport);
  const unitProfit = computeUnitProfit(initialCoins, unitRise);
  return {
    effectivePriceChangePct: rise,
    effectivePriceChangeMultiple: riseMultiple,
    positionGeometricMultiple: multiple,
    positionGeometricMultipleTheoretical: theoreticalMultiple,
    magicB: computeMagicB(rise, multiple),
    unitRise,
    unitProfit,
    positionProfit: computePositionProfit(unitProfit, multiple),
    positionProfitTheoretical: computePositionProfit(unitProfit, theoreticalMultiple),
    hedgeWearR,
    hedgeWearUsd,
    hedgeWearLegCount: hedgePnls.length,
    executionWearR: executionWear.r,
    executionWearUsd: executionWear.usd,
    executionWear,
    geometricMetricBasis: { initialCoins, initialEntryPrice, initialStopPrice, initialReductionFactors: reduction == null ? [] : initialReductionFactors, earlyReductionFraction: reduction, addRatios, finalExitPrice, lastSupport, firstAdd, theoreticalFactors }
  };
}
var MAGIC_B_FORMULA, MAGIC_B_THEORETICAL_FORMULA, MAGIC_B_METHODS_DESCRIPTION;
var init_campaignGeometricMetrics = __esm({
  "src/lib/campaignGeometricMetrics.ts"() {
    init_usdtLiveCampaignMetrics();
    init_campaignAnalysis();
    init_campaignAddSizingCheck();
    init_campaignLegExecution();
    init_campaignRealizedPnl();
    init_campaignMainPriceChange();
    init_objectiveOperationTime();
    init_campaignLegGeometricFactor();
    init_campaignExecutionWear();
    MAGIC_B_FORMULA = "\u795E\u5947\u7684 b = \u51E0\u4F55\u4ED3\u4F4D \xD7 \u76F8\u5BF9\u6DA8\u5E45";
    MAGIC_B_THEORETICAL_FORMULA = "\u795E\u5947\u7684 b\uFF08\u7406\u8BBA\uFF09 = \u51E0\u4F55\u4ED3\u4F4D\uFF08\u7406\u8BBA\uFF09 \xD7 \u76F8\u5BF9\u6DA8\u5E45";
    MAGIC_B_METHODS_DESCRIPTION = `\u7B97\u6CD5\u4E8C \xB7 \u51E0\u4F55\u516C\u5F0F\uFF1A${MAGIC_B_FORMULA}\u3002\u65B9\u6CD5\u4E09 \xB7 \u795E\u5947\u7684 b\uFF08\u7406\u8BBA\uFF09\uFF1A${MAGIC_B_THEORETICAL_FORMULA}\u3002\u795E\u5947\u7684 b \u6307\u6807\u91C7\u7528\u7B97\u6CD5\u4E8C\uFF0C\u65B9\u6CD5\u4E09\u4EC5\u4F5C\u7406\u8BBA\u5BF9\u7167\u3002`;
  }
});

// src/lib/formatters.ts
var init_formatters = __esm({
  "src/lib/formatters.ts"() {
  }
});

// src/lib/campaignUnitProfit.ts
function computeGeometricGrowth(b) {
  if (b == null || !Number.isFinite(b)) return null;
  const value = 1 + GEOMETRIC_GROWTH_FRACTION * b;
  return Number.isFinite(value) ? value : null;
}
var GEOMETRIC_GROWTH_FRACTION;
var init_campaignUnitProfit = __esm({
  "src/lib/campaignUnitProfit.ts"() {
    init_formatters();
    GEOMETRIC_GROWTH_FRACTION = 0.1;
  }
});

// src/lib/campaignMetrics.ts
function campaignGrowthFactor(payoffRatio) {
  return computeGeometricGrowth(payoffRatio) ?? 1;
}
function computeCampaignExpectanciesFromMagicB(b) {
  if (b == null || !Number.isFinite(b)) {
    return { arithmeticExpectancy: null, geometricExpectancy: null };
  }
  const p = ARITHMETIC_EXPECTANCY_WIN_RATE;
  const arithmeticExpectancy = p * b - (1 - p);
  return {
    arithmeticExpectancy,
    geometricExpectancy: campaignGrowthFactor(b) - 1
  };
}
var ARITHMETIC_EXPECTANCY_WIN_RATE;
var init_campaignMetrics = __esm({
  "src/lib/campaignMetrics.ts"() {
    init_campaignUnitProfit();
    init_campaignPrimaryMainLeg();
    ARITHMETIC_EXPECTANCY_WIN_RATE = 0.5;
  }
});

// src/components/journal/MagicBMethodFormulas.tsx
var init_MagicBMethodFormulas = __esm({
  "src/components/journal/MagicBMethodFormulas.tsx"() {
    init_campaignGeometricMetrics();
  }
});

// src/lib/legPositionShare.ts
function legPositionSideFromDirection(direction) {
  return direction === "short" ? "short" : "long";
}
function isMainLegRole(role) {
  return role === "main_open" || role === "reentry_main" || typeof role === "string" && role.startsWith("main_add_");
}
function resolveLegPositionShareSide(campaignDirection, inputs) {
  if (campaignDirection === "main_short") return "short";
  if (campaignDirection === "main_long") return "long";
  const mainLeg = inputs.find((input) => isMainLegRole(input.role));
  if (mainLeg) return mainLeg.side;
  let long = 0;
  let short = 0;
  for (const input of inputs) {
    if (!input.counted || !contributes(input.notional)) continue;
    if (input.side === "short") short += input.notional;
    else long += input.notional;
  }
  return short > long ? "short" : "long";
}
function contributes(value) {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}
function computeLegPositionShares(inputs) {
  const sums = {
    long: { coins: 0, coinLegs: 0, notional: 0, notionalLegs: 0 },
    short: { coins: 0, coinLegs: 0, notional: 0, notionalLegs: 0 }
  };
  for (const input of inputs) {
    if (!input.counted) continue;
    const sum = sums[input.side];
    if (contributes(input.coinQty)) {
      sum.coins += input.coinQty;
      sum.coinLegs += 1;
    }
    if (contributes(input.notional)) {
      sum.notional += input.notional;
      sum.notionalLegs += 1;
    }
  }
  const totalsFor = (side) => {
    const sum = sums[side];
    return {
      side,
      totalCoins: sum.coinLegs > 0 && sum.coins > 0 ? sum.coins : null,
      totalNotional: sum.notionalLegs > 0 && sum.notional > 0 ? sum.notional : null
    };
  };
  const bySide = { long: totalsFor("long"), short: totalsFor("short") };
  const byLeg = /* @__PURE__ */ new Map();
  for (const input of inputs) {
    const totals = bySide[input.side];
    const share = (value, total) => input.counted && contributes(value) && total != null ? value / total * 100 : null;
    byLeg.set(input.legId, {
      side: input.side,
      coinQty: input.coinQty,
      notional: input.notional,
      counted: input.counted,
      coinSharePct: share(input.coinQty, totals.totalCoins),
      notionalSharePct: share(input.notional, totals.totalNotional)
    });
  }
  const sides = LEG_POSITION_SIDES.map((side) => bySide[side]).filter((totals) => totals.totalCoins != null || totals.totalNotional != null);
  return { byLeg, bySide, sides };
}
var LEG_POSITION_SIDES;
var init_legPositionShare = __esm({
  "src/lib/legPositionShare.ts"() {
    LEG_POSITION_SIDES = ["long", "short"];
  }
});

// src/lib/legRowStatus.ts
function isPendingOrderRole(role) {
  return role === "mirror_tp" || !!role?.startsWith("hedge_");
}
function legFillEvidenceStatus(leg, evidence) {
  const id2 = leg.trade_record_id;
  if (!id2) {
    const triggered = (evidence?.events ?? []).some((event) => event.journal_id === leg.id && FILLED_EVENT_TYPES.has(event.event_type));
    return triggered ? "open" : "pending";
  }
  if (evidence?.unfilledOrderIds?.has(id2)) return "pending";
  const order = (evidence?.orders ?? []).find((item) => !item.foreignReplay && item.id === id2);
  if (order) return order.status === "triggered" ? "open" : "pending";
  return "open";
}
function legRowStatus(leg, record, evidence) {
  if (isLiquidationRecord(record)) return "liquidated";
  if (record) return "closed";
  if (leg.post_simulated_close_time || leg.post_real_close_time || leg.post_outcome) return "closed";
  if (isPendingOrderRole(leg.leg_role)) return legFillEvidenceStatus(leg, evidence);
  return "open";
}
var FILLED_EVENT_TYPES;
var init_legRowStatus = __esm({
  "src/lib/legRowStatus.ts"() {
    init_liquidationRecord();
    FILLED_EVENT_TYPES = /* @__PURE__ */ new Set(["hedge_triggered", "mirror_tp_triggered"]);
  }
});

// src/lib/legPositionShareInputs.ts
function buildLegPositionShareInputs(legs, recordMap, corrections, evidence) {
  return legs.map((leg) => {
    const record = leg.trade_record_id ? recordMap.get(leg.trade_record_id) ?? null : null;
    const entryPrice = resolveLegExecution(leg, record, corrections).entryPrice;
    const coinQty = leg.pre_position_size != null && entryPrice != null && entryPrice > 0 ? leg.pre_position_size / entryPrice : null;
    return {
      legId: leg.id,
      side: legPositionSideFromDirection(leg.direction),
      role: leg.leg_role,
      coinQty,
      notional: leg.pre_position_size ?? null,
      counted: legRowStatus(leg, record, evidence) !== "pending"
    };
  });
}
function campaignMainSideNotional(campaignDirection, inputs) {
  const side = resolveLegPositionShareSide(campaignDirection, inputs);
  const mirrors = inputs.filter((input) => input.counted && input.side === side && input.role === "mirror_tp");
  const mirrorTotal = mirrors.every((input) => input.notional != null && Number.isFinite(input.notional) && input.notional >= 0) ? mirrors.reduce((sum, input) => sum + input.notional, 0) : null;
  return { side, total: computeLegPositionShares(inputs).bySide[side].totalNotional, mirrorTotal };
}
var init_legPositionShareInputs = __esm({
  "src/lib/legPositionShareInputs.ts"() {
    init_campaignLegExecution();
    init_legPositionShare();
    init_legRowStatus();
  }
});

// src/lib/campaignPositionAmplification.ts
function computePositionAmplification(initialMainExposureNotional, mainSideNotionalTotal, mirrorNotional = 0) {
  if (initialMainExposureNotional == null || !Number.isFinite(initialMainExposureNotional) || initialMainExposureNotional <= 0) return null;
  if (mainSideNotionalTotal == null || !Number.isFinite(mainSideNotionalTotal)) return null;
  if (mirrorNotional == null || !Number.isFinite(mirrorNotional) || mirrorNotional < 0 || mainSideNotionalTotal < mirrorNotional) return null;
  return (mainSideNotionalTotal - mirrorNotional) / initialMainExposureNotional;
}
function computeCampaignPositionAmplification(campaign, legs, tradeRecords, corrections, evidence = {}) {
  const live = campaign.comparison?.liveUsdt;
  if (live) {
    const { openingNotional, totalEntryNotional } = usdtLiveFillMetrics(live);
    return computePositionAmplification(openingNotional, totalEntryNotional);
  }
  const initial = computeInitialMainExposureNotional(campaign, legs, tradeRecords);
  if (!Number.isFinite(initial) || initial <= 0) return null;
  const inputs = buildLegPositionShareInputs(legs, buildTradeRecordLookup(tradeRecords), corrections, { events: campaign.actual_evolution, ...evidence });
  const mainSide = campaignMainSideNotional(campaign.direction, inputs);
  return computePositionAmplification(initial, mainSide.total, mainSide.mirrorTotal);
}
var init_campaignPositionAmplification = __esm({
  "src/lib/campaignPositionAmplification.ts"() {
    init_usdtLiveCampaignMetrics();
    init_campaignAnalysis();
    init_legPositionShareInputs();
    init_objectiveOperationTime();
  }
});

// src/lib/campaignPnlOverview.tsx
function computeUnrealizedPriceChangePct(mainPriceChangePct, peakPriceChangePct) {
  if (mainPriceChangePct == null || !Number.isFinite(mainPriceChangePct) || peakPriceChangePct == null || !Number.isFinite(peakPriceChangePct)) return null;
  const value = peakPriceChangePct - mainPriceChangePct;
  return Number.isFinite(value) ? value : null;
}
var init_campaignPnlOverview = __esm({
  "src/lib/campaignPnlOverview.tsx"() {
    init_MagicBMethodFormulas();
    init_campaignB();
    init_campaignAnalysis();
    init_campaignPositionAmplification();
    init_campaignExecutionWear();
    init_campaignGeometricMetrics();
    init_campaignMetrics();
    init_campaignMainPriceChange();
    init_legPriceChange();
    init_campaignLegGeometricFactor();
    init_campaignUnitProfit();
  }
});

// src/lib/mirrorTpSummary.ts
function mirrorTpOutcome(payoffRatio, realizedPnl) {
  if (payoffRatio != null && Number.isFinite(payoffRatio)) {
    if (Math.abs(payoffRatio) <= MIRROR_TP_FLAT_BAND) return "flat";
    return payoffRatio > 0 ? "win" : "loss";
  }
  if (realizedPnl == null || !Number.isFinite(realizedPnl)) return "open";
  if (realizedPnl > 0) return "win";
  if (realizedPnl < 0) return "loss";
  return "flat";
}
function campaignAchievedMirrorTp(legs, tradeRecords) {
  const recordIds = new Set(tradeRecords.map((record) => record.id));
  return legs.some(
    (leg) => leg.leg_role === "mirror_tp" && leg.trade_record_id != null && recordIds.has(leg.trade_record_id)
  );
}
function mirrorTpRank(achieved, payoffRatio, realizedPnl) {
  const outcome = mirrorTpOutcome(payoffRatio, realizedPnl);
  const withinGroup = outcome === "loss" ? 0 : outcome === "win" ? 2 : 1;
  return (achieved ? MIRROR_TP_ACHIEVED_OFFSET : 0) + withinGroup;
}
var MIRROR_TP_FLAT_BAND, MIRROR_TP_ACHIEVED_OFFSET;
var init_mirrorTpSummary = __esm({
  "src/lib/mirrorTpSummary.ts"() {
    MIRROR_TP_FLAT_BAND = 0.1;
    MIRROR_TP_ACHIEVED_OFFSET = 3;
  }
});

// src/lib/campaignOperationRange.ts
var UTC8_OFFSET_MS;
var init_campaignOperationRange = __esm({
  "src/lib/campaignOperationRange.ts"() {
    UTC8_OFFSET_MS = 8 * 36e5;
  }
});

// src/lib/campaignListSort.ts
function rowPayoffRatio(row) {
  return row.profitCaptureRatio != null && Number.isFinite(row.profitCaptureRatio) ? row.profitCaptureRatio / 100 : null;
}
function rowMirrorTpRank(row) {
  return mirrorTpRank(
    campaignAchievedMirrorTp(row.legs, row.tradeRecords),
    rowPayoffRatio(row),
    row.campaign.final_realized_pnl ?? null
  );
}
function campaignLeverage(campaign, legs) {
  const initial = Number(campaign.initial_leverage);
  if (Number.isFinite(initial) && initial > 0) return initial;
  let max = 0;
  for (const leg of legs) {
    const value = Number(leg.leverage);
    if (Number.isFinite(value) && value > max) max = value;
  }
  return max;
}
function rowMainPriceEfficiency(row) {
  return computeMainPriceEfficiency(row.mainPriceChangePct, row.initialExpectedMaxDrawdownPct);
}
function rowUnrealizedPriceChangePct(row) {
  return computeUnrealizedPriceChangePct(row.mainPriceChangePct, row.peakPriceChangePct);
}
function rowAddEfficiency(row) {
  if (rowAddCount(row) === 0) return null;
  return computeAddEfficiency(rowPayoffRatio(row), rowMainPriceEfficiency(row));
}
function rowAddCount(row) {
  return row.liveAddCount ?? campaignMainAddCount(row.legs);
}
function rowGeometricMetrics(row) {
  const cached = geometricMetricsCache.get(row);
  if (cached) return cached;
  let metrics;
  try {
    metrics = computeCampaignGeometricMetrics(row.campaign, row.legs, row.tradeRecords);
  } catch {
    metrics = { effectivePriceChangePct: null, effectivePriceChangeMultiple: null, positionGeometricMultiple: null, geometricMetricBasis: { initialCoins: null, earlyReductionFraction: null, addRatios: null, finalExitPrice: null, lastSupport: null } };
  }
  geometricMetricsCache.set(row, metrics);
  return metrics;
}
function rowPositionGeometricMultiple(row) {
  return row.positionGeometricMultiple !== void 0 ? row.positionGeometricMultiple : rowGeometricMetrics(row).positionGeometricMultiple;
}
function rowPositionGeometricMultipleTheoretical(row) {
  return row.positionGeometricMultipleTheoretical !== void 0 ? row.positionGeometricMultipleTheoretical : rowGeometricMetrics(row).positionGeometricMultipleTheoretical ?? null;
}
function rowEffectivePriceChangePct(row) {
  return row.effectivePriceChangePct !== void 0 ? row.effectivePriceChangePct : rowGeometricMetrics(row).effectivePriceChangePct;
}
function rowRelativePriceChange(row) {
  const percentage = rowEffectivePriceChangePct(row);
  return percentage == null || !Number.isFinite(percentage) ? null : percentage / 100;
}
function rowUnitRise(row) {
  return row.unitRise !== void 0 ? row.unitRise : rowGeometricMetrics(row).unitRise ?? null;
}
function rowExecutionWear(row) {
  const cached = row.executionWearR !== void 0;
  const total = cached ? row.executionWearR ?? null : rowGeometricMetrics(row).executionWearR ?? null;
  const hedge = cached ? row.hedgeWearR ?? null : rowGeometricMetrics(row).hedgeWearR ?? null;
  if (total == null || !Number.isFinite(total)) return { total: null, hedge: null, other: null };
  const hedgePart = hedge != null && Number.isFinite(hedge) ? hedge : null;
  return { total, hedge: hedgePart, other: total - (hedgePart ?? 0) };
}
function rowExecutionWearR(row) {
  return rowExecutionWear(row).total;
}
function rowUnitProfit(row) {
  return row.unitProfit !== void 0 ? row.unitProfit : rowGeometricMetrics(row).unitProfit ?? null;
}
function rowPositionProfit(row) {
  return row.positionProfit !== void 0 ? row.positionProfit : rowGeometricMetrics(row).positionProfit ?? null;
}
function rowPositionProfitTheoretical(row) {
  return row.positionProfitTheoretical !== void 0 ? row.positionProfitTheoretical : rowGeometricMetrics(row).positionProfitTheoretical ?? null;
}
function rowGeometricGrowth(row) {
  return computeGeometricGrowth(rowPayoffRatio(row));
}
function rowMagicB(row) {
  return resolveUnifiedMagicB(row.magicB !== void 0 ? row.magicB : rowGeometricMetrics(row).magicB);
}
function rowPositionAmplification(row) {
  if (row.positionAmplification !== void 0) return row.positionAmplification;
  if (positionAmplificationCache.has(row)) return positionAmplificationCache.get(row) ?? null;
  let value = null;
  try {
    value = computeCampaignPositionAmplification(row.campaign, row.legs, row.tradeRecords);
  } catch {
  }
  positionAmplificationCache.set(row, value);
  return value;
}
var positionAmplificationCache, geometricMetricsCache, CAMPAIGN_TITLE_COLLATOR;
var init_campaignListSort = __esm({
  "src/lib/campaignListSort.ts"() {
    init_campaignUnitProfit();
    init_campaignExecutionWear();
    init_campaignMainPriceChange();
    init_campaignPnlOverview();
    init_mirrorTpSummary();
    init_objectiveOperationTime();
    init_campaignPositionAmplification();
    init_campaignGeometricMetrics();
    init_campaignB();
    init_campaignOperationRange();
    positionAmplificationCache = /* @__PURE__ */ new WeakMap();
    geometricMetricsCache = /* @__PURE__ */ new WeakMap();
    CAMPAIGN_TITLE_COLLATOR = new Intl.Collator(["zh-Hans-CN", "en"], {
      numeric: true,
      sensitivity: "base"
    });
  }
});

// src/lib/campaignMetricLetters.ts
var num, safe, CAMPAIGN_METRIC_LETTERS, METRIC_BY_LETTER, LETTER_BY_CARD_MODE, LETTER_BY_OVERVIEW_KEY;
var init_campaignMetricLetters = __esm({
  "src/lib/campaignMetricLetters.ts"() {
    init_campaignGeometricMetrics();
    init_campaignMetrics();
    init_campaignListSort();
    num = (v) => v != null && Number.isFinite(v) ? v : null;
    safe = (f) => (row) => {
      try {
        return num(f(row));
      } catch {
        return null;
      }
    };
    CAMPAIGN_METRIC_LETTERS = [
      { letter: "d", aliases: [], name: "\u9884\u671F\u56DE\u64A4", unit: "%", help: "\u9996\u4ED3\u5F00\u4ED3\u4EF7\u5230\u521D\u59CB\u6B62\u635F\u4EF7\u7684\u56DE\u64A4\u5E45\u5EA6", source: "campaign", cardMode: "expectedDrawdownPct", overviewKey: "expectedMaxDrawdownPct", get: safe((r) => r.initialExpectedMaxDrawdownPct > 0 ? r.initialExpectedMaxDrawdownPct : null) },
      { letter: "G", aliases: [], name: "\u76F8\u5BF9\u6DA8\u5E45", unit: "\xD7", help: "G = (F \u2212 K\u2098) \xF7 (E \u2212 K\u521D)\uFF1A\u79BB\u573A\u4EF7\u76F8\u5BF9\u6700\u540E\u652F\u6491\u7684\u6DA8\u5E45\uFF0C\u4EE5\u9996\u4ED3\u98CE\u9669\u8DDD\u79BB\u4E3A\u5355\u4F4D", source: "campaign", cardMode: "effectivePriceChangePct", overviewKey: "effectivePriceChangePct", get: safe(rowRelativePriceChange) },
      { letter: "n", aliases: [], name: "\u52A0\u4ED3\u6B21\u6570", unit: "\u6B21", help: "\u4E3B\u529B\u52A0\u4ED3\u7684\u6B21\u6570", source: "campaign", cardMode: "addCount", overviewKey: "addCount", get: safe(rowAddCount) },
      { letter: "M", aliases: [], name: "\u51E0\u4F55\u4ED3\u4F4D", unit: "x", help: "(1 \u2212 \u03B1f) \xD7 \u220F(1 + \u03B1\u2096)\uFF1A\u52A0\u4ED3\u540E\u76F8\u5BF9\u9996\u4ED3\u7684\u51E0\u4F55\u4ED3\u4F4D\u500D\u6570\uFF08\u5B9E\u9645\uFF09", source: "campaign", cardMode: "positionGeometricMultiple", overviewKey: "positionGeometricMultiple", get: safe(rowPositionGeometricMultiple) },
      { letter: "M\u209C", aliases: ["Mt"], name: "\u51E0\u4F55\u4ED3\u4F4D\uFF08\u7406\u8BBA\uFF09", unit: "x", help: "\u6309\u7406\u8BBA\u52A0\u4ED3\u7CFB\u6570\u7B97\u7684\u51E0\u4F55\u4ED3\u4F4D", source: "campaign", get: safe(rowPositionGeometricMultipleTheoretical) },
      { letter: "B", aliases: [], name: "\u795E\u5947\u7684 b", unit: "\xD7", help: "\u51E0\u4F55\u4ED3\u4F4D \xD7 \u76F8\u5BF9\u6DA8\u5E45\uFF08\u5B9E\u9645\uFF09", source: "campaign", cardMode: "magicB", overviewKey: "magicB", get: safe(rowMagicB) },
      { letter: "B\u209C", aliases: ["Bt"], name: "\u795E\u5947\u7684 b\uFF08\u7406\u8BBA\uFF09", unit: "\xD7", help: "\u51E0\u4F55\u4ED3\u4F4D\uFF08\u7406\u8BBA\uFF09\xD7 \u76F8\u5BF9\u6DA8\u5E45\uFF1B\u6CA1\u6709\u52A0\u4ED3\u7684\u6218\u5F79\u6CA1\u6709\u8FD9\u4E2A\u8BFB\u6570", source: "campaign", get: safe((r) => computeMagicB(rowEffectivePriceChangePct(r), rowPositionGeometricMultipleTheoretical(r))) },
      { letter: "b", aliases: [], name: "\u76C8\u4E8F\u6BD4", unit: "\xD7", help: "\u5DF2\u5B9E\u73B0\u51C0\u76C8\u4E8F \xF7 L\u2080", source: "campaign", cardMode: "captureRate", overviewKey: "payoffRatio", get: safe(rowPayoffRatio) },
      { letter: "w", aliases: [], name: "L_\u78E8\u635F", unit: "R", help: "L_\u78E8\u635F \xF7 L\u2080\uFF1A\u4E2D\u9014\u5BF9\u51B2\u7684\u635F\u76CA + \u6700\u7EC8\u5BF9\u51B2\u7684\u4EF7\u5DEE / \u6570\u91CF\u78E8\u635F", source: "campaign", cardMode: "executionWear", overviewKey: "executionWear", get: safe(rowExecutionWearR) },
      { letter: "g", aliases: [], name: "\u51E0\u4F55\u671F\u671B", unit: "\u500D", help: "1 + 0.1 \xD7 b\uFF08\u65B9\u6CD5\u4E00\uFF0C\u6309\u76C8\u4E8F\u6BD4\uFF09\uFF1B1.00 = \u4E0D\u8D5A\u4E0D\u4E8F", source: "campaign", cardMode: "geometricExpectancy", overviewKey: "geometricExpectancy", get: safe(rowGeometricGrowth) },
      { letter: "A", aliases: [], name: "\u4ED3\u4F4D\u653E\u5927", unit: "x", help: "(\u4E3B\u65B9\u5411\u603B\u540D\u4E49\u4ED3\u4F4D \u2212 \u955C\u50CF\u6B62\u76C8\u540D\u4E49\u4ED3\u4F4D) \xF7 \u4E3B\u529B\u5F00\u4ED3\u540D\u4E49\u4ED3\u4F4D", source: "campaign", cardMode: "positionAmplification", overviewKey: "positionAmplification", get: safe(rowPositionAmplification) },
      { letter: "y", aliases: [], name: "\u52A0\u4ED3\u6548\u7528", unit: "\xD7", help: "b \xF7 |\u03B7|\uFF1A\u6BCF\u5355\u4F4D\u9996\u4ED3\u6DA8\u8DCC\u5E45\u6362\u6765\u591A\u5C11\u76C8\u4E8F\u6BD4", source: "campaign", cardMode: "addEfficiency", overviewKey: "addEfficiency", get: safe(rowAddEfficiency) },
      { letter: "E", aliases: [], name: "\u7B97\u672F\u671F\u671B", unit: "R", help: "E\u1D62 = 50% \xD7 b \u2212 50%", source: "campaign", cardMode: "arithmeticExpectancy", overviewKey: "arithmeticExpectancy", get: safe((r) => computeCampaignExpectanciesFromMagicB(rowPayoffRatio(r)).arithmeticExpectancy) },
      { letter: "\u0394P", aliases: ["deltaP"], name: "\u5355\u4F4D\u6DA8\u5E45", unit: "U/\u5E01", help: "\u0394P = F \u2212 K\u2098\uFF1A\u79BB\u573A\u4EF7\u51CF\u6700\u540E\u652F\u6491", source: "campaign", cardMode: "unitRise", overviewKey: "unitRise", get: safe(rowUnitRise) },
      { letter: "U", aliases: [], name: "\u5355\u4F4D\u5229\u6DA6", unit: "USDT", help: "U = Q \xD7 \u0394P\uFF08Q = \u9996\u4ED3\u5E01\u6570\uFF09", source: "campaign", cardMode: "unitProfit", overviewKey: "unitProfit", get: safe(rowUnitProfit) },
      { letter: "W", aliases: [], name: "\u4ED3\u4F4D\u5229\u6DA6", unit: "USDT", help: "W = U \xD7 \u51E0\u4F55\u4ED3\u4F4D\uFF08\u5B9E\u9645\uFF09", source: "campaign", cardMode: "positionProfit", overviewKey: "positionProfit", get: safe(rowPositionProfit) },
      { letter: "W\u209C", aliases: ["Wt"], name: "\u4ED3\u4F4D\u5229\u6DA6\uFF08\u7406\u8BBA\uFF09", unit: "USDT", help: "U \xD7 \u51E0\u4F55\u4ED3\u4F4D\uFF08\u7406\u8BBA\uFF09", source: "campaign", get: safe(rowPositionProfitTheoretical) },
      { letter: "c", aliases: [], name: "\u9996\u4ED3\u6DA8\u8DCC\u5E45", unit: "%", help: "\u9996\u4ED3\u4ECE\u5F00\u4ED3\u5230\u5E73\u4ED3\u7684\u6DA8\u8DCC\u5E45\uFF08\u6309\u4E3B\u529B\u65B9\u5411\u8BB0\u6B63\u8D1F\uFF09\uFF1B\u4E3B\u529B\u672A\u5E73\u65F6\u6CA1\u6709", source: "campaign", cardMode: "mainPriceChange", overviewKey: "mainPriceChange", get: safe((r) => r.mainPriceChangePct) },
      { letter: "\u03B7", aliases: ["eta"], name: "\u9996\u4ED3\u6DA8\u8DCC\u5E45\u500D\u6570", unit: "\xD7", help: "\u03B7 = \u9996\u4ED3\u6DA8\u8DCC\u5E45 \xF7 \u9884\u671F\u56DE\u64A4", source: "campaign", cardMode: "mainPriceEfficiency", overviewKey: "mainPriceEfficiency", get: safe(rowMainPriceEfficiency) },
      { letter: "z", aliases: [], name: "\u6DA8\u5E45\u672A\u5151\u73B0", unit: "%", help: "\u5CF0\u503C\u6DA8\u5E45 \u2212 \u9996\u4ED3\u6DA8\u8DCC\u5E45\uFF08\u8981\u5148\u7B97\u51FA\u5CF0\u503C\u6DA8\u5E45\uFF09", source: "campaign", cardMode: "unrealizedPriceChangePct", overviewKey: "unrealizedPriceChangePct", get: safe(rowUnrealizedPriceChangePct) },
      { letter: "T", aliases: [], name: "\u955C\u50CF\u6B62\u76C8", unit: "\u7EA7", help: "\u955C\u50CF\u6B62\u76C8\u7684\u7ED3\u679C\u7B49\u7EA7 0\u20135\uFF080 = \u672A\u5B9E\u73B0\uFF09", source: "campaign", cardMode: "mirrorTp", get: safe(rowMirrorTpRank) },
      { letter: "L\u2080", aliases: ["L0"], name: "\u6700\u5927\u9884\u671F\u4E8F\u635F", unit: "USDT", help: "\u4E3B\u529B\u5F00\u4ED3\u540D\u4E49\u4ED3\u4F4D \xD7 \u9884\u671F\u56DE\u64A4\u6BD4\u4F8B\uFF1A\u5165\u573A\u65F6\u5728\u521D\u59CB\u5BF9\u51B2\u98CE\u9669\u8FB9\u754C\u4E0B\u7684\u6700\u5927\u4E8F\u635F", source: "campaign", overviewKey: "initialExpectedMaxLoss", get: safe((r) => r.initialExpectedMaxLoss) },
      { letter: "p", aliases: [], name: "\u5DF2\u5B9E\u73B0 P&L", unit: "USDT", help: "\u6574\u573A\u6218\u5F79\u5DF2\u5B9E\u73B0\u7684\u51C0\u76C8\u4E8F", source: "campaign", overviewKey: "realizedPnl", get: safe((r) => r.campaign.final_realized_pnl) },
      { letter: "h", aliases: [], name: "\u5CF0\u503C\u6DA8\u5E45", unit: "%", help: "\u6301\u4ED3\u671F\u95F4\u9996\u4ED3\u7684\u6700\u5927\u6D6E\u52A8\u6DA8\u5E45\uFF08\u6309 K \u7EBF\u7B97\uFF0C\u4EA4\u6613\u6218\u5F79\u5217\u8868\u7B97\u8FC7\u624D\u6709\uFF09", source: "campaign", overviewKey: "peakPriceChange", get: safe((r) => r.peakPriceChangePct) },
      { letter: "D", aliases: [], name: "\u52A8\u6001\u6700\u5927\u56DE\u64A4", unit: "%", help: "\u6301\u4ED3\u671F\u95F4\u6B64\u524D\u5CF0\u503C\u5230\u6B64\u540E\u8C37\u503C\u7684\u6700\u5927\u8DCC\u5E45\uFF08\u6309 K \u7EBF\u7B97\uFF0C\u4EA4\u6613\u6218\u5F79\u5217\u8868\u7B97\u8FC7\u624D\u6709\uFF09", source: "campaign", cardMode: "dynamicMaxDrawdownPct", overviewKey: "dynamicMaxDrawdownPct", get: safe((r) => r.dynamicMaxDrawdownPct) },
      // 【用户要求】2026-10-26 静态最大回撤；下标 ₛ = 静态
      { letter: "D\u209B", aliases: ["Ds"], name: "\u9759\u6001\u6700\u5927\u56DE\u64A4", unit: "%", help: "\u6301\u4ED3\u671F\u95F4\u6700\u4E0D\u5229\u4EF7\u683C\u79BB\u4E70\u5165\u4EF7\u7684\u8DCC\u5E45 \xF7 \u4E70\u5165\u4EF7\uFF08\u4E3B\u591A\u770B\u6700\u4F4E\u4EF7\u3001\u4E3B\u7A7A\u770B\u6700\u9AD8\u4EF7\uFF1B\u6309 K \u7EBF\u7B97\uFF0C\u4EA4\u6613\u6218\u5F79\u5217\u8868\u7B97\u8FC7\u624D\u6709\uFF09", source: "campaign", cardMode: "staticMaxDrawdownPct", overviewKey: "staticMaxDrawdownPct", get: safe((r) => r.staticMaxDrawdownPct) },
      { letter: "\u03BB", aliases: ["lev"], name: "\u6760\u6746\u500D\u6570", unit: "x", help: "\u4E3B\u529B\u5F00\u4ED3\u65F6\u7684\u521D\u59CB\u6760\u6746\uFF08\u8001\u6218\u5F79\u53D6\u5404\u817F\u6700\u5927\u6760\u6746\uFF09", source: "campaign", overviewKey: "mainLeverage", get: safe((r) => campaignLeverage(r.campaign, r.legs)) },
      { letter: "i", aliases: [], name: "\u81EA\u8BC4", unit: "\u7EA7", help: "\u6218\u5F79\u5C01\u9762\u4E0A\u7684\u81EA\u8BC4 1\u20135", source: "campaign", get: safe((r) => r.campaign.importance_weight) },
      { letter: "s", aliases: [], name: "\u4FE1\u53F7\u8BC4\u5206", unit: "\u7EA7", help: "\u4FE1\u53F7\u5E93\u91CC\u8FD9\u6761\u4FE1\u53F7\u7684\u661F\u7EA7 1\u20135\uFF1B\u6CA1\u8BC4\u5206 = \u7A7A\u3002\u5C5E\u4E8E\u4FE1\u53F7\u672C\u8EAB\uFF0C\u65F6\u95F4\u70B9\u662F\u90A3\u6761\u4FE1\u53F7\u7684\u65F6\u95F4", source: "signal" }
    ];
    METRIC_BY_LETTER = new Map(CAMPAIGN_METRIC_LETTERS.map((m) => [m.letter, m]));
    LETTER_BY_CARD_MODE = new Map(CAMPAIGN_METRIC_LETTERS.filter((m) => m.cardMode).map((m) => [m.cardMode, m.letter]));
    LETTER_BY_OVERVIEW_KEY = new Map(CAMPAIGN_METRIC_LETTERS.filter((m) => m.overviewKey).map((m) => [m.overviewKey, m.letter]));
  }
});

// src/lib/signalMarket.ts
var init_signalMarket = __esm({
  "src/lib/signalMarket.ts"() {
  }
});

// src/lib/deepDig/features.ts
function sellerNegativeFormula(formula, core) {
  if (formula.includes(SELLER_SIGN_MARK)) return formula;
  const program2 = compileFeatureFormula(formula).program;
  const last = program2.statements.at(-1);
  const names = new Set(program2.statements.flatMap((s) => s.name && (s.name === core || new RegExp(`^avg_${core}(?:_\\d+)?$`).test(s.name)) ? [s.name] : []));
  let capture = "";
  let result = last.name;
  if (!result) {
    result = "_seller_result";
    while (program2.statements.some((s) => s.name === result) || program2.inputs.has(result)) result += "_";
    const render = (n) => n.k === "num" ? String(n.v) : n.k === "var" ? n.name : n.k === "un" ? `(${n.op} ${render(n.a)})` : n.k === "bin" ? `(${render(n.a)} ${n.op} ${render(n.b)})` : `${n.name}(${n.args.map(render).join(", ")})`;
    capture = `
${result} = ${render(last.expr)}`;
  }
  names.delete(result);
  names.add(result);
  return `${formula}${capture}
${SELLER_SIGN_MARK}
# \u5356\u65B9\u8F93\u51FA\u53D6\u8D1F\uFF1A\u4E2D\u95F4\u91CF\u4FDD\u6301\u539F\u6837\uFF1B\u539F\u503C\u548C\u5DF2\u5B9A\u4E49\u7684\u5747\u503C\u4E00\u5E76\u8F6C\u6362\u3002
${[...names].map((name) => `${name} = -${name}`).join("\n")}`;
}
function featureParams(d) {
  const original = { BAR_MINUTES: intervalMs(intervalOf(d)) / 6e4, hl: halfLifeOf(d), \u534A\u8870\u671F: halfLifeOf(d), avgh: avgHoursOf(d), \u5E73\u5747\u65F6\u957F: avgHoursOf(d), MBI_N: mbiNOf(d), MBI_Z0: mbiZ0Of(d) };
  if (!featureUsesMbi2(d)) return original;
  const minutes = intervalMs(intervalOf(d)) / 6e4;
  return { ...original, MBI2_T_HOURS: mbi2HoursOf(d, minutes), MBI2_N: mbi2NOf(d, minutes), MBI2_Z0: mbi2Z0Of(d), MBI2_BAND: mbi2BandOf(d), MBI2_CONFIRM: mbi2ConfirmOf(d) };
}
function translateLegacyGroupExpr(expr) {
  return expr.replace(/[\p{L}_][\p{L}\p{N}_]*/gu, (id2) => LEGACY_GROUP_VARS[id2] ?? id2);
}
function upgradeGroupVars(d) {
  if (d.groupVars === 2) return d;
  return { ...d, positive: translateLegacyGroupExpr(d.positive), control: translateLegacyGroupExpr(d.control), groupVars: 2 };
}
function bearFeatureFormula(source, original, core, scale = 1, response = false) {
  const formula = source + "\n" + (response ? `${BEAR_RESPONSE_MARK}
seller_gain = 2
${core} = seller_response(${original}, seller_gain, ${scale})` : `${core} = min(${original}, 0)`);
  const names = new Set(compileFeatureFormula(formula).program.statements.flatMap((s) => s.name ? [s.name] : []));
  return appendResearchAverages(formula, names, { core, avg: "avg_" + core, avg2: "avg_" + core + "_2" }) + "\n" + core + " = " + core;
}
function createSellerRetentionCopy(source, spec) {
  const copy = copyFeatureDefinition(source, [source], Date.UTC(2026, 9, 30, 3));
  const program2 = compileFeatureFormula(source.formula).program, declared = new Set(program2.statements.map((s) => s.name));
  const last = program2.statements.at(-1);
  const render = (n) => n.k === "num" ? String(n.v) : n.k === "var" ? n.name : n.k === "un" ? `(${n.op} ${render(n.a)})` : n.k === "bin" ? `(${render(n.a)} ${n.op} ${render(n.b)})` : `${n.name}(${n.args.map(render).join(",")})`;
  const base = declared.has(source.chartCore ?? spec.sourceCore) ? source.chartCore ?? spec.sourceCore : last.name ?? render(last.expr);
  const built = retentionFormula(copy.formula, base, spec.core, spec.bound, source.researchWindowHours ?? 48);
  const names = new Set(compileFeatureFormula(built.formula).program.statements.flatMap((s) => s.name ? [s.name] : []));
  const formula = appendResearchAverages(built.formula, names, { core: spec.core, avg: "avg_" + spec.core, avg2: "avg_" + spec.core + "_2" }) + "\n" + spec.core + " = " + spec.core;
  return {
    ...copy,
    id: spec.id,
    name: source.name + "\uFF5C\u6210\u4EA4\u4FDD\u7559\u589E\u5F3A",
    short: source.short + "\xB7\u4FDD\u7559",
    builtin: true,
    chartCore: spec.core,
    sellerSignVersion: 1,
    retentionSourceId: source.id,
    retentionPrefix: built.prefix,
    retentionVersion: 1,
    formula,
    definition: source.definition + "\n\u72EC\u7ACB\u526F\u672C v1\uFF1A\u539F\u7B97\u6CD5\u5B8C\u6574\u4FDD\u7559\uFF0C\u65B0\u589E\u6210\u4EA4\u652F\u6301\u52A0\u6743\u7684\u5386\u53F2\u4EF7\u683C\u4F4D\u79FB\u91CD\u4F30\u3002\u5931\u5B88\u672A\u6536\u590D\u4E3A\u8D1F\uFF0C\u6536\u590D\u540E\u56DE\u5347\uFF1B\u4E3B\u52A8\u6210\u4EA4\u5931\u8861\u53CA\u5355\u4F4D\u5931\u8861\u4E0B\u884C\u51B2\u51FB\u4F5C\u4E3A\u6743\u91CD\u4EE3\u7406\uFF0C\u4E0D\u4EE3\u8868\u5B8C\u6574\u8BA2\u5355\u7C3FOFI\u6216\u56E0\u679C\u51B2\u51FB\u3002\u4EE5\u8FC7\u53BBavgh\u5C0F\u65F6\u6CE2\u52A8\u7387\u6807\u51C6\u5316\uFF0C\u6210\u4EA4\u57FA\u7EBF\u548C\u6CE2\u52A8\u7387\u53EA\u7528\u4E0A\u4E00\u6839\u53CA\u4EE5\u524D\uFF1B\u7F3A\u5931/\u7F3A\u6839/\u9884\u70ED\u4E0D\u8DB3\u4E0D\u8865\u96F6\u3002\u65B0\u589E\u5206\u91CF\u5728\u6700\u7EC8\u538B\u7F29\u524D\u6309gain\u5408\u6210\uFF08\u9ED8\u8BA40.5\uFF0Cgain=0\u6062\u590D\u539F\u8BFB\u6570\uFF09\uFF1B\u539F\u7A97\u53E3\u548C\u53C2\u6570\u4E0D\u7F29\u77ED\uFF0C\u65B0\u7A97\u53E3\u9ED8\u8BA4" + (source.researchWindowHours ?? 48) + "\u5C0F\u65F6\u3002\u56FA\u5B9A\u96F6\u4E2D\u5FC3\uFF0C\u539F\u59CB/\u5747\u503C\u5E8F\u5217\u4E0E\u5B58\u50A8\u7248\u672C\u72EC\u7ACB\uFF0C\u9608\u503C\u9700\u53E6\u884C\u9A8C\u8BC1\u3002"
  };
}
function ati6hDependencyOf(d) {
  if (d.ATI6H_dependency) return d.ATI6H_dependency;
  let source = MBI2_DEF;
  try {
    const saved = JSON.parse(readPersistedStateRaw(getUserPrefix() + FEATURES_KEY) ?? "[]");
    const found = Array.isArray(saved) ? saved.find((x) => x?.id === "mbi2") : null;
    if (found) source = { ...source, ...found };
  } catch {
  }
  return { formula: source.formula, MBI2_T_HOURS: source.MBI2_T_HOURS, MBI2_Z0: source.MBI2_Z0, MBI2_BAND: source.MBI2_BAND, MBI2_CONFIRM: source.MBI2_CONFIRM };
}
function dbl5VariantDefinition(timeframe) {
  const { id: id2, version, label, minutes, periodLabel } = DBL5_PROFILES[timeframe];
  return {
    ...DBL5_DEF,
    id: id2,
    chartTemplate: id2,
    name: label,
    short: label,
    interval: timeframe,
    researchWindowHours: 72 * minutes / 60,
    DBL5_config: { ...dbl5Defaults(timeframe) },
    definition: `\u6309\u5DF2\u6536\u76D8\u7684 ${periodLabel} K \u7EBF\u8BC6\u522B\u8FBE\u74E6\u65AF\u7BB1\u4F53\u548C\u9632\u5B88\u7EBF\u3002\u9ED8\u8BA4 n=3\uFF0C\u51E0\u4F55\u7A97\u53E3 72 \u6839\u3002`,
    formula: DBL5_DEF.formula.replace(DBL5_VERSION, version)
  };
}
function guardPlusInput(name) {
  return name === "DBL5P" ? "DBL5P_raw_value" : "DBL5P_raw_" + name.slice(6);
}
function createSellerFocusCopy(source, id2 = source.id + "-v2", now = SELLER_FOCUS_CREATED_AT) {
  const copy = copyFeatureDefinition(source, [source], now);
  let prefix2 = "focus2";
  while (new RegExp("\\b" + prefix2 + "(?:_|\\b)").test(copy.formula)) prefix2 += "_";
  const program2 = compileFeatureFormula(copy.formula).program;
  const render = (n) => {
    if (n.k === "num") return String(n.v);
    if (n.k === "var") return n.name;
    if (n.k === "un") return `(${n.op} ${render(n.a)})`;
    if (n.k === "bin") return `(${render(n.a)} ${n.op} ${render(n.b)})`;
    const args = n.args.map(render), original = FOCUS_BASE_ARITIES[n.name];
    if (original?.includes(args.length)) args.push(prefix2 + "_h", prefix2 + "_weight");
    return n.name + "(" + args.join(", ") + ")";
  };
  const markers = [...new Set(copy.formula.match(/# seller-[\w-]+/g) ?? [])];
  const formula = [
    ...markers,
    "# seller-focus-v2\uFF1A\u539F\u7A97\u53E3\u4E0D\u53D8\uFF1B\u6700\u8FD12\u5C0F\u65F6\u76F8\u5BF9\u66F4\u65E9\u6570\u636E3\u500D\u6743\u91CD",
    prefix2 + "_h = 2",
    prefix2 + "_weight = 3",
    ...program2.statements.map((s) => (s.name ? s.name + " = " : "") + render(s.expr))
  ].join("\n");
  const state = source.id === "state";
  return {
    ...copy,
    id: id2,
    name: source.name + "\uFF5C\u7248\u672C2",
    short: state ? "\u72B6\u6001 S\xB7\u7248\u672C2" : source.short + "\xB7\u7248\u672C2",
    chartCore: source.chartCore ?? FOCUS_SOURCE_CORES[source.id] ?? program2.statements.at(-1)?.name ?? void 0,
    sellerSignVersion: 1,
    focusSourceId: source.id,
    focusVersion: 2,
    focusPrefix: prefix2,
    formula,
    definition: source.definition + "\n\u7248\u672C2\uFF1A\u72EC\u7ACB\u590D\u5236\u521B\u5EFA\u65F6\u7684\u8D26\u53F7\u516C\u5F0F\u548C\u53C2\u6570\uFF0C\u4FDD\u7559\u539F\u7A97\u53E3\u3001\u5468\u671F\u3001\u534A\u8870\u671F\u53CA\u9884\u70ED\uFF1B\u5386\u53F2\u805A\u5408\u6838\u4E2D\u6700\u8FD12\u5C0F\u65F6\u7684\u76F8\u5BF9\u6743\u91CD\u4E3A\u66F4\u65E9\u6570\u636E\u76843\u500D\u3002\u53EF\u5728\u672C\u526F\u672C\u516C\u5F0F\u9876\u90E8\u4FEE\u6539 " + prefix2 + "_h \u548C " + prefix2 + "_weight\uFF1B\u6743\u91CD1\u6062\u590D\u590D\u5236\u65F6\u539F\u8BA1\u7B97\u3002\u91CD\u52A0\u6743\u5747\u503C\u3001\u6CE2\u52A8\u5C3A\u5EA6\u3001\u9012\u63A8/\u6210\u4EA4\u6838\uFF1B\u6781\u503C\u4E0E\u65F6\u95F4\u6EDE\u540E\u4FDD\u6301\u539F\u4E49\uFF0C\u4E0D\u76F4\u63A5\u653E\u5927\u6700\u7EC8\u5206\u6570\u3002" + (state ? "\u72B6\u6001S\u4FDD\u63010\u20131\u523B\u5EA6\uFF0C0.5\u4E3A\u5747\u8861\uFF0C\u8D8A\u4F4E\u8D8A\u504F\u5356\u65B9\uFF1B\u56FE\u8868\u6CBF\u7528\u539FS\u76840.6\u53C2\u8003\u7EBF\u3002" : "\u96F6\u4ECD\u4E3A\u5747\u8861\uFF0C\u5356\u65B9\u4ECD\u4E3A\u8D1F\u503C\u3002") + "\u539F\u9608\u503C\u4E0D\u81EA\u52A8\u6CBF\u7528\u3002"
  };
}
function newFeatureTemplate(now) {
  return {
    id: `f-${now.toString(36)}`,
    name: "\u65B0\u7279\u5F81\u503C",
    short: "X",
    definition: "",
    formula: "# \u4F8B\uFF1A\u6700\u8FD1 144 \u6839 K \u7EBF\u7684\u6DA8\u8DCC\u5E45\uFF085 \u5206\u949F\u5468\u671F = 12 \u5C0F\u65F6\uFF09\nln(C / prev(C, 144))",
    scale: 100,
    unit: "%",
    positive: DEFAULT_POSITIVE,
    control: DEFAULT_CONTROL,
    source: "campaigns",
    groupVars: 2,
    createdAt: now
  };
}
function copyFeatureDefinition(source, existing, now = Date.now()) {
  let id2 = newFeatureTemplate(now).id, serial = 1;
  while (existing.some((d) => d.id === id2)) id2 = newFeatureTemplate(now).id + "-" + serial++;
  let number = 1;
  const name = () => source.name + "\uFF08\u526F\u672C" + (number === 1 ? "" : number) + "\uFF09";
  while (existing.some((d) => d.name === name())) number++;
  const { builtin: _builtin, removed: _removed, visibilityVersion: _visibility, ...copy } = structuredClone(source);
  return {
    ...copy,
    id: id2,
    name: name(),
    short: source.short + "\xB7\u526F\u672C" + (number === 1 ? "" : number),
    chartTemplate: featureTemplateId(source),
    createdAt: now
  };
}
function compileFeatureFormula(formula) {
  const program2 = parseFormula(formula, /* @__PURE__ */ new Set([
    ...SERIES_VARIABLES.map((v) => v.name),
    ...PARAM_NAMES,
    ...ATI6H_NUMERIC_FIELDS.map((n) => n === "ATI6H" ? "ATI6H_raw_value" : "ATI6H_raw_" + n.slice(6)),
    ...DBL5_FIELDS.map((n) => n === "DBL5" ? "DBL5_raw_value" : "DBL5_raw_" + n.slice(5)),
    ...DBL5_GUARD_PLUS_NUMERIC.map(guardPlusInput),
    ...IMPULSE_1115_CLASSIFICATION_FIELDS.map((n) => n === "DBL5C" ? "DBL5C_raw_value" : "DBL5C_raw_" + n.slice(6)),
    ...SBS5M_FIELDS.map((n) => n === "SBS5M" ? "SBS5M_raw_value" : "SBS5M_raw_" + n.slice(6)),
    ...PRS6H_FIELDS.map((n) => n === "PRS6H" ? "PRS6H_raw_value" : "PRS6H_raw_" + n.slice(6))
  ]));
  const usesImpulse1115Classification = [...program2.inputs].some((name) => name.startsWith("DBL5C_raw_"));
  const usesDbl5GuardPlus = usesImpulse1115Classification || [...program2.inputs].some((name) => name.startsWith("DBL5P_raw_"));
  return { program: program2, usesAmounts: [...program2.inputs].some((n) => AMOUNT_VARIABLES.has(n)), usesBtc: program2.inputs.has("CB"), usesMbi: featureUsesMbi({ formula }), usesMbi2: featureUsesMbi2({ formula }), usesAti6h: [...program2.inputs].some((n) => n.startsWith("ATI6H_raw_")), usesDbl5: usesDbl5GuardPlus || [...program2.inputs].some((n) => n.startsWith("DBL5_raw_")), usesDbl5GuardPlus, ...usesImpulse1115Classification ? { usesImpulse1115Classification } : {}, usesSbs5m: [...program2.inputs].some((n) => n.startsWith("SBS5M_raw_")), usesPrs6h: [...program2.inputs].some((n) => n.startsWith("PRS6H_raw_")) };
}
var FEATURES_KEY, ORIGINAL_SELLER_CORES, FOCUS_SOURCE_CORES, btcFreeId, BTC_ADJUSTED_SELLER_IDS, SELLER_FEATURE_CORES, SELLER_SIGN_MARK, BEAR_RESPONSE_MARK, DEFAULT_INTERVAL, DEFAULT_HALF_LIFE_HOURS, DEFAULT_AVG_HOURS, INTERVAL_LABEL, featureTemplateId, intervalOf, halfLifeOf, avgHoursOf, featureUsesMbi, featureUsesMbi2, PARAM_VARIABLES, PARAM_NAMES, SERIES_VARIABLES, AMOUNT_VARIABLES, DEFAULT_GROUPS, DEFAULT_POSITIVE, DEFAULT_CONTROL, LEGACY_GROUP_VARS, LEGACY_DRIFT_SPEED_FORMULA, EMA_DRIFT_SPEED_FORMULA, LEGACY_V_DRIFT_SPEED_FORMULA, LEGACY_A_DRIFT_SPEED_FORMULA, DRIFT_SPEED_FORMULA, DRIFT_SPEED_DEF, BSS_FORMULA, BSS_NEW_HEAD, BSS_NEW_VD, BSS_LINE_UPGRADES, BSS_DEF, DRIFT_SPEED_Z_FORMULA, DRIFT_SPEED_Z_DEF, CBA_FORMULA, CBA_DEF, CBI_FORMULA, CBI_DEF, CBA2_DEF, CBI2_FORMULA, CBI2_DEF, MBI_FORMULA, MBI_DEF, mbi2Copy, _oldN, _oldZ, mbi2Own, MBI2_FORMULA, MBI2_DEF, CDI2_FORMULA, CDI2_DEF, STATE_FORMULA, STATE_DEF, STATE2_FORMULA, STATE2_DEF, SELLER_CONTROL_FORMULA, SELLER_CONTROL_DEF, DSS_FORMULA, DSS_DEF, CDA_FORMULA, CDA_DEF, CDA_HOURLY_DEF, CTBA_DEF, ctba12hCopy, CTBA_12H_DEF, LEGACY_MBI_BEAR_FORMULA, LEGACY_CTBA_BEAR_FORMULA, MBI_BEAR_DEF, CTBA_BEAR_DEF, mbi2SellerCopy, MBI2_BEAR_DEF, ctba12hSellerCopy, CTBA_12H_BEAR_DEF, retentionSources, SELLER_RETENTION_FEATURES, ATI6H_DEF, PRS6H_DEF, SBS5M_DEF, SBS5M_DIMENSIONS, DBL5_DEF, featureUsesDbl5GuardPlus, DBL5_GUARD_PLUS_DEF, IMPULSE_1115_CLASSIFICATION_DEF, DBL5_DIMENSIONS, DBL5_HOURLY_FEATURES, ORIGINAL_BUILTIN_FEATURES, SELLER_FOCUS_CREATED_AT, SELLER_FOCUS_FEATURES, BTC_ADJUSTED_FEATURES, BTC_FREE_FEATURES, BSS_COMPONENT_FEATURES, ATR_PRICE_PCT_DEF, BUILTIN_FEATURES, definitionKey;
var init_features = __esm({
  "src/lib/deepDig/features.ts"() {
    init_cdaPeriods();
    init_dbl5mMarketRules();
    init_dbl5GuardPlus();
    init_impulse1115Classification();
    init_dbl5m();
    init_dbl5m();
    init_sbs5m();
    init_prs6h();
    init_persistedStateStorage();
    init_userStoragePrefix();
    init_ati6h();
    init_mbi2();
    init_sellerRetention();
    init_ctba();
    init_cba2();
    init_mbi2();
    init_mbi();
    init_researchAverageFormula();
    init_recentFocusMath();
    init_marketData();
    init_grouping();
    init_campaignMetricLetters();
    init_signalMarket();
    init_formula();
    FEATURES_KEY = "deep_dig_features_v1";
    ORIGINAL_SELLER_CORES = { cdi2: "CDI2", dss: "DSS", "seller-control": "bc", cda: "CDA", "mbi-bear": "MBI_bear", "ctba-bear": "CTBA_bear", "mbi2-bear": "MBI2_bear", "ctba_12h-bear": "CTBA_12H_bear", ...Object.fromEntries(SELLER_RETENTION_SPECS.map((s) => [s.id, s.core])) };
    FOCUS_SOURCE_CORES = { ...ORIGINAL_SELLER_CORES, state: "state" };
    btcFreeId = (id2) => `${id2}-no-btc-v1`;
    BTC_ADJUSTED_SELLER_IDS = ["cdi2", "cdi2-retain"];
    SELLER_FEATURE_CORES = {
      [CDA_HOURLY_ID]: "CDA",
      ...ORIGINAL_SELLER_CORES,
      ...Object.fromEntries(Object.entries(ORIGINAL_SELLER_CORES).map(([id2, core]) => [id2 + "-v2", core])),
      ...Object.fromEntries(BTC_ADJUSTED_SELLER_IDS.flatMap((id2) => [id2, `${id2}-v2`].map((sourceId) => [btcFreeId(sourceId), ORIGINAL_SELLER_CORES[id2]])))
    };
    SELLER_SIGN_MARK = "# seller-negative-v1";
    BEAR_RESPONSE_MARK = "# seller-response-v2";
    DEFAULT_INTERVAL = "5m";
    DEFAULT_HALF_LIFE_HOURS = 6;
    DEFAULT_AVG_HOURS = 24;
    INTERVAL_LABEL = { "1m": "1 \u5206\u949F", "3m": "3 \u5206\u949F", "5m": "5 \u5206\u949F", "15m": "15 \u5206\u949F", "30m": "30 \u5206\u949F", "1h": "1 \u5C0F\u65F6", "2h": "2 \u5C0F\u65F6", "4h": "4 \u5C0F\u65F6", "6h": "6 \u5C0F\u65F6", "12h": "12 \u5C0F\u65F6", "1d": "1 \u5929" };
    featureTemplateId = (d) => d.chartTemplate ?? d.id;
    intervalOf = (d) => dbl5ProfileForFeature(featureTemplateId(d))?.timeframe ?? (usesHourlyCda(d) ? "1h" : ["cba-2", "ctba", "sbs_5m"].includes(featureTemplateId(d) ?? "") ? "5m" : d.interval ?? DEFAULT_INTERVAL);
    halfLifeOf = (d) => d.halfLifeHours != null && d.halfLifeHours > 0 ? d.halfLifeHours : DEFAULT_HALF_LIFE_HOURS;
    avgHoursOf = (d) => d.avgHours != null && d.avgHours > 0 ? d.avgHours : DEFAULT_AVG_HOURS;
    featureUsesMbi = (d) => d.id === "mbi" || /\bmbiz\s*\(/.test((d.formula ?? "").replace(/(#|\/\/).*$/gm, ""));
    featureUsesMbi2 = (d) => d.id === "mbi2" || /\bmbiz2\s*\(/.test((d.formula ?? "").replace(/(#|\/\/).*$/gm, ""));
    PARAM_VARIABLES = [
      { name: "BAR_MINUTES", alias: "BAR_MINUTES", label: "\u5F53\u524D\u8BA1\u7B97\u5468\u671F\u7684\u5206\u949F\u6570\uFF08\u81EA\u52A8\u8BFB\u53D6\uFF0C\u4E0D\u624B\u586B\uFF09" },
      { name: "hl", alias: "\u534A\u8870\u671F", label: "\u534A\u8870\u671F\uFF08\u5C0F\u65F6\uFF0C\u4E0A\u9762\u9009\u7684\uFF1B\u4E5F\u53EF\u5199\u300C\u534A\u8870\u671F\u300D\uFF09" },
      { name: "avgh", alias: "\u5E73\u5747\u65F6\u957F", label: "\u5E73\u5747\u65F6\u957F\uFF08\u5C0F\u65F6\uFF0C\u4E0A\u9762\u9009\u7684\uFF1B\u4E5F\u53EF\u5199\u300C\u5E73\u5747\u65F6\u957F\u300D\uFF09\uFF0C\u914D avg(x, avgh) \u7528" },
      { name: "MBI2_N", alias: "MBI2_N", label: "MBI2 \u6309\u5C0F\u65F6\u548C\u5468\u671F\u6D3E\u751F\u7684\u6839\u6570\uFF08\u4E0D\u624B\u586B\uFF09" },
      { name: "MBI2_T_HOURS", alias: "MBI2_T_HOURS", label: "MBI2 \u65E5\u5386\u65F6\u957F\uFF08\u5C0F\u65F6\uFF09" },
      { name: "MBI2_BAND", alias: "MBI2_BAND", label: "MBI2 \u7F13\u51B2\u5E26\u534A\u5BBD\uFF08\u9ED8\u8BA40.2\uFF09" },
      { name: "MBI2_CONFIRM", alias: "MBI2_CONFIRM", label: "MBI2 \u786E\u8BA4\u9608\u503C\uFF08\u9ED8\u8BA40.8\uFF09" },
      { name: "MBI2_Z0", alias: "MBI2_Z0", label: "MBI2 \u72EC\u7ACB\u9971\u548C\u5C3A\u5EA6" },
      { name: "MBI_N", alias: "MBI_N", label: `MBI \u8870\u51CF\u5468\u671F\uFF08K \u7EBF\u6839\u6570\uFF0C\u9ED8\u8BA4 ${MBI_N}\uFF1B\u03B1 \u4E25\u683C\u7B49\u4E8E 1/n\uFF09` },
      { name: "MBI_Z0", alias: "MBI_Z0", label: `MBI \u9971\u548C\u5C3A\u5EA6\uFF08\u9ED8\u8BA4 ${MBI_Z0}\uFF09` }
    ];
    PARAM_NAMES = PARAM_VARIABLES.flatMap((p) => [p.name, p.alias]);
    SERIES_VARIABLES = [
      { name: "T", label: "K\u7EBF\u5F00\u76D8\u65F6\u95F4\uFF08\u6BEB\u79D2\uFF09" },
      { name: "C", label: "\u6536\u76D8\u4EF7" },
      { name: "O", label: "\u5F00\u76D8\u4EF7" },
      { name: "H", label: "\u6700\u9AD8\u4EF7" },
      { name: "L", label: "\u6700\u4F4E\u4EF7" },
      { name: "Q", label: "\u6210\u4EA4\u989D\uFF08USDT\uFF09= B + S" },
      { name: "B", label: "\u4E3B\u52A8\u4E70\u5165\u6210\u4EA4\u989D\uFF08USDT\uFF09" },
      { name: "S", label: "\u4E3B\u52A8\u5356\u51FA\u6210\u4EA4\u989D\uFF08USDT\uFF09= Q \u2212 B" },
      { name: "E", label: "\u6210\u4EA4\u5747\u4EF7 VWAP = \u6210\u4EA4\u989D \xF7 \u6210\u4EA4\u91CF" },
      { name: "CB", label: "\u540C\u65F6\u6BB5 BTCUSDT \u6536\u76D8\u4EF7\uFF08\u7528\u5230\u65F6\u53E6\u53D6\uFF1B\u53D6\u4E0D\u5230\u4E3A\u7A7A\uFF09" }
    ];
    AMOUNT_VARIABLES = /* @__PURE__ */ new Set(["Q", "B", "S", "E"]);
    DEFAULT_GROUPS = {
      // 与原 Deep RSA 分组一致：理论 b 或盈亏比 > 3 为正样本，< 0.5 为对照
      campaigns: { positive: "B\u209C > 3 or b > 3", control: "B\u209C < 0.5 or b < 0.5" },
      // 与原信号分组一致：≥ 3 星为正样本，< 3 星为对照
      signals: { positive: "s >= 3", control: "s < 3" }
    };
    DEFAULT_POSITIVE = DEFAULT_GROUPS.campaigns.positive;
    DEFAULT_CONTROL = DEFAULT_GROUPS.campaigns.control;
    LEGACY_GROUP_VARS = { b: "B\u209C", r: "b", pnl: "p", chg: "c", wear: "w" };
    LEGACY_DRIFT_SPEED_FORMULA = [
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u91D1\u989D\uFF08USDT\uFF09\uFF0CQ = B + S",
      "N = abs(B - S)              # \u4E3B\u52A8\u51C0\u8D44\u91D1",
      "F = ln(1 + N / ema(Q, 6))   # \u8D44\u91D1\u529B\u91CF\uFF1A\u51C0\u8D44\u91D1\u6BD4\u5E73\u65F6\u7684\u6210\u4EA4\u989D\u5F02\u5E38\u591A\u5C11",
      "A = (B - S) / Q             # \u4E3B\u52A8\u4E70\u65B9\u4F18\u52BF",
      "G = 1 + max(A, 0)           # \u4E70\u65B9\u4F18\u52BF\u6743\u91CD",
      "R = ln(C / prev(C))         # \u4EF7\u683C\u53D8\u5316",
      "U = nz(F * G * R)           # \u5355\u6839\u63A8\u52A8\u529B\uFF08\u7F3A\u6570\u636E\u7684\u90A3\u6839\u8BB0 0\uFF09",
      "V = ema(U, 6, 0)            # \u6F02\u79FB\u901F\u5EA6\uFF1A\u534A\u8870\u671F 6 \u5C0F\u65F6\u6307\u6570\u5E73\u6ED1"
    ].join("\n");
    EMA_DRIFT_SPEED_FORMULA = [
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u91D1\u989D\uFF08USDT\uFF09\uFF0CQ = B + S\uFF1Bhl = \u4E0A\u9762\u9009\u7684\u534A\u8870\u671F\uFF08\u5C0F\u65F6\uFF09",
      "N = abs(B - S)              # \u4E3B\u52A8\u51C0\u8D44\u91D1",
      "F = ln(1 + N / ema(Q, hl))  # \u8D44\u91D1\u529B\u91CF\uFF1A\u51C0\u8D44\u91D1\u6BD4\u5E73\u65F6\u7684\u6210\u4EA4\u989D\u5F02\u5E38\u591A\u5C11",
      "A = (B - S) / Q             # \u4E3B\u52A8\u4E70\u65B9\u4F18\u52BF",
      "G = 1 + max(A, 0)           # \u4E70\u65B9\u4F18\u52BF\u6743\u91CD",
      "R = ln(C / prev(C))         # \u4EF7\u683C\u53D8\u5316",
      "U = nz(F * G * R)           # \u5355\u6839\u63A8\u52A8\u529B\uFF08\u7F3A\u6570\u636E\u7684\u90A3\u6839\u8BB0 0\uFF09",
      "V = ema(U, hl, 0)           # \u6F02\u79FB\u901F\u5EA6\uFF1A\u6309\u534A\u8870\u671F hl \u6307\u6570\u5E73\u6ED1"
    ].join("\n");
    LEGACY_V_DRIFT_SPEED_FORMULA = [
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u91D1\u989D\uFF08USDT\uFF09\uFF0CQ = B + S\uFF1Bhl = \u534A\u8870\u671F\uFF0Cavgh = \u5E73\u5747\u65F6\u957F\uFF08\u5C0F\u65F6\uFF0C\u90FD\u5728\u4E0B\u9762\u9009\uFF09",
      "N = abs(B - S)                 # \u4E3B\u52A8\u51C0\u8D44\u91D1",
      "F = ln(1 + N / avg(Q, avgh))   # \u8D44\u91D1\u529B\u91CF\uFF1A\u51C0\u8D44\u91D1\u6BD4\u8FC7\u53BB avgh \u5C0F\u65F6\u7684\u5E73\u5747\u6210\u4EA4\u989D\u5F02\u5E38\u591A\u5C11",
      "A = (B - S) / Q                # \u4E3B\u52A8\u4E70\u65B9\u4F18\u52BF",
      "G = 1 + max(A, 0)              # \u4E70\u65B9\u4F18\u52BF\u6743\u91CD",
      "R = ln(C / prev(C))            # \u4EF7\u683C\u53D8\u5316",
      "U = nz(F * G * R)              # \u5355\u6839\u63A8\u52A8\u529B\uFF08\u7F3A\u6570\u636E\u7684\u90A3\u6839\u8BB0 0\uFF09",
      "V = ema(U, hl, 0)              # \u6F02\u79FB\u901F\u5EA6\uFF1A\u6309\u534A\u8870\u671F hl \u6307\u6570\u5E73\u6ED1"
    ].join("\n");
    LEGACY_A_DRIFT_SPEED_FORMULA = LEGACY_V_DRIFT_SPEED_FORMULA.replace("V = ema(U, hl, 0)", "a = ema(U, hl, 0)");
    DRIFT_SPEED_FORMULA = LEGACY_A_DRIFT_SPEED_FORMULA.replace("F = ln(", "f = ln(").replace("U = nz(F * G * R)", "F = nz(f * G * R)").replace("ema(U, hl, 0)", "ema(F, hl, 0)").replace("\u5355\u6839\u63A8\u52A8\u529B", "\u5355\u6839\u63A8\u529B");
    DRIFT_SPEED_DEF = {
      id: "drift-speed",
      visibilityVersion: 1,
      name: "\u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 DSP\xB7a",
      short: "a",
      definition: "\u8FDB\u573A\u524D\u6700\u540E\u4E00\u6839 K \u7EBF\u4E0A\uFF0C\u52A8\u6001\u8C22\u6797\u70B9\uFF08\u591A\u7A7A\u535A\u5F08\u7684\u5747\u8861\u4EF7\uFF09\u6BCF\u6839\u5F80\u4E0A\uFF08+\uFF09\u6216\u5F80\u4E0B\uFF08\u2212\uFF09\u79FB\u52A8\u591A\u5C11\uFF1A\u51C0\u8D44\u91D1\u529B\u91CF \xD7 \u4E70\u65B9\u4F18\u52BF\u6743\u91CD \xD7 \u6DA8\u8DCC\u5E45\uFF0C\u6309\u534A\u8870\u671F\u6307\u6570\u5E73\u6ED1\uFF08\u5468\u671F\u3001\u534A\u8870\u671F\u89C1\u4E0B\uFF09\u3002",
      formula: DRIFT_SPEED_FORMULA,
      scale: 1e4,
      unit: "\u57FA\u70B9/\u6839",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    BSS_FORMULA = [
      "# BSS = 0.45\xB7M\u6807\u51C6\u5316 + 0.25\xB7Vd + 0.30\xB7A\uFF0C\u22121 ~ 1\uFF1BVd = V \u968F\u4EF7\u683C\u65B9\u5411\u7684\u52A0\u51CF\u5206\uFF1B\u8BA2\u5355\u7C3F I \u6CA1\u6709\u5386\u53F2\u6570\u636E\uFF0C\u53BB\u6389",
      "# Q = \u6210\u4EA4\u989D\uFF0CB / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF08USDT\uFF09\uFF1Bavgh = \u6807\u51C6\u5316\u7A97\u53E3\uFF08\u4E0B\u9762\u9009\uFF0C\u9ED8\u8BA4 24 \u5C0F\u65F6\uFF09",
      "n = 1                                   # \u8FD1\u671F\u7A97\u53E3\uFF08\u5C0F\u65F6\uFF09",
      "M = C / ago(C, n) - 1                   # \u4EF7\u683C\u52A8\u91CF\uFF1A\u8FD1 n \u5C0F\u65F6\u6DA8\u8DCC\u5E45",
      "V = avg(Q, n) / avg(Q, avgh)            # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF1A\u8FD1 n \u5C0F\u65F6\u5E73\u5747\u6210\u4EA4\u989D \xF7 \u8FD1 avgh \u5C0F\u65F6\u5E73\u5747",
      "A = (avg(B, n) - avg(S, n)) / avg(Q, n) # \u6210\u4EA4\u653B\u51FB\u6027\uFF1A(\u4E3B\u52A8\u4E70 \u2212 \u4E3B\u52A8\u5356) \xF7 \u5408\u8BA1\uFF0C\u22121 ~ 1",
      "Mz = tanh(zscore(M, avgh))              # M \u6807\u51C6\u5316\uFF1A\u6EDA\u52A8 z-score \u538B\u5230 \u22121 ~ 1",
      "Vz = tanh(zscore(V, avgh))              # V \u6807\u51C6\u5316",
      "Vd = if(M > 0, Vz, if(M < 0, min(-Vz, 0), 0))   # \u6DA8\u65F6\u653E\u91CF\u52A0\u5206\u3001\u7F29\u91CF\u6263\u5206\uFF1B\u8DCC\u65F6\u653E\u91CF\u6263\u5206\u3001\u7F29\u91CF\u4E0D\u52A0\u5206",
      "BSS = 0.45 * Mz + 0.25 * Vd + 0.30 * A"
    ].join("\n");
    BSS_NEW_HEAD = "# BSS = 0.45\xB7M\u6807\u51C6\u5316 + 0.25\xB7Vd + 0.30\xB7A\uFF0C\u22121 ~ 1\uFF1BVd = V \u968F\u4EF7\u683C\u65B9\u5411\u7684\u52A0\u51CF\u5206\uFF1B\u8BA2\u5355\u7C3F I \u6CA1\u6709\u5386\u53F2\u6570\u636E\uFF0C\u53BB\u6389";
    BSS_NEW_VD = "Vd = if(M > 0, Vz, if(M < 0, min(-Vz, 0), 0))   # \u6DA8\u65F6\u653E\u91CF\u52A0\u5206\u3001\u7F29\u91CF\u6263\u5206\uFF1B\u8DCC\u65F6\u653E\u91CF\u6263\u5206\u3001\u7F29\u91CF\u4E0D\u52A0\u5206";
    BSS_LINE_UPGRADES = [
      { match: (l) => l.startsWith("# BSS = 0.45\xB7M\u6807\u51C6\u5316 + 0.25\xB7V\u6807\u51C6\u5316 + 0.30\xB7A") || l.startsWith("# BSS = 0.45\xB7M\u6807\u51C6\u5316 + 0.25\xB7sign(M)\xB7V\u6807\u51C6\u5316 + 0.30\xB7A"), to: BSS_NEW_HEAD },
      { match: (l) => l === "BSS = 0.45 * Mz + 0.25 * Vz + 0.30 * A", to: `${BSS_NEW_VD}
BSS = 0.45 * Mz + 0.25 * Vd + 0.30 * A` },
      { match: (l) => /^Vd = sign\(M\) \* Vz\b/.test(l), to: BSS_NEW_VD }
    ];
    BSS_DEF = {
      id: "bss",
      name: "\u4E70\u5356\u5F3A\u5EA6\u7EFC\u5408\u5206 BSS",
      short: "BSS",
      definition: "\u8FDB\u573A\u524D\u6700\u540E\u4E00\u6839 K \u7EBF\u4E0A\u7684\u4E70\u5356\u5F3A\u5EA6\uFF08\u22121 ~ 1\uFF09\uFF1A0.45 \xD7 \u4EF7\u683C\u52A8\u91CF M \u6807\u51C6\u5316 + 0.25 \xD7 \u76F8\u5BF9\u6210\u4EA4\u91CF V \u6807\u51C6\u5316 + 0.30 \xD7 \u6210\u4EA4\u653B\u51FB\u6027 A\u3002> 0.55 \u4E14 M > 0 \u4E70\u65B9\u4F18\u52BF\u660E\u786E\uFF1B\u4ECE\u9AD8\u4F4D\u56DE\u843D\u5230 < 0.2 \u6216 A \u8F6C\u8D1F = \u5F31\u4E86\uFF08\u9608\u503C\u9700\u81EA\u884C\u9A8C\u8BC1\uFF09\u3002\u8BA2\u5355\u7C3F\u6CA1\u6709\u5386\u53F2\uFF0C\u677F\u4E0D\u5E73\u8861 I \u53BB\u6389\u3002",
      formula: BSS_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    DRIFT_SPEED_Z_FORMULA = [
      "# \u6CE2\u52A8\u7387\u5F52\u4E00\u5316\uFF1AR / sd(R)\uFF0C\u672A\u51CF\u5747\u503C\uFF1B\u518D\u52A0\u6743\u548C\u5E73\u6ED1\u540E\u7684 az \u4E0D\u662F\u6807\u51C6 Z \u5206\u6570\uFF0C0 \u4E3A\u51C0\u63A8\u529B\u65B9\u5411\u5206\u754C",
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u91D1\u989D\uFF08USDT\uFF09\uFF0CQ = B + S\uFF1Bhl = \u534A\u8870\u671F\uFF0Cavgh = \u5E73\u5747\u65F6\u957F\uFF08\u5C0F\u65F6\uFF0C\u90FD\u5728\u4E0B\u9762\u9009\uFF09",
      "N = abs(B - S)                 # \u4E3B\u52A8\u51C0\u8D44\u91D1",
      "f = ln(1 + N / avg(Q, avgh))   # \u8D44\u91D1\u529B\u91CF\uFF1A\u51C0\u8D44\u91D1\u6BD4\u8FC7\u53BB avgh \u5C0F\u65F6\u7684\u5E73\u5747\u6210\u4EA4\u989D\u5F02\u5E38\u591A\u5C11",
      "A = (B - S) / Q                # \u4E3B\u52A8\u4E70\u65B9\u4F18\u52BF",
      "G = 1 + max(A, 0)              # \u4E70\u65B9\u4F18\u52BF\u6743\u91CD",
      "R = ln(C / prev(C))            # \u4EF7\u683C\u53D8\u5316",
      "Rz = R / sd(R, avgh)           # \u6CE2\u52A8\u7387\u7F29\u653E\u7684\u4EF7\u683C\u53D8\u5316\uFF1A\u672A\u51CF\u5747\u503C\uFF0C\u4E0D\u662F\u6807\u51C6 Z \u5206\u6570",
      "F = nz(f * G * Rz)             # \u5355\u6839\u63A8\u529B\uFF08\u6807\u51C6\u5DEE\u5355\u4F4D\uFF1B\u7F3A\u6570\u636E\u7684\u90A3\u6839\u8BB0 0\uFF09",
      "az = ema(F, hl, 0)             # \u6CE2\u52A8\u7387\u5F52\u4E00\u5316\u63A8\u529B\uFF1A\u6309\u534A\u8870\u671F hl \u6307\u6570\u5E73\u6ED1"
    ].join("\n");
    DRIFT_SPEED_Z_DEF = {
      id: "drift-speed-z",
      name: "\u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 DSP\xB7az\uFF08\u6CE2\u52A8\u7387\u5F52\u4E00\u5316\uFF09",
      short: "az",
      definition: "\u539F\u59CB az = EMA(f \xD7 G \xD7 R / sd(R))\uFF0C\u56FE\u4E0A\u8BFB\u6570\u4E3A 100 \xD7 az\u3002\u4EC5\u6309\u6CE2\u52A8\u7387\u7F29\u653E\u6DA8\u8DCC\uFF0C\u4E0D\u51CF\u5747\u503C\uFF1B\u6700\u7EC8\u6307\u6807\u672A\u6807\u51C6\u5316\u3001\u65B9\u5DEE\u4E0D\u4FDD\u8BC1\u4E3A 1\u30020 \u662F\u51C0\u63A8\u529B\u65B9\u5411\u5206\u754C\uFF0C15 \u4EC5\u5BF9\u5E94\u672A\u4E58\u663E\u793A\u500D\u6570\u524D\u7684 0.15\uFF0C\u4E0D\u662F\u7406\u8BBA\u5F3A\u5F31\u95E8\u69DB\u6216 15 \u4E2A\u6807\u51C6\u5DEE\u3002",
      formula: DRIFT_SPEED_Z_FORMULA,
      scale: 100,
      unit: "\u5F52\u4E00\u5316\xD7100",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    CBA_FORMULA = [
      "# CBA \u4E70\u65B9\u5B9A\u4EF7\u4F18\u52BF\u6307\u6570\uFF08\u2212100 ~ 100\uFF09= 100\xB7tanh(\u03A3 w\xB7F\xB7G\xB7R)\uFF1B\u6B63 = \u5411\u4E0A\u7684\u4EF7\u683C\u4F18\u52BF\u4ECD\u88AB\u4FDD\u7559\uFF0C\u8D1F = \u4EF7\u683C\u7ED3\u679C\u4E0D\u652F\u6301\u4E70\u65B9\u4F18\u52BF\uFF1B\u4E0D\u662F\u80DC\u7387",
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF0CQ = B + S\uFF0CE = \u6210\u4EA4\u5747\u4EF7\uFF08VWAP\uFF09\uFF1Bhl = \u65F6\u95F4\u6743\u91CD\u534A\u8870\u671F\uFF0Cavgh = \u5E38\u6001\u6210\u4EA4\u989D\u4E0E\u6CE2\u52A8\u7387\u7684\u56DE\u770B\u65F6\u957F\uFF08\u5C0F\u65F6\uFF0C\u90FD\u5728\u4E0B\u9762\u9009\uFF09",
      "eta = 0.5                                     # \u03B7\uFF1A\u53CC\u5411\u6D3B\u8DC3\u6210\u4EA4\u7684\u4FDD\u7559\u6743\u91CD\uFF080 < \u03B7 \u2264 1\uFF09",
      "alpha = 1                                     # \u03B1\uFF1A\u4E3B\u52A8\u4E70\u5165\u4F18\u52BF\u7684\u989D\u5916\u52A0\u6743\u7CFB\u6570\uFF08\u2265 0\uFF09",
      "D = B - S                                     # \u4E3B\u52A8\u6210\u4EA4\u51C0\u5DEE\u989D\uFF08\u4E0D\u662F\u5E02\u573A\u51C0\u8D44\u91D1\u6D41\u5165\uFF09",
      "A = D / Q                                     # \u4E3B\u52A8\u4E70\u5356\u5931\u8861\uFF0C\u22121 ~ 1",
      "Vbar = prev(avg(Q, avgh))                     # \u622A\u81F3\u4E0A\u4E00\u6839\u7684\u5E38\u6001\u6210\u4EA4\u989D\uFF1A\u8FC7\u53BB avgh \u5C0F\u65F6\u5E73\u5747",
      "F = ln(1 + (abs(D) + eta * (Q - abs(D))) / Vbar)  # \u6210\u4EA4\u652F\u6301",
      "G = 1 + alpha * max(A, 0)                     # \u4E3B\u52A8\u4E70\u5165\u52A0\u6743",
      "P = min(E, C)                                 # \u5F53\u524D\u4EF7\uFF1A\u6210\u4EA4\u5747\u4EF7\u4E0E\u6536\u76D8\u4EF7\u53D6\u4F4E",
      "sig = prev(sd(ln(E / prev(E)), avgh))         # \u622A\u81F3\u4E0A\u4E00\u6839\uFF1A\u6210\u4EA4\u5747\u4EF7\u5BF9\u6570\u6536\u76CA\u7387\u7684\u6CE2\u52A8\u7387 \u03C3",
      "CBA = 100 * tanh(retain(F * G, P, prev(E), hl, 48) / sig)  # 48 \u5C0F\u65F6\u7A97\u53E3\u3001\u65F6\u95F4\u6743\u91CD w\u3001\u4FDD\u7559\u4E0A\u79FB\u901F\u5EA6 R = ln(P \xF7 E\u1D62\u208B\u2081) \xF7 ((t \u2212 i + 1)\xB7\u03C3)"
    ].join("\n");
    CBA_DEF = {
      id: "cba",
      name: "\u4E70\u65B9\u5B9A\u4EF7\u4F18\u52BF\u6307\u6570 CBA",
      short: "CBA",
      definition: "\u8FDB\u573A\u524D\u6700\u540E\u4E00\u6839 K \u7EBF\u4E0A\u7684\u4E70\u65B9\u5B9A\u4EF7\u4F18\u52BF\uFF08\u2212100 ~ 100\uFF09\uFF1A\u8FC7\u53BB 48 \u5C0F\u65F6\u6BCF\u6839 K \u7EBF\u7684\u6210\u4EA4\u652F\u6301 \xD7 \u4E3B\u52A8\u4E70\u5165\u52A0\u6743 \xD7 \u4FDD\u7559\u4E0A\u79FB\u901F\u5EA6\uFF0C\u6309\u65F6\u95F4\u6743\u91CD\u52A0\u603B\u540E 100\xB7tanh \u538B\u7F29\u3002\u6B63\u503C = \u5411\u4E0A\u7684\u4EF7\u683C\u4F18\u52BF\u4ECD\u88AB\u4FDD\u7559\uFF1B\u8D1F\u503C = \u4EF7\u683C\u7ED3\u679C\u4E0D\u652F\u6301\u4E70\u65B9\u4F18\u52BF\u3002\u4E0D\u662F\u80DC\u7387\u3002",
      formula: CBA_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    CBI_FORMULA = [
      "# CBI \u4E70\u65B9\u4F18\u52BF\u6307\u6570\uFF08\u22121 ~ 1\uFF09= P \xD7 D\uFF1B> 0 \u4E70\u65B9\u5360\u4F18\u3002D = \u65B9\u5411\uFF08\u56DB\u4E2A\u5206\u91CF\u52A0\u6743\uFF09\uFF0CP = \u53C2\u4E0E\u5EA6\uFF08\u53EF\u4FE1\u5EA6\uFF09",
      "# V = \u6210\u4EA4\u989D Q\uFF0CV\u1D47 / V\u02E2 = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D B / S\uFF1Bavgh = \u57FA\u7EBF\u671F\uFF08\u5C0F\u65F6\uFF0C\u4E0B\u9762\u9009\uFF1B\u539F\u6587 V\u0304 \u662F\u540C\u65F6\u6BB5 20 \u5929\u4E2D\u4F4D\u6570\uFF0C\u62FF\u4E0D\u5230\uFF0C\u6539\u7528\u8FC7\u53BB avgh \u5C0F\u65F6\uFF09",
      "h = 12                                          # \u65F6\u95F4\u8870\u51CF\u534A\u8870\u671F\uFF08\u6839\uFF09\uFF1Aw = 2^(\u2212(t \u2212 i) \xF7 h)",
      "N = 48                                          # \u6C42\u548C\u7A97\u53E3\uFF1A\u6700\u8FD1 N \u6839",
      "m = 12                                          # \u5747\u4EF7\u659C\u7387\u56DE\u770B\u6839\u6570",
      "kappa = 1                                       # \u03BA\uFF1A\u5438\u6536\u659C\u7387\u7684\u6536\u7F29\u5F3A\u5EA6",
      "k = 2                                           # \u53C2\u4E0E\u5EA6\u654F\u611F\u5EA6",
      "ATR = atr(H, L, C, 14)                          # \u5E73\u5747\u771F\u5B9E\u6CE2\u5E45\uFF0814 \u6839\uFF09",
      "Vbar = prev(median(Q, avgh))                    # \u57FA\u7EBF\u6210\u4EA4\u989D\uFF1A\u622A\u81F3\u4E0A\u4E00\u6839\u3001\u8FC7\u53BB avgh \u5C0F\u65F6\u7684\u4E2D\u4F4D\u6570",
      "x = (B - S) / Vbar                              # \u4E3B\u52A8\u51C0\u6D41\u91CF",
      "r = (C - prev(C)) / ATR                         # \u5355\u6839\u6536\u76CA\uFF08\u4EE5 ATR \u8BA1\uFF09",
      "F = wsum(B - S, h, N) / wsum(Q, h, N)           # F \u4E3B\u52A8\u6027",
      "lam0 = rsum(r * sign(x), avgh) / rsum(abs(x), avgh)   # \u03BB\u2080\uFF1A\u57FA\u7EBF\u5BF9\u79F0\u51B2\u51FB",
      "lp = (wsum(if(x > 0, r, 0), h, N) + kappa * lam0) / (wsum(if(x > 0, x, 0), h, N) + kappa)   # \u03BB\u207A\uFF1A\u4E70\u4E00\u4FA7\u7684\u4EF7\u683C\u51B2\u51FB\u659C\u7387",
      "lm = (wsum(if(x < 0, r, 0), h, N) - kappa * lam0) / (wsum(if(x < 0, x, 0), h, N) - kappa)   # \u03BB\u207B\uFF1A\u5356\u4E00\u4FA7\u7684\u4EF7\u683C\u51B2\u51FB\u659C\u7387",
      "A = (lp - lm) / (abs(lp) + abs(lm))             # A \u5438\u6536",
      "CLV = if(H > L, (2 * C - H - L) / (H - L), 0)   # \u6536\u76D8\u5728 K \u7EBF\u533A\u95F4\u91CC\u7684\u4F4D\u7F6E\uFF08\u22121 ~ 1\uFF09",
      "K = wsum(Q * CLV, h, N) / wsum(Q, h, N)         # K \u6536\u76D8\u63A7\u5236",
      "M = wsum(Q * ((H + L + C) / 3), h, N) / wsum(Q, h, N)   # \u7A97\u53E3\u6210\u4EA4\u989D\u52A0\u6743\u5747\u4EF7\uFF08\u5E73\u5747\u6210\u672C\uFF09",
      "d = (C - M) / ATR                               # \u4EF7\u683C\u76F8\u5BF9\u5747\u4EF7\u7684\u504F\u79BB",
      "v = (M - prev(M, m)) / (m * ATR)                # \u5747\u4EF7\u6F02\u79FB\u901F\u5EA6\uFF08ATR / \u6839\uFF09",
      "uF = tanh((F - prev(median(F, avgh))) / prev(rscale(F, avgh)) / 2)   # \u7A33\u5065 z \u538B\u5230 \u22121 ~ 1\uFF1Az = (X \u2212 \u4E2D\u6027\u70B9) \xF7 rscale\uFF0Crscale = 1.4826\xB7MAD\uFF08MAD = 0 \u65F6 1.2533\xB7\u5E73\u5747\u7EDD\u5BF9\u504F\u5DEE\uFF09\uFF1BF \u7684\u4E2D\u6027\u70B9 = \u57FA\u7EBF\u4E2D\u4F4D\u6570",
      "uA = tanh(A / prev(rscale(A, avgh)) / 2)",
      "uK = tanh(K / prev(rscale(K, avgh)) / 2)",
      "uS = (tanh(d / prev(rscale(d, avgh)) / 2) + tanh(v / prev(rscale(v, avgh)) / 2)) / 2   # S \u7ED3\u6784",
      "D = (0.30 * uF + 0.30 * uA + 0.15 * uK + 0.25 * uS) / (0.30 + 0.30 + 0.15 + 0.25)   # \u65B9\u5411",
      "RV = wsum(Q, h, N) / wsum(Vbar, h, N)           # \u76F8\u5BF9\u6210\u4EA4\u91CF",
      "P = RV ^ k / (1 + RV ^ k)                       # \u53C2\u4E0E\u5EA6\uFF08\u53EF\u4FE1\u5EA6\uFF09",
      "CBI = P * D"
    ].join("\n");
    CBI_DEF = {
      id: "cbi",
      name: "\u4E70\u65B9\u4F18\u52BF\u6307\u6570 CBI",
      short: "CBI",
      definition: "\u8FDB\u573A\u524D\u6700\u540E\u4E00\u6839 K \u7EBF\u4E0A\u7684\u4E70\u65B9\u4F18\u52BF\uFF08\u22121 ~ 1\uFF09= \u53C2\u4E0E\u5EA6 P \xD7 \u65B9\u5411 D\uFF1AD \u7531\u4E3B\u52A8\u6027 F\u3001\u5438\u6536 A\u3001\u6536\u76D8\u63A7\u5236 K\u3001\u7ED3\u6784 S \u56DB\u4E2A\u5206\u91CF\uFF08\u7A33\u5065 z \u538B\u5230 \u22121 ~ 1\uFF09\u6309 0.30 / 0.30 / 0.15 / 0.25 \u52A0\u6743\uFF1BP = RV\xB2 \xF7 (1 + RV\xB2)\u3002> 0 \u4E70\u65B9\u5360\u4F18\u3002",
      formula: CBI_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    CBA2_DEF = { id: "cba-2", name: "\u6210\u4EA4\u652F\u6301\u4E0B\u7684\u4EF7\u683C\u91CD\u5FC3\u8FC1\u79FB\u6307\u6807 CBA-2", short: "CBA-2", definition: CBA2_DEFINITION, formula: CBA2_FORMULA, scale: 1, unit: "", positive: DEFAULT_POSITIVE, control: DEFAULT_CONTROL, source: "campaigns", groupVars: 2, builtin: true };
    CBI2_FORMULA = [
      "# CBI-2 \u4E70\u65B9\u4F18\u52BF\u6307\u6570\u7B2C 2 \u7248\uFF08\u22121 ~ 1\uFF09= 2p \u2212 1\uFF1B0 = \u4E94\u4E94\u5F00\uFF0C0.1 \u2248 55:45\u3002p = (1 \u2212 \u03A8)\xB7\u03C3(L\u2081) + \u03A8\xB7\u03C3(L\u2082)\uFF0C\u03C3 = logistic",
      "# V = \u6210\u4EA4\u989D Q\uFF0CV\u1D47 / V\u02E2 = B / S\uFF0CCB = \u540C\u65F6\u6BB5 BTCUSDT \u6536\u76D8\u4EF7\uFF1Bavgh = \u57FA\u7EBF\u671F\uFF08\u5C0F\u65F6\uFF0C\u4E0B\u9762\u9009\uFF1B\u539F\u6587 20 \u5929 / 14 \u5929\u62FF\u4E0D\u5230\uFF0C\u6539\u7528\u8FC7\u53BB avgh \u5C0F\u65F6\uFF09",
      "k = 2                                            # \u53C2\u4E0E\u5EA6\u654F\u611F\u5EA6",
      "kappa = 0.5                                      # \u03BA\uFF1A\u5438\u6536\u659C\u7387\u7684\u6536\u7F29\u5F3A\u5EA6",
      "m = 6                                            # \u52A8\u91CF / \u5747\u4EF7\u659C\u7387\u56DE\u770B\u6839\u6570",
      "ATR = atr(H, L, C, 14)                           # \u5E73\u5747\u771F\u5B9E\u6CE2\u5E45\uFF0814 \u6839\uFF09",
      "ATRb = prev(median(ATR, avgh))                   # ATR\u0304\uFF1A\u57FA\u7EBF\u671F ATR \u4E2D\u4F4D\u6570",
      "Vbar = prev(median(Q, avgh))                     # V\u0304\uFF1A\u57FA\u7EBF\u6210\u4EA4\u989D\uFF08\u4E2D\u4F4D\u6570\uFF09",
      "x = (B - S) / Vbar                               # \u4E3B\u52A8\u51C0\u6D41\u91CF\uFF08\u9664\u4EE5\u57FA\u7EBF\u91CF\uFF09",
      "r = (C - prev(C)) / ATRb                         # \u5355\u6839\u6536\u76CA\uFF08\u9664\u4EE5 ATR\u0304\uFF09",
      "rho = ln(C / prev(C))                            # \u5BF9\u6570\u6536\u76CA \u03C1",
      "rb = ln(CB / prev(CB))                           # BTC \u7684\u5BF9\u6570\u6536\u76CA",
      "F = wsum(B - S, 3, 12) / wsum(Q, 3, 12)          # F \u4E3B\u52A8\u4E70\u5356\u5931\u8861\uFF0812 \u6839\uFF0C\u534A\u8870\u671F 3\uFF09",
      "dF = wsum(B - S, 2, 6) / wsum(Q, 2, 6) - wsum(B - S, 6, 24) / wsum(Q, 6, 24)   # \u0394F = F\u2086 \u2212 F\u2082\u2084\uFF1A\u4E70\u76D8\u589E\u51CF",
      "lam0 = rsum(r * sign(x), avgh) / rsum(abs(x), avgh)   # \u03BB\u2080\uFF1A\u57FA\u7EBF\u671F\u7684\u5BF9\u79F0\u51B2\u51FB",
      "lp = (wsum(if(x > 0, r, 0), 6, 24) + kappa * lam0) / (wsum(if(x > 0, x, 0), 6, 24) + kappa)   # \u03BB\u207A\uFF0824 \u6839\uFF0C\u534A\u8870\u671F 6\uFF09",
      "lm = (wsum(if(x < 0, r, 0), 6, 24) - kappa * lam0) / (wsum(if(x < 0, x, 0), 6, 24) - kappa)   # \u03BB\u207B",
      "A = (lp - lm) / (abs(lp) + abs(lm))              # A \u5438\u6536",
      "lpf = (wsum(if(x > 0, r, 0), 3, 12) + kappa * lam0) / (wsum(if(x > 0, x, 0), 3, 12) + kappa)  # \u5FEB\u901F\u7248 \u03BB\u207A\uFF0812 \u6839\uFF0C\u534A\u8870\u671F 3\uFF09",
      "lmf = (wsum(if(x < 0, r, 0), 3, 12) - kappa * lam0) / (wsum(if(x < 0, x, 0), 3, 12) - kappa)  # \u5FEB\u901F\u7248 \u03BB\u207B",
      "Af = (lpf - lmf) / (abs(lpf) + abs(lmf))         # A_f \u5438\u6536\u5FEB\u901F\u7248",
      "e = r - (lp * max(x, 0) + lm * min(x, 0))        # \u6210\u4EA4\u89E3\u91CA\u4E0D\u4E86\u7684\u4EF7\u683C\u53D8\u5316",
      "U = e / prev(sd(e, avgh))                        # U \u610F\u5916\u5EA6\uFF1A\u9664\u4EE5\u57FA\u7EBF\u6807\u51C6\u5DEE s_e",
      "phi = prev(beta(rho, rb, 24))                    # \u03C6\uFF1A\u5BF9 BTC \u7684\u56DE\u5F52\u659C\u7387\uFF08\u8FC7\u53BB 1 \u5929\uFF09",
      "Mo = msum(rho - nz(phi * rb), m) / (ATR / C * sqrt(m))   # Mo \u5254\u9664 BTC \u540E\u7684\u77ED\u671F\u52A8\u91CF\uFF08BTC \u8BFB\u6570\u7F3A\u5931\u65F6\u4E0D\u5254\u9664\uFF09",
      "M = wsum(Q * ((H + L + C) / 3), 6, 24) / wsum(Q, 6, 24)  # \u6210\u4EA4\u989D\u52A0\u6743\u5747\u4EF7\uFF0824 \u6839\uFF0C\u534A\u8870\u671F 6\uFF09",
      "d = (C - M) / ATR                                # \u4EF7\u683C\u76F8\u5BF9\u5747\u4EF7\u7684\u504F\u79BB",
      "v = (M - prev(M, m)) / (m * ATR)                 # \u5747\u4EF7\u6F02\u79FB\u901F\u5EA6\uFF08ATR / \u6839\uFF09",
      "Hh = highest(H, 12)                              # \u6700\u8FD1 12 \u6839\u6700\u9AD8\u4EF7",
      "Ll = lowest(L, 12)                               # \u6700\u8FD1 12 \u6839\u6700\u4F4E\u4EF7",
      "K = if(Hh > Ll, (2 * C - Hh - Ll) / (Hh - Ll), 0)   # K \u6700\u8FD1 1 \u5C0F\u65F6\u7684\u6536\u76D8\u4F4D\u7F6E\uFF08\u22121 ~ 1\uFF09",
      "S6 = msum(S, 6)                                  # \u6700\u8FD1 6 \u6839\u4E3B\u52A8\u5356\u51FA\u4E4B\u548C",
      "Ex = ln(highest(S6, 43) / S6)                    # Ex \u5356\u76D8\u8870\u7AED\u5EA6\uFF1A48 \u6839\u5185\u4EFB\u610F\u8FDE\u7EED 6 \u6839\u7684\u6700\u5927\u503C \xF7 \u6700\u8FD1 6 \u6839",
      "DD = (highest(C, 48) - C) / ATR                  # \u8DDD 48 \u6839\u6700\u9AD8\u6536\u76D8\u7684\u56DE\u64A4\uFF08ATR\uFF09",
      "RV = msum(Q, 12) / msum(Vbar, 12)                # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF0812 \u6839\uFF09",
      "RV24 = msum(Q, 24) / msum(Vbar, 24)              # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF0824 \u6839\uFF09",
      "g = 2 * RV ^ k / (1 + RV ^ k)                    # \u53C2\u4E0E\u5EA6\u653E\u5927\u7CFB\u6570\uFF08\u91CF\u80FD\u6B63\u5E38 = 1\uFF09",
      "Psi = 1 / (1 + exp(-4 * (ln(RV24) - ln(2.5)))) / (1 + exp(-2 * (DD - 3)))   # \u03A8 \u6050\u614C\u5EA6 = \u03C3(4\xB7(ln RV\u2082\u2084 \u2212 ln 2.5))\xB7\u03C3(2\xB7(DD \u2212 3))",
      "zF = clip((F - prev(median(F, avgh))) / prev(rscale(F, avgh)), -3, 3)   # \u7A33\u5065 z \u622A\u65AD\u5230 \xB13\uFF1A(X \u2212 \u4E2D\u6027\u70B9) \xF7 (1.4826\xB7MAD)\uFF1BF \u7684\u4E2D\u6027\u70B9 = \u57FA\u7EBF\u4E2D\u4F4D\u6570",
      "zdF = clip(dF / prev(rscale(dF, avgh)), -3, 3)",
      "zA = clip(A / prev(rscale(A, avgh)), -3, 3)",
      "zMo = clip(Mo / prev(rscale(Mo, avgh)), -3, 3)",
      "zd = clip(d / prev(rscale(d, avgh)), -3, 3)",
      "zv = clip(v / prev(rscale(v, avgh)), -3, 3)",
      "zK = clip(K / prev(rscale(K, avgh)), -3, 3)",
      "zU = clip(U / prev(rscale(U, avgh)), -3, 3)",
      "zAf = clip(Af / prev(rscale(Af, avgh)), -3, 3)",
      "zEx = clip(Ex / prev(rscale(Ex, avgh)), -3, 3)",
      "L1 = 0 + g * (0.07 * zF + 0.04 * zdF + 0.07 * zA + 0.07 * zMo + 0.04 * zd + 0.04 * zv + 0.02 * zK) + 0.2 * min(zU, 0)   # L\u2081 \u987A\u52BF\u5206\u652F\uFF08\u5BF9\u6570\u51E0\u7387\uFF09",
      "L2 = -0.5 + 0.35 * zAf + 0.25 * zEx              # L\u2082 \u5438\u6536\u5206\u652F\uFF08\u5BF9\u6570\u51E0\u7387\uFF09",
      "p = (1 - Psi) / (1 + exp(-L1)) + Psi / (1 + exp(-L2))   # \u4E0A\u6DA8\uFF08\u4EA4\u6613\u6210\u529F\uFF09\u7684\u6982\u7387",
      "CBI2 = 2 * p - 1"
    ].join("\n");
    CBI2_DEF = {
      id: "cbi2",
      name: "\u4E70\u65B9\u4F18\u52BF\u6307\u6570 CBI-2",
      short: "CBI-2",
      definition: "\u8FDB\u573A\u524D\u6700\u540E\u4E00\u6839 K \u7EBF\u4E0A\u7684\u4E70\u65B9\u4F18\u52BF\u7B2C 2 \u7248\uFF08\u22121 ~ 1\uFF09= 2p \u2212 1\uFF1Ap \u662F\u4E0A\u6DA8\u7684\u6982\u7387\uFF0C\u7531\u987A\u52BF\u5206\u652F L\u2081\uFF08\u4E3B\u52A8\u6027\u3001\u4E70\u76D8\u589E\u51CF\u3001\u5438\u6536\u3001\u5254\u9664 BTC \u7684\u52A8\u91CF\u3001\u5747\u4EF7\u504F\u79BB\u4E0E\u6F02\u79FB\u3001\u6536\u76D8\u4F4D\u7F6E\u3001\u610F\u5916\u5EA6\uFF09\u4E0E\u5438\u6536\u5206\u652F L\u2082\uFF08\u5FEB\u901F\u5438\u6536\u3001\u5356\u76D8\u8870\u7AED\uFF09\u6309\u6050\u614C\u5EA6 \u03A8 \u6DF7\u5408\u30020 = \u4E94\u4E94\u5F00\uFF0C0.1 \u2248 55:45\u3002",
      formula: CBI2_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    MBI_FORMULA = appendResearchAverages([
      "# MBI \u53EA\u770B\u5DF2\u6536\u76D8\u4EF7\u683C\uFF1B\u53C2\u6570 MBI_N\u3001MBI_Z0 \u5728\u4E0B\u65B9\u8BBE\u7F6E\u3002",
      "# x = ln(C)\uFF1B\u03B1 = 1/MBI_N\uFF1B\u03BA = 1/\u221A(\u03B1\xB7(2\u2212\u03B1))\u3002",
      "# M\u3001S \u4ECE\u5E8F\u5217\u9996\u6839\u9012\u63A8\uFF1BS \u521D\u503C\u4E3A\u524D n \u4E2A\u5BF9\u6570\u6DA8\u8DCC\u5E73\u65B9\u7684\u5E73\u5747\u3002",
      "# z \u4F7F\u7528\u66F4\u65B0\u524D\u7684 M\u3001S\uFF1B\u524D 5n \u6839\u4E3A\u7A7A\uFF0C\u4E0D\u53C2\u4E0E\u5747\u503C\u3001\u5E73\u6ED1\u6216\u8BC4\u4F30\u3002",
      "z = mbiz(C, MBI_N)",
      "MBI = tanh(z / MBI_Z0)"
    ].join("\n"), /* @__PURE__ */ new Set(["z", "MBI"]), { core: "MBI", avg: "avg_MBI", avg2: "avg_MBI_2" }) + "\nMBI = MBI";
    MBI_DEF = {
      id: "mbi",
      name: "MBI \u8FC8\u514B\u5C14\u4E70\u65B9\u4F18\u52BF",
      short: "MBI",
      definition: MBI_TOOLTIP,
      formula: MBI_FORMULA,
      MBI_N,
      MBI_Z0,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    mbi2Copy = copyFeatureDefinition(MBI_DEF, [MBI_DEF], Date.UTC(2026, 9, 29, 14));
    ({ MBI_N: _oldN, MBI_Z0: _oldZ, ...mbi2Own } = mbi2Copy);
    MBI2_FORMULA = appendResearchAverages([
      "# MBI2 \u72EC\u7ACB\u526F\u672C\uFF1BMBI2_N\u7531\u65E5\u5386\u5C0F\u65F6\u6D3E\u751F\uFF0C\u524D5n\u6839\u4E3A\u7A7A\uFF1Bz0\u56FA\u5B9A1.25\u3002",
      "MBI2_z = mbiz2(C, MBI2_N)",
      "MBI2 = tanh(MBI2_z / MBI2_Z0)"
    ].join("\n"), /* @__PURE__ */ new Set(["MBI2_z", "MBI2"]), { core: "MBI2", avg: "avg_MBI2", avg2: "avg_MBI2_2" }) + [
      "",
      "MBI2_state = mbi2state(MBI2,T,MBI2_BAND,MBI2_CONFIRM,0)",
      "MBI2_lead_h = mbi2state(MBI2,T,MBI2_BAND,MBI2_CONFIRM,1)",
      "MBI2_confirm_h = mbi2state(MBI2,T,MBI2_BAND,MBI2_CONFIRM,2)",
      "MBI2 = MBI2"
    ].join("\n");
    MBI2_DEF = {
      ...mbi2Own,
      id: "mbi2",
      name: "MBI2 \u8FC8\u514B\u5C14\u4E70\u65B9\u4F18\u52BF\uFF08\u53EF\u8C03\u7248\uFF09",
      short: "MBI2",
      builtin: true,
      chartTemplate: "mbi2",
      chartCore: "MBI2",
      formula: MBI2_FORMULA,
      MBI2_Z0,
      MBI2_BAND: 0.2,
      MBI2_CONFIRM: 0.8,
      researchWindowHours: 48,
      definition: MBI2_TOOLTIP + " \u672A\u624B\u52A8\u8BBE\u5C0F\u65F6\u6570\u65F6\uFF0C\u6BCF\u4E2A\u5468\u671F\u9ED8\u8BA4n=25\uFF1B\u624B\u52A8\u8BBE\u5B9A\u540E\u56FA\u5B9A\u65E5\u5386\u65F6\u957F\u3002\u72B6\u6001\u4E3A\u4E70\u65B9\u786E\u8BA4/\u4E70\u65B9\u8BD5\u63A2/\u5747\u8861/\u5356\u65B9\u8BD5\u63A2/\u5356\u65B9\u786E\u8BA4\u3002\u6301\u7EED\u5C0F\u65F6\u4EE5\u5F53\u524D\u65B9\u5411\u53CA\u672C\u6BB5\u786E\u8BA4\u4E3A\u8D77\u70B9\uFF0C\u8D77\u59CB\u6839\u4E3A0\uFF0C\u6700\u591A48\u5C0F\u65F6\u3002\u626B\u63CF\u4EC5\u5C55\u793A\uFF0C\u4E0D\u81EA\u52A8\u8C03\u6574\u9ED8\u8BA4\u53C2\u6570\u3002"
    };
    CDI2_FORMULA = sellerNegativeFormula([
      "# CDI2 \u4E70\u65B9\u5931\u63A7\u7A0B\u5EA6\uFF08\u22121 ~ 1\uFF09\uFF1A\u8D8A\u4F4E\uFF08\u8D8A\u8D1F\uFF09\u8868\u793A\u5356\u65B9\u4F18\u52BF\u8D8A\u5F3A\u3001\u4E70\u65B9\u63A7\u5236\u8D8A\u5F31\uFF1Bp \u4E3A\u6A21\u578B\u6620\u5C04\u5206\u6570\uFF0C\u672A\u7ECF\u80DC\u7387\u6821\u51C6",
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF0CCB = \u540C\u65F6\u6BB5 BTC \u6536\u76D8\u4EF7\uFF1B\u7A97\u53E3\u3001\u7CFB\u6570\u4E0E CBI-2 \u76F8\u540C\uFF0C\u65B9\u5411\u5BF9\u79F0\u8F6C\u6362",
      "k = 2                                            # \u53C2\u4E0E\u5EA6\u654F\u611F\u5EA6",
      "kappa = 0.5                                      # \u03BA\uFF1A\u5438\u6536\u659C\u7387\u7684\u6536\u7F29\u5F3A\u5EA6",
      "m = 6                                            # \u52A8\u91CF / \u5747\u4EF7\u659C\u7387\u56DE\u770B\u6839\u6570",
      "ATR = atr(H, L, C, 14)                           # \u5E73\u5747\u771F\u5B9E\u6CE2\u5E45\uFF0814 \u6839\uFF09",
      "ATRb = prev(median(ATR, avgh))                   # ATR\u0304\uFF1A\u57FA\u7EBF\u671F ATR \u4E2D\u4F4D\u6570",
      "Vbar = prev(median(Q, avgh))                     # V\u0304\uFF1A\u57FA\u7EBF\u6210\u4EA4\u989D\uFF08\u4E2D\u4F4D\u6570\uFF09",
      "x = (S - B) / Vbar                               # \u4E3B\u52A8\u5356\u51FA\u51C0\u5DEE\u989D\uFF08\u9664\u4EE5\u57FA\u7EBF\u91CF\uFF09",
      "r = (prev(C) - C) / ATRb                         # \u5411\u4E0B\u4EF7\u683C\u53D8\u5316\uFF08\u9664\u4EE5 ATR\u0304\uFF09",
      "rho = -ln(C / prev(C))                            # \u5411\u4E0B\u5BF9\u6570\u6536\u76CA \u03C1",
      "rb = -ln(CB / prev(CB))                           # BTC \u7684\u5411\u4E0B\u5BF9\u6570\u6536\u76CA",
      "F = wsum(S - B, 3, 12) / wsum(Q, 3, 12)          # F \u4E3B\u52A8\u5356\u4E70\u5931\u8861\uFF0812 \u6839\uFF0C\u534A\u8870\u671F 3\uFF09",
      "dF = wsum(S - B, 2, 6) / wsum(Q, 2, 6) - wsum(S - B, 6, 24) / wsum(Q, 6, 24)   # \u0394F = F\u2086 \u2212 F\u2082\u2084\uFF1A\u5356\u76D8\u589E\u51CF",
      "lam0 = rsum(r * sign(x), avgh) / rsum(abs(x), avgh)   # \u03BB\u2080\uFF1A\u57FA\u7EBF\u671F\u7684\u5BF9\u79F0\u51B2\u51FB",
      "lp = (wsum(if(x > 0, r, 0), 6, 24) + kappa * lam0) / (wsum(if(x > 0, x, 0), 6, 24) + kappa)   # \u03BB\u207A\uFF0824 \u6839\uFF0C\u534A\u8870\u671F 6\uFF09",
      "lm = (wsum(if(x < 0, r, 0), 6, 24) - kappa * lam0) / (wsum(if(x < 0, x, 0), 6, 24) - kappa)   # \u03BB\u207B",
      "A = (lp - lm) / (abs(lp) + abs(lm))              # A \u5356\u65B9\u5438\u6536",
      "lpf = (wsum(if(x > 0, r, 0), 3, 12) + kappa * lam0) / (wsum(if(x > 0, x, 0), 3, 12) + kappa)  # \u5FEB\u901F\u7248 \u03BB\u207A\uFF0812 \u6839\uFF0C\u534A\u8870\u671F 3\uFF09",
      "lmf = (wsum(if(x < 0, r, 0), 3, 12) - kappa * lam0) / (wsum(if(x < 0, x, 0), 3, 12) - kappa)  # \u5FEB\u901F\u7248 \u03BB\u207B",
      "Af = (lpf - lmf) / (abs(lpf) + abs(lmf))         # A_f \u5356\u65B9\u5438\u6536\u5FEB\u901F\u7248",
      "e = r - (lp * max(x, 0) + lm * min(x, 0))        # \u6210\u4EA4\u89E3\u91CA\u4E0D\u4E86\u7684\u5411\u4E0B\u4EF7\u683C\u53D8\u5316\uFF08\u8D1F\u503C\u4E3A\u610F\u5916\u4E0A\u6DA8\uFF0C\u60E9\u7F5A\u5356\u65B9\u5224\u65AD\uFF09",
      "U = e / prev(sd(e, avgh))                        # U \u610F\u5916\u5EA6\uFF1A\u9664\u4EE5\u57FA\u7EBF\u6807\u51C6\u5DEE s_e",
      "phi = prev(beta(rho, rb, 24))                    # \u03C6\uFF1A\u5BF9 BTC \u7684\u56DE\u5F52\u659C\u7387\uFF08\u8FC7\u53BB 1 \u5929\uFF09",
      "Mo = msum(rho - nz(phi * rb), m) / (ATR / C * sqrt(m))   # Mo \u5254\u9664 BTC \u540E\u7684\u5411\u4E0B\u77ED\u671F\u52A8\u91CF\uFF08BTC \u8BFB\u6570\u7F3A\u5931\u65F6\u4E0D\u5254\u9664\uFF09",
      "M = wsum(Q * ((H + L + C) / 3), 6, 24) / wsum(Q, 6, 24)  # \u6210\u4EA4\u989D\u52A0\u6743\u5747\u4EF7\uFF0824 \u6839\uFF0C\u534A\u8870\u671F 6\uFF09",
      "d = (M - C) / ATR                                # \u5747\u4EF7\u76F8\u5BF9\u4EF7\u683C\u7684\u5411\u4E0B\u504F\u79BB",
      "v = (prev(M, m) - M) / (m * ATR)                 # \u5747\u4EF7\u5411\u4E0B\u6F02\u79FB\u901F\u5EA6\uFF08ATR / \u6839\uFF09",
      "Hh = highest(H, 12)                              # \u6700\u8FD1 12 \u6839\u6700\u9AD8\u4EF7",
      "Ll = lowest(L, 12)                               # \u6700\u8FD1 12 \u6839\u6700\u4F4E\u4EF7",
      "K = if(Hh > Ll, (Hh + Ll - 2 * C) / (Hh - Ll), 0)   # K \u6700\u8FD1 12 \u6839\u7684\u5411\u4E0B\u6536\u76D8\u4F4D\u7F6E\uFF08\u22121 ~ 1\uFF09",
      "B6 = msum(B, 6)                                  # \u6700\u8FD1 6 \u6839\u4E3B\u52A8\u4E70\u5165\u4E4B\u548C",
      "Ex = ln(highest(B6, 43) / B6)                    # Ex \u4E70\u76D8\u8870\u7AED\u5EA6\uFF1A48 \u6839\u5185\u4EFB\u610F\u8FDE\u7EED 6 \u6839\u7684\u6700\u5927\u503C \xF7 \u6700\u8FD1 6 \u6839",
      "DU = (C - lowest(C, 48)) / ATR                  # \u8DDD 48 \u6839\u6700\u4F4E\u6536\u76D8\u7684\u4E0A\u51B2\uFF08ATR\uFF09",
      "RV = msum(Q, 12) / msum(Vbar, 12)                # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF0812 \u6839\uFF09",
      "RV24 = msum(Q, 24) / msum(Vbar, 24)              # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF0824 \u6839\uFF09",
      "g = 2 * RV ^ k / (1 + RV ^ k)                    # \u53C2\u4E0E\u5EA6\u653E\u5927\u7CFB\u6570\uFF08\u91CF\u80FD\u6B63\u5E38 = 1\uFF09",
      "Psi = 1 / (1 + exp(-4 * (ln(RV24) - ln(2.5)))) / (1 + exp(-2 * (DU - 3)))   # \u03A8 \u4EA2\u594B\u5EA6 = \u03C3(4\xB7(ln RV\u2082\u2084 \u2212 ln 2.5))\xB7\u03C3(2\xB7(DU \u2212 3))",
      "zF = clip((F - prev(median(F, avgh))) / prev(rscale(F, avgh)), -3, 3)   # \u7A33\u5065 z \u622A\u65AD\u5230 \xB13\uFF1A(X \u2212 \u4E2D\u6027\u70B9) \xF7 (1.4826\xB7MAD)\uFF1BF \u7684\u4E2D\u6027\u70B9 = \u57FA\u7EBF\u4E2D\u4F4D\u6570",
      "zdF = clip(dF / prev(rscale(dF, avgh)), -3, 3)",
      "zA = clip(A / prev(rscale(A, avgh)), -3, 3)",
      "zMo = clip(Mo / prev(rscale(Mo, avgh)), -3, 3)",
      "zd = clip(d / prev(rscale(d, avgh)), -3, 3)",
      "zv = clip(v / prev(rscale(v, avgh)), -3, 3)",
      "zK = clip(K / prev(rscale(K, avgh)), -3, 3)",
      "zU = clip(U / prev(rscale(U, avgh)), -3, 3)",
      "zAf = clip(Af / prev(rscale(Af, avgh)), -3, 3)",
      "zEx = clip(Ex / prev(rscale(Ex, avgh)), -3, 3)",
      "L1 = 0 + g * (0.07 * zF + 0.04 * zdF + 0.07 * zA + 0.07 * zMo + 0.04 * zd + 0.04 * zv + 0.02 * zK) + 0.2 * min(zU, 0)   # L\u2081 \u5356\u65B9\u987A\u52BF\u5206\u652F\uFF08\u5BF9\u6570\u51E0\u7387\uFF09",
      "L2 = -0.5 + 0.35 * zAf + 0.25 * zEx              # L\u2082 \u5356\u65B9\u5438\u6536\u5206\u652F\uFF08\u5BF9\u6570\u51E0\u7387\uFF09",
      "p = (1 - Psi) / (1 + exp(-L1)) + Psi / (1 + exp(-L2))   # \u5356\u65B9\u4F18\u52BF\u7684\u6A21\u578B\u6620\u5C04\u5206\u6570\uFF08\u975E\u5B9E\u6D4B\u80DC\u7387\uFF09",
      "CDI2 = 2 * p - 1"
    ].join("\n"), "CDI2");
    CDI2_DEF = {
      id: "cdi2",
      name: "\u4E70\u65B9\u5931\u63A7\u7A0B\u5EA6",
      short: "CDI2",
      definition: "\u4E70\u65B9\u5931\u63A7\u7A0B\u5EA6\uFF08\u22121 ~ 1\uFF09\uFF1A\u8D8A\u4F4E\uFF08\u8D8A\u8D1F\uFF09\u8868\u793A\u4F18\u52BF\u8D8A\u5411\u5356\u65B9\u8F6C\u79FB\u3001\u5356\u65B9\u4F18\u52BF\u8D8A\u5F3A\u3001\u4E70\u65B9\u63A7\u5236\u8D8A\u5F31\u3002\u6CBF\u7528 CBI-2 \u7684\u7A97\u53E3\u4E0E\u6743\u91CD\uFF0C\u6539\u770B\u4E3B\u52A8\u5356\u76D8\u3001\u5356\u76D8\u589E\u51CF\u3001\u5356\u65B9\u5438\u6536\u3001\u5254\u9664 BTC \u540E\u7684\u5411\u4E0B\u52A8\u91CF\u3001\u5747\u4EF7\u4E0B\u79FB\u4E0E\u4F4E\u4F4D\u6536\u76D8\uFF1B\u653E\u91CF\u4E0A\u51B2\u65F6\u4FA7\u91CD\u4E70\u76D8\u8870\u7AED\u4E0E\u5FEB\u901F\u5356\u65B9\u5438\u6536\u3002p \u662F\u6A21\u578B\u6620\u5C04\u5206\u6570\uFF0C\u672A\u7ECF\u771F\u5B9E\u4E0B\u8DCC\u6982\u7387\u6216\u80DC\u7387\u6821\u51C6\u3002",
      sellerSignVersion: 1,
      formula: CDI2_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    STATE_FORMULA = [
      "# \u591A\u7A7A\u72B6\u6001 S\uFF080 ~ 1\uFF09\uFF1A0 = \u5356\u65B9\u5B8C\u5168\u5360\u4F18\uFF0C0.5 = \u5747\u8861\uFF0C1 = \u4E70\u65B9\u5B8C\u5168\u5360\u4F18\uFF1B\u4E09\u90E8\u5206\u90FD\u4E70\u5356\u5BF9\u79F0\uFF0C\u76F8\u52A0\u540E logistic \u538B\u5230 0 ~ 1",
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF0CQ = B + S\uFF0CE = \u6210\u4EA4\u5747\u4EF7\uFF0CCB = \u540C\u65F6\u6BB5 BTC \u6536\u76D8\u4EF7\uFF1Bhl = \u534A\u8870\u671F\uFF0Cavgh = \u57FA\u7EBF\u65F6\u957F\uFF08\u5C0F\u65F6\uFF0C\u4E0B\u9762\u9009\uFF09",
      "wc = 3                                           # CBI-2 \u4E70\u5356\u5BF9\u79F0\u5206\u7684\u6743\u91CD\uFF08\u5B83\u672C\u8EAB\u8BFB\u6570\u504F\u5C0F\uFF0C0.04 \u2248 52:48\uFF09",
      "wa = 0.4                                         # \u63A8\u529B az \u7684\u6743\u91CD",
      "wb = 1                                           # \u5B9A\u4EF7\u4FDD\u7559\u7684\u6743\u91CD",
      "sh = 4                                           # CBI-2 \u90E8\u5206\u7684\u5E73\u6ED1\u534A\u8870\u671F\uFF08\u5C0F\u65F6\uFF09",
      "ka = 10                                          # az \u6BCF 0.1 \u8BB0 1 \u4E2A\u5BF9\u6570\u51E0\u7387\u5355\u4F4D",
      "# \u2014\u2014 1. CBI-2\uFF1A\u4E70\u65B9\u5206\u6570 p\uFF08\u4E0E CBI-2 \u516C\u5F0F\u76F8\u540C\uFF09",
      ...CBI2_FORMULA.split("\n").slice(2),
      "# \u2014\u2014 \u5356\u65B9\u5206\u6570 ps\uFF08\u4E0E CDI2 \u76F8\u540C\uFF1A\u65B9\u5411\u9879\u53D6\u53CD\uFF0C\u5438\u6536\u5206\u652F\u6539\u770B\u4E70\u76D8\u8870\u7AED\u4E0E\u4E0A\u51B2\uFF09",
      "dir = 0.07 * zF + 0.04 * zdF + 0.07 * zA + 0.07 * zMo + 0.04 * zd + 0.04 * zv + 0.02 * zK   # CBI-2 \u7684\u65B9\u5411\u5408\u8BA1",
      "B6 = msum(B, 6)                                  # \u6700\u8FD1 6 \u6839\u4E3B\u52A8\u4E70\u5165\u4E4B\u548C",
      "ExS = ln(highest(B6, 43) / B6)                   # \u4E70\u76D8\u8870\u7AED\u5EA6",
      "DU = (C - lowest(C, 48)) / ATR                   # \u8DDD 48 \u6839\u6700\u4F4E\u6536\u76D8\u7684\u4E0A\u51B2\uFF08ATR\uFF09",
      "PsiS = 1 / (1 + exp(-4 * (ln(RV24) - ln(2.5)))) / (1 + exp(-2 * (DU - 3)))   # \u4EA2\u594B\u5EA6",
      "zExS = clip(ExS / prev(rscale(ExS, avgh)), -3, 3)",
      "L1s = -g * dir + 0.2 * min(-zU, 0)               # \u5356\u65B9\u987A\u52BF\u5206\u652F",
      "L2s = -0.5 - 0.35 * zAf + 0.25 * zExS            # \u5356\u65B9\u5438\u6536\u5206\u652F",
      "ps = (1 - PsiS) / (1 + exp(-L1s)) + PsiS / (1 + exp(-L2s))   # \u5356\u65B9\u5206\u6570",
      "Lc = (ln(p / (1 - p)) - ln(ps / (1 - ps))) / 2   # \u4E70\u5356\u5BF9\u79F0\u5206\uFF08\u5BF9\u6570\u51E0\u7387\uFF09\uFF1A\u4E70\u65B9\u5360\u4F18 > 0\uFF0C\u5356\u65B9\u5360\u4F18 < 0",
      "Lcs = ema(nz(Lc), sh, 0)                         # \u5E73\u6ED1\uFF08\u4E0D\u5E73\u5747\u6709\u754C\u7684 2p \u2212 1\uFF0C\u514D\u5F97\u6781\u7AEF\u88AB\u538B\u5411\u4E2D\u95F4\uFF09",
      "# \u2014\u2014 2. \u63A8\u529B az\uFF08\u4E70\u5356\u53CC\u65B9\u90FD\u52A0\u6743\uFF09",
      "uN = abs(B - S)                                  # \u4E3B\u52A8\u51C0\u8D44\u91D1",
      "uf = ln(1 + uN / avg(Q, avgh))                   # \u8D44\u91D1\u529B\u91CF",
      "uA = (B - S) / Q                                 # \u4E3B\u52A8\u4E70\u5356\u5931\u8861\uFF0C\u22121 ~ 1",
      "uG = 1 + abs(uA)                                 # \u5931\u8861\u6743\u91CD\uFF1A\u54EA\u8FB9\u4E3B\u52A8\u90FD\u52A0\u6743\uFF08\u539F DSP \u53EA\u52A0\u6743\u4E70\u65B9\uFF09",
      "uR = ln(C / prev(C))                             # \u4EF7\u683C\u53D8\u5316",
      "uRz = uR / sd(uR, avgh)                          # \u51E0\u4E2A\u6807\u51C6\u5DEE",
      "uF = nz(uf * uG * uRz)                           # \u5355\u6839\u63A8\u529B",
      "az = ema(uF, hl, 0)                              # \u63A8\u529B\u6F02\u79FB\u901F\u5EA6\uFF08Z \u5206\u6570\uFF09",
      "La = clip(ka * az, -3, 3)                        # \u6362\u6210\u5BF9\u6570\u51E0\u7387\u5355\u4F4D",
      "# \u2014\u2014 3. \u5B9A\u4EF7\u4FDD\u7559\uFF08CBA \u7684\u4E70\u5356\u5BF9\u79F0\u7248\uFF09",
      "cD = B - S                                       # \u4E3B\u52A8\u6210\u4EA4\u51C0\u5DEE\u989D",
      "cA = cD / Q                                      # \u4E3B\u52A8\u4E70\u5356\u5931\u8861",
      "cVbar = prev(avg(Q, avgh))                       # \u622A\u81F3\u4E0A\u4E00\u6839\u7684\u5E38\u6001\u6210\u4EA4\u989D",
      "cF = ln(1 + (abs(cD) + 0.5 * (Q - abs(cD))) / cVbar)   # \u6210\u4EA4\u652F\u6301",
      "sig = prev(sd(ln(E / prev(E)), avgh))            # \u6210\u4EA4\u5747\u4EF7\u5BF9\u6570\u6536\u76CA\u7387\u7684\u6CE2\u52A8\u7387",
      "Sb = retain(cF * (1 + max(cA, 0)), min(E, C), prev(E), hl, 48) / sig   # \u4E70\u65B9\uFF1A\u5411\u4E0A\u7684\u4EF7\u683C\u4F18\u52BF\u662F\u5426\u88AB\u4FDD\u7559\uFF08\u53D6\u8F83\u4F4E\u4EF7\uFF09",
      "Ss = retain(cF * (1 + max(-cA, 0)), max(E, C), prev(E), hl, 48) / sig  # \u5356\u65B9\uFF1A\u5411\u4E0B\u7684\u4EF7\u683C\u4F18\u52BF\u662F\u5426\u88AB\u4FDD\u7559\uFF08\u53D6\u8F83\u9AD8\u4EF7\uFF09",
      "Lb = clip((Sb + Ss) / 2, -3, 3)                  # \u5BF9\u79F0\u5B9A\u4EF7\u4FDD\u7559",
      "# \u2014\u2014 \u5408\u6210",
      "Lt = wc * Lcs + wa * La + wb * Lb                # \u5408\u8BA1\u5BF9\u6570\u51E0\u7387",
      "state = 1 / (1 + exp(-Lt))"
    ].join("\n");
    STATE_DEF = {
      id: "state",
      name: "\u591A\u7A7A\u72B6\u6001 S\uFF080\u20131\uFF09",
      short: "\u72B6\u6001",
      definition: "\u5F53\u524D\u591A\u7A7A\u72B6\u6001\uFF080 ~ 1\uFF09\uFF1A0 = \u5356\u65B9\u5B8C\u5168\u5360\u4F18\uFF0C0.5 = \u5747\u8861\uFF0C1 = \u4E70\u65B9\u5B8C\u5168\u5360\u4F18\u3002\u7531\u4E09\u90E8\u5206\u5408\u6210\uFF0C\u90FD\u505A\u6210\u4E70\u5356\u5BF9\u79F0\uFF1ACBI-2 \u7684\u4E70\u65B9\u5206\u6570\u4E0E\u540C\u4E00\u5957\u7B97\u6CD5\u7684\u5356\u65B9\u5206\u6570\u4E4B\u5DEE\uFF08\u5BF9\u6570\u51E0\u7387\uFF0C4 \u5C0F\u65F6\u534A\u8870\u671F\u5E73\u6ED1\uFF09\u3001\u4E70\u5356\u53CC\u65B9\u90FD\u52A0\u6743\u7684\u63A8\u529B az\u3001\u4E70\u5356\u53CC\u65B9\u5404\u7B97\u4E00\u6B21\u7684\u5B9A\u4EF7\u4FDD\u7559\uFF08CBA \u5BF9\u79F0\u7248\uFF09\u3002\u6570\u503C\u662F\u6A21\u578B\u5206\u6570\uFF0C\u4E0D\u662F\u80DC\u7387\u3002",
      formula: STATE_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    STATE2_FORMULA = STATE_FORMULA.split("\n").filter((line) => !line.startsWith("Sb = ")).map((line) => line.startsWith("# \u591A\u7A7A\u72B6\u6001 S\uFF08") ? "# \u591A\u7A7A\u72B6\u6001 S2\uFF080 ~ 1\uFF09\uFF1A\u6CBF\u7528\u72B6\u6001 S\uFF0C\u7B2C\u4E09\u90E8\u5206\u6539\u4E3A CDA \u5B9A\u4EF7\u4FDD\u7559\u3001\u6743\u91CD 3\uFF1B\u8D8A\u9AD8\u8D8A\u504F\u4E70\u65B9" : line.startsWith("wb = ") ? "wb = 3                                           # CDA \u5B9A\u4EF7\u4FDD\u7559\u7684\u6743\u91CD\uFF08\u72B6\u6001 S \u4E3A 1\uFF09" : line.startsWith("# \u2014\u2014 3.") ? "# \u2014\u2014 3. CDA \u5B9A\u4EF7\u4FDD\u7559\uFF08\u6CBF\u7528\u72B6\u6001 S \u7684\u5C3A\u5EA6\u3001\u65B9\u5411\u4E0E\u622A\u65AD\uFF09" : line.startsWith("Lb = ") ? "Lb = clip(Ss, -3, 3)                             # CDA \u7684\u6709\u7B26\u53F7\u5B9A\u4EF7\u4FDD\u7559\uFF0C\u8D1F\u503C\u504F\u5356\u65B9\uFF1B\u4FDD\u6301\u539F\u5408\u6210\u5C3A\u5EA6" : line.startsWith("state = ") ? line.replace("state = ", "state2 = ") : line).join("\n");
    STATE2_DEF = {
      ...STATE_DEF,
      id: "state2",
      name: "\u591A\u7A7A\u72B6\u6001 S2\uFF080\u20131\uFF09",
      short: "\u72B6\u6001 S2",
      definition: "\u72B6\u6001 S \u7684\u72EC\u7ACB\u53D8\u4F53\uFF080 ~ 1\uFF09\uFF1A\u5C06\u7B2C\u4E09\u90E8\u5206\u7531 CBA \u4E70\u5356\u5BF9\u79F0\u5B9A\u4EF7\u4FDD\u7559\u6539\u4E3A CDA \u5BF9\u5E94\u7684\u6709\u7B26\u53F7\u5B9A\u4EF7\u4FDD\u7559\uFF0C\u8D8A\u8D1F\u8868\u793A\u5356\u65B9\u8D8A\u5F3A\uFF1B\u6CBF\u7528\u539F\u5206\u91CF\u5C3A\u5EA6\u4E0E \xB13 \u622A\u65AD\u3002\u6743\u91CD\u4E3A 3 / 0.4 / 3\uFF08\u5B9A\u4EF7\u4FDD\u7559\u6743\u91CD\u7531\u72B6\u6001 S \u7684 1 \u63D0\u9AD8\u5230 3\uFF09\uFF1BCBI-2 \u4E70\u5356\u5BF9\u79F0\u5206\u3001\u5BF9\u79F0\u63A8\u529B az\u30014 \u5C0F\u65F6\u5E73\u6ED1\u4E0E\u6700\u7EC8 logistic \u5747\u4E0D\u53D8\u3002\u8D8A\u9AD8\u8D8A\u504F\u4E70\u65B9\uFF0C0.5 \u4E3A\u6A21\u578B\u4E2D\u6027\u70B9\uFF1B\u4E0D\u662F\u80DC\u7387\u3002",
      formula: STATE2_FORMULA
    };
    SELLER_CONTROL_FORMULA = sellerNegativeFormula([
      "# \u5356\u65B9\u63A7\u5236\u529B\uFF1A\u6DA8\u8DCC\u5171\u7528\u5BF9\u79F0\u6743\u91CD 1 + abs(A)\uFF0C\u4E0D\u56E0\u54EA\u65B9\u4E3B\u52A8\u800C\u7CFB\u7EDF\u6027\u504F\u5411\u5356\u65B9",
      "# RMS = sqrt(avg(R * R, avgh))\uFF0C\u4FDD\u7559\u6F02\u79FB\uFF1B\u4E0D\u662F\u51CF\u5747\u503C\u7684\u6807\u51C6\u5DEE\u6216\u6700\u7EC8\u6307\u6807\u7684 Z \u5206\u6570",
      "N = abs(B - S)",
      "f = ln(1 + N / avg(Q, avgh))",
      "A = (B - S) / Q",
      "W = 1 + abs(A)",
      "R = ln(C / prev(C))",
      "Rz = R / sqrt(avg(R * R, avgh))",
      "Dn = max(-Rz, 0)",
      "Up = max(Rz, 0)",
      "F = nz(f * W * (Dn - Up))",
      "bc = ema(F, hl, 0)"
    ].join("\n"), "bc");
    SELLER_CONTROL_DEF = {
      id: "seller-control",
      name: "\u5356\u65B9\u63A7\u5236\u529B",
      short: "DSP\xB7bc",
      definition: "\u8861\u91CF\u5356\u65B9\u662F\u5426\u63A7\u5236\u4EF7\u683C\u7ED3\u679C\uFF1A\u4E3B\u52A8\u5356\u538B\u4F4E\u4EF7\u683C\u3001\u6216\u88AB\u52A8\u5356\u76D8\u538B\u4F4F\u4E3B\u52A8\u4E70\uFF0C\u90FD\u8BA1\u4E3A\u5356\u65B9\u5360\u4F18\uFF1B\u4E0A\u6DA8\uFF08\u542B\u5356\u538B\u5931\u8D25\uFF09\u8BA1\u4E3A\u4E70\u65B9\u5360\u4F18\u3002\u6DA8\u8DCC\u5171\u7528 1 + abs(A) \u5BF9\u79F0\u6743\u91CD\u548C\u6536\u76CA RMS \u5F52\u4E00\u5316\u3002\u6309 hl \u534A\u8870\u671F\u5E73\u6ED1\u5E76\u53D6\u8D1F\u540E\uFF0C\u8D1F\u503C\u8868\u793A\u5356\u65B9\u5360\u4F18\uFF0C\u6B63\u503C\u8868\u793A\u4E70\u65B9\u5360\u4F18\uFF0C\u5747\u8861\u7EA6\u4E3A 0\u3002",
      formula: SELLER_CONTROL_FORMULA,
      sellerSignVersion: 1,
      scale: 100,
      unit: "%\u03C3/\u6839",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    DSS_FORMULA = sellerNegativeFormula([
      "# DSS \u4E70\u65B9\u72B6\u6001\u6076\u5316\uFF08\u22121 ~ 1\uFF09= 0.45\xB7\u5411\u4E0B\u52A8\u91CF\u6807\u51C6\u5316 + 0.25\xB7\u5356\u65B9\u6210\u4EA4\u91CF\u65B9\u5411\u5206 + 0.30\xB7\u4E3B\u52A8\u5356\u65B9\u5931\u8861",
      "# Q = \u6210\u4EA4\u989D\uFF0CB / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF1Bavgh = \u6807\u51C6\u5316\u7A97\u53E3\uFF08\u5C0F\u65F6\uFF0C\u9ED8\u8BA4 24\uFF09\uFF1B\u7A97\u53E3\u4E0E\u6743\u91CD\u6CBF\u7528 BSS",
      "n = 1                                   # \u8FD1\u671F\u7A97\u53E3\uFF08\u5C0F\u65F6\uFF09",
      "M = 1 - C / ago(C, n)                   # \u5411\u4E0B\u4EF7\u683C\u52A8\u91CF\uFF1A\u76F8\u5BF9 n \u5C0F\u65F6\u524D\u7684\u8DCC\u5E45\uFF0C\u4E0B\u8DCC\u4E3A\u6B63",
      "V = avg(Q, n) / avg(Q, avgh)            # \u76F8\u5BF9\u6210\u4EA4\u91CF\uFF1A\u8FD1\u671F\u5E73\u5747\u6210\u4EA4\u989D \xF7 \u57FA\u7EBF\u5E73\u5747",
      "A = (avg(S, n) - avg(B, n)) / avg(Q, n) # \u4E3B\u52A8\u5356\u65B9\u5931\u8861\uFF1A(\u4E3B\u52A8\u5356 \u2212 \u4E3B\u52A8\u4E70) \xF7 \u5408\u8BA1",
      "Mz = tanh(zscore(M, avgh))              # \u5411\u4E0B\u52A8\u91CF\u6807\u51C6\u5316\uFF0C\u4FDD\u7559 BSS \u7684\u6EDA\u52A8\u53E3\u5F84",
      "Vz = tanh(zscore(V, avgh))              # \u76F8\u5BF9\u6210\u4EA4\u91CF\u6807\u51C6\u5316",
      "Vd = if(M > 0, Vz, if(M < 0, min(-Vz, 0), 0))   # \u8DCC\u65F6\u653E\u91CF\u52A0\u5206\u3001\u7F29\u91CF\u6263\u5206\uFF1B\u6DA8\u65F6\u653E\u91CF\u6263\u5206\u3001\u7F29\u91CF\u4E0D\u52A0\u5206",
      "DSS = 0.45 * Mz + 0.25 * Vd + 0.30 * A"
    ].join("\n"), "DSS");
    DSS_DEF = {
      id: "dss",
      name: "\u4E70\u65B9\u72B6\u6001\u6076\u5316",
      short: "DSS",
      definition: "\u4E70\u65B9\u72B6\u6001\u6076\u5316\uFF08\u22121 ~ 1\uFF09\uFF1A0.45 \xD7 \u5411\u4E0B\u52A8\u91CF\u6807\u51C6\u5316 + 0.25 \xD7 \u5356\u65B9\u6210\u4EA4\u91CF\u65B9\u5411\u5206 + 0.30 \xD7 \u4E3B\u52A8\u5356\u65B9\u5931\u8861\u3002\u4E0B\u8DCC\u65F6\u653E\u91CF\u52A0\u5206\u3001\u7F29\u91CF\u6263\u5206\uFF1B\u4E0A\u6DA8\u65F6\u653E\u91CF\u6263\u5206\u3001\u7F29\u91CF\u4E0D\u52A0\u5206\u3002\u6CBF\u7528 BSS \u7684 1 \u5C0F\u65F6\u8FD1\u671F\u7A97\u53E3\u3001\u6807\u51C6\u5316\u7A97\u53E3\u548C\u6743\u91CD\uFF1B\u6570\u503C\u8D8A\u4F4E\uFF08\u8D8A\u8D1F\uFF09\u8868\u793A\u7EFC\u5408\u72B6\u6001\u8D8A\u504F\u5411\u5356\u65B9\u3002\u8BFB\u6570\u662F\u76F8\u5BF9\u5E38\u6001\u7684\u72B6\u6001\u8BC4\u5206\uFF0C\u4E0D\u662F\u6076\u5316\u901F\u5EA6\u6216\u4E0B\u8DCC\u6982\u7387\u3002",
      sellerSignVersion: 1,
      formula: DSS_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    CDA_FORMULA = sellerNegativeFormula([
      "# CDA \u4E70\u65B9\u963B\u529B\uFF08\u2212100 ~ 100\uFF09\uFF1A\u6210\u4EA4\u652F\u6301 \xD7 \u4E3B\u52A8\u5356\u51FA\u6743\u91CD \xD7 \u4FDD\u7559\u4E0B\u79FB\u901F\u5EA6\uFF0C\u6309\u65F6\u95F4\u52A0\u6743\u540E 100\xB7tanh \u538B\u7F29",
      "# B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF0CQ = B + S\uFF0CE = \u6210\u4EA4\u5747\u4EF7\uFF1Bhl\u3001avgh \u5747\u4EE5\u5C0F\u65F6\u8BA1\uFF0C\u6CBF\u7528 CBA",
      "eta = 0.5                                     # \u53CC\u5411\u6D3B\u8DC3\u6210\u4EA4\u7684\u4FDD\u7559\u6743\u91CD",
      "alpha = 1                                     # \u4E3B\u52A8\u5356\u51FA\u4F18\u52BF\u7684\u989D\u5916\u52A0\u6743\u7CFB\u6570",
      "D = S - B                                     # \u4E3B\u52A8\u5356\u51FA\u51C0\u5DEE\u989D",
      "A = D / Q                                     # \u4E3B\u52A8\u5356\u65B9\u5931\u8861",
      "Vbar = prev(avg(Q, avgh))                     # \u622A\u81F3\u4E0A\u4E00\u6839\u7684\u5E38\u6001\u6210\u4EA4\u989D",
      "F = ln(1 + (abs(D) + eta * (Q - abs(D))) / Vbar)  # \u6210\u4EA4\u652F\u6301",
      "G = 1 + alpha * max(A, 0)                     # \u4E3B\u52A8\u5356\u51FA\u52A0\u6743",
      "P = max(E, C)                                 # \u5F53\u524D\u4EF7\u53D6\u6210\u4EA4\u5747\u4EF7\u4E0E\u6536\u76D8\u4EF7\u7684\u8F83\u9AD8\u8005\uFF0C\u4FDD\u5B88\u8861\u91CF\u5411\u4E0B\u6210\u679C",
      "sig = prev(sd(ln(E / prev(E)), avgh))         # \u622A\u81F3\u4E0A\u4E00\u6839\u7684\u6210\u4EA4\u5747\u4EF7\u5BF9\u6570\u6536\u76CA\u7387\u6CE2\u52A8\u7387",
      "CDA = 100 * tanh(-retain(F * G, P, prev(E), hl, 48) / sig)  # \u4FDD\u7559\u4E0B\u79FB\u901F\u5EA6 = ln(E\u1D62\u208B\u2081 \xF7 P) \xF7 ((t \u2212 i + 1)\xB7\u03C3)\uFF0C48 \u5C0F\u65F6\u7A97\u53E3"
    ].join("\n"), "CDA");
    CDA_DEF = {
      id: "cda",
      name: "\u4E70\u65B9\u963B\u529B " + CDA_FIVE_MINUTE_LABEL,
      short: CDA_FIVE_MINUTE_LABEL,
      definition: "\u4E70\u65B9\u963B\u529B\uFF08\u2212100 ~ 100\uFF09\uFF1A\u8FC7\u53BB 48 \u5C0F\u65F6\u6BCF\u6839 K \u7EBF\u7684\u6210\u4EA4\u652F\u6301 \xD7 \u4E3B\u52A8\u5356\u51FA\u6743\u91CD \xD7 \u5F53\u524D\u4ECD\u4FDD\u7559\u7684\u5411\u4E0B\u4EF7\u683C\u4F4D\u79FB\u901F\u5EA6\uFF0C\u6309\u65F6\u95F4\u52A0\u6743\u540E 100\xB7tanh \u538B\u7F29\u3002\u5F53\u524D\u4EF7\u53D6\u6210\u4EA4\u5747\u4EF7\u4E0E\u6536\u76D8\u4EF7\u7684\u8F83\u9AD8\u8005\uFF0C\u4FDD\u5B88\u8861\u91CF\u5356\u65B9\u6210\u679C\uFF1B\u8D1F\u503C\u8868\u793A\u5411\u4E0B\u7684\u4EF7\u683C\u4F18\u52BF\u4ECD\u88AB\u4FDD\u7559\uFF0C\u6570\u503C\u8D8A\u4F4E\u8868\u793A\u4E70\u65B9\u9762\u4E34\u7684\u5356\u65B9\u963B\u529B\u8D8A\u5F3A\u3002\u6CBF\u7528 CBA \u7684\u7A97\u53E3\u3001\u6743\u91CD\u548C\u6CE2\u52A8\u7387\u6807\u51C6\u5316\uFF1B\u8FD9\u662F\u72B6\u6001\u8BC4\u5206\uFF0C\u4E0D\u662F\u8BA2\u5355\u7C3F\u963B\u529B\u4EF7\u4F4D\u6216\u4E0B\u8DCC\u6982\u7387\u3002",
      sellerSignVersion: 1,
      formula: CDA_FORMULA,
      scale: 1,
      unit: "",
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      source: "campaigns",
      groupVars: 2,
      builtin: true
    };
    CDA_HOURLY_DEF = {
      ...CDA_DEF,
      id: CDA_HOURLY_ID,
      chartTemplate: CDA_HOURLY_ID,
      name: "\u4E70\u65B9\u963B\u529B " + CDA_HOURLY_LABEL,
      short: CDA_HOURLY_LABEL,
      interval: "1h",
      halfLifeHours: DEFAULT_HALF_LIFE_HOURS * CDA_HOURLY_TIME_SCALE,
      avgHours: DEFAULT_AVG_HOURS * CDA_HOURLY_TIME_SCALE,
      formula: CDA_FORMULA.replace("hl, 48)", "hl, " + CDA_HOURLY_RETENTION_HOURS + ")").replace("48 \u5C0F\u65F6\u7A97\u53E3", CDA_HOURLY_RETENTION_HOURS + " \u5C0F\u65F6\u7A97\u53E3"),
      definition: CDA_DEF.definition.replace("48 \u5C0F\u65F6", CDA_HOURLY_RETENTION_HOURS + " \u5C0F\u65F6") + " \u4F7F\u7528\u539F\u751F 1 \u5C0F\u65F6 K \u7EBF\u3002\u65F6\u95F4\u7A97\u53E3\u4E3A 5 \u5206\u949F\u7248\u7684 12 \u500D\uFF0C\u6743\u91CD\u3001\u5C3A\u5EA6\u548C\u65B9\u5411\u76F8\u540C\u3002"
    };
    CTBA_DEF = { id: "ctba", name: "CTBA\uFF5C\u8D8B\u52BF\u4E70\u65B9\u4F18\u52BF", short: "CTBA", definition: CTBA_DESCRIPTION, formula: ctbaFormula(), scale: 1, unit: "", positive: DEFAULT_POSITIVE, control: DEFAULT_CONTROL, source: "campaigns", groupVars: 2, builtin: true, interval: "5m" };
    ctba12hCopy = copyFeatureDefinition(CTBA_DEF, [CTBA_DEF], Date.UTC(2026, 9, 29));
    CTBA_12H_DEF = {
      ...ctba12hCopy,
      id: "ctba_12h",
      name: "CTBA-12H\uFF5C\u8D8B\u52BF\u4E70\u65B9\u4F18\u52BF\uFF0812\u5C0F\u65F6\uFF09",
      short: "CTBA-12H",
      builtin: true,
      chartTemplate: "ctba",
      chartCore: "CTBA",
      interval: "5m",
      halfLifeHours: 2,
      researchWindowHours: 12,
      formula: "ctba_12h_version = 1\n" + ctbaFormula({ ...CTBA_12H_DEFAULTS }),
      definition: "\u539F CTBA \u7684\u72EC\u7ACB12\u5C0F\u65F6\u526F\u672C\uFF1A5m\uFF0CN=144\uFF0CEMA 8/24\uFF0C\u6CE2\u52A8\u7A97\u53E348\u6839\uFF0C\u4E3B\u52A8\u4E70\u5356\u534A\u8870\u671F24\u6839\uFF082h\uFF09\uFF0C\u03BB=ln(2)/24\uFF0C\u03B5=1e-12\uFF0C\u6743\u91CD0.35/0.40/0.25\u3002100\xB7tanh[0.35\xB7tanh(T)+0.40\xB7tanh(M)+0.25\xB7F]\uFF1B0\u662F\u56FA\u5B9A\u7EFC\u5408\u4E2D\u6027\u57FA\u51C6\uFF0C\u6B63\u503C\u504F\u4E70\u65B9\u3001\u8D1F\u503C\u504F\u5356\u65B9\u3002\u5206\u91CF\u6B63\u8D1F\u53EF\u62B5\u6D88\uFF0C0\u4E0D\u5355\u72EC\u8BC1\u660E\u4E3B\u52A8\u4E70\u5356\u989D\u76F8\u7B49\u3002\u65E0\u5E73\u79FB\u3001\u65E0\u6837\u672C\u91CD\u5B9A\u5FC3\u3001\u65E0\u622A\u8D1F\uFF1B\u4FDD\u7559\u7F3A\u5931\u4E0E\u5168\u7CBE\u5EA6\u3002\u7814\u7A76\u5C55\u793A\u5165\u573A\u524D144\u6839\u5DF2\u6536\u76D8\u7EBF\uFF0C\u53E6\u53D6\u6EDA\u52A8\u4E0EEMA\u9884\u70ED\uFF1B\u539FCTBA\u72EC\u7ACB\u4FDD\u7559\u3002"
    };
    LEGACY_MBI_BEAR_FORMULA = bearFeatureFormula(MBI_FORMULA, "MBI", "MBI_bear");
    LEGACY_CTBA_BEAR_FORMULA = bearFeatureFormula(CTBA_DEF.formula, "CTBA", "CTBA_bear");
    MBI_BEAR_DEF = {
      ...MBI_DEF,
      id: "mbi-bear",
      name: "MBI \u7A7A\u65B9\u8D8B\u52BF",
      short: "MBI\xB7\u7A7A\u65B9",
      chartTemplate: "mbi",
      chartCore: "MBI_bear",
      sellerSignVersion: 1,
      definition: "MBI \u7A7A\u65B9\u8D8B\u52BF v2\uFF1A0 \u4E3A\u591A\u7A7A\u5E73\u8861\uFF0C\u5356\u65B9\u4F18\u52BF\u7528\u8D1F\u503C\u3001\u4E70\u65B9\u4F18\u52BF\u7528\u6B63\u503C\uFF0C\u4FDD\u7559 \u22121\uFF5E1 \u53CC\u5411\u523B\u5EA6\u3002\u6B63\u503C\u539F\u6837\u4FDD\u7559\uFF1B\u8D1F\u503C\u5728 tanh \u538B\u7F29\u524D\u65BD\u52A0 seller_gain\uFF08\u9ED8\u8BA4 2\uFF09\uFF0C\u589E\u5F3A\u5F31\u5356\u65B9\u4FE1\u53F7\uFF0C\u4FDD\u6301\u96F6\u8F74\u3001\u8870\u51CF\u5468\u671F\u3001\u9971\u548C\u5C3A\u5EA6\u3001\u9884\u70ED\u53CA\u5747\u503C\u7A97\u53E3\u4E0D\u53D8\u3002MBI=\u22120.5 \u65F6\u7A7A\u65B9\u8BFB\u6570\u4E3A\u22120.8\uFF1B\u7F3A\u5931\u503C\u4E0D\u8865\u96F6\u3002\u589E\u76CA\u53EF\u5728\u516C\u5F0F\u4E2D\u4FEE\u6539\u3002",
      formula: bearFeatureFormula(MBI_FORMULA, "MBI", "MBI_bear", 1, true)
    };
    CTBA_BEAR_DEF = {
      ...CTBA_DEF,
      id: "ctba-bear",
      name: "CTBA \u7A7A\u65B9\u8D8B\u52BF",
      short: "CTBA\xB7\u7A7A\u65B9",
      chartTemplate: "ctba",
      chartCore: "CTBA_bear",
      sellerSignVersion: 1,
      definition: "CTBA \u7A7A\u65B9\u8D8B\u52BF v2\uFF1A0 \u4E3A\u8D8B\u52BF\u4F4D\u7F6E\u3001VWAP \u52A8\u80FD\u53CA\u4E3B\u52A8\u6210\u4EA4\u91D1\u989D\u7684\u7EFC\u5408\u5E73\u8861\uFF0C\u5356\u65B9\u4F18\u52BF\u4E3A\u8D1F\u3001\u4E70\u65B9\u4F18\u52BF\u4E3A\u6B63\uFF0C\u4FDD\u7559 \u2212100\uFF5E100 \u53CC\u5411\u523B\u5EA6\u3002\u6B63\u503C\u539F\u6837\u4FDD\u7559\uFF1B\u8D1F\u503C\u5728\u5916\u5C42 tanh \u538B\u7F29\u524D\u65BD\u52A0 seller_gain\uFF08\u9ED8\u8BA4 2\uFF09\u3002CTBA=\u221250 \u65F6\u7A7A\u65B9\u8BFB\u6570\u4E3A\u221280\u3002\u5168\u90E8\u7A97\u53E3\u3001\u6743\u91CD\u30015m \u5DF2\u6536\u76D8\u89C4\u5219\u3001\u9884\u70ED\u548C\u5747\u503C\u7A97\u53E3\u4FDD\u6301\u4E0D\u53D8\uFF0C\u7F3A\u5931\u503C\u4E0D\u8865\u96F6\uFF1B\u589E\u76CA\u53EF\u5728\u516C\u5F0F\u4E2D\u4FEE\u6539\u3002",
      formula: bearFeatureFormula(CTBA_DEF.formula, "CTBA", "CTBA_bear", 100, true)
    };
    mbi2SellerCopy = copyFeatureDefinition(MBI2_DEF, [MBI2_DEF], Date.UTC(2026, 9, 29, 15));
    MBI2_BEAR_DEF = {
      ...mbi2SellerCopy,
      id: "mbi2-bear",
      name: "MBI2 \u5356\u65B9\u8D8B\u52BF\uFF08\u53EF\u8C03\u7248\uFF09",
      short: "MBI2\xB7\u5356\u65B9",
      builtin: true,
      chartTemplate: "mbi2",
      chartCore: "MBI2_bear",
      sellerSignVersion: 1,
      formula: bearFeatureFormula(MBI2_FORMULA, "MBI2", "MBI2_bear", 1, true) + [
        "",
        "MBI2_bear_state = mbi2state(MBI2_bear,T,MBI2_BAND,MBI2_CONFIRM,0)",
        "MBI2_bear_lead_h = mbi2state(MBI2_bear,T,MBI2_BAND,MBI2_CONFIRM,1)",
        "MBI2_bear_confirm_h = mbi2state(MBI2_bear,T,MBI2_BAND,MBI2_CONFIRM,2)",
        "MBI2_bear = MBI2_bear"
      ].join("\n"),
      definition: "MBI2 \u7684\u72EC\u7ACB\u5356\u65B9\u526F\u672C\u30020\u4E3A\u7EFC\u5408\u5747\u8861\uFF0C\u5356\u65B9\u8D8A\u5F3A\u8D8A\u8D1F\uFF0C\u6B63\u503C\u539F\u6837\u4FDD\u7559\uFF1Bseller_gain\u9ED8\u8BA42\uFF0C\u53EA\u589E\u5F3A\u8D1F\u5411\u5E45\u5EA6\uFF0C\u4E0D\u7F29\u77ED\u65E5\u5386\u65F6\u957F\u30015n\u9884\u70ED\u6216\u5747\u503C\u7A97\u53E3\u3002\u4FDD\u7559\u72EC\u7ACB\u7684\u7F13\u51B2\u72B6\u6001\u53CA\u672C\u8F6E/\u786E\u8BA4\u6301\u7EED\u5C0F\u65F6\uFF1B\u72B6\u6001\u9608\u503C\u4F5C\u7528\u4E8E\u672C\u526F\u672C\u589E\u5F3A\u540E\u7684\u8BFB\u6570\u3002\u786E\u8BA4\u9608\u503C\u9ED8\u8BA40.8\u3001\u7F13\u51B2\u5E26\u9ED8\u8BA40.2\uFF0Cz0\u56FA\u5B9A1.25\u3002\u7F3A\u5931\u4E0D\u8865\u96F6\uFF0C\u539FMBI2\u53CA\u539FMBI\u4E0D\u53D8\uFF1B\u53C2\u6570\u626B\u63CF\u4ECD\u5728\u539FMBI2\u4E70\u65B9\u7814\u7A76\u4E2D\u8FD0\u884C\uFF0C\u672C\u526F\u672C\u652F\u6301\u901A\u7528\u63CF\u8FF0\u4E0E\u63A8\u65AD\u7EDF\u8BA1\u3002"
    };
    ctba12hSellerCopy = copyFeatureDefinition(CTBA_12H_DEF, [CTBA_12H_DEF], Date.UTC(2026, 9, 29, 15, 1));
    CTBA_12H_BEAR_DEF = {
      ...ctba12hSellerCopy,
      id: "ctba_12h-bear",
      name: "CTBA-12H \u5356\u65B9\u8D8B\u52BF\uFF0812\u5C0F\u65F6\uFF09",
      short: "CTBA-12H\xB7\u5356\u65B9",
      builtin: true,
      chartTemplate: "ctba",
      chartCore: "CTBA_12H_bear",
      sellerSignVersion: 1,
      formula: "ctba_12h_bear_version = 1\n" + bearFeatureFormula(CTBA_12H_DEF.formula, "CTBA", "CTBA_12H_bear", 100, true),
      definition: "CTBA-12H \u7684\u72EC\u7ACB\u5356\u65B9\u526F\u672C\u30025m\uFF0CN144\uFF0CEMA8/24\uFF0C\u6CE2\u52A8\u7A97\u53E348\u6839\uFF0C\u4E3B\u52A8\u6210\u4EA4\u534A\u8870\u671F24\u6839\uFF082\u5C0F\u65F6\uFF09\uFF0C\u6743\u91CD0.35/0.40/0.25\u5168\u90E8\u4FDD\u7559\u30020\u4E3A\u56FA\u5B9A\u7EFC\u5408\u5747\u8861\u57FA\u51C6\uFF1B\u6B63\u503C\u539F\u6837\u4FDD\u7559\uFF0C\u8D1F\u503C\u5728\u5916\u5C42tanh\u524D\u4EE5seller_gain\uFF08\u9ED8\u8BA42\uFF09\u589E\u5F3A\uFF0C\u4E0D\u622A\u8D1F\u3001\u4E0D\u6309\u6837\u672C\u5E73\u79FB\u6216\u7F29\u653E\u3002\u8D1F\u5411\u7EDD\u5BF9\u503C\u7406\u8BBA\u4E0A\u754C\u7EA696.4028\uFF0C\u4FDD\u7559\u5BF9\u79F0\u96F6\u8F74\u548C12\u5C0F\u65F6\u7814\u7A76\u7A97\u53E3\uFF1B\u5747\u503C\u53E6\u8BFB\u8DB3\u591F\u9884\u70ED\u3002T/M/F\u53CA\u7F3A\u5931\u4FDD\u7559\uFF0C\u516C\u5F0F\u3001\u7F13\u5B58\u548C\u8BA1\u7B97\u72B6\u6001\u72EC\u7ACB\uFF0C\u539FCTBA-12H\u53CACTBA\u4E0D\u53D8\u3002"
    };
    retentionSources = [CDI2_DEF, SELLER_CONTROL_DEF, DSS_DEF, MBI_BEAR_DEF, CTBA_BEAR_DEF, MBI2_BEAR_DEF, CTBA_12H_BEAR_DEF];
    SELLER_RETENTION_FEATURES = SELLER_RETENTION_SPECS.map((s) => createSellerRetentionCopy(retentionSources.find((d) => d.id === s.sourceId), s));
    ATI6H_DEF = {
      id: "ati6h",
      name: "ATI-6H\uFF5C\u52A0\u4ED3\u652F\u6301\u8BC1\u636E\u6307\u6570",
      short: "ATI-6H",
      builtin: true,
      chartTemplate: "ati6h",
      chartCore: "ATI6H",
      interval: "5m",
      halfLifeHours: 1,
      researchWindowHours: 6,
      scale: 1,
      unit: "",
      source: "campaigns",
      groupVars: 2,
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      ATI6H_volume_mode: "taker",
      definition: "\u6700\u8FD16\u5C0F\u65F6\u5DF2\u6536\u76D8\u5E02\u573A\u8BC1\u636E\uFF0C\u9ED8\u8BA45m\u517172\u6839\uFF0C\u8BC1\u636E\u534A\u8870\u671F1\u5C0F\u65F6\u3002A\u4E70\u65B9\u786E\u8BA4\u3001B\u56FA\u5B9A\u652F\u6491\u6709\u6548\u6027\u3001C\u4E0B\u884C\u4E0E\u6210\u4EA4\u65B9\u5411\u652F\u6301\u3001D\u8FD1\u671F\u63D2\u9488\u98CE\u9669\u4F4E\u3001E\u524D\u65B9\u963B\u529B\u7A7A\u95F4\u3001F\u8C03\u6574\u540E\u7A81\u7834\u524D\u9AD8\u5E76\u7EF4\u6301\u3002\u6743\u91CD0.15/0.35/0.20/0.10/0.10/0.10\u7684\u51E0\u4F55\u5E73\u5747\uFF0C\u96F6\u503C\u5426\u51B3\uFF1B\u975E\u96F6\u77ED\u677F\u53EF\u88AB\u90E8\u5206\u8865\u507F\uFF0C\u5206\u6570\u4E0D\u662F\u80DC\u7387\u6216\u52A0\u4ED3\u6307\u4EE4\u3002\u652F\u6491\u3001\u5931\u6548\u53CA\u7A81\u7834\u7EBF\u5728\u7ED3\u6784\u5185\u51BB\u7ED3\uFF1B\u53F3\u4FA7\u786E\u8BA4\u540E\u624D\u751F\u6548\uFF0C\u7834\u4F4D\u6C38\u4E45\u5931\u6548\u3002\u65B0\u589E\u5E02\u573A\u8BC1\u636E\u96506\u5C0F\u65F6\uFF1B\u5916\u90E8MBI2\u53CA\u5176\u5355\u6839\u5BF9\u6570\u6536\u76CARMS\u4FDD\u7559\u81EA\u8EAB\u9012\u63A8\u548C\u9884\u70ED\u3002\u6210\u4EA4\u6A21\u5F0F\u56FA\u5B9A\u4E3Ataker\uFF08\u771F\u5B9E\u8BA1\u4EF7\u91D1\u989D\uFF09\uFF1B\u7F3A\u5931\u4E0D\u5207\u6362\u4EE3\u7406\uFF0C\u4E0D\u8865\u96F6\u3002\u4E0D\u9644\u5E2648\u5C0F\u65F6\u6C47\u603B\u6216\u989D\u5916\u5E73\u6ED1\u3002",
      formula: "# ati6h-v1\uFF1A\u539F\u751F\u9010\u6839\u7ED3\u6784\u8BC1\u636E\uFF0C\u65E0\u8BA2\u5355\u6267\u884C\uFF1B\u6240\u6709\u503C\u4FDD\u6301\u539F\u59CB\u7CBE\u5EA6\n" + ATI6H_NUMERIC_FIELDS.filter((n) => n !== "ATI6H").map((n) => `${n} = ATI6H_raw_${n.slice(6)}`).join("\n") + "\nATI6H = ATI6H_raw_value"
    };
    PRS6H_DEF = {
      id: PRS6H_ID,
      name: "\u65E5\u5185\u987A\u52BF\u52A0\u4ED3\u8BC1\u636E",
      short: "PRS-6H",
      chartTemplate: "prs6h",
      chartCore: "PRS6H",
      builtin: true,
      interval: "5m",
      halfLifeHours: 0.5,
      researchWindowHours: 6,
      scale: 1,
      unit: "\u5206",
      source: "campaigns",
      groupVars: 2,
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      definition: "PRS-6H v1\uFF1A\u591A\u5934\u65E5\u5185\u52A0\u4ED3\u7684\u5E02\u573A\u8BC1\u636E\uFF0C0\u2013100\u5206\u3002\u56FA\u5B9A\u5E73\u53F0\u4E0E\u5931\u6548\u7EBF\u2192\u51BB\u7ED3\u540E\u7684\u72EC\u7ACB\u6D4B\u8BD5\u2192\u66F4\u9AD8\u9632\u5B88\u2192\u8FDE\u7EED\u4E24\u6839\u7A81\u7834\u786E\u8BA4\uFF1B\u8FD1\u671F\u8BC1\u636E\u52A0\u6743\uFF0CT/S/D/B/V\u6743\u91CD0.15/0.40/0.25/0.15/0.05\uFF0C\u53E6\u53D7\u6838\u5FC3\u5206\u9879\u4E0B\u9650\u4E0E\u786C\u6761\u4EF6\u5426\u51B3\u3002\u521D\u59CB\u7ED3\u6784\u4EC5\u5EFA\u7ACB\u57FA\u51C6\uFF1B\u540C\u4E00\u7ED3\u6784\u6700\u591A\u4E00\u4E2A\u5E02\u573A\u5C31\u7EEA\u4E8B\u4EF6\u30020\u8868\u793A\u672C\u6307\u6807\u8BC1\u636E\u672A\u6EE1\u8DB3\uFF0C\u4E0D\u662F\u770B\u7A7A\u3002\u8D26\u6237\u6D6E\u76C8\u3001\u4F59\u989D\u3001\u98CE\u9669\u9884\u7B97\u4E0D\u8FDB\u5165\u5206\u6570\uFF0C\u7ED3\u6784\u5931\u6548\u7EBF\u4E0D\u6539\u771F\u5B9E\u6B62\u635F\uFF1B\u5B9E\u9645\u8D26\u6237\u6743\u9650\u4E0E\u6267\u884C\u68C0\u67E5\u6CBF\u7528\u5DF2\u6709\u6A21\u5757\u3002\u6240\u6709\u9ED8\u8BA4\u503C\u4E3A\u7814\u7A76\u521D\u503C\uFF0C\u4E0D\u662F\u539F\u4E66\u516C\u5F0F\u6216\u5DF2\u8BC1\u5B9E\u7B56\u7565\u3002\u663E\u793A6h\uFF0C\u52A0\u8F7D\u9884\u70ED\u5E76\u987A\u5E8F\u6062\u590D\u7ED3\u6784\u3002\u62A5\u4EF7\u5E01\u6210\u4EA4\u989D\u4E3A\u9ED8\u8BA4\u6A21\u5F0F\uFF0C\u7F3A\u5931\u4E0D\u8865\u96F6\uFF0C\u4E0D\u9759\u9ED8\u5207\u6362\u6D41\u91CF\u6A21\u5F0F\u3002",
      formula: "# PRS-6H v1 \xB7 \u56FA\u5B9A\u7ED3\u6784\u3001\u56E0\u679C\u6D4B\u8BD5\u4E0E\u5E02\u573A\u95E8\u63A7\uFF1B\u7814\u7A76\u521D\u503C\n" + PRS6H_FIELDS.filter((n) => n !== "PRS6H").map((n) => `${n} = PRS6H_raw_${n.slice(6)}`).join("\n") + "\nPRS6H = PRS6H_raw_value"
    };
    SBS5M_DEF = {
      id: SBS5M_ID,
      name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491",
      short: "SBS-5M",
      builtin: true,
      chartTemplate: SBS5M_ID,
      chartCore: "SBS5M",
      interval: "5m",
      researchWindowHours: 6,
      halfLifeHours: 0.5,
      scale: 1,
      unit: "\u4EF7\u683C",
      source: "campaigns",
      groupVars: 2,
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      SBS5M_dimension: "price",
      definition: "SBS-5M v1 \xB7 \u7814\u7A76\u521D\u503C\u30025\u5206\u949F\u5DF2\u6536\u76D8K\u7EBF\u5F62\u6210\u6A2A\u5411\u7BB1\u4F53\uFF0C\u51BB\u7ED3\u8FB9\u754C\u540E\u7531\u72EC\u7ACB\u6D4B\u8BD5\u786E\u8BA4\uFF1B\u7236\u7BB1\u4E24\u6839\u7A81\u7834\u540E\uFF0C\u66F4\u9AD8\u65B0\u7BB1\u901A\u8FC7\u6D4B\u8BD5\u624D\u62AC\u5347\u3002\u56FA\u5B9A\u5931\u6548\u53C2\u8003\u88AB\u89E6\u53CA\u6216\u8FDE\u7EED\u4E24\u6839\u6536\u4E8E\u7BB1\u5E95\u4E0B\u65B9\u5373\u65AD\u7EBF\uFF1B\u786E\u8BA4\u540E\u9ED8\u8BA46\u5C0F\u65F6\u8FC7\u671F\uFF0C\u518D\u6B21\u6D4B\u8BD5\u4E0D\u7EED\u671F\u3002\u6210\u4EA4\u989D\u9ED8\u8BA4\u62A5\u4EF7\u5E01\u6A21\u5F0F\uFF0C\u7F3A\u53E3\u7ED3\u675F\u7ED3\u6784\u3002\u4E3B\u503C\u6709\u4EF7\u683C\u5355\u4F4D\uFF0C\u7981\u6B62\u8DE8\u54C1\u79CD\u6C47\u603B\uFF1B\u8DE8\u54C1\u79CD\u8BF7\u9009\u62E9\u8BC1\u636E\u5206\u3001\u6807\u51C6\u5316\u8DDD\u79BB\u6216\u53F0\u9636\u4E8B\u4EF6\u5E45\u5EA6\u3002\u9ED8\u8BA4\u4ECE\u52A0\u8F7D\u7A97\u53E3\u8D77\u70B9\u660E\u786E\u521D\u59CB\u5316\uFF0C\u975E\u4EFB\u610F6\u5C0F\u65F6\u4E0E\u5B8C\u6574\u5386\u53F2\u7B49\u4EF7\u3002\u8BC1\u636E\u5206\u4E0D\u662F\u80DC\u7387\uFF0C\u4E0D\u63A7\u5236\u771F\u5B9E\u6B62\u635F\u6216\u52A0\u4ED3\u3002",
      formula: "# sbs-5m-v1 \xB7 fixed box, independent later test; raw price axis\n" + SBS5M_FIELDS.filter((n) => n !== "SBS5M").map((n) => `${n} = SBS5M_raw_${n.slice(6)}`).join("\n") + "\nSBS5M = SBS5M_raw_value"
    };
    SBS5M_DIMENSIONS = [
      { id: "sbs_5m_quality", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u8BC1\u636E\u5206", short: "SBS\xB7\u8BC1\u636E", core: "SBS5M_support_quality", dimension: "quality", unit: "\u5206" },
      { id: "sbs_5m_distance", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u6807\u51C6\u5316\u8DDD\u79BB", short: "SBS\xB7\u8DDD\u79BB", core: "SBS5M_distance_to_support", dimension: "distance", unit: "\u4E8B\u524D\u5C3A\u5EA6" },
      { id: "sbs_5m_step", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u53F0\u9636\u5E45\u5EA6", short: "SBS\xB7\u53F0\u9636", core: "SBS5M_step_height_atr", dimension: "step", unit: "\u65B0\u51BB\u7ED3\u5C3A\u5EA6" }
    ].map((d) => ({
      ...SBS5M_DEF,
      id: d.id,
      name: d.name,
      short: d.short,
      chartCore: d.core,
      SBS5M_dimension: d.dimension,
      unit: d.unit,
      formula: "# sbs-5m-v1 \xB7 normalized dimension; no pooled absolute prices\n" + ["SBS5M_support_quality", "SBS5M_distance_to_support", "SBS5M_step_height_atr", "SBS5M_step_event_height"].filter((n) => n !== d.core).map((n) => `${n} = SBS5M_raw_${n.slice(6)}`).join("\n") + `
${d.core} = SBS5M_raw_${d.core.slice(6)}`
    }));
    DBL5_DEF = {
      id: DBL5_ID,
      name: "DBL-5-5mins\uFF5C\u8FBE\u74E6\u65AF\u7BB1\u4F53\u4E0B\u8F68",
      short: "DBL-5-5mins",
      builtin: true,
      chartTemplate: DBL5_ID,
      chartCore: "DBL5",
      interval: "5m",
      researchWindowHours: 6,
      scale: 1,
      unit: "\u4EF7\u683C",
      source: "campaigns",
      groupVars: 2,
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      DBL5_dimension: "price",
      definition: "\u5DF2\u6536\u76D85\u5206\u949F\u8FBE\u74E6\u65AF\u7BB1\u4F53\u5DE5\u7A0B\u6539\u7F16\uFF0C\u9ED8\u8BA4n=3\u3001\u51E0\u4F55\u8BC1\u636E\u7A97\u53E3360\u5206\u949F\u3002\u5C40\u90E8\u65B0\u9AD8\u540E\u72EC\u7ACB\u89C2\u5BDF\u7BB1\u5E95\uFF1B\u4E0A\u4E0B\u8FB9\u754C\u7B49\u5F85\u5B8C\u6210\u624D\u53D1\u5E03\u5E76\u51BB\u7ED3\u3002\u76F8\u90BB\u6240\u9009\u7BB1\u4F53\u5206\u4E3A\u57FA\u51C6\u3001\u5B8C\u6574\u4E0A\u79FB\u3001\u5185\u90E8\u7BB1\u5E95\u62AC\u9AD8\u548C\u540C\u5E95\u65B0\u7BB1\u3002\u6700\u4F4E\u4EF7\u4E25\u683C\u4F4E\u4E8E\u5F53\u524D\u4E0B\u8F68\u5373\u7834\u574F\uFF0C\u89E6\u53CA\u4E0D\u7834\u574F\uFF1B\u5230\u671F\u4ECE\u5C40\u90E8\u65B0\u9AD8\u4F9D\u8D56\u7684\u6700\u65E9K\u7EBF\u8BA1\u65F6\uFF0C\u7F3A\u53E3\u91CD\u7F6E\u3002\u786E\u8BA4\u7BB1\u5E95\u4E0D\u7B49\u4E8E\u540E\u7EED\u56DE\u8E29\u5DF2\u9A8C\u8BC1\u3002\u4E3B\u503C\u6709\u4EF7\u683C\u5355\u4F4D\uFF0C\u8BF7\u9009\u5355\u54C1\u79CD\u7814\u7A76\uFF1B\u8DE8\u54C1\u79CD\u4F7F\u7528\u57FA\u70B9\u6216\u5E74\u9F84\u7EF4\u5EA6\u3002\u53C2\u6570\u5C1A\u672A\u5B9E\u8BC1\u62DF\u5408\uFF0C\u4E0D\u6D89\u53CA\u771F\u5B9E\u6B62\u635F\u3001\u4ED3\u4F4D\u6216\u6267\u884C\u3002",
      formula: "# dbl-5-v2 \xB7 exact tick structure, available only after full confirmation\n" + DBL5_FIELDS.filter((n) => n !== "DBL5").map((n) => `${n} = DBL5_raw_${n.slice(5)}`).join("\n") + "\nDBL5 = DBL5_raw_value"
    };
    featureUsesDbl5GuardPlus = (def) => /\bDBL5[PC]_raw_\w+\b/.test(def.formula ?? "");
    DBL5_GUARD_PLUS_DEF = {
      ...DBL5_DEF,
      id: DBL5_GUARD_PLUS_VERSION,
      name: DBL5_GUARD_PLUS_LABEL,
      short: DBL5_GUARD_PLUS_LABEL,
      chartCore: "DBL5P",
      definition: "\u65E0 BTC \u4F9D\u8D56\u30025m \u6536\u76D8\u540E\u6BD4\u8F83\u539F\u7248\u9632\u5B88\u7EBF\u4E0E\u51BB\u7ED3\u7684\u6025\u62C9\u8D77\u70B9\u53C2\u8003\u3002\u6025\u62C9\u8D77\u70B9\u53C2\u8003\uFF0C\u5C1A\u4E0D\u4EE3\u8868\u56DE\u8E29\u9A8C\u8BC1\u3002",
      formula: "# " + DBL5_GUARD_PLUS_VERSION + "\n" + [...DBL5_GUARD_PLUS_NUMERIC.slice(1), "DBL5P"].map((name) => `${name} = ${guardPlusInput(name)}`).join("\n")
    };
    IMPULSE_1115_CLASSIFICATION_DEF = {
      ...DBL5_GUARD_PLUS_DEF,
      id: IMPULSE_1115_CLASSIFICATION_VERSION,
      name: IMPULSE_1115_CLASSIFICATION_LABEL,
      short: IMPULSE_1115_CLASSIFICATION_LABEL,
      chartCore: "DBL5C",
      unit: "\u5206\u7C7B",
      DBL5C_parameters: { ...IMPULSE_1115_CLASSIFICATION_DEFAULTS },
      definition: "\u72EC\u7ACB\u89C2\u5BDF\u539F\u6025\u62C9\u7EBF\u7684\u6301\u4ED3\u72B6\u6001\u3002\u4E00\u7C7B\u4E3A\u6B63\u5E38\u5EF6\u7EED\uFF08\u7B2C1\u30012\u79CD\uFF09\uFF0C\u4E8C\u7C7B\u4E3A\u8D70\u5F31\u3001\u8DCC\u7834\u6216\u4FEE\u590D\uFF08\u7B2C3\u81F36\u79CD\uFF09\u3002\u4E3B\u5206\u7C7B\u53EA\u67091\u62162\uFF1B\u7EC6\u52060\u8868\u793A\u7B49\u5F85\uFF0C1\u81F36\u5BF9\u5E94\u516D\u79CD\u72B6\u6001\u3002\u53EA\u5728\u8BC1\u636E\u9F50\u5907\u76845m\u6536\u76D8\u751F\u6548\uFF0C\u4FDD\u7559\u6BCF\u6761\u7EBF\u7684\u6D4B\u8BD5\u3001\u523A\u7A7F\u3001\u8DCC\u7834\u3001\u6536\u590D\u53CA\u72B6\u6001\u5386\u53F2\u3002\u539F\u7EBF\u65AD\u88C2\u6216\u5230\u671F\u540E\u4ECD\u4EE5\u51BB\u7ED3\u4EF7\u683C\u89C2\u5BDF\uFF1B\u884C\u60C5\u7F3A\u53E3\u6682\u505C\u8BE5\u7EBF\u3002\u672C\u5206\u7C7B\u4E0D\u89E6\u53D1\u4EA4\u6613\u52A8\u4F5C\u3002\u7F16\u8F91\u5B9A\u4E49\u53EF\u8C03\u6574\u5206\u7C7B\u53C2\u6570\u3002",
      formula: "# " + IMPULSE_1115_CLASSIFICATION_VERSION + "\n# DBL5C\uFF1A\u4E3B\u5206\u7C7B1/2\uFF1Bstate\uFF1A\u5DF2\u786E\u8BA4\u7B2C1\u81F36\u79CD\uFF0C0\u4E3A\u8FC7\u6E21\uFF1Bvalid\uFF1A\u6570\u636E\u8FDE\u7EED\u53EF\u7528\uFF1Bpierced\uFF1A\u66FE\u523A\u7A7F\n" + [...IMPULSE_1115_CLASSIFICATION_FIELDS.slice(1), "DBL5C"].map((name) => name + " = " + (name === "DBL5C" ? "DBL5C_raw_value" : "DBL5C_raw_" + name.slice(6))).join("\n")
    };
    DBL5_DIMENSIONS = [
      { id: "darvas_5m_distance_bps", name: "DBL-5-5mins\uFF5C\u8DDD\u4E0B\u8F68\u57FA\u70B9", short: "DBL\xB7\u8DDD\u79BB", core: "DBL5_distance_bps", dimension: "distance", unit: "bp" },
      { id: "darvas_5m_width_bps", name: "DBL-5-5mins\uFF5C\u7BB1\u5BBD\u57FA\u70B9", short: "DBL\xB7\u7BB1\u5BBD", core: "DBL5_width_bps", dimension: "width", unit: "bp" },
      { id: "darvas_5m_age_minutes", name: "DBL-5-5mins\uFF5C\u786E\u8BA4\u5E74\u9F84", short: "DBL\xB7\u5E74\u9F84", core: "DBL5_age_minutes", dimension: "age", unit: "\u5206\u949F" }
    ].map((d) => ({
      ...DBL5_DEF,
      id: d.id,
      name: d.name,
      short: d.short,
      chartCore: d.core,
      DBL5_dimension: d.dimension,
      unit: d.unit,
      formula: "# dbl-5-v2 \xB7 derived units and boolean event flags, no absolute price pooling\n" + DBL5_FIELDS.filter((n) => n !== "DBL5" && n !== "DBL5_upper" && n !== d.core).map((n) => `${n} = DBL5_raw_${n.slice(5)}`).join("\n") + `
${d.core} = DBL5_raw_${d.core.slice(5)}`
    }));
    DBL5_HOURLY_FEATURES = [
      dbl5VariantDefinition("1h"),
      ...DBL5_DIMENSIONS.map((d) => ({
        ...dbl5VariantDefinition("1h"),
        id: d.id.replace("_5m_", "_1h_"),
        name: d.name.replace("DBL-5-5mins", "DBL-5-1h"),
        short: d.short.replace("DBL\xB7", "DBL-5-1h\xB7"),
        chartCore: d.chartCore,
        unit: d.unit,
        DBL5_dimension: d.DBL5_dimension,
        formula: d.formula.replace(DBL5_VERSION, DBL5_PROFILES["1h"].version)
      }))
    ];
    ORIGINAL_BUILTIN_FEATURES = [DRIFT_SPEED_DEF, BSS_DEF, CBA_DEF, DRIFT_SPEED_Z_DEF, CBI_DEF, CBA2_DEF, CBI2_DEF, MBI_DEF, MBI2_DEF, CTBA_DEF, CTBA_12H_DEF, STATE_DEF, STATE2_DEF, CDI2_DEF, SELLER_CONTROL_DEF, DSS_DEF, CDA_DEF, MBI_BEAR_DEF, CTBA_BEAR_DEF, MBI2_BEAR_DEF, CTBA_12H_BEAR_DEF, ...SELLER_RETENTION_FEATURES, ATI6H_DEF, PRS6H_DEF, SBS5M_DEF, ...SBS5M_DIMENSIONS, DBL5_DEF, ...DBL5_DIMENSIONS];
    SELLER_FOCUS_CREATED_AT = Date.parse("2026-10-30T06:03:46Z");
    SELLER_FOCUS_FEATURES = Object.keys(FOCUS_SOURCE_CORES).map((id2) => ({ ...createSellerFocusCopy(id2 === CDA_DEF.id ? { ...CDA_DEF, name: "\u4E70\u65B9\u963B\u529B", short: "CDA" } : ORIGINAL_BUILTIN_FEATURES.find((d) => d.id === id2), id2 + "-v2", id2 === "state" ? Date.parse("2026-10-30T06:26:11Z") : SELLER_FOCUS_CREATED_AT), builtin: true }));
    BTC_ADJUSTED_FEATURES = [
      CBI2_DEF,
      CDI2_DEF,
      STATE_DEF,
      STATE2_DEF,
      ...SELLER_RETENTION_FEATURES.filter((def) => def.retentionSourceId === CDI2_DEF.id),
      ...SELLER_FOCUS_FEATURES.filter((def) => ["state", "cdi2", "cdi2-retain"].includes(def.focusSourceId ?? ""))
    ];
    BTC_FREE_FEATURES = BTC_ADJUSTED_FEATURES.map((source) => ({
      ...source,
      id: btcFreeId(source.id),
      name: `${source.name}\uFF5C\u65E0 BTC`,
      short: `${source.short}\xB7\u65E0BTC`,
      chartTemplate: featureTemplateId(source),
      btcFreeSourceId: source.id,
      focusSourceId: source.focusSourceId ? btcFreeId(source.focusSourceId) : void 0,
      retentionSourceId: source.retentionSourceId ? btcFreeId(source.retentionSourceId) : void 0,
      definition: `\u72EC\u7ACB\u7248\u672C v1\uFF0C\u6E90\u6307\u6807\u4E3A\u300C${source.name}\u300D\u3002\u77ED\u671F\u52A8\u91CF\u76F4\u63A5\u4F7F\u7528\u6807\u7684\u81EA\u8EAB\u6536\u76CA\u3002\u5176\u4F59\u516C\u5F0F\u3001\u7A97\u53E3\u548C\u6743\u91CD\u6CBF\u7528\u6E90\u6307\u6807\u3002\u7B5B\u9009\u9608\u503C\u9700\u5355\u72EC\u9A8C\u8BC1\u3002`,
      formula: "# no-btc-v1 \xB7 \u6807\u7684\u81EA\u8EAB\u52A8\u91CF\n" + source.formula.split("\n").filter((line) => !/^\s*(?:rb|phi)\s*=/.test(line) && !/^\s*#.*\bBTC(?:USDT)?\b/.test(line)).map((line) => line.replace(/rho\s*-\s*nz\(\s*\(?phi\s*\*\s*rb\)?\s*\)(?:\s*#.*)?/, "rho").replace(/\s+#.*\bBTC\b.*$/, "")).join("\n")
    }));
    BSS_COMPONENT_FEATURES = [
      {
        id: "bss-mz-v1",
        core: "BSS_Mz",
        label: "\u4EF7\u683C\u52A8\u91CF",
        definition: "\u8FD1\u671F\u6DA8\u8DCC\u5E45\u7ECF\u6EDA\u52A8\u6807\u51C6\u5316\u540E\u53D6 tanh\u3002BSS \u4E2D\u6743\u91CD\u4E3A 45%\u3002",
        expression: "M = C / ago(C, n) - 1\nBSS_Mz = tanh(zscore(M, avgh))"
      },
      {
        id: "bss-vd-v1",
        core: "BSS_Vd",
        label: "\u65B9\u5411\u6210\u4EA4\u91CF",
        definition: "\u4E0A\u6DA8\u65F6\u653E\u91CF\u52A0\u5206\u3001\u7F29\u91CF\u6263\u5206\uFF1B\u4E0B\u8DCC\u65F6\u653E\u91CF\u6263\u5206\u3001\u7F29\u91CF\u4E3A\u96F6\uFF1B\u5E73\u76D8\u4E3A\u96F6\u3002BSS \u4E2D\u6743\u91CD\u4E3A 25%\u3002",
        expression: "M = C / ago(C, n) - 1\nV = avg(Q, n) / avg(Q, avgh)\nVz = tanh(zscore(V, avgh))\nBSS_Vd = if(M > 0, Vz, if(M < 0, min(-Vz, 0), 0))"
      },
      {
        id: "bss-a-v1",
        core: "BSS_A",
        label: "\u6210\u4EA4\u653B\u51FB\u6027",
        definition: "\u8FD1\u671F\u4E3B\u52A8\u4E70\u5356\u6210\u4EA4\u989D\u4E4B\u5DEE\u9664\u4EE5\u540C\u671F\u603B\u6210\u4EA4\u989D\u3002BSS \u4E2D\u6743\u91CD\u4E3A 30%\u3002",
        expression: "BSS_A = (avg(B, n) - avg(S, n)) / avg(Q, n)"
      }
    ].map(({ id: id2, core, label, definition, expression }) => {
      const base = "n = 1\n" + expression;
      const formula = appendResearchAverages(base, /* @__PURE__ */ new Set([core]), { core, avg: "avg_" + core, avg2: "avg_" + core + "_2" });
      return {
        ...BSS_DEF,
        id: id2,
        name: "BSS " + label + "\uFF08" + core.slice(4) + "\uFF09",
        short: "BSS\xB7" + core.slice(4),
        chartCore: core,
        definition,
        formula: formula + "\n" + core + " = " + core
      };
    });
    ATR_PRICE_PCT_DEF = {
      id: "atr-price-pct-v1",
      name: "\u771F\u5B9E\u6CE2\u52A8\u7387\u5360\u73B0\u4EF7\uFF08%\uFF09",
      short: "\u771F\u5B9E\u6CE2\u52A8\u7387\u5360\u73B0\u4EF7\uFF08%\uFF09",
      definition: "\u6240\u9009 K \u7EBF\u5468\u671F\u7684 Wilder ATR \u9664\u4EE5\u8BA1\u7B97\u65F6\u70B9\u7684\u4EF7\u683C\uFF0C\u4E58\u4EE5 100\u3002\u9ED8\u8BA4\u53D6 14 \u6839 K \u7EBF\u3002",
      chartCore: "ATRP",
      formula: "ATRP = atr(H, L, C, 14) / C * 100",
      interval: "5m",
      scale: 1,
      unit: "%",
      source: "campaigns",
      groupVars: 2,
      positive: DEFAULT_POSITIVE,
      control: DEFAULT_CONTROL,
      builtin: true
    };
    BUILTIN_FEATURES = [...ORIGINAL_BUILTIN_FEATURES, CDA_HOURLY_DEF, ...DBL5_HOURLY_FEATURES, DBL5_GUARD_PLUS_DEF, IMPULSE_1115_CLASSIFICATION_DEF, ...SELLER_FOCUS_FEATURES, ...BTC_FREE_FEATURES, ATR_PRICE_PCT_DEF, ...BSS_COMPONENT_FEATURES];
    definitionKey = (d) => {
      const g = upgradeGroupVars(d);
      const raw = d.formula.trim() === LEGACY_DRIFT_SPEED_FORMULA ? EMA_DRIFT_SPEED_FORMULA : d.formula.trim();
      const formula = raw.split("\n").map((l) => l.replace(/#.*$/, "").trimEnd()).filter(Boolean).join("\n");
      const key = [formula, g.positive.trim(), g.control.trim(), d.source ?? "campaigns"];
      if (intervalOf(d) !== DEFAULT_INTERVAL) key.push(intervalOf(d));
      if (halfLifeOf(d) !== DEFAULT_HALF_LIFE_HOURS) key.push(`hl=${halfLifeOf(d)}`);
      if (avgHoursOf(d) !== DEFAULT_AVG_HOURS) key.push(`avgh=${avgHoursOf(d)}`);
      if (featureUsesMbi(d)) key.push(`MBI_N=${mbiNOf(d)}`, `MBI_Z0=${mbiZ0Of(d)}`);
      if (featureUsesMbi2(d)) {
        const p = featureParams(d);
        key.push(`MBI2_T_HOURS=${p.MBI2_T_HOURS}`, `MBI2_Z0=${p.MBI2_Z0}`, `MBI2_BAND=${p.MBI2_BAND}`, `MBI2_CONFIRM=${p.MBI2_CONFIRM}`);
      }
      const dbl5 = dbl5ProfileForFeature(featureTemplateId(d));
      if (dbl5) key.push(dbl5.version, DBL5_MARKET_RULE_VERSION, dbl5ConfigHash(d.DBL5_config), "DBL5_config=" + JSON.stringify(dbl5Parameters(d.DBL5_config)), "DBL5_dimension=" + (d.DBL5_dimension ?? "price"), "DBL5_research_symbol=" + (d.DBL5_research_symbol ?? ""), "DBL5_initialization_start=" + (d.DBL5_initialization_start ?? ""));
      if (/\bDBL5C_raw_/.test(d.formula)) key.push(IMPULSE_1115_CLASSIFICATION_VERSION, "DBL5C_parameters=" + JSON.stringify({ ...IMPULSE_1115_CLASSIFICATION_DEFAULTS, ...d.DBL5C_parameters }));
      if (featureUsesDbl5GuardPlus(d)) key.push(DBL5_GUARD_PLUS_VERSION, JSON.stringify(DBL5_GUARD_PLUS_PARAMS));
      if (featureTemplateId(d) === SBS5M_ID) key.push(SBS5M_VERSION, sbsConfigHash(d.SBS5M_config), "SBS5M_config=" + JSON.stringify(sbsParameters(d.SBS5M_config)), "SBS5M_dimension=" + (d.SBS5M_dimension ?? "price"), "init:window-start-v1", "SBS5M_research_symbol=" + (d.SBS5M_research_symbol ?? ""));
      if (featureTemplateId(d) === "prs6h") key.push(PRS6H_VERSION, "PRS6H_config=" + JSON.stringify(d.PRS6H_config ?? {}), d.PRS6H_config?.volumeMode ?? "quote");
      if (featureTemplateId(d) === "ati6h") key.push(ATI6H_VERSION, "ATI6H_parameters=" + JSON.stringify(d.ATI6H_parameters ?? {}), "ATI6H_volume_mode=" + (d.ATI6H_volume_mode ?? "taker"), "ATI6H_dependency=" + JSON.stringify(ati6hDependencyOf(d)));
      if (d.chartTemplate) key.push("chart=" + d.chartTemplate);
      if (d.researchWindowHours != null) key.push("researchHours=" + d.researchWindowHours);
      return JSON.stringify(key);
    };
  }
});

// src/lib/impulse5m.ts
var IMPULSE_5M_DISPLAY_NAME, IMPULSE_5M_VERSION;
var init_impulse5m = __esm({
  "src/lib/impulse5m.ts"() {
    IMPULSE_5M_DISPLAY_NAME = "DBL-5-\u6025\u62C9\u7EBF-0";
    IMPULSE_5M_VERSION = "impulse-low-5m-v1";
  }
});

// src/lib/fish/qualityBoxReference.ts
function validateBoxStopReference(r) {
  if (!r || !Object.prototype.hasOwnProperty.call(BOX_STOP_REFERENCE_LABELS, r.kind)) throw Error("\u8BF7\u9009\u62E9\u53EF\u6267\u884C\u7684\u6025\u62C9\u7EBF K \u57FA\u51C6");
  if (r.kind === "impulse0") {
    if (r.version !== IMPULSE_5M_VERSION) throw Error("\u6025\u62C9\u7EBF-0 \u7248\u672C\u4E0D\u7B26");
    return;
  }
  if (r.version === DBL5_GUARD_PLUS_VERSION && r.impulseBufferAtr === void 0) return;
  if (r.version !== DBL5_GUARD_PLUS_CONFIGURABLE_K_VERSION || !Number.isFinite(r.impulseBufferAtr) || r.impulseBufferAtr < 0 || r.impulseBufferAtr > 20) throw Error("\u6025\u62C9\u7EBF-1115 \u7684\u7248\u672C\u4E0E\u5197\u4F59\u53C2\u6570\u4E0D\u7B26\uFF080\u201320 ATR\uFF09");
}
var BOX_STOP_REFERENCE_VERSION, BOX_STOP_REFERENCE_LABELS, boxStopReferenceIdentity;
var init_qualityBoxReference = __esm({
  "src/lib/fish/qualityBoxReference.ts"() {
    init_impulse5m();
    init_dbl5GuardPlus();
    BOX_STOP_REFERENCE_VERSION = "holding-box-stop-reference-v1";
    BOX_STOP_REFERENCE_LABELS = {
      "impulse0": IMPULSE_5M_DISPLAY_NAME,
      "impulse1115": IMPULSE_1115_DISPLAY_NAME,
      "guard-plus1115": DBL5_GUARD_PLUS_DISPLAY_NAME
    };
    boxStopReferenceIdentity = (r) => [r.kind, r.version, ...r.kind === "impulse0" ? [] : [r.impulseBufferAtr ?? null]];
  }
});

// src/lib/atr.ts
var init_atr = __esm({
  "src/lib/atr.ts"() {
  }
});

// src/lib/impulse1115ClassificationDisplay.ts
var IMPULSE_1115_CLASS_COLORS, IMPULSE_1115_REFERENCE_CLASS, IMPULSE_1115_REFERENCE_DETECTED_AT, IMPULSE_1115_DISPLAY_REFERENCE, IMPULSE_1115_CLASSIFICATION_RENDER_FIELDS;
var init_impulse1115ClassificationDisplay = __esm({
  "src/lib/impulse1115ClassificationDisplay.ts"() {
    init_dbl5m();
    IMPULSE_1115_CLASS_COLORS = Object.freeze({ 1: "#16a34a", 2: "#ea580c" });
    IMPULSE_1115_REFERENCE_CLASS = "_DBL5C_reference_class";
    IMPULSE_1115_REFERENCE_DETECTED_AT = "_DBL5C_reference_detected_at";
    IMPULSE_1115_DISPLAY_REFERENCE = "_DBL5C_display_reference";
    IMPULSE_1115_CLASSIFICATION_RENDER_FIELDS = [IMPULSE_1115_REFERENCE_CLASS, IMPULSE_1115_REFERENCE_DETECTED_AT, IMPULSE_1115_DISPLAY_REFERENCE];
  }
});

// src/lib/dbl5mPersistence.ts
var init_dbl5mPersistence = __esm({
  "src/lib/dbl5mPersistence.ts"() {
    init_dbl5m();
    init_userStoragePrefix();
  }
});

// src/lib/sbs5mPersistence.ts
var init_sbs5mPersistence = __esm({
  "src/lib/sbs5mPersistence.ts"() {
    init_sbs5m();
    init_userStoragePrefix();
  }
});

// src/lib/prs6hPersistence.ts
var init_prs6hPersistence = __esm({
  "src/lib/prs6hPersistence.ts"() {
    init_prs6h();
    init_userStoragePrefix();
  }
});

// src/lib/ati6hMarketData.ts
var init_ati6hMarketData = __esm({
  "src/lib/ati6hMarketData.ts"() {
    init_binanceRateLimit();
    init_turingCupMarketData();
    init_turingCupSymbol();
    init_userStoragePrefix();
  }
});

// src/lib/chartComputeClient.ts
var init_chartComputeClient = __esm({
  "src/lib/chartComputeClient.ts"() {
    init_dbl5m();
    init_dbl5mMarketRules();
    init_dbl5m();
    init_dbl5mPersistence();
    init_sbs5mPersistence();
    init_sbs5m();
    init_prs6hPersistence();
    init_prs6h();
    init_marketData();
    init_features();
  }
});

// src/lib/featureSource.ts
var CHART_PARAM;
var init_featureSource = __esm({
  "src/lib/featureSource.ts"() {
    init_cdaPeriods();
    init_impulse1115ClassificationDisplay();
    init_dbl5m();
    init_dbl5mPersistence();
    init_sbs5m();
    init_sbs5mPersistence();
    init_prs6hPersistence();
    init_features();
    init_ati6hMarketData();
    init_features();
    init_chartComputeClient();
    init_features();
    init_mbi();
    init_mbi2();
    init_marketData();
    init_formula();
    init_persistedStateStorage();
    init_userStoragePrefix();
    CHART_PARAM = {
      prs6h: { param: "hl" },
      ati6h: { param: "hl" },
      "drift-speed": { param: "hl" },
      "drift-speed-z": { param: "hl" },
      cba: { param: "hl" },
      "cba-2": { param: "hl" },
      state: { param: "avgh" },
      state2: { param: "avgh" },
      cdi2: { param: "avgh" },
      "seller-control": { param: "hl" },
      dss: { constant: "n" },
      cda: { param: "hl" },
      [CDA_HOURLY_ID]: { param: "hl" },
      ctba: { constant: "N" },
      cbi2: { param: "avgh" },
      bss: { constant: "n" },
      "bss-mz-v1": { constant: "n" },
      "bss-vd-v1": { constant: "n" },
      "bss-a-v1": { constant: "n" },
      cbi: { constant: "h" }
    };
  }
});

// src/lib/fish/shared.ts
var init_shared = __esm({
  "src/lib/fish/shared.ts"() {
  }
});

// src/lib/fish/thresholdRange.ts
function validateFishRange({ min, max }) {
  if (min === void 0 && max === void 0) throw Error("\u533A\u95F4\u81F3\u5C11\u586B\u5199\u4E00\u4E2A\u8FB9\u754C");
  if ([min, max].some((n) => n !== void 0 && !Number.isFinite(n))) throw Error("\u533A\u95F4\u8FB9\u754C\u5FC5\u987B\u662F\u6709\u9650\u6570\u5B57");
  if (min !== void 0 && max !== void 0 && min > max) throw Error("\u533A\u95F4\u4E0B\u9650\u4E0D\u80FD\u5927\u4E8E\u4E0A\u9650");
}
var init_thresholdRange = __esm({
  "src/lib/fish/thresholdRange.ts"() {
  }
});

// src/lib/fish/algorithm.ts
function shortFishHash(text) {
  let a = 2166136261, b = 5381;
  for (let i = 0; i < text.length; i++) {
    a = Math.imul(a ^ text.charCodeAt(i), 16777619);
    b = Math.imul(b, 33) ^ text.charCodeAt(i);
  }
  return `${(a >>> 0).toString(36)}${(b >>> 0).toString(36)}`;
}
var FISH_PRESETS;
var init_algorithm = __esm({
  "src/lib/fish/algorithm.ts"() {
    init_dbl5m();
    init_dbl5m();
    init_dbl5GuardPlus();
    init_features();
    init_formula();
    init_marketData();
    init_featureSource();
    init_timeFormat();
    init_shared();
    init_thresholdRange();
    FISH_PRESETS = [
      { name: "\u591A\u5468\u671F\u4E3A\u6B63", lines: [24, 12, 6, 3, 1].map((h) => `avg(X,${h}) > 0`) },
      { name: "\u77ED\u671F\u5F3A\u4E8E\u957F\u671F", lines: ["avg(X,1)>=avg(X,3) and avg(X,3)>=avg(X,6) and avg(X,6)>=avg(X,12) and avg(X,12)>=avg(X,24)"] },
      { name: "\u6B63\u503C\u5360\u6BD4", lines: ["avg(X > 0, 6) >= 0.7"] },
      { name: "\u5747\u503C\u4E0A\u884C", lines: ["avg(X,3) > ago(avg(X,3),3)"] },
      { name: "\u5F53\u524D\u503C\u4E3A\u6B63", lines: ["X > 0"] },
      { name: "\u6210\u4EA4\u989D\u95E8\u69DB", lines: ["rsum(Q, 24) >= 20000000"] }
    ];
  }
});

// src/lib/fish/boxAlgorithmVersions.ts
function nativeGuardVersion(timeframe, version) {
  if (timeframe === "5m") return version;
  return version === DBL5_RETEST_GUARD_VERSION ? `dbl5-${timeframe}-guard-retest-v1` : `dbl5-${timeframe}-guard-v1`;
}
function structureVersions(rule) {
  const fromFormula = /^#\s*([a-z0-9-]+)/i.exec(String(rule.definition?.formula ?? ""))?.[1];
  const box = rule.versions?.box ?? fromFormula ?? (rule.algorithm === "dbl5" ? DBL5_PROFILES[structureDbl5Timeframe(rule)].version : CURRENT_BOX_VERSION[rule.algorithm]);
  const guard = rule.kSource === "guard" ? rule.versions?.guard ?? nativeGuardVersion(structureDbl5Timeframe(rule), dbl5GuardVersion(rule.definition?.DBL5_config)) : void 0;
  return guard ? { box, guard } : { box };
}
function freezeStructureVersions(rule) {
  const versions = structureVersions(rule);
  if (rule.kSource !== "guard" || rule.algorithm !== "dbl5") return { ...rule, versions };
  const config = rule.definition.DBL5_config ?? {};
  return { ...rule, versions, definition: { ...rule.definition, DBL5_config: {
    ...config,
    guard_trend_atr: config.guard_trend_atr ?? DBL5_GUARD_DEFAULTS.guard_trend_atr,
    guard_range_atr: config.guard_range_atr ?? DBL5_GUARD_DEFAULTS.guard_range_atr,
    guard_range_closes: config.guard_range_closes ?? DBL5_GUARD_DEFAULTS.guard_range_closes
  } } };
}
function assertStructureVersionsAvailable(rule) {
  const v = structureVersions(rule), box = boxAlgorithmVersion(v.box);
  const expectedBox = rule.algorithm === "dbl5" ? DBL5_PROFILES[structureDbl5Timeframe(rule)].version : CURRENT_BOX_VERSION[rule.algorithm];
  if (!box || box.algorithm !== rule.algorithm || box.layer !== "box" || v.box !== expectedBox) throw Error(`\u65B9\u6848\u51BB\u7ED3\u7684\u7BB1\u4F53\u7B97\u6CD5\u7248\u672C ${v.box} \u5F53\u524D\u6CA1\u6709\u53EF\u8FD0\u884C\u7684\u5B9E\u73B0\uFF0C\u8BF7\u52FF\u6539\u7528\u5176\u5B83\u7248\u672C\u4EE3\u66FF`);
  if (v.guard && v.guard !== nativeGuardVersion(structureDbl5Timeframe(rule), DBL5_GUARD_VERSION) && v.guard !== nativeGuardVersion(structureDbl5Timeframe(rule), DBL5_RETEST_GUARD_VERSION)) throw Error(`\u65B9\u6848\u51BB\u7ED3\u7684\u9632\u5B88\u7EBF\u7248\u672C ${v.guard} \u5F53\u524D\u6CA1\u6709\u53EF\u8FD0\u884C\u7684\u5B9E\u73B0\uFF0C\u8BF7\u52FF\u6539\u7528\u5176\u5B83\u7248\u672C\u4EE3\u66FF`);
  if (v.guard && v.guard !== nativeGuardVersion(structureDbl5Timeframe(rule), dbl5GuardVersion(rule.definition.DBL5_config))) throw Error("\u65B9\u6848\u51BB\u7ED3\u7684\u9632\u5B88\u7EBF\u7248\u672C\u4E0E\u5B9E\u9645\u53C2\u6570\u4E0D\u4E00\u81F4");
}
var structureDbl5Timeframe, BOX_ALGORITHM_VERSIONS, CURRENT_BOX_VERSION, CURRENT_GUARD_VERSION, boxAlgorithmVersion, BOX_K_EXECUTION_VERSIONS;
var init_boxAlgorithmVersions = __esm({
  "src/lib/fish/boxAlgorithmVersions.ts"() {
    init_impulse1115Classification();
    init_dbl5GuardPlus();
    init_dbl5m();
    structureDbl5Timeframe = (rule) => rule.algorithm === "dbl5" ? dbl5ProfileForFeature(rule.definition?.id)?.timeframe ?? "5m" : "5m";
    BOX_ALGORITHM_VERSIONS = Object.freeze([
      {
        id: "dbl-5-v2",
        algorithm: "dbl5",
        layer: "box",
        label: "DBL-5 v2",
        since: "2026-11-02 \u4E4B\u524D\uFF0811-02 \u672A\u6539\u52A8\uFF09",
        summary: "\u8FBE\u74E6\u65AF\u7BB1\u4F53\u4E0B\u8F68\uFF1A\u7BB1\u4F53\u5B8C\u6210\u624D\u51BB\u7ED3\uFF0C\u5F71\u7EBF\u4E25\u683C\u8DCC\u7834\u4E0B\u8F68\u5373\u7834\u574F\uFF0C\u4E0D\u5206\u4E0A\u6DA8 / \u9707\u8361\u3002",
        rules: ["\u5DF2\u6536\u76D8 5 \u5206\u949F\u7EBF\uFF0C\u9ED8\u8BA4 n=3\u3001\u51E0\u4F55\u7A97\u53E3 360 \u5206\u949F", "\u5C40\u90E8\u65B0\u9AD8\u540E\u89C2\u5BDF\u7BB1\u5E95\uFF0C\u4E0A\u4E0B\u8FB9\u754C\u90FD\u5B8C\u6210\u624D\u53D1\u5E03\u5E76\u51BB\u7ED3", "\u76F8\u90BB\u7BB1\u4F53\u5206\u4E3A\u57FA\u51C6\u3001\u5B8C\u6574\u4E0A\u79FB\u3001\u5185\u90E8\u7BB1\u5E95\u62AC\u9AD8\u3001\u540C\u5E95\u65B0\u7BB1", "\u6700\u4F4E\u4EF7\u4E25\u683C\u4F4E\u4E8E\u4E0B\u8F68\u5373\u7834\u574F\uFF08\u5F71\u7EBF\u4E5F\u7B97\uFF09\uFF0C\u89E6\u53CA\u4E0D\u7B97\uFF1B\u7F3A\u53E3\u91CD\u7F6E"]
      },
      {
        id: "sbs-5m-v1",
        algorithm: "sbs5m",
        layer: "box",
        label: "SBS-5M v1",
        since: "2026-11-02 \u4E4B\u524D\uFF0811-02 \u672A\u6539\u52A8\uFF09",
        summary: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF1A\u6A2A\u5411\u7BB1\u4F53\u51BB\u7ED3\u540E\u987B\u72EC\u7ACB\u6D4B\u8BD5\u786E\u8BA4\uFF0C\u53F0\u9636\u62AC\u5347\u8981\u65B0\u7BB1\u6D4B\u8BD5\u6210\u529F\u3002",
        rules: ["5 \u5206\u949F\u7EBF 6 \u6839\u5F62\u6210\u6A2A\u5411\u7BB1\u4F53\uFF0C\u51BB\u7ED3\u8FB9\u754C", "\u72EC\u7ACB\u6D4B\u8BD5\u6210\u529F\u624D\u786E\u8BA4\uFF1B\u7236\u7BB1\u4E24\u6839\u7A81\u7834\u540E\uFF0C\u66F4\u9AD8\u65B0\u7BB1\u6D4B\u8BD5\u6210\u529F\u624D\u62AC\u5347", "\u89E6\u53CA\u5931\u6548\u53C2\u8003\u6216\u8FDE\u7EED 2 \u6839\u6536\u4E8E\u7BB1\u5E95\u4E0B\u65B9\u5373\u65AD\u7EBF", "\u786E\u8BA4\u540E\u9ED8\u8BA4 6 \u5C0F\u65F6\u8FC7\u671F\uFF0C\u518D\u6B21\u6D4B\u8BD5\u4E0D\u7EED\u671F"]
      },
      {
        id: "dbl5-guard-v1",
        algorithm: "dbl5",
        layer: "guard",
        label: "\u9632\u5B88\u7EBF v1",
        since: "2026-11-02\uFF08\u4E0A\u7EBF\u7248\u672C 478\uFF09",
        summary: "\u53E0\u5728 DBL-5 v2 \u4E0A\uFF1A\u5206\u4E0A\u6DA8 / \u9707\u8361\u7559\u5197\u4F59\uFF0C\u53EA\u8BA4\u6536\u76D8\u8DCC\u7834\uFF0C\u5F71\u7EBF\u4E0D\u7B97\u3002",
        rules: [
          `\u4E0A\u6DA8\u671F\uFF08\u65B0\u7BB1\u5E95\u62AC\u9AD8\u4E14\u4E0E\u4E0A\u4E00\u7BB1\u4F53\u91CD\u53E0 \u2264 \u8F83\u5C0F\u7BB1\u9AD8 ${DBL5_GUARD_DEFAULTS.overlap * 100}%\uFF09\uFF1A\u7EBF\uFF1D\u7BB1\u5E95 \u2212 a\xD7ATR\uFF0C\u53EA\u5347\u4E0D\u964D\uFF08a \u9ED8\u8BA4 ${DBL5_GUARD_DEFAULTS.guard_trend_atr}\uFF09`,
          `\u9707\u8361\u671F\uFF1A\u7EBF\uFF1D\u9707\u8361\u533A\u6700\u4F4E\u7BB1\u5E95 \u2212 b\xD7ATR\uFF0C\u533A\u95F4\u5185\u5C0F\u7BB1\u4F53\u4E0D\u62AC\u7EBF\uFF08b \u9ED8\u8BA4 ${DBL5_GUARD_DEFAULTS.guard_range_atr}\uFF09`,
          `\u8DCC\u7834\uFF1A\u4E0A\u6DA8\u671F ${DBL5_GUARD_DEFAULTS.guard_trend_closes} \u6839\u3001\u9707\u8361\u671F\u8FDE\u7EED ${DBL5_GUARD_DEFAULTS.guard_range_closes} \u6839 5 \u5206\u949F\u6536\u76D8\u5728\u7EBF\u4E0B\uFF1B\u786E\u8BA4\u540E\u6E05\u7A7A\uFF0C\u7B49\u4E0B\u4E00\u4E2A\u7BB1\u4F53\u91CD\u5EFA`,
          `ATR \u4E3A 5 \u5206\u949F ATR(${DBL5_GUARD_DEFAULTS.atr_period})\uFF1B\u9996\u4E2A\u7BB1\u4F53\u6309\u9707\u8361\u671F`
        ]
      },
      {
        id: DBL5_RETEST_GUARD_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: "\u9632\u5B88\u7EBF-20261112",
        since: "2026-11-12",
        summary: "\u6700\u7EC8\u7BB1\u5E95\u9996\u6B21\u51FA\u73B0\u5728\u5C40\u90E8\u65B0\u9AD8\u540E\u7684\u7B2C\u4E00\u6839 5 \u5206\u949F\u7EBF\u4E0A\u65F6\uFF0C\u7B49\u5F85\u72EC\u7ACB\u56DE\u8E29\u786E\u8BA4\u540E\u542F\u7528\u9632\u5B88\u7EBF\u3002",
        rules: [
          "\u53EA\u5728\u7BB1\u4F53\u5B8C\u6574\u786E\u8BA4\u540E\u5F00\u59CB\u89C2\u5BDF\uFF1B\u5DF2\u6709\u9632\u5B88\u7EBF\u6309\u81EA\u8EAB\u89C4\u5219\u7EE7\u7EED\u6709\u6548\u3002",
          `\u7528\u7BB1\u4F53\u786E\u8BA4\u65F6\u7684 ATR \u51BB\u7ED3\u89C2\u5BDF\u533A\uFF1A\u7BB1\u5E95\u81F3\u7BB1\u5E95\uFF0B${DBL5_GUARD_RETEST.nearAtr} ATR\u3002\u5148\u6709\u4E00\u6839\u6700\u4F4E\u4EF7\u5728\u89C2\u5BDF\u533A\u4E4B\u4E0A\u3001\u6536\u76D8\u81F3\u5C11\u79BB\u7BB1\u5E95 ${DBL5_GUARD_RETEST.departureAtr} ATR \u7684 5 \u5206\u949F\u7EBF\u3002`,
          "\u968F\u540E\u4E00\u6839\u56DE\u5230\u89C2\u5BDF\u533A\uFF0C\u6700\u4F4E\u4EF7\u672A\u8DCC\u7A7F\u7BB1\u5E95\u4E14\u6536\u76D8\u56DE\u5230\u89C2\u5BDF\u533A\u4E0A\u65B9\uFF0C\u624D\u6309\u5F53\u65F6\u7684\u9632\u5B88\u7EBF\u516C\u5F0F\u751F\u6548\u3002\u7BB1\u4F53\u7834\u574F\u3001\u5230\u671F\u3001\u6362\u7BB1\u6216\u6570\u636E\u4E0D\u8FDE\u7EED\u4F1A\u7ED3\u675F\u8FD9\u6B21\u7B49\u5F85\u3002"
        ]
      },
      {
        id: DBL5_GUARD_PLUS_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: DBL5_GUARD_PLUS_LABEL,
        since: "2026-11-15",
        summary: "\u72EC\u7ACB\u65E0 BTC \u4F9D\u8D56\u5B9E\u9A8C\u7248\u672C\uFF0C\u5408\u5E76\u539F\u7248\u9632\u5B88\u7EBF\u4E0E\u4EC5\u51ED\u5DF2\u6536\u76D8 5m \u786E\u8BA4\u7684\u6025\u62C9\u8D77\u70B9\u53C2\u8003\u3002",
        rules: [
          "\u4E24\u6839\u7D27\u51D1\u6574\u7406\u540E\u89C2\u5BDF 1\u20133 \u6839\u3002\u53C2\u8003\u8D77\u70B9\u4E4B\u524D\u7684 ATR\u3001\u52A0\u6743\u5E38\u6001\u3001\u6700\u8FD1\u4E09\u6839\u6700\u9AD8\u4EF7\uFF0C\u6700\u65E9\u5408\u683C\u7A97\u53E3\u4F18\u5148\u3002",
          "\u6025\u62C9\u9996\u6B21\u786E\u8BA4\u51BB\u7ED3\u6700\u4F4E\u4EF7\u51CF 0.5 \u500D\u524D\u7F6E ATR\uFF0C\u5411\u4E0B\u53D6\u81F3\u62A5\u4EF7\u6B65\u957F\uFF1B\u4E0D\u7B49\u65B0\u7BB1\u4F53\u3002",
          "\u6025\u62C9\u4E00\u6839\u6536\u76D8\u4E25\u683C\u8DCC\u7834\u6216\u8D77\u70B9\u6EE1 360 \u5206\u949F\u65F6\u5931\u6548\uFF0C\u4FDD\u7559\u4E0E\u57FA\u7EBF\u72EC\u7ACB\u7684\u4E8B\u4EF6\u3002",
          "\u6025\u62C9\u8D77\u70B9\u53C2\u8003\uFF0C\u5C1A\u4E0D\u4EE3\u8868\u56DE\u8E29\u9A8C\u8BC1\u3002\u91CF\u80FD\u4EC5\u4F5C\u4E3A\u8F85\u52A9\u8BC1\u636E\u3002"
        ]
      },
      {
        id: IMPULSE_1115_POSITION_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: IMPULSE_1115_POSITION_LABEL,
        since: "2026-11-15",
        summary: "1115 \u7684\u72EC\u7ACB\u52A0\u4ED3\u4F4D\u7F6E\u3002\u53EA\u6709\u9996\u6B21\u6025\u62C9\u53EF\u4EE5\u89E6\u53D1\uFF0CK \u53D6\u5F53\u65F6\u6709\u6548\u7684\u6025\u62C9\u53C2\u8003\u3002",
        rules: ["\u6CBF\u7528 1115 \u7684\u9636\u6BB5\u3001\u8FC7\u4F38\u3001\u5931\u6548\u548C\u6536\u76D8\u786E\u8BA4\u89C4\u5219\u3002", "\u4EE5\u6025\u62C9\u53C2\u8003\u5355\u72EC\u8BC4\u4F30\u52A0\u4ED3\uFF0C\u4E0E\u540C\u8F6E\u5176\u4ED6\u4F4D\u7F6E\u5171\u7528\u65B9\u5411\u3001\u5426\u51B3\u548C\u4ED3\u4F4D\u8BA1\u7B97\u3002"]
      },
      {
        id: IMPULSE_1115_CONFIGURABLE_K_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: IMPULSE_1115_DISPLAY_NAME,
        since: "2026-11-15",
        summary: "\u6CBF\u7528 1115 \u9996\u6B21\u6025\u62C9\u786E\u8BA4\uFF0C\u4EE5\u8D77\u6DA8\u4F4E\u70B9\u548C\u53EF\u8C03\u7684\u524D\u7F6E ATR \u5197\u4F59\u8BA1\u7B97 K\u3002",
        rules: ["\u6536\u76D8\u786E\u8BA4\u6025\u62C9\u540E\uFF0C\u51BB\u7ED3\u6025\u62C9\u524D\u7684 5 \u5206\u949F ATR(14)\uFF0C\u6309\u6240\u8BBE\u500D\u6570\u4ECE\u8D77\u6DA8\u4F4E\u70B9\u6263\u51CF\uFF0C\u5411\u4E0B\u53D6\u81F3\u62A5\u4EF7\u6B65\u957F\u3002", "K \u6700\u5C0F\u8DDD\u79BB\u3001\u65B9\u5411\u3001\u5426\u51B3\u3001\u5B9A\u91CF\u548C\u4E00\u6839 5 \u5206\u949F\u6536\u76D8\u8DCC\u7834 K \u7684\u89C4\u5219\u7167\u5E38\u751F\u6548\u3002"]
      },
      {
        id: DBL5_1115_POSITION_RACE_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: "\u7EC4\u5408\u7248\u4E0E\u72EC\u7ACB\u6025\u62C9\u5E76\u9009",
        since: "2026-11-16",
        summary: "\u65E0 BTC \u4F9D\u8D56\u3002\u7EC4\u5408\u7248\u548C\u72EC\u7ACB\u6025\u62C9\u5206\u522B\u6309\u5404\u81EA\u5DF2\u51BB\u7ED3\u7684\u89C4\u5219\u8BC4\u4F30\u52A0\u4ED3\u3002",
        rules: ["\u540C\u4E00\u8F6E\u53EA\u6210\u4EA4\u4E00\u6B21\uFF0C\u8F83\u65E9\u8FBE\u6807\u8005\u4F18\u5148\uFF0C\u540C\u5206\u949F\u5148\u8BC4\u4F30\u7EC4\u5408\u7248\u3002", "\u4F7F\u7528\u6210\u4EA4\u4F4D\u7F6E\u5BF9\u5E94\u7684 K\u3001\u6700\u5C0F\u8DDD\u79BB\u4E0E\u6B62\u635F\u6267\u884C\u89C4\u5219\u3002"]
      },
      {
        id: DBL5_GUARD_PLUS_CONFIGURABLE_K_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: `${DBL5_GUARD_PLUS_DISPLAY_NAME} \xB7 \u53EF\u8C03\u6025\u62C9 ATR`,
        since: "2026-11-16",
        summary: "\u65E0 BTC \u4F9D\u8D56\u3002\u539F\u7EC4\u5408\u7248\u7684\u9996\u6B21\u6025\u62C9\u5224\u5B9A\u548C\u9632\u5B88\u7EBF\u4E0D\u53D8\uFF0C\u6025\u62C9\u53C2\u8003\u4F7F\u7528\u81EA\u5B9A\u7684\u524D\u7F6E ATR \u5197\u4F59\u3002",
        rules: ["\u6025\u62C9\u53C2\u8003\uFF1D\u8D77\u6DA8\u4F4E\u70B9 \u2212 \u6240\u8BBE\u500D\u6570 \xD7 \u6025\u62C9\u524D\u7684 5 \u5206\u949F ATR(14)\uFF0C\u6309\u62A5\u4EF7\u6B65\u957F\u5411\u4E0B\u53D6\u6574\u3002", "\u4E0E\u9632\u5B88\u7EBF\u6309\u539F\u7EC4\u5408\u89C4\u5219\u9009\u53D6\u6709\u6548\u53C2\u8003\uFF0C\u4F7F\u7528\u8BE5\u53C2\u8003\u7684 K \u548C\u6536\u76D8\u786E\u8BA4\u65B9\u5F0F\u3002"]
      },
      {
        id: IMPULSE_1115_CLASSIFICATION_VERSION,
        algorithm: "dbl5",
        layer: "guard",
        label: IMPULSE_1115_CLASSIFICATION_LABEL,
        since: "2026-11-19",
        summary: "\u539F\u6025\u62C9\u8BC6\u522B\u548C\u53C2\u8003\u4EF7\u683C\u4E0D\u53D8\uFF0C\u65B0\u589E\u72EC\u7ACB\u3001\u56E0\u679C\u7684\u6301\u4ED3\u72B6\u6001\u5206\u7C7B\u3002",
        rules: [
          "\u7B2C1\u30012\u79CD\u56FA\u5B9A\u6620\u5C04\u4E00\u7C7B\uFF1B\u7B2C3\u81F36\u79CD\u56FA\u5B9A\u6620\u5C04\u4E8C\u7C7B\u3002\u8FC7\u6E21\u72B6\u6001\u8BF4\u660E\u7B49\u5F85\u6761\u4EF6\uFF0C\u4E0D\u53E6\u589E\u4E3B\u5206\u7C7B\u3002",
          "\u6BCF\u6761\u6025\u62C9\u7EBF\u72EC\u7ACB\u51BB\u7ED3\u4EF7\u683C\u4E0EATR\uFF0C\u9010\u6839\u5DF2\u6536\u76D85m\u66F4\u65B0\uFF1B\u523A\u7A7F\u3001\u6709\u6548\u8DCC\u7834\u4E0E\u4FEE\u590D\u4FDD\u7559\u5404\u81EA\u8BC1\u636E\u3002",
          "\u539F\u7EBF\u65AD\u88C2\u3001\u5230\u671F\u540E\u4ECD\u53EF\u6309\u51BB\u7ED3\u4EF7\u683C\u89C2\u5BDF\uFF1B\u7F3A\u53E3\u6682\u505C\u8BE5\u7EBF\u3002\u5386\u53F2\u4E0D\u56DE\u586B\uFF0C\u68C0\u67E5\u70B9\u987B\u4E0E\u539F\u751F\u8BC1\u636E\u6210\u5BF9\u6062\u590D\u3002",
          "\u53EA\u8F93\u51FA\u5206\u7C7B\u4E0E\u5C55\u793A\uFF1B\u539F\u9632\u5B88\u7EBF\u3001\u6025\u62C9\u7EBF\u3001\u6A21\u677F\u7248\u672C\u548C\u4EA4\u6613\u52A8\u4F5C\u4E0D\u53D8\u3002"
        ]
      },
      ...DBL5_VARIANT_TIMEFRAMES.flatMap((timeframe) => {
        const { version, label, periodLabel, minutes } = DBL5_PROFILES[timeframe];
        return [
          {
            id: version,
            algorithm: "dbl5",
            layer: "box",
            label,
            since: "2026-11-16",
            summary: `DBL-5 v2 \u7684\u72EC\u7ACB ${periodLabel}\u7248\u672C\uFF0C\u7BB1\u4F53\u8BC6\u522B\u3001\u9009\u62E9\u548C\u5931\u6548\u6CBF\u7528\u539F\u89C4\u5219\u3002`,
            rules: [`\u4EC5\u4F7F\u7528\u5DF2\u6536\u76D8\u7684 ${periodLabel} K \u7EBF\uFF0Cn=3\uFF0C\u51E0\u4F55\u7A97\u53E3\u9ED8\u8BA4 72 \u6839\uFF08${72 * minutes / 60} \u5C0F\u65F6\uFF09`, "\u521D\u59CB\u9884\u70ED\u81F3\u5C11 288 \u6839\uFF1B\u65B0\u9C9C\u5EA6\u534A\u8870\u671F 12 \u6839"]
          },
          {
            id: nativeGuardVersion(timeframe, DBL5_GUARD_VERSION),
            algorithm: "dbl5",
            layer: "guard",
            label: `${timeframe} \u9632\u5B88\u7EBF v1`,
            since: "2026-11-16",
            summary: `\u6CBF\u7528\u539F\u9632\u5B88\u7EBF\u7684\u5B9E\u7EBF\u3001\u865A\u7EBF\u3001\u5197\u4F59\u53CA\u65AD\u88C2\u89C4\u5219\uFF0C\u4F7F\u7528 ${periodLabel} ATR(14) \u4E0E\u6536\u76D8\u786E\u8BA4\u3002`,
            rules: ["\u4E0A\u6DA8\u671F\u9ED8\u8BA4 1 \u6839\uFF0C\u9707\u8361\u671F\u9ED8\u8BA4\u8FDE\u7EED 2 \u6839\u6536\u76D8\u4E25\u683C\u5728\u7EBF\u4E0B\u540E\u786E\u8BA4\uFF1BATR \u500D\u6570\u53CA\u9707\u8361\u671F\u786E\u8BA4\u6839\u6570\u53EF\u6309\u539F\u89C4\u5219\u8BBE\u7F6E"]
          },
          {
            id: nativeGuardVersion(timeframe, DBL5_RETEST_GUARD_VERSION),
            algorithm: "dbl5",
            layer: "guard",
            label: `${timeframe} \u9632\u5B88\u7EBF-20261112`,
            since: "2026-11-16",
            summary: `\u6CBF\u7528\u9632\u5B88\u7EBF-20261112 \u7684\u72EC\u7ACB\u56DE\u8E29\u6761\u4EF6\u3002\u7B49\u5F85\u79BB\u5F00\u548C\u56DE\u8E29\u4F7F\u7528\u5DF2\u6536\u76D8\u7684 ${periodLabel} K \u7EBF\u3002`,
            rules: ["\u89C2\u5BDF\u533A\u4E0E\u79BB\u5F00\u8DDD\u79BB\u7684 ATR \u500D\u6570\u6CBF\u7528\u539F\u7248\uFF1B\u72EC\u7ACB\u56DE\u8E29\u786E\u8BA4\u524D\u7EE7\u7EED\u68C0\u67E5\u5DF2\u6709\u9632\u5B88\u7EBF"]
          }
        ];
      })
    ]);
    CURRENT_BOX_VERSION = Object.freeze({ dbl5: "dbl-5-v2", sbs5m: "sbs-5m-v1" });
    CURRENT_GUARD_VERSION = "dbl5-guard-v1";
    boxAlgorithmVersion = (id2) => BOX_ALGORITHM_VERSIONS.find((v) => v.id === id2);
    BOX_K_EXECUTION_VERSIONS = Object.freeze([
      { id: "holding-impulse-1115-classified-origin-k-v3", since: "2026-11-20", summary: "\u4E00\u7C7B\uFF0F\u4E8C\u7C7B\u65B0\u8BBE\u7F6E\u7EDF\u4E00\u4EE5\u8BE5\u6025\u62C9\u7684\u8D77\u6DA8\u70B9\uFF08\u8D77\u6DA8\u4F4E\u70B9\uFF09\u8BA1\u7B97 K\uFF1D\u8D77\u6DA8\u70B9\u2212N\xD7\u6025\u62C9\u5F00\u59CB\u524D\u51BB\u7ED3\u76845m ATR(14)\uFF0C\u4E0E\u539F1115\u4F4D\u7F6E\u540C\u4E00\u57FA\u51C6\uFF0C\u53EA\u6263\u4E00\u6B21N\u500D\uFF1B\u5206\u7C7B\u4ECD\u72EC\u7ACB\u51B3\u5B9A\u89E6\u53D1\u65F6\u673A\u3002K\u6309\u62A5\u4EF7\u6B65\u957F\u5411\u4E0B\u53D6\u6574\uFF0C\u7EE7\u7EED\u5E94\u7528\u6700\u5C0F\u8DDD\u79BB\uFF0C\u5B9A\u91CF\u4E0E\u9000\u51FA\u5171\u7528K\uFF1B\u539Fv1\u3001v2\u53CA\u5DF2\u5B58\u65B9\u6848\u3001\u6A21\u677F\u4E0D\u81EA\u52A8\u8F6C\u6362\u3002" },
      { id: "holding-limited-static-drawdown-v1", since: "2026-11-19", summary: "\u786C\u6027\u7EC8\u6B62\u72EC\u7ACB\u65B0\u589E\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4\uFF0C\u6309\u9996\u4ED3\u4E70\u5165\u4EF7\xD7\uFF081\u2212\u6240\u8BBE\u767E\u5206\u6BD4\uFF09\u89E6\u4EF7\u5168\u4ED3\u9000\u51FA\uFF0C\u8DF3\u7A7A\u6309\u5F00\u76D8\u4EF7\uFF1B\u53EF\u9009\u955C\u50CF\u524D\uFF0F\u540E\u9636\u6BB5\u3002\u8D77\u59CB\u6709\u6548\u7684\u9650\u5236\u9608\u503C\u53EF\u51BB\u7ED3\u4E3A\u521D\u59CB\u98CE\u9669\uFF0C\u955C\u50CF\u540E\u53CA\u52A0\u4ED3\u540E\u65B0\u8BBE\u9608\u503C\u4E0D\u56DE\u5199\u9996\u4ED3\u98CE\u9669\u3002\u539F\u81EA\u7531\u9759\u6001\u56DE\u64A4\u3001\u666E\u901A\u5356\u51FA\u7B97\u6CD5\u53CA\u5DF2\u5B58\u6A21\u677F\u4E0D\u8F6C\u6362\u3002" },
      { id: "holding-impulse-1115-classified-line-k-v2", since: "2026-11-19", summary: "\u4E00\u7C7B\uFF0F\u4E8C\u7C7B\u52A0\u4ED3\u4F4D\u7F6E\u65B0\u589E K\uFF1D\u539F\u751F\u6025\u62C9\u7EBF\u4EF7\u683C\u2212N\xD7\u8BE5\u7EBF\u51BB\u7ED3 ATR\uFF0CN \u53EF\u624B\u52A8\u8BBE\u7F6E\u5E76\u6309\u8F6E\u6B21\u3001\u5206\u7C7B\u548C\u5206\u652F\u72EC\u7ACB\u4FDD\u5B58\u3002\u6309\u62A5\u4EF7\u6B65\u957F\u5411\u4E0B\u53D6\u6574\uFF0C\u5B9A\u91CF\u548C\u9000\u51FA\u5171\u7528\u6240\u9009 K\uFF1B\u4FDD\u7559\u539F\u8D77\u6DA8\u4F4E\u70B9\u57FA\u51C6\u7684 v1 \u5B9E\u73B0\u4E0E\u6307\u7EB9\uFF0C\u5DF2\u5B58\u65B9\u6848\u4E0D\u81EA\u52A8\u8F6C\u6362\u3002" },
      { id: "holding-mirror-hard-stop-stages-v1", since: "2026-11-19", summary: "\u65B0\u589E\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u524D\uFF0F\u540E\u786C\u6027\u7EC8\u6B62\u9636\u6BB5\u3002\u51CF\u4ED3\u5B9E\u9645\u6210\u4EA4\u540E\u524D\u6BB5\u9000\u51FA\u5224\u65AD\u505C\u6B62\uFF0C\u540E\u6BB5\u72EC\u7ACB\u5F00\u59CB\u8BA1\u6570\uFF1B\u76D8\u4E2D\u6210\u4EA4\u4EE5\u6536\u76D8\u53EF\u786E\u8BA4\u65F6\u70B9\u5207\u6362\u6307\u6807\uFF0C\u4EF7\u683C\u4FDD\u62A4\u4ECE\u4E0B\u4E00\u5206\u949F\u5F00\u59CB\u3002\u5168\u7A0B\u6761\u4EF6\u3001\u65E7\u7248\u51CF\u4ED3\u540E\u6761\u4EF6\u3001\u539F\u751F\u7BB1\u4F53\u4E0E\u9632\u5B88\u7EBF\u8BA1\u7B97\u5747\u4FDD\u7559\uFF0C\u4E0D\u81EA\u52A8\u8FC1\u79FB\u5DF2\u5B58\u6A21\u677F\u3002" },
      { id: "holding-post-mirror-protection-v1", since: "2026-11-19", summary: "\u65B0\u589E\u72EC\u7ACB\u7684\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u540E\u542F\u52A8\u7EA6\u675F\uFF1A\u4EC5\u51ED\u672C\u6B21\u6301\u4ED3\u51CF\u4ED3\u6210\u4EA4\u8BB0\u5F55\u542F\u7528 DBL-5 \u9632\u5B88\u7EBF\u6216 CDA \u786C\u6027\u7EC8\u6B62\u3002\u5F00\u76D8\u51CF\u4ED3\u540E\u5F53\u5206\u949F\u53EF\u68C0\u67E5\uFF0C\u76D8\u4E2D\u51CF\u4ED3\u540E\u9632\u5B88\u7EBF\u4ECE\u4E0B\u4E00\u5206\u949F\u3001CDA \u4ECE\u9996\u4E2A\u540E\u7EED\u8BFB\u6570\u68C0\u67E5\uFF1B\u4E0D\u8FFD\u8865\u542F\u52A8\u524D\u65AD\u88C2\u548C\u8BA1\u6570\u3002\u539F\u9632\u5B88\u7EBF\u8BA1\u7B97\u3001\u539F\u7EC8\u6B62\u9009\u9879\u53CA\u5DF2\u5B58\u6A21\u677F\u4FDD\u6301\u4E0D\u53D8\u3002" },
      { id: "holding-support-second-exit-v1", since: "2026-11-19", summary: "\u65B0\u589E\u72EC\u7ACB\u9009\u9879\u201C\u6301\u4ED3\u671F\u95F4\u4E8C\u6B21\u65AD\u88C2\u7EC8\u6B62\u201D\uFF1A\u6309\u51BB\u7ED3\u5468\u671F\u4E0E\u9632\u5B88\u7EBF\u53C2\u6570\u7D2F\u8BA1\u672C\u6B21\u6301\u4ED3\u540E\u7684\u72EC\u7ACB\u539F\u751F\u7EA2\u53C9\u3002\u9996\u6B21\u53EA\u8BA1\u6570\uFF0C\u4E0D\u56E0\u672C\u6761\u4EF6\u505C\u6B62\u52A0\u4ED3\uFF1B\u7B2C\u4E8C\u6B21\u786E\u8BA4\u540E\u6309\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u4EF7\u5356\u51FA\u5168\u90E8\u6301\u4ED3\u3002\u9884\u70ED\u4E0E\u6301\u7EED\u5728\u7EBF\u4E0B\u4E0D\u91CD\u590D\u8BA1\u6570\uFF0C\u9632\u5B88\u7EBF\u91CD\u5EFA\u53CA\u6682\u505C\u7EED\u7B97\u4E0D\u6E05\u96F6\uFF0C\u5176\u4ED6\u52A0\u4ED3\u5426\u51B3\u548C\u9000\u51FA\u4ECD\u72EC\u7ACB\u751F\u6548\u3002\u4FDD\u7559\u539F\u201C\u9996\u6B21\u65AD\u88C2\u505C\u52A0\u4ED3\uFF0C\u4E8C\u6B21\u65AD\u88C2\u7EC8\u6B62\u201D\u7248\u672C\u53CA\u6A21\u677F\u8BED\u4E49\u3002" },
      { id: "holding-impulse-1115-classified-position-v1", since: "2026-11-19", summary: "\u52A0\u4ED3\u4F4D\u7F6E\u4FDD\u7559\u539F\u6025\u62C9\u7EBF\uFF0C\u65B0\u589E1115\u4E00\u7C7B\u4E0E\u4E8C\u7C7B\uFF1B\u53EA\u5728\u539F\u751F5\u5206\u949F\u6536\u76D8\u786E\u8BA4\u65B0\u5206\u7C7B\u72B6\u6001\u65F6\u751F\u6210\u673A\u4F1A\uFF0C\u8FC7\u6E21\u72B6\u6001\u3001\u9884\u70ED\u53CA\u6301\u7EED\u540C\u72B6\u6001\u4E0D\u8865\u5355\u3002\u9010\u8F6E\u53CA\u5907\u9009\u72EC\u7ACB\u51BB\u7ED3\u5206\u7C7B\u53C2\u6570\u4E0EK\uFF0C\u6CBF\u7528\u539F\u65B9\u5411\u3001\u5426\u51B3\u3001\u5B9A\u91CF\u53CA\u9000\u51FA\u3002" },
      { id: "payoff-stop-dbl5-initial-risk-v3", since: "2026-11-24", summary: "\u6309\u4E70\u5165\u65F6\u5DF2\u786E\u8BA4\u7684 DBL-5 \u6267\u884C\u7EBF\u51BB\u7ED3\u9996\u4ED3 L\u2080\uFF0C\u53D6\u4F4E\u4E8E\u4E70\u5165\u4EF7\u7684\u6700\u5C0F\u6B63\u8DDD\u79BB\u3002" },
      { id: "signal-guard-distance-pct-v1", since: "2026-11-24", summary: "\u539F\u4FE1\u53F7\u65F6\u70B9\u7528\u5DF2\u6536\u76D8\u73B0\u4EF7\u3001\u8BE5\u65F6\u523B\u6709\u6548\u7684\u51BB\u7ED3\u9632\u5B88\u7EBF\u53CA\u5176\u539F\u751F ATR \u8BA1\u7B97\u542B\u5197\u4F59\u7684\u767E\u5206\u6BD4\uFF0C\u6309\u672A\u820D\u5165\u8BFB\u6570\u6BD4\u8F83\u95E8\u69DB\u3002" },
      { id: "static-dbl5-distance-v2", since: "2026-11-24", summary: "\u4E70\u524D\u9759\u6001\u8DDD\u79BB\u5148\u53D6\u4E94\u5206\u949F\u6536\u76D8\u4EF7\u4E0E\u539F\u7EBF\u4EF7\u7684\u7EDD\u5BF9\u4EF7\u5DEE\uFF0C\u518D\u52A0\u5197\u4F59\u500D\u6570\u4E58 ATR\uFF0C\u9664\u4EE5\u6536\u76D8\u4EF7\u8BA1\u767E\u5206\u6BD4\u3002\u6700\u8FD1\u7EBF\u53D6\u6709\u6548\u9632\u5B88\u7EBF\u548C\u6025\u62C9\u7EBF\u8DDD\u79BB\u7684\u6700\u5C0F\u503C\u3002" },
      { id: "static-dbl5-distance-v1", since: "2026-11-24", summary: "\u9759\u6001\u4E70\u524D\u8FC7\u6EE4\u4F7F\u7528\u6700\u8FD1\u5DF2\u6536\u76D8\u7684\u4E94\u5206\u949F\u4EF7\u4E0E\u5DF2\u786E\u8BA4\u539F\u751F\u4EF7\u7EBF\uFF0C\u72EC\u7ACB\u51BB\u7ED3 ATR \u5197\u4F59\u5E76\u6BD4\u8F83\u767E\u5206\u6BD4\u8DDD\u79BB\u3002" },
      { id: "sell-dbl5-line-or-v2", since: "2026-11-24", summary: "DBL-5 \u5356\u51FA\u65B0\u589E\u9632\u5B88\u5B9E\u7EBF\u4E0E\u865A\u7EBF\u7684\u72EC\u7ACB\u9009\u62E9\u3001\u5404\u539F\u751F\u6025\u62C9\u57FA\u51C6\uFF0C\u4EE5\u53CA\u9632\u5B88\u4E0E\u6025\u62C9\u4E24\u8DEF\u72EC\u7ACB ATR\u3001\u4EFB\u4E00\u8DEF\u89E6\u4EF7\u9000\u51FA\u3002" },
      { id: "sell-dbl5-line-v1", since: "2026-11-24", summary: "\u6301\u4ED3\u5356\u51FA\u7B97\u6CD5\u65B0\u589E DBL-5 \u9632\u5B88\u7EBF\u4E0E\u6025\u62C9\u7EBF-1115\uFF0C\u6CBF\u7528\u539F\u751F\u4E94\u5206\u949F\u4EF7\u7EBF\u53CA\u73B0\u6709\u7BB1\u4F53\u89E6\u4EF7\u6267\u884C\u3002\u5404\u6BB5\u72EC\u7ACB\u51BB\u7ED3 ATR \u5197\u4F59\u4E0E\u4EF7\u7EBF\u53C2\u6570\u3002" },
      { id: "holding-box-stop-independent-channels-v1", since: "2026-11-19", summary: "\u786C\u6027\u7EC8\u6B62\u53EF\u540C\u65F6\u542F\u7528\u975E\u6025\u62C9\u4E0E\u6025\u62C9\u4E24\u8DEF\u3002\u6BCF\u8DEF\u72EC\u7ACB\u51BB\u7ED3\u539F\u751F\u53C2\u8003\u3001ATR\u5197\u4F59\u3001K\u66F4\u65B0\u53CA\u786E\u8BA4\u65B9\u5F0F\uFF0C\u72EC\u7ACB\u4FDD\u5B58K\u4E0E\u6536\u76D8\u8BA1\u6570\uFF0C\u4EFB\u4E00\u8DEF\u5148\u89E6\u53D1\u5373\u9000\u51FA\uFF1B\u505C\u7528\u4FDD\u7559\u53C2\u6570\u3002\u5171\u7528\u6240\u9009\u542F\u52A8\u9636\u6BB5\uFF0C\u65E7\u5355\u8DEF\u65B9\u6848\u4E0D\u81EA\u52A8\u8F6C\u6362\uFF0C\u539F\u751F\u7BB1\u4F53\u3001\u9632\u5B88\u7EBF\u4E0E\u6025\u62C9\u8BC6\u522B\u7B97\u6CD5\u4E0D\u53D8\u3002" },
      { id: "holding-box-stop-reference-v1", since: "2026-11-19", summary: "\u786C\u6027\u7EC8\u6B62\u7684 K \u57FA\u51C6\u72EC\u7ACB\u65B0\u589E\u6025\u62C9\u7EBF-0\u3001\u6025\u62C9\u7EBF-1115\u53CA\u9632\u5B88\u7EBF\uFF0B\u6025\u62C9\u7EBF-1115\u3002\u4F7F\u7528\u540C\u7248\u539F\u751F\u5DF2\u6536\u76D8 5 \u5206\u949F\u53C2\u8003\uFF0C\u518D\u6263\u6B64\u5904\u989D\u5916\u5197\u4F59\u5E76\u6309\u62A5\u4EF7\u6B65\u957F\u5411\u4E0B\u53D6\u6574\uFF1B\u6309\u6240\u9009\u56FA\u5B9A\uFF0F\u53EA\u5347\uFF0F\u8DDF\u968F\u4E0E\u89E6\u4EF7\uFF0F\u6536\u76D8\u6267\u884C\u3002\u65E0\u6709\u6548\u7EBF\u65F6\u7B49\u5F85\uFF0C\u5DF2\u6709 K \u5728\u7EBF\u5931\u6548\u6216\u5230\u671F\u540E\u7EE7\u7EED\u4FDD\u62A4\u3002\u65E7\u6A21\u677F\u4E0E\u539F\u7BB1\u4F53\u3001\u9632\u5B88\u7EBF\u8F93\u51FA\u4E0D\u53D8\u3002" },
      { id: "addition-holding-box-break-v1", since: "2026-11-19", summary: "\u65B0\u589E\u5171\u7528\u4E00\u7968\u5426\u51B3\uFF1A\u6301\u4ED3\u671F\u95F4\u9996\u6B21\u539F\u751F\u9632\u5B88\u7EBF\u7EA2\u53C9\u786E\u8BA4\u540E\uFF0C\u542F\u7528\u8BE5\u6761\u4EF6\u7684\u52A0\u4ED3\u8F6E\u6B21\u53CA\u5206\u652F\u4E0D\u518D\u52A0\u4ED3\uFF1B\u7B5B\u9009\u6309\u672C\u8F6E\u8D77\u70B9\u540E\u7684\u65AD\u88C2\u6301\u7EED\u6392\u9664\u3002\u4E70\u5165\uFF0F\u7B5B\u9009\u524D\u9884\u70ED\u4E0D\u8BA1\u3001\u91CD\u5EFA\u4E0D\u89E3\u9664\u3002\u6309\u51BB\u7ED3\u5468\u671F\u4E0E\u53C2\u6570\u91CD\u5EFA\u5386\u53F2\uFF0C\u7F3A\u6570\u636E\u6682\u4E0D\u653E\u884C\u3002\u72EC\u7ACB\u5F00\u5173\uFF0C\u4E0D\u89E6\u53D1\u5356\u51FA\uFF0C\u4E0D\u6539\u53D8\u65E7\u7BB1\u4F53\u3001\u52A0\u4ED3\u5426\u51B3\u548C\u6A21\u677F\u3002" },
      { id: "holding-support-second-break-v1", since: "2026-11-19", summary: "\u72EC\u7ACB\u9009\u7528\uFF1A\u4ECE\u672C\u6B21\u6301\u4ED3\u5F00\u59CB\u6309\u51BB\u7ED3\u5468\u671F\u4E0E\u9632\u5B88\u7EBF\u53C2\u6570\u7D2F\u8BA1\u539F\u751F\u7EA2\u53C9\u3002\u7B2C\u4E00\u6B21\u65AD\u88C2\u9501\u5B9A\u672C\u7B14\u5168\u90E8\u540E\u7EED\u52A0\u4ED3\uFF0C\u7B2C\u4E8C\u6B21\u72EC\u7ACB\u65AD\u88C2\u786E\u8BA4\u540E\u6309\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u4EF7\u5168\u4ED3\u5356\u51FA\uFF1B\u9884\u70ED\u4E8B\u4EF6\u548C\u6301\u7EED\u5728\u7EBF\u4E0B\u4E0D\u91CD\u590D\u8BA1\u6570\u3002\u9501\u5B9A\u8DE8\u6682\u505C\u7EED\u7B97\u53CA\u52A0\u4ED3\u5206\u652F\u5207\u6362\u4FDD\u7559\uFF0C\u5176\u4ED6\u4FDD\u62A4\u4E0E\u5356\u51FA\u4ECD\u53EF\u66F4\u65E9\u89E6\u53D1\u3002" },
      { id: "binance-manual-monitor-v1", since: "2026-11-15", summary: "\u5E01\u5B89 U \u672C\u4F4D\u624B\u52A8\u9996\u4ED3\u6309\u771F\u5B9E\u6210\u4EA4\u6570\u91CF\u548C\u4EF7\u683C\u521D\u59CB\u5316\uFF0C\u51BB\u7ED3\u6240\u9009\u4E70\u540E\u6A21\u677F\uFF1B\u6BCF\u7B14\u6258\u7BA1\u52A8\u4F5C\u5148\u6838\u5BF9\u5B9E\u9645\u6301\u4ED3\uFF0C\u968F\u540E\u6309\u5B9E\u9645\u6210\u4EA4\u7EED\u7B97\u3002" },
      { id: "holding-dbl5-binance-trade-grid-v1", since: "2026-11-13", summary: "\u6301\u4ED3\u76D1\u6D4B\u9047\u5230\u53EF\u6838\u9A8C\u7684\u5E01\u5B89 AKEUSDT / RAVEUSDT \u62A5\u4EF7\u683C\u70B9\u9519\u8BEF\u65F6\uFF0C\u4ECE\u5165\u573A\u524D\u6309\u4EA4\u6613\u6240\u516C\u5E03\u7684\u7CBE\u786E\u6210\u4EA4\u683C\u70B9\u91CD\u653E\u3002\u4FDD\u7559\u539F\u59CB\u6210\u4EA4\u4EF7\u683C\u3001\u7BB1\u4F53\u3001\u9632\u5B88\u7EBF\u53CA\u5356\u51FA\u53C2\u6570\uFF0C\u6210\u529F\u7ED3\u679C\u5355\u72EC\u6807\u8BB0\u6570\u636E\u4FEE\u590D\u7248\u672C\uFF1B\u771F\u5B9E\u7F3A\u53E3\u7EE7\u7EED\u62A5\u9519\u3002" },
      { id: "holding-dbl5-binance-trade-grid-v2", since: "2026-11-17", summary: "\u6301\u4ED3\u7BB1\u4F53\u6B62\u635F\u652F\u6301\u5E01\u5B89 BULLAUSDT \u65B0\u65E7\u6302\u5355\u6DF7\u5408\u6210\u4EA4\u3002\u4EC5\u5728\u539F\u62A5\u4EF7\u6821\u9A8C\u5931\u8D25\u65F6\u6309 0.000001 \u7CBE\u786E\u6821\u9A8C\u539F\u59CB\u4EF7\u683C\uFF0C\u9002\u7528\u4E8E\u5DF2\u4FDD\u5B58\u7684 5 \u5206\u949F\u548C 1 \u5C0F\u65F6 DBL-5 \u7BB1\u4F53\u89C4\u5219\u3002\u771F\u5B9E\u884C\u60C5\u7F3A\u53E3\u7EE7\u7EED\u62A5\u9519\u3002" },
      { id: "selected-l0-limited-drawdown-v1", since: "2026-11-26", summary: "\u76C8\u4E8F\u6BD4\u4E0E\u76C8\u4E8F\u6BD4\u6B62\u76C8\u6309\u9996\u4ED3\u540D\u4E49\u91D1\u989D\u4E58\u9996\u4ED3\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4\u6BD4\u4F8B\u8BA1\u7B97\u98CE\u9669\u91D1\u989D\u3002" },
      { id: "selected-l0-dbl5-execution-line-v1", since: "2026-11-26", summary: "\u76C8\u4E8F\u6BD4\u4E0E\u76C8\u4E8F\u6BD4\u6B62\u76C8\u4F7F\u7528\u5F00\u4ED3\u65F6\u4F4E\u4E8E\u4E70\u5165\u4EF7\u7684\u6700\u8FD1 DBL-5 \u6267\u884C\u7EBF\uFF0C\u6309\u9996\u4ED3\u6570\u91CF\u4E58\u4EF7\u5DEE\u8BA1\u7B97\u98CE\u9669\u91D1\u989D\u3002" },
      { id: "holding-dbl5-binance-trade-grid-v4", since: "2026-11-26", summary: "\u6301\u4ED3\u5386\u53F2\u56DE\u653E\u5728\u7BB1\u4F53\u6B62\u635F\u6216\u52A0\u4ED3\u62A5\u4EF7\u6821\u9A8C\u5931\u8D25\u65F6\uFF0C\u6309\u5E01\u5B89\u516C\u544A\u751F\u6548\u533A\u95F4\u91CD\u8BFB\u539F\u59CB\u6210\u4EA4\u4EF7\uFF0C\u5E76\u4EE5\u5F53\u671F\u5408\u7EA6\u683C\u70B9\u8BA1\u7B97\u4FDD\u62A4\u4EF7\u3002" },
      { id: "holding-dbl5-binance-trade-grid-v3", since: "2026-11-26", summary: "\u6301\u4ED3\u56DE\u653E\u5728\u539F\u6821\u9A8C\u5931\u8D25\u540E\u6309\u5E01\u5B89\u516C\u544A\u6062\u590D ON\u3001\u5E01\u5B89\u4EBA\u751F\u4E0E SOON \u7684\u5386\u53F2\u62A5\u4EF7\u7CBE\u5EA6\u3002FIL \u4EC5\u63A5\u53D7\u9010\u7B14\u6210\u4EA4\u5DF2\u6838\u9A8C\u7684\u4F8B\u5916\u4EF7\u683C\uFF0C\u4FDD\u62A4\u4EF7\u7EE7\u7EED\u4F7F\u7528\u5408\u7EA6\u62A5\u4EF7\u7CBE\u5EA6\u3002" },
      { id: "holding-box-stop-guard-regime-v2", since: "2026-11-13", summary: "DBL-5 \u9632\u5B88\u7EBF\u53EF\u6309\u4E0A\u6DA8\u671F\u5B9E\u7EBF\u6216\u9707\u8361\u671F\u865A\u7EBF\u5EFA\u7ACB\u4E0E\u66F4\u65B0\u786C\u6B62\u635F K\u3002\u5176\u4ED6\u7EBF\u578B\u51FA\u73B0\u65F6\u6CBF\u7528\u5DF2\u6709 K\uFF0C\u5C1A\u65E0 K \u65F6\u7B49\u5F85\u3002\u6CBF\u7528\u51BB\u7ED3\u7684\u9632\u5B88\u7EBF\u7B97\u6CD5\u3001\u5197\u4F59\u3001K \u66F4\u65B0\u4E0E\u6210\u4EA4\u786E\u8BA4\u8BBE\u7F6E\u3002" },
      { id: "breakeven-floor-v2", since: "2026-11-15", summary: "\u4FDD\u672C\u5E95\u7EBF\u8DDF\u968F\u5B9E\u9645\u89E6\u53D1\u52A0\u4ED3\u7684\u4F4D\u7F6E K\uFF0C\u6309 F \u5B9A\u91CF\uFF1B\u9010\u7B14\u51BB\u7ED3\u5356\u51FA K \u4E0E F\u3002\u9632\u5B88\u7EBF\u6309\u914D\u7F6E\u6536\u76D8\u6216\u89E6\u4EF7\uFF0C\u5176\u4ED6\u4F4D\u7F6E\u6309\u89E6\u4EF7\u3002" },
      { id: "addition-round-exits-v1", since: "2026-11-20", summary: "\u6BCF\u6B21\u52A0\u4ED3\u53EF\u5355\u72EC\u8BBE\u7F6E\u4FDD\u672C\u5E95\u7EBF\u3001K \u7684\u6267\u884C\u65B9\u5F0F\u3001\u652F\u6491\u4E0B\u79FB\u51CF\u4ED3\u53CA\u6709\u6548\u6DA8\u5E45\u4FDD\u62A4\u3002\u6309\u5B9E\u9645\u6210\u4EA4\u6B21\u6570\u5207\u6362\uFF0C\u7EED\u7B97\u6CBF\u7528\u5DF2\u6210\u4EA4\u8F6E\u6B21\u3002" },
      { id: "breakeven-floor-v4", since: "2026-11-20", summary: "\u6309\u5B9E\u9645\u6301\u4ED3\u6210\u672C\u548C\u5DF2\u5B9E\u73B0\u51C0\u76C8\u4E8F\u5728\u672C\u6B21\u4F4D\u7F6E K \u5B9A\u91CF\uFF0C\u72EC\u7ACB\u5356\u51FA\u7EBF F\uFF1DK\uFF0Bm\xD7ATR\u3002\u89E6\u7EBF\u5168\u4ED3\u9000\u51FA\uFF0C\u96F6\u500D\u6570\u76D8\u4E2D\u89E6 K\uFF0C\u8DF3\u7A7A\u4EE5\u5F00\u76D8\u4EF7\u6210\u4EA4\u3002" },
      { id: "breakeven-floor-v3", since: "2026-11-19", summary: "\u4FDD\u672C\u5E95\u7EBF\u72EC\u7ACB\u6309\u76D8\u4E2D\u89E6\u4EF7\u6267\u884C\uFF0C\u8986\u76D6\u5B9E\u9645\u6210\u4EA4\u7684\u9632\u5B88\u7EBF\u3001\u539F\u6025\u62C9\u7EBF\u53CA\u4E00\u7C7B\uFF0F\u4E8C\u7C7B\u6025\u62C9\u7EBF\u3002F\uFF1DK\u2212N\xD7ATR\uFF1BN\uFF1D0\u3001F \u4E0E K \u91CD\u5408\u65F6\u4E5F\u4E0D\u7B49\u5F85 K \u6536\u76D8\u786E\u8BA4\u3002\u8DF3\u7A7A\u8D8A\u8FC7 F \u6309\u5F00\u76D8\u4EF7\u3002\u5B9A\u91CF\u4ECD\u6309 F\uFF0C\u65E7\u7248\u6267\u884C\u4E0E\u5DF2\u4FDD\u5B58\u65B9\u6848\u4FDD\u6301\u539F\u6837\u3002" },
      { id: "addition-position-race-v1", since: "2026-11-15", summary: "5 \u5206\u949F\u6025\u62C9\u7EBF\u4E0E\u539F\u4F4D\u7F6E\u53EF\u5E76\u884C\u6216\u72EC\u7ACB\u542F\u7528\u3002\u540C\u5206\u949F\u53EA\u6267\u884C\u4E00\u6B21\uFF0C\u6309\u6210\u529F\u6210\u4EA4\u5171\u7528\u8F6E\u6B21\u4E0E\u6301\u4ED3\u8D26\u3002\u6025\u62C9\u6309\u5DF2\u6536\u76D8 5 \u5206\u949F\u91CF\u4EF7\u786E\u8BA4\uFF0C\u65E0 BTC \u4F9D\u8D56\u3002" },
      { id: "addition-k-touch-v1", since: "2026-11-07", summary: "\u52A0\u4ED3\u5356\u51FA\u7B2C\u4E00\u884C\u7684 K / K\u2032 \u6539\u4E3A\u76D8\u4E2D\u5373\u65F6\u89E6\u78B0\u5168\u4ED3\u5356\u51FA\uFF0C\u5305\u542B\u9632\u5B88\u7EBF\u4E0E\u5F71\u7EBF\uFF1B\u8DF3\u7A7A\u6309\u5F00\u76D8\u4EF7\u3002\u65E7\u65B9\u6848\u672A\u9009\u6B64\u7248\u672C\u4ECD\u6309\u539F\u89C4\u5219\u6267\u884C\uFF0C\u539F\u52A0\u4ED3\u5B9A\u91CF\u4E0E F \u4E0D\u53D8\u3002" }
    ]);
  }
});

// src/lib/fish/qualityBoxHistoricalTicks.ts
var windows, timelines;
var init_qualityBoxHistoricalTicks = __esm({
  "src/lib/fish/qualityBoxHistoricalTicks.ts"() {
    windows = {
      AGTUSDT: [
        // https://www.binance.com/en/support/announcement/detail/84b9812b7a88404baedec318c5d60b37
        ["2025-05-20T10:30:00Z", "2026-10-22T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/84b9812b7a88404baedec318c5d60b37
        ["2026-10-22T06:30:00Z", "2026-11-21T00:00:00Z", "0.00001"]
      ],
      AKEUSDT: [
        // https://www.binance.com/en/support/announcement/detail/82a93632adbd4d0cb42bbf24c9b35400
        ["2025-09-26T12:30:00Z", "2026-08-15T06:00:00Z", "0.0000001"],
        // https://www.binance.com/en/support/announcement/detail/82a93632adbd4d0cb42bbf24c9b35400
        ["2026-08-15T06:00:00Z", "2026-11-21T00:00:00Z", "0.000001"]
      ],
      ATUSDT: [
        // https://www.binance.com/en/support/announcement/detail/1cd08ee9bafd40a2a94e8dfc58408f82
        ["2025-10-29T11:30:00Z", "2025-12-22T07:00:00Z", "0.0001"],
        // https://www.binance.com/en/support/announcement/detail/1cd08ee9bafd40a2a94e8dfc58408f82
        ["2025-12-22T07:00:00Z", "2026-06-13T06:30:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/6baee79f009c4f39b8aa62d8a09a24df
        ["2026-06-13T06:30:00Z", "2026-11-20T16:01:00Z", "0.0001"]
      ],
      BRUSDT: [
        // https://www.binance.com/en/support/announcement/detail/cb6f7e88fed2459a8de11d55a69bef58
        ["2025-03-21T12:45:00Z", "2025-04-17T06:00:00Z", "0.0001"],
        // https://www.binance.com/en/support/announcement/detail/cb6f7e88fed2459a8de11d55a69bef58
        ["2025-04-17T06:00:00Z", "2026-10-22T06:30:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/84b9812b7a88404baedec318c5d60b37
        ["2026-10-22T06:30:00Z", "2026-11-20T16:01:00Z", "0.0001"]
      ],
      BTWUSDT: [
        // https://www.binance.com/en/support/announcement/detail/3d7ade5e0521477cbe75ca92a913c211
        ["2026-06-04T14:15:00Z", "2026-06-10T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/3d7ade5e0521477cbe75ca92a913c211
        ["2026-06-10T06:30:00Z", "2026-09-17T06:30:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/2b19feada63c4f97b05322298f4121cb
        ["2026-09-17T06:30:00Z", "2026-11-21T00:00:00Z", "0.0001"]
      ],
      BULLAUSDT: [
        // https://www.binance.com/en/support/announcement/detail/cf3f3712e01843cf8616551013341612
        ["2025-07-04T09:00:00Z", "2025-08-04T07:00:00Z", "0.0001"],
        // https://www.binance.com/en/support/announcement/detail/cf3f3712e01843cf8616551013341612
        ["2025-08-04T07:00:00Z", "2026-04-02T06:30:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/74de1917c41548108f9b799658fa3f3f
        ["2026-04-02T06:30:00Z", "2026-09-17T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/2b19feada63c4f97b05322298f4121cb
        ["2026-09-17T06:30:00Z", "2026-11-20T16:01:00Z", "0.00001"]
      ],
      DOLOUSDT: [
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-05-01T03:00:00Z", "2025-09-03T07:00:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-09-03T07:00:00Z", "2026-11-20T16:01:00Z", "0.00001"]
      ],
      DOODUSDT: [
        // https://www.binance.com/en/support/announcement/detail/d901cffcd4a745b5a1151697109571a8
        ["2025-05-09T13:30:00Z", "2025-10-08T07:00:00Z", "0.0000001"],
        // https://www.binance.com/en/support/announcement/detail/d901cffcd4a745b5a1151697109571a8
        ["2025-10-08T07:00:00Z", "2026-11-20T16:01:00Z", "0.000001"]
      ],
      HAEDALUSDT: [
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-05-01T03:15:00Z", "2025-09-03T07:00:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-09-03T07:00:00Z", "2026-11-21T00:00:00Z", "0.00001"]
      ],
      NXPCUSDT: [
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-05-15T06:30:00Z", "2025-09-03T07:00:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-09-03T07:00:00Z", "2026-11-20T16:01:00Z", "0.0001", "0.00001"]
      ],
      QUSDT: [
        // https://www.binance.com/en/support/announcement/detail/4688df6f250848478383acf772a7424c
        ["2025-09-02T07:30:00Z", "2026-10-28T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/4688df6f250848478383acf772a7424c
        ["2026-10-28T06:30:00Z", "2026-11-21T00:00:00Z", "0.00001"]
      ],
      SOLUSDT: [
        // Confirmed replay month after the 2024-10-14 change; outstanding orders retained their grid.
        // https://www.binance.com/en/support/announcement/detail/8bfe2e9b86734cd08f3cbcdb82b79f51
        ["2025-02-01T00:00:00Z", "2025-03-01T00:00:00Z", "0.01", "0.001"]
      ],
      STABLEUSDT: [
        // https://www.binance.com/en/support/announcement/detail/1cd08ee9bafd40a2a94e8dfc58408f82
        ["2025-11-06T12:00:00Z", "2025-12-22T07:00:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/1cd08ee9bafd40a2a94e8dfc58408f82
        ["2025-12-22T07:00:00Z", "2026-04-06T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/6dbc37d4df4b42cd91b3ca768ec547dd
        ["2026-04-06T06:30:00Z", "2026-11-20T16:01:00Z", "0.00001"]
      ],
      TSTUSDT: [
        // https://www.binance.com/en/support/announcement/detail/fed6c0cbecb84685a157fed45da638ad
        ["2025-02-09T13:00:00Z", "2025-06-12T06:00:00Z", "0.0001"],
        // https://www.binance.com/en/support/announcement/detail/fed6c0cbecb84685a157fed45da638ad
        ["2025-06-12T06:00:00Z", "2026-04-02T06:30:00Z", "0.00001"],
        // https://www.binance.com/en/support/announcement/detail/74de1917c41548108f9b799658fa3f3f
        ["2026-04-02T06:30:00Z", "2026-07-30T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/731403f07ae7487b907bef649bdda4d6
        ["2026-07-30T06:30:00Z", "2026-11-20T16:01:00Z", "0.00001"]
      ],
      XVGUSDT: [
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2024-12-01T00:00:00Z", "2025-09-03T07:00:00Z", "0.0000001"],
        // https://www.binance.com/en/support/announcement/detail/0f7995f922734628892b4b66d9d62e1a
        ["2025-09-03T07:00:00Z", "2026-11-20T16:01:00Z", "0.000001", "0.0000001"]
      ],
      \u9F99\u867EUSDT: [
        // https://www.binance.com/en/support/announcement/detail/2b19feada63c4f97b05322298f4121cb
        ["2026-03-11T11:30:00Z", "2026-09-17T06:30:00Z", "0.000001"],
        // https://www.binance.com/en/support/announcement/detail/2b19feada63c4f97b05322298f4121cb
        ["2026-09-17T06:30:00Z", "2026-11-21T00:00:00Z", "0.00001"]
      ]
    };
    timelines = new Map(Object.entries(windows).map(([symbol2, rows]) => [
      symbol2,
      rows.map(([from, until, orderTick, executionTick = orderTick]) => ({ from: Date.parse(from), until: Date.parse(until), orderTick, executionTick }))
    ]));
  }
});

// src/lib/fish/qualityBoxMarketRepair.ts
var BOX_MARKET_REPAIR_VERSION, BULLA_BOX_MARKET_REPAIR_VERSION, HISTORICAL_BOX_MARKET_REPAIR_VERSION, rules;
var init_qualityBoxMarketRepair = __esm({
  "src/lib/fish/qualityBoxMarketRepair.ts"() {
    init_dbl5m();
    init_timeFormat();
    init_qualityBoxHistoricalTicks();
    init_dbl5mMarketRules();
    BOX_MARKET_REPAIR_VERSION = "holding-dbl5-binance-trade-grid-v1";
    BULLA_BOX_MARKET_REPAIR_VERSION = "holding-dbl5-binance-trade-grid-v2";
    HISTORICAL_BOX_MARKET_REPAIR_VERSION = "holding-dbl5-binance-trade-grid-v3";
    rules = {
      RAVEUSDT: { ...DBL5_TICK_CHANGES[0], version: BOX_MARKET_REPAIR_VERSION },
      // Binance continues to match outstanding orders on the original grid.
      // https://www.binance.com/en/square/post/355516476087650
      AKEUSDT: { effectiveAt: Date.UTC(2026, 7, 15, 6), before: "0.0000001", after: "0.000001", version: BOX_MARKET_REPAIR_VERSION },
      // https://www.binance.com/en/support/announcement/detail/2b19feada63c4f97b05322298f4121cb
      BULLAUSDT: { before: "0.000001", after: "0.00001", version: BULLA_BOX_MARKET_REPAIR_VERSION },
      // https://www.binance.com/en/support/announcement/detail/82a93632adbd4d0cb42bbf24c9b35400
      ONUSDT: { effectiveAt: Date.UTC(2026, 7, 15, 6), before: "0.00001", after: "0.0001", version: HISTORICAL_BOX_MARKET_REPAIR_VERSION },
      // https://www.binance.com/en/support/announcement/detail/3d7ade5e0521477cbe75ca92a913c211
      \u5E01\u5B89\u4EBA\u751FUSDT: { effectiveAt: Date.UTC(2026, 5, 10, 6, 30), before: "0.00001", after: "0.0001", version: HISTORICAL_BOX_MARKET_REPAIR_VERSION },
      // https://www.binance.com/en/support/announcement/detail/a1e0bd9e7e124105ad10fdcfa923ce42
      SOONUSDT: { effectiveAt: Date.UTC(2025, 9, 10, 7), before: "0.00001", after: "0.0001", version: HISTORICAL_BOX_MARKET_REPAIR_VERSION }
    };
  }
});

// src/lib/fish/qualityInitialization.ts
var init_qualityInitialization = __esm({
  "src/lib/fish/qualityInitialization.ts"() {
    init_turingCupSymbol();
  }
});

// src/lib/fish/qualityAdditionStructure.ts
function validateStructureAddition(rule) {
  if (!rule || !["dbl5", "sbs5m"].includes(rule.algorithm) || !["raise", "confirm", "retest"].includes(rule.trigger) || !["support", "invalidation"].includes(rule.kBasis) || !["atr", "percent"].includes(rule.bufferUnit)) throw Error("\u7BB1\u4F53\u52A0\u4ED3\u7B97\u6CD5\u6216\u89E6\u53D1\u65B9\u5F0F\u65E0\u6548");
  if (rule.algorithm === "dbl5" && (rule.trigger === "retest" || rule.kBasis === "invalidation")) throw Error("DBL-5 \u4E0D\u63D0\u4F9B\u72EC\u7ACB\u56DE\u8E29\u786E\u8BA4\u6216\u7B97\u6CD5\u5931\u6548\u7EBF\uFF0C\u8BF7\u9009\u62E9\u5DF2\u786E\u8BA4\u4E0B\u8F68");
  if (rule.kSource != null && !["previous", "current", "guard"].includes(rule.kSource)) throw Error("K \u57FA\u51C6\u987B\u4E3A\u65E7 C\u3001\u65B0 C \u6216\u9632\u5B88\u7EBF");
  if (rule.kSource === "guard" && (rule.algorithm !== "dbl5" || rule.kBasis !== "support")) throw Error("\u9632\u5B88\u7EBF\u76EE\u524D\u53EA\u7528\u4E8E DBL-5 \u7684\u5DF2\u786E\u8BA4\u4E0B\u8F68");
  if (rule.guardTrendOnly != null && typeof rule.guardTrendOnly !== "boolean") throw Error("\u9632\u5B88\u7EBF\u7C7B\u578B\u987B\u4E3A\u300C\u5B9E\u7EBF\u548C\u865A\u7EBF\u300D\u6216\u300C\u53EA\u7528\u5B9E\u7EBF\u300D");
  if (!Number.isFinite(rule.buffer) || rule.buffer < 0 || rule.bufferUnit === "percent" && rule.buffer >= 100) throw Error("\u652F\u6491\u5197\u4F59\u987B\u4E3A\u4E0D\u5C0F\u4E8E 0 \u7684\u6709\u9650\u6570\u5B57\uFF1B\u767E\u5206\u6BD4\u987B\u5C0F\u4E8E 100");
  if (rule.minDistancePct != null && (!Number.isFinite(rule.minDistancePct) || rule.minDistancePct <= 0 || rule.minDistancePct >= 50)) throw Error("K \u6700\u5C0F\u8DDD\u79BB\u987B\u4E3A\u5927\u4E8E 0\u3001\u5C0F\u4E8E 50 \u7684\u767E\u5206\u6BD4");
  const def = rule.definition, timeframe = structureDbl5Timeframe(rule);
  const builtin = timeframe !== "5m" ? dbl5VariantDefinition(timeframe) : rule.algorithm === "dbl5" ? DBL5_DEF : SBS5M_DEF;
  if (!def || def.id !== builtin.id || def.chartTemplate !== builtin.chartTemplate || def.interval !== builtin.interval || def.formula !== builtin.formula) throw Error("\u7BB1\u4F53\u52A0\u4ED3\u987B\u4F7F\u7528\u539F\u751F5\u5206\u949F\u7ED3\u6784\u5B9A\u4E49\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u7B97\u6CD5");
  if (rule.algorithm === "dbl5") {
    const config = dbl5Parameters(def.DBL5_config);
    if (config.timeframe !== builtin.interval) throw Error("DBL-5 \u7684\u53C2\u6570\u5468\u671F\u987B\u4E0E\u7BB1\u4F53\u7248\u672C\u4E00\u81F4");
  } else sbsParameters(def.SBS5M_config);
  assertStructureVersionsAvailable(rule);
  const configurableImpulse = rule.guardPlusVersion === DBL5_GUARD_PLUS_CONFIGURABLE_K_VERSION;
  if (rule.guardPlusVersion !== void 0 && (rule.guardPlusVersion !== DBL5_GUARD_PLUS_VERSION && !configurableImpulse || timeframe !== "5m" || rule.kSource !== "guard" || rule.algorithm !== "dbl5" || structureVersions(rule).guard !== CURRENT_GUARD_VERSION)) {
    throw Error("\u6025\u62C9-1115 \u4EC5\u7528\u4E8E DBL-5 \u9632\u5B88\u7EBF v1 \u7684\u52A0\u4ED3\u4F4D\u7F6E");
  }
  if (configurableImpulse && (!Number.isFinite(rule.guardPlusImpulseBufferAtr) || rule.guardPlusImpulseBufferAtr < 0)) {
    throw Error("\u7EC4\u5408\u7248\u7684\u6025\u62C9\u5197\u4F59\u987B\u4E3A\u4E0D\u5C0F\u4E8E 0 \u7684\u6709\u9650 ATR \u500D\u6570");
  }
  if (!configurableImpulse && rule.guardPlusImpulseBufferAtr !== void 0) throw Error("\u7EC4\u5408\u7248\u6025\u62C9\u5197\u4F59\u7684\u6267\u884C\u7248\u672C\u4E0D\u5339\u914D");
}
var guardTrendOnly, structureKSourceLabel, structureAdditionIdentity;
var init_qualityAdditionStructure = __esm({
  "src/lib/fish/qualityAdditionStructure.ts"() {
    init_qualityBoxMarketRepair();
    init_qualityInitialization();
    init_features();
    init_boxAlgorithmVersions();
    init_dbl5GuardPlus();
    init_dbl5m();
    init_dbl5mMarketRules();
    init_sbs5m();
    init_algorithm();
    init_shared();
    guardTrendOnly = (r) => r.kSource === "guard" && r.guardTrendOnly === true;
    structureKSourceLabel = (r) => r.kSource === "current" ? "\u65B0C" : r.kSource === "guard" ? guardTrendOnly(r) ? "\u9632\u5B88\u7EBF\uFF08\u53EA\u7528\u5B9E\u7EBF\uFF09" : "\u9632\u5B88\u7EBF" : "\u65E7C";
    structureAdditionIdentity = (r) => ["box-addition-v1", r.kSource === "current" ? "k-from-current-box-v2" : r.kSource === "guard" ? `k-from-${structureVersions(r).guard}` : "k-from-previous-box-v2", r.algorithm, r.trigger, r.kBasis, r.bufferUnit, r.buffer, definitionKey(r.definition), DBL5_MARKET_RULE_VERSION, ...guardTrendOnly(r) ? ["guard-trend-only-v1"] : [], ...r.minDistancePct != null ? [["k-min-distance-v1", r.minDistancePct]] : [], ...r.guardPlusVersion ? [[r.guardPlusVersion, dbl5GuardPlusParams(r.guardPlusImpulseBufferAtr)]] : []];
  }
});

// src/lib/fish/qualityBoxStop.ts
function freezeBoxStop(rule) {
  if (rule.version === BOX_STOP_CHANNELS_VERSION && rule.channels) return selectBoxStopChannels({ regular: { ...rule.channels.regular, rule: freezeBoxStop(rule.channels.regular.rule) }, impulse: { ...rule.channels.impulse, rule: freezeBoxStop(rule.channels.impulse.rule) } });
  const structure = freezeStructureVersions(rule.structure), d = structure.definition;
  return { ...rule, structure: { ...structure, definition: { ...d, ...structure.algorithm === "dbl5" ? { DBL5_config: dbl5Parameters(d.DBL5_config) } : { SBS5M_config: sbsParameters(d.SBS5M_config) } } } };
}
function selectBoxStopChannels(channels) {
  const saved = structuredClone(channels);
  return { ...saved.regular.rule, version: BOX_STOP_CHANNELS_VERSION, channels: saved };
}
function boxStopAlgorithmLabel(rule) {
  return rule.structure.algorithm === "dbl5" ? DBL5_PROFILES[structureDbl5Timeframe(rule.structure)].label : "SBS-5M";
}
function validateBoxStop(rule) {
  if (rule?.version === BOX_STOP_CHANNELS_VERSION) {
    const c = rule.channels;
    if (!c || !c.regular || !c.impulse || Object.keys(c).length !== 2) throw Error("\u8BF7\u4FDD\u7559\u6025\u62C9\u4E0E\u975E\u6025\u62C9\u4E24\u8DEF\u72EC\u7ACB\u914D\u7F6E");
    for (const key of ["regular", "impulse"]) {
      const v = c[key];
      if (typeof v.enabled !== "boolean" || !v.rule || v.rule.channels || v.rule.version === BOX_STOP_CHANNELS_VERSION || isBoxBreak(v.rule)) throw Error("\u53CC\u8DEF\u6B62\u635F\u987B\u5404\u81EA\u4F7F\u7528\u72EC\u7ACB\u89E6\u4EF7\u6216\u6536\u76D8\u786E\u8BA4\u89C4\u5219");
      validateBoxStop(v.rule);
    }
    if (c.regular.rule.reference || !c.impulse.rule.reference) throw Error("\u975E\u6025\u62C9\u7EBF\u4E0E\u6025\u62C9\u7EBF\u7684\u53C2\u8003\u4E0D\u53EF\u6DF7\u7528");
    const { channels: _, ...base } = rule;
    if (stableBoxStop({ ...base, version: c.regular.rule.version }) !== stableBoxStop(c.regular.rule)) throw Error("\u53CC\u8DEF\u6B62\u635F\u7684\u5E38\u89C4\u57FA\u51C6\u4E0E\u51BB\u7ED3\u53C2\u6570\u4E0D\u4E00\u81F4");
    return;
  }
  if (rule?.channels) throw Error("\u53CC\u8DEF\u6B62\u635F\u53C2\u6570\u4E0E\u6267\u884C\u7248\u672C\u4E0D\u7B26\uFF0C\u8BF7\u4FDD\u7559\u539F\u7248");
  if (!rule || ![BOX_STOP_VERSION, BOX_STOP_GUARD_REGIME_VERSION, BOX_BREAK_VERSION, BOX_SECOND_BREAK_VERSION, BOX_SECOND_EXIT_VERSION, BOX_STOP_REFERENCE_VERSION].includes(rule.version)) throw Error("\u7BB1\u4F53\u786C\u6B62\u635F\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u539F\u7248\u5E76\u65B0\u5EFA\u65B9\u6848");
  validateStructureAddition(rule.structure);
  const nativeConfirmation = `close-${structureDbl5Timeframe(rule.structure)}`;
  if (rule.version === BOX_STOP_REFERENCE_VERSION) {
    validateBoxStopReference(rule.reference);
    if (rule.structure.algorithm !== "dbl5" || structureDbl5Timeframe(rule.structure) !== "5m" || rule.guardRegime !== void 0) throw Error("\u6025\u62C9\u7EBF K \u57FA\u51C6\u987B\u4F7F\u7528\u72EC\u7ACB\u7684\u539F\u751F 5 \u5206\u949F\u6267\u884C\u7248\u672C");
    if (rule.reference.kind !== "impulse0" && (rule.structure.kSource !== "guard" || dbl5GuardVersion(rule.structure.definition.DBL5_config) !== DBL5_GUARD_VERSION)) throw Error("\u6025\u62C9\u7EBF-1115 \u987B\u4FDD\u7559\u539F\u9632\u5B88\u7EBF v1 \u57FA\u7EBF");
  } else if (rule.reference !== void 0) throw Error("\u6025\u62C9\u7EBF K \u57FA\u51C6\u4E0E\u6267\u884C\u7248\u672C\u4E0D\u7B26\uFF0C\u8BF7\u4FDD\u7559\u539F\u7248\u5E76\u65B0\u5EFA\u526F\u672C");
  if (rule.version === BOX_STOP_GUARD_REGIME_VERSION) {
    if (rule.structure.algorithm !== "dbl5" || rule.structure.kSource !== "guard" || !["trend", "range"].includes(rule.guardRegime ?? "")) {
      throw Error("\u7BB1\u4F53\u786C\u6B62\u635F\u7684\u5355\u4E00\u7EBF\u578B\u987B\u4F7F\u7528 DBL-5 \u9632\u5B88\u7EBF\u5E76\u9009\u62E9\u5B9E\u7EBF\u6216\u865A\u7EBF");
    }
  } else if (rule.guardRegime !== void 0) throw Error("\u7BB1\u4F53\u786C\u6B62\u635F\u7684\u9632\u5B88\u7EBF\u7C7B\u578B\u4E0E\u6267\u884C\u7248\u672C\u4E0D\u7B26");
  if (isBoxBreak(rule)) {
    if (rule.structure.algorithm !== "dbl5" || rule.structure.kSource !== "guard" || rule.structure.buffer !== 0 || rule.structure.bufferUnit !== "atr" || rule.confirmation !== "guard-break" || rule.update !== "follow" || rule.closes !== 1) throw Error("\u652F\u6491\u65AD\u88C2\u987B\u4F7F\u7528 DBL-5 \u9632\u5B88\u7EBF\u539F\u751F\u7EA2\u53C9\u4E8B\u4EF6\uFF0C\u4E0D\u80FD\u6DFB\u52A0\u89E6\u4EF7\u5197\u4F59\u6216\u53E6\u884C\u786E\u8BA4");
    return;
  }
  if (!["current", "guard"].includes(rule.structure.kSource ?? "") || !["fixed", "raise-only", "follow"].includes(rule.update) || !["touch", "close-1m", nativeConfirmation].includes(rule.confirmation) || !Number.isInteger(rule.closes) || rule.closes < 1 || rule.closes > 100) throw Error("\u8BF7\u5B8C\u5584\u7BB1\u4F53\u786C\u6B62\u635F\u7684\u57FA\u51C6\u3001\u66F4\u65B0\u65B9\u5F0F\u4E0E\u786E\u8BA4\u6839\u6570\uFF081\u2013100\uFF09");
}
function boxStopIdentity(r) {
  if (r.version === BOX_STOP_CHANNELS_VERSION) return [r.version, stableBoxStop(r)];
  const config = r.structure.definition.DBL5_config;
  const structure = (r.version === BOX_STOP_GUARD_REGIME_VERSION || isBoxSecondBreak(r) || r.reference) && config ? { ...r.structure, definition: { ...r.structure.definition, DBL5_config: Object.fromEntries(Object.keys(config).sort().map((key) => [key, config[key]])) } } : r.structure;
  return [r.version, structureAdditionIdentity(structure), r.update, r.confirmation, r.closes, ...r.guardRegime ? [r.guardRegime] : [], ...r.reference ? [boxStopReferenceIdentity(r.reference)] : []];
}
var BOX_STOP_KIND, BOX_STOP_VERSION, BOX_STOP_CHANNELS_VERSION, BOX_STOP_CHANNEL_LABELS, BOX_STOP_GUARD_REGIME_VERSION, BOX_STOP_GUARD_REGIMES, BOX_BREAK_VERSION, BOX_SECOND_BREAK_VERSION, BOX_SECOND_EXIT_VERSION, boxStopRuleEntries, stableBoxStop, isBoxSecondBreakExitOnly, isBoxSecondBreak, isBoxBreak, boxStopLabel;
var init_qualityBoxStop = __esm({
  "src/lib/fish/qualityBoxStop.ts"() {
    init_features();
    init_qualityBoxReference();
    init_dbl5mMarketRules();
    init_turingCupSymbol();
    init_atr();
    init_algorithm();
    init_boxAlgorithmVersions();
    init_qualityAdditionStructure();
    init_qualityInitialization();
    init_shared();
    init_dbl5m();
    init_sbs5m();
    init_qualityBoxMarketRepair();
    init_qualityPostMirrorProtection();
    init_qualityMirrorHardStopStages();
    BOX_STOP_KIND = "box-stop";
    BOX_STOP_VERSION = "holding-box-stop-v1";
    BOX_STOP_CHANNELS_VERSION = "holding-box-stop-independent-channels-v1";
    BOX_STOP_CHANNEL_LABELS = { regular: "\u975E\u6025\u62C9\u7EBF", impulse: "\u6025\u62C9\u7EBF" };
    BOX_STOP_GUARD_REGIME_VERSION = "holding-box-stop-guard-regime-v2";
    BOX_STOP_GUARD_REGIMES = { both: "\u5B9E\u7EBF\u548C\u865A\u7EBF", trend: "\u53EA\u7528\u5B9E\u7EBF", range: "\u53EA\u7528\u865A\u7EBF" };
    BOX_BREAK_VERSION = "holding-support-break-v1";
    BOX_SECOND_BREAK_VERSION = "holding-support-second-break-v1";
    BOX_SECOND_EXIT_VERSION = "holding-support-second-exit-v1";
    boxStopRuleEntries = (rule) => rule.channels ? ["regular", "impulse"].map((channel) => ({ channel, ...rule.channels[channel] })) : [{ enabled: true, rule }];
    stableBoxStop = (value) => JSON.stringify(value, (_k, v) => v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, v[k]])) : v);
    isBoxSecondBreakExitOnly = (rule) => rule.version === BOX_SECOND_EXIT_VERSION;
    isBoxSecondBreak = (rule) => rule.version === BOX_SECOND_BREAK_VERSION || isBoxSecondBreakExitOnly(rule);
    isBoxBreak = (rule) => rule.version === BOX_BREAK_VERSION || isBoxSecondBreak(rule);
    boxStopLabel = (r) => r.channels ? boxStopRuleEntries(r).map((c) => `${BOX_STOP_CHANNEL_LABELS[c.channel]}${c.enabled ? "\uFF1A" + boxStopLabel(c.rule) : "\uFF08\u672A\u542F\u7528\uFF09"}`).join("\uFF1B\u4EFB\u4E00\u8DEF\u89E6\u53D1\u9000\u51FA\uFF1B") : isBoxSecondBreakExitOnly(r) ? `${boxStopAlgorithmLabel(r)} \u6301\u4ED3\u671F\u95F4\u4E8C\u6B21\u65AD\u88C2\u7EC8\u6B62\uFF1B\u9996\u6B21\u53EA\u8BA1\u6570\uFF0C\u4E0D\u56E0\u672C\u6761\u4EF6\u505C\u52A0\u4ED3\uFF1B\u7B2C\u4E8C\u6B21\u65AD\u88C2\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u5168\u4ED3\u5356\u51FA` : isBoxSecondBreak(r) ? `${boxStopAlgorithmLabel(r)} \u9996\u6B21\u652F\u6491\u65AD\u88C2\u505C\u6B62\u52A0\u4ED3\uFF0C\u7B2C\u4E8C\u6B21\u65AD\u88C2\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u5168\u4ED3\u5356\u51FA` : isBoxBreak(r) ? `${boxStopAlgorithmLabel(r)} \u652F\u6491\u65AD\u88C2\uFF08\u9632\u5B88\u7EBF\u7EA2\u53C9\u786E\u8BA4\uFF09\uFF1B\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u5168\u4ED3\u5356\u51FA` : `${boxStopAlgorithmLabel(r)} ${r.reference ? BOX_STOP_REFERENCE_LABELS[r.reference.kind] : r.structure.kSource === "guard" ? `\u9632\u5B88\u7EBF${r.guardRegime ? `\uFF08${BOX_STOP_GUARD_REGIMES[r.guardRegime]}\uFF09` : ""}` : r.structure.kBasis === "invalidation" ? "\u5931\u6548\u7EBF" : "\u7BB1\u5E95"} \u2212 ${r.structure.buffer}${r.structure.bufferUnit === "atr" ? "ATR" : "%"}\uFF1B${{ fixed: "\u9996\u6B21\u6709\u6548\u7EBF\u56FA\u5B9A", "raise-only": "\u53EA\u5347\u4E0D\u964D", follow: "\u8DDF\u968F\u6700\u65B0\u7EBF" }[r.update]}\uFF1B${r.confirmation === "touch" ? "\u89E6\u78B0 K \u7ACB\u5373\u5356\u51FA" : `${r.confirmation === "close-1m" ? "1 \u5206\u949F" : DBL5_PROFILES[structureDbl5Timeframe(r.structure)].periodLabel}\u8FDE\u7EED ${r.closes} \u6839\u6536\u76D8 \u2264 K`}`;
  }
});

// src/lib/fish/qualityVeto.ts
function validateHoldingVeto(v) {
  validateMirrorHardStopStage(v);
  if (v.kind === MIRROR_LOSS_REVIEW_KIND) {
    validateMirrorLossThreshold(v);
    if (v.direction !== ">=" || !Number.isFinite(v.threshold) || v.threshold < 1 / 60 || v.threshold > 12 || v.activation || v.mirrorStage?.stage === "after") throw Error("\u5B9A\u65F6\u4E8F\u635F\u7EC8\u6B62\u987B\u4F7F\u7528\u4FDD\u7559\u7248\u672C\u3001\u653E\u5728\u955C\u50CF\u524D\uFF0C\u9996\u6B21\u68C0\u67E5\u65F6\u95F4\u987B\u4E3A 1 \u5206\u949F\u81F3 12 \u5C0F\u65F6");
    return;
  }
  if (v.mirrorLossThreshold !== void 0) throw Error("\u53EF\u7F16\u8F91\u4E8F\u635F\u95E8\u69DB\u53EA\u9002\u7528\u4E8E\u672A\u955C\u50CF\u5B9A\u65F6\u68C0\u67E5");
  if (v.mirrorReviewSchedule !== void 0) throw Error("\u53EF\u7F16\u8F91\u5224\u65AD\u95F4\u9694\u53EA\u9002\u7528\u4E8E\u672A\u955C\u50CF\u5B9A\u65F6\u68C0\u67E5");
  if (v.kind === MIRROR_DEADLINE_KIND) {
    if (v.mirrorDeadlineVersion !== MIRROR_DEADLINE_VERSION || v.direction !== ">=" || !Number.isFinite(v.threshold) || v.threshold < 1 / 60 || v.threshold > 24 * 366 || v.activation || v.mirrorStage?.stage === "after") throw Error("\u955C\u50CF\u9650\u65F6\u7EC8\u6B62\u987B\u4F7F\u7528\u4FDD\u7559\u7248\u672C\u3001\u653E\u5728\u955C\u50CF\u524D\uFF0C\u5E76\u586B\u5199 1 \u5206\u949F\u81F3 8784 \u5C0F\u65F6\u7684\u65F6\u957F");
    return;
  }
  if (v.mirrorDeadlineVersion !== void 0) throw Error("\u955C\u50CF\u9650\u65F6\u7EC8\u6B62\u7684\u6761\u4EF6\u7C7B\u578B\u4E0E\u7248\u672C\u4E0D\u7B26");
  if (v.limitedStaticVersion !== void 0 && (!isLimitedStaticDrawdownVeto(v) || !Number.isFinite(v.threshold) || v.threshold <= 0 || v.threshold >= 100)) throw Error("\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4\u987B\u4F7F\u7528\u4FDD\u7559\u7684\u6267\u884C\u7248\u672C\uFF0C\u5E76\u586B\u5199\u5927\u4E8E 0\u3001\u4F4E\u4E8E 100% \u7684\u9608\u503C");
  if (v.activation !== void 0 && (v.activation !== POST_MIRROR_PROTECTION_VERSION || !canGateAfterMirror(v))) throw Error("\u955C\u50CF\u51CF\u4ED3\u540E\u542F\u52A8\u4EC5\u9002\u7528\u4E8E\u72EC\u7ACB DBL-5 \u9632\u5B88\u7EBF\u6216 CDA \u786C\u6027\u7EC8\u6B62\uFF0C\u8BF7\u4FDD\u7559\u539F\u6761\u4EF6\u5E76\u65B0\u5EFA\u526F\u672C");
  if (v.kind === BOX_STOP_KIND) {
    validateBoxStop(v.boxStop);
    return;
  }
  if (![...Object.keys(holdingPriceLabels), "indicator", ADDITION_PROFIT_KIND, PAYOFF_STOP_KIND].includes(v.kind)) throw new Error("\u672A\u77E5\u7684\u6301\u4ED3\u5426\u51B3\u6307\u6807");
  if (v.kind === PAYOFF_STOP_KIND) {
    if (!(v.threshold > 0) || !Number.isFinite(v.threshold) || v.direction !== ">=") throw new Error("\u76C8\u4E8F\u6BD4\u6B62\u76C8\u987B\u586B\u5199\u5927\u4E8E 0 \u7684\u500D\u6570\uFF08R\uFF09");
    return;
  }
  if (!Number.isFinite(v.threshold) || !["<", ">", "<=", ">="].includes(v.direction)) throw new Error("\u4E00\u7968\u5426\u51B3\u6761\u4EF6\u987B\u8BBE\u7F6E\u6709\u6548\u65B9\u5411\u548C\u6709\u9650\u6570\u5B57\u9608\u503C");
  if (v.kind !== "indicator" && v.kind !== ADDITION_PROFIT_KIND && (!(v.threshold > 0 && v.threshold <= 100) || v.direction !== ">=")) throw new Error("\u56DE\u64A4\u6216\u8DCC\u5E45\u9608\u503C\u987B\u5927\u4E8E 0 \u4E14\u4E0D\u8D85\u8FC7 100%\uFF0C\u8FBE\u5230\uFF08\u2265\uFF09\u5373\u89E6\u53D1");
  if (v.kind === ADDITION_PROFIT_KIND && (!(v.threshold >= 0) || !Number.isFinite(v.geometricMultiple ?? 100) || !((v.geometricMultiple ?? 100) > 0) || v.direction !== ">=")) throw new Error("\u52A0\u4ED3\u6B62\u76C8\u987B\u8BBE\u7F6E\u5927\u4E8E 0 \u7684\u51E0\u4F55\u4ED3\u4F4D\u500D\u6570\u53CA\u4E0D\u5C0F\u4E8E 0 \u7684\u6DA8\u5E45\u767E\u5206\u6BD4");
  if (v.kind === "indicator" && (!v.snapshot || !v.metric)) throw new Error("\u4E00\u7968\u5426\u51B3\u6307\u6807\u7F3A\u5C11\u516C\u5F0F\u5FEB\u7167");
}
function payoffStopL0Pct(vetoes = []) {
  const stops = activeHoldingVetoes(vetoes).filter((v) => v.kind === "static-drawdown" && v.mirrorStage?.stage !== "after" && (v.direction === ">=" || v.direction === ">") && v.threshold > 0 && v.threshold <= 100);
  const limited = stops.filter(isLimitedStaticDrawdownVeto), selected = limited.length ? limited : stops;
  return selected.length ? Math.min(...selected.map((v) => v.threshold)) : void 0;
}
function holdingBoxStopIdentity(v) {
  const r = v.boxStop, config = r.structure.definition.DBL5_config;
  return boxStopIdentity((v.activation || v.mirrorStage) && config ? { ...r, structure: { ...r.structure, definition: { ...r.structure.definition, DBL5_config: Object.fromEntries(Object.entries(config).sort(([a], [b]) => a.localeCompare(b))) } } } : r);
}
function holdingVetoIdentity(vetoes = []) {
  return activeHoldingVetoes(vetoes).map((v) => [v.kind, v.direction, v.threshold, v.metric ?? null, v.snapshot?.definitionKey ?? null, v.snapshot?.interval ?? null, ...v.kind === ADDITION_PROFIT_KIND ? [v.geometricMultiple ?? 100] : [], ...v.kind === BOX_STOP_KIND ? [holdingBoxStopIdentity(v)] : [], ...v.activation ? [v.activation] : [], ...v.mirrorStage ? [[v.mirrorStage.version, v.mirrorStage.stage]] : [], ...v.limitedStaticVersion ? [v.limitedStaticVersion] : [], ...v.mirrorDeadlineVersion ? [v.mirrorDeadlineVersion] : [], ...v.mirrorLossThreshold ? [[v.mirrorLossThreshold.version, v.mirrorLossThreshold.unit, v.mirrorLossThreshold.value]] : [], ...v.mirrorReviewSchedule ? [[v.mirrorReviewSchedule.version, v.mirrorReviewSchedule.intervalHours, v.mirrorReviewSchedule.endHours]] : []]).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
}
var FREE_STATIC_DRAWDOWN_LABEL, LIMITED_STATIC_DRAWDOWN_LABEL, LIMITED_STATIC_DRAWDOWN_VETO_VERSION, isLimitedStaticDrawdownVeto, holdingPriceLabels, ADDITION_PROFIT_KIND, PAYOFF_STOP_KIND, L0_DRAWDOWN, L0_DBL5, isSelectedL0, holdingVetoName, holdingVetoLabel, activeHoldingVetoes;
var init_qualityVeto = __esm({
  "src/lib/fish/qualityVeto.ts"() {
    init_qualityMirrorHardStopStages();
    init_qualityMirrorDeadline();
    init_qualityMirrorLossReview();
    init_qualityPostMirrorProtection();
    init_qualityBoxStop();
    FREE_STATIC_DRAWDOWN_LABEL = "\u81EA\u7531\u9759\u6001\u6700\u5927\u56DE\u64A4";
    LIMITED_STATIC_DRAWDOWN_LABEL = "\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4";
    LIMITED_STATIC_DRAWDOWN_VETO_VERSION = "holding-limited-static-drawdown-v1";
    isLimitedStaticDrawdownVeto = (v) => v.kind === "static-drawdown" && v.limitedStaticVersion === LIMITED_STATIC_DRAWDOWN_VETO_VERSION;
    holdingPriceLabels = { "static-drawdown": "\u6301\u4ED3\u8FC7\u7A0B\u9759\u6001\u6700\u5927\u56DE\u64A4", "dynamic-drawdown": "\u6301\u4ED3\u8FC7\u7A0B\u52A8\u6001\u6700\u5927\u56DE\u64A4", "drop-1m": "1\u5206\u949F\u5185\u8DCC\u5E45", "drop-5m": "5\u5206\u949F\u5185\u8DCC\u5E45" };
    ADDITION_PROFIT_KIND = "addition-geometric-profit";
    PAYOFF_STOP_KIND = "payoff-ratio";
    L0_DRAWDOWN = "selected-l0-limited-drawdown-v1";
    L0_DBL5 = "selected-l0-dbl5-execution-line-v1";
    isSelectedL0 = (version) => version === L0_DRAWDOWN || version === L0_DBL5;
    holdingVetoName = (v) => (v.kind === "static-drawdown" ? isLimitedStaticDrawdownVeto(v) ? LIMITED_STATIC_DRAWDOWN_LABEL : FREE_STATIC_DRAWDOWN_LABEL : v.label) + (v.activation ? "\uFF08" + POST_MIRROR_PROTECTION_LABEL + "\uFF09" : "") + (v.mirrorStage ? "\uFF08" + mirrorHardStopStageLabel(v.mirrorStage) + "\uFF09" : "");
    holdingVetoLabel = (v) => v.kind === MIRROR_LOSS_REVIEW_KIND ? mirrorLossReviewSummary(v.threshold, v.mirrorLossThreshold, v.mirrorReviewSchedule) : v.kind === MIRROR_DEADLINE_KIND ? `\u6301\u4ED3 ${v.threshold} \u5C0F\u65F6${MIRROR_DEADLINE_LABEL}\u5373\u6E05\u4ED3` : v.kind === BOX_STOP_KIND && "boxStop" in v ? boxStopLabel(v.boxStop) + (v.activation ? POST_MIRROR_PROTECTION_LABEL : "") + (v.mirrorStage ? mirrorHardStopStageLabel(v.mirrorStage) : "") : v.kind === PAYOFF_STOP_KIND ? `\u76C8\u4E8F\u6BD4 \u2265 ${v.threshold}R${v.mirrorStage ? mirrorHardStopStageLabel(v.mirrorStage) : ""}` : v.kind === ADDITION_PROFIT_KIND ? `\u51E0\u4F55\u4ED3\u4F4D \u2265 ${v.geometricMultiple ?? 100}\xD7 \u4E14 \u4EF7\u683C\u9AD8\u51FA\u5747\u8861\u4EF7 \u2265 ${v.threshold}%` : `${holdingVetoName(v)} ${v.direction} ${v.threshold}${v.kind === "indicator" ? "" : "%"}`;
    activeHoldingVetoes = (conditions = []) => conditions.filter((v) => v.enabled);
  }
});

// src/lib/fish/screeningYield.ts
var init_screeningYield = __esm({
  "src/lib/fish/screeningYield.ts"() {
  }
});

// src/lib/fish/holdingImpulse1115Classification.ts
function holdingImpulse1115Identity(rule) {
  return rule ? [rule.version, IMPULSE_1115_CLASSIFICATION_VERSION, definitionKey(rule.definition)] : [];
}
var HOLDING_IMPULSE_1115_CLASSIFICATION_VERSION;
var init_holdingImpulse1115Classification = __esm({
  "src/lib/fish/holdingImpulse1115Classification.ts"() {
    init_features();
    init_dbl5m();
    init_impulse1115Classification();
    init_algorithm();
    init_qualityInitialization();
    init_shared();
    init_screeningYield();
    HOLDING_IMPULSE_1115_CLASSIFICATION_VERSION = "holding-impulse-1115-classification-v1";
  }
});

// src/lib/fish/qualityClassifiedImpulsePosition.ts
var CLASSIFIED_IMPULSE_POSITION_VERSION, CLASSIFIED_IMPULSE_LINE_K_POSITION_VERSION, CLASSIFIED_IMPULSE_ORIGIN_K_POSITION_VERSION, classifiedImpulsePositionLabel, classifiedImpulsePositionsIdentity;
var init_qualityClassifiedImpulsePosition = __esm({
  "src/lib/fish/qualityClassifiedImpulsePosition.ts"() {
    init_dbl5m();
    init_features();
    init_impulse1115Classification();
    init_dbl5GuardPlus();
    init_dbl5mMarketRules();
    init_algorithm();
    init_holdingImpulse1115Classification();
    init_qualityAdditionStructure();
    init_qualityInitialization();
    init_shared();
    CLASSIFIED_IMPULSE_POSITION_VERSION = "holding-impulse-1115-classified-position-v1";
    CLASSIFIED_IMPULSE_LINE_K_POSITION_VERSION = "holding-impulse-1115-classified-line-k-v2";
    CLASSIFIED_IMPULSE_ORIGIN_K_POSITION_VERSION = "holding-impulse-1115-classified-origin-k-v3";
    classifiedImpulsePositionLabel = (mainClass) => `DBL-5-\u6025\u62C9\u7EBF-1115 \xB7 ${mainClass === 1 ? "\u4E00\u7C7B" : "\u4E8C\u7C7B"}`;
    classifiedImpulsePositionsIdentity = (positions = []) => positions.map((p) => [p.version, p.mainClass, p.bufferAtr, p.minDistancePct ?? null, p.skipNative ?? null, definitionKey(p.definition)]);
  }
});

// src/lib/fish/qualityDoubleDrop.ts
var DOUBLE_DROP_VERSION;
var init_qualityDoubleDrop = __esm({
  "src/lib/fish/qualityDoubleDrop.ts"() {
    DOUBLE_DROP_VERSION = "addition-double-drop-v1";
  }
});

// src/lib/fish/preEntryStallTurn5m.ts
function validateEntryStallTurn5m(c) {
  const bars = (n, min, max) => Number.isInteger(n) && n % 5 === 0 && n >= min * 5 && n <= max * 5;
  const history = c.historyHours * 12;
  if (c.version !== ENTRY_STALL_TURN_5M_VERSION || typeof c.enabled !== "boolean") throw Error("5\u5206\u949F\u6EDE\u6DA8\u8F6C\u5F31\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u539F\u65B9\u6848");
  if (!Number.isFinite(history) || history < 1 || history > 864 || Math.abs(history - Math.round(history)) > 1e-8 || !bars(c.riseMinutes, 3, 288) || !bars(c.stallMinutes, 2, 48) || !bars(c.turnMinutes, 1, 6) || c.turnMinutes > c.stallMinutes || !Number.isFinite(c.risePct) || c.risePct <= 0 || c.risePct >= 100 || !Number.isFinite(c.maxProgressPct) || c.maxProgressPct < 0 || c.maxProgressPct >= 100 || c.pullback != null && (typeof c.pullback.enabled !== "boolean" || !Number.isFinite(c.pullback.pct) || c.pullback.pct <= 0 || c.pullback.pct >= 100)) throw Error("\u6EDE\u6DA8\u8F6C\u5F31\u53C2\u6570\u65E0\u6548\uFF1A5\u5206\u949F\u7248\u987B\u4F7F\u7528\u5B8C\u6574K\u7EBF\uFF1B\u4E0A\u6DA83\uFF5E288\u6839\u3001\u6EDE\u6DA82\uFF5E48\u6839\u3001\u8F6C\u5F311\uFF5E6\u6839\u4E14\u4E0D\u957F\u4E8E\u6EDE\u6DA8\uFF1B\u5386\u53F25\u5206\u949F\uFF5E72\u5C0F\u65F6\u4E14\u4E3A5\u5206\u949F\u6574\u6570\u500D\uFF1B\u6DA8\u5E45\u548C\u56DE\u8C03\u95E8\u69DB\u5927\u4E8E0\u4E14\u5C0F\u4E8E100%\uFF0C\u63A8\u8FDB\u6BD4\u4F8B0\uFF5E\u5C0F\u4E8E100%");
}
var ENTRY_STALL_TURN_5M_VERSION, PULLBACK_NEW_HIGH_5M_VERSION, defaultEntryStallTurn5m, M, FIVE;
var init_preEntryStallTurn5m = __esm({
  "src/lib/fish/preEntryStallTurn5m.ts"() {
    init_algorithm();
    init_shared();
    init_screeningYield();
    init_timeFormat();
    ENTRY_STALL_TURN_5M_VERSION = "entry-stall-turn-5m-v2";
    PULLBACK_NEW_HIGH_5M_VERSION = "addition-pullback-new-high-5m-v1";
    defaultEntryStallTurn5m = () => ({ version: ENTRY_STALL_TURN_5M_VERSION, enabled: true, historyHours: 6, riseMinutes: 60, risePct: 1, stallMinutes: 15, maxProgressPct: 20, turnMinutes: 10, pullback: { enabled: true, pct: 3 } });
    M = 6e4;
    FIVE = 5 * M;
  }
});

// src/lib/fish/qualityAdditionVeto.ts
function boxBreakVetoIdentity(config) {
  const rule = config.rule, parameters = rule.structure.definition.DBL5_config;
  const stable3 = parameters ? { ...rule, structure: { ...rule.structure, definition: { ...rule.structure.definition, DBL5_config: Object.fromEntries(Object.keys(parameters).sort().map((k) => [k, parameters[k]])) } } } : rule;
  return [config.version, boxStopIdentity(stable3)];
}
function validateAdditionVetoes(vetoes) {
  for (const v of activeAdditionVetoes(vetoes)) {
    if (!ADDITION_VETO_KINDS.includes(v.kind)) throw new Error("\u52A0\u4ED3\u5426\u51B3\u6761\u4EF6\u7C7B\u578B\u65E0\u6548");
    if (v.kind === "indicator") {
      const metric = v.indicator;
      if (metric?.version !== INDICATOR_ENTRY_VETO_VERSION || !metric.snapshot?.definitionKey || !metric.metric || !["<", "<=", ">", ">="].includes(metric.direction) || !Number.isFinite(metric.threshold)) throw Error("\u7B97\u6CD5\u5426\u51B3\u7684\u516C\u5F0F\u3001\u6BD4\u8F83\u65B9\u5F0F\u6216\u9608\u503C\u65E0\u6548");
      continue;
    }
    if (v.kind === "box-break") {
      if (v.historyHours != null || v.boxBreak?.version !== BOX_BREAK_VETO_VERSION || v.boxBreak?.rule?.version !== BOX_BREAK_VERSION) throw Error("\u6301\u4ED3\u671F\u95F4\u7BB1\u4F53\u65AD\u88C2\uFF1A\u7F3A\u5C11\u72EC\u7ACB\u7684\u51BB\u7ED3\u6267\u884C\u7248\u672C\uFF0C\u6216\u8BEF\u7528\u4E86\u5176\u4ED6\u626B\u63CF\u8303\u56F4");
      validateBoxStop(v.boxBreak.rule);
      continue;
    }
    if (v.kind === "guard-distance") {
      if (v.atr == null || !Number.isFinite(v.atr) || v.atr <= 0) throw Error("\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC\uFF1AATR \u500D\u6570\u987B\u4E3A\u5927\u4E8E 0 \u7684\u6709\u9650\u6570\u5B57");
      const config = v.guardDistance;
      const timeframe = config?.parameters?.timeframe;
      if (v.historyHours != null || !config || timeframe !== "5m" && timeframe !== "1h" || config.version !== (timeframe === "1h" ? GUARD_DISTANCE_1H_VETO_VERSION : GUARD_DISTANCE_VETO_VERSION) || config.boxVersion !== DBL5_PROFILES[timeframe].version || ![
        config.parameters.n,
        config.parameters.window_minutes,
        config.parameters.guard_trend_atr,
        config.parameters.guard_range_atr,
        config.parameters.guard_range_closes
      ].every(Number.isFinite)) {
        throw Error("\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC\uFF1A\u7F3A\u5C11\u53EF\u6267\u884C\u7684\u51BB\u7ED3\u7248\u672C\u6216\u53C2\u6570");
      }
      if (dbl5GuardVersion(dbl5Parameters(config.parameters)) !== config.guardVersion) {
        throw Error("\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC\uFF1A\u9632\u5B88\u7EBF\u7248\u672C\u4E0E\u51BB\u7ED3\u53C2\u6570\u4E0D\u4E00\u81F4");
      }
      continue;
    }
    if (isFiveMinuteShapeVeto(v)) {
      validateEntryStallTurn5m({ ...defaultEntryStallTurn5m(), historyHours: v.historyHours, ...v.kind === "stall-turn" ? { riseMinutes: v.riseMinutes, risePct: v.risePct, stallMinutes: v.stallMinutes, maxProgressPct: v.maxProgressPct, turnMinutes: v.turnMinutes, pullback: void 0 } : { pullback: { enabled: true, pct: v.pct } } });
      continue;
    }
    const d = { ...ADDITION_VETO_DEFAULTS[v.kind], ...v }, bad = (x, lo, hi) => x == null || !Number.isFinite(x) || x < lo || x > hi;
    if (v.historyHours != null && (!Number.isFinite(v.historyHours) || v.historyHours < 1 / 12 || v.historyHours > 720)) throw Error("\u5426\u51B3\u5386\u53F2\u56DE\u770B\u987B\u4E3A 5 \u5206\u949F\u81F3 720 \u5C0F\u65F6");
    if (v.kind === "double-drop") {
      if (v.atr == null && v.pct == null) throw Error("\u4E8C\u6B21\u6025\u8DCC\uFF1A\u8BF7\u586B\u5199 ATR \u500D\u6570\u6216\u56DE\u843D\u767E\u5206\u6BD4");
      if (v.atr != null && (bad(v.atr, 0, 50) || v.atr === 0)) throw Error("\u4E8C\u6B21\u6025\u8DCC\uFF1AATR \u500D\u6570\u987B\u5927\u4E8E 0 \u4E14\u4E0D\u8D85\u8FC7 50");
      if (v.pct != null && (bad(v.pct, 0, 100) || v.pct === 0)) throw Error("\u4E8C\u6B21\u6025\u8DCC\uFF1A\u56DE\u843D\u767E\u5206\u6BD4\u987B\u5927\u4E8E 0 \u4E14\u4E0D\u8D85\u8FC7 100%");
      if (v.join != null && !["and", "or"].includes(v.join)) throw Error("\u4E8C\u6B21\u6025\u8DCC\uFF1A\u7EC4\u5408\u65B9\u5F0F\u65E0\u6548");
      continue;
    }
    if ((v.kind === "upper-wick" || v.kind === "lower-wick" || v.kind === "lower-spike") && (bad(d.lookbackBars, 1, 288) || !Number.isInteger(d.lookbackBars))) throw new Error(`${ADDITION_VETO_LABELS[v.kind]}\uFF1A\u56DE\u770B\u6839\u6570\u987B\u4E3A 1\u2013288 \u7684\u6574\u6570`);
    if (v.kind === "fast-drop") {
      if (!d.windows?.length) throw new Error("\u6301\u4ED3\u671F\u95F4\u6025\u8DCC\uFF1A\u81F3\u5C11\u586B\u4E00\u7EC4\u300CN \u5206\u949F\u5185\u8DCC\u5E45\u300D");
      for (const w of d.windows) if (bad(w.minutes, 1, 240) || !Number.isInteger(w.minutes) || bad(w.pct, 0, 100)) throw new Error("\u6301\u4ED3\u671F\u95F4\u6025\u8DCC\uFF1A\u5206\u949F\u987B\u4E3A 1\u2013240 \u7684\u6574\u6570\uFF0C\u8DCC\u5E45\u987B\u4E3A 0\u2013100%");
      continue;
    }
    if (v.kind === "pullback") {
      const d2 = pullbackParams(v);
      if (d2.atr == null && d2.pct == null) throw new Error("\u51B2\u9AD8\u56DE\u843D\uFF1AATR \u500D\u6570\u4E0E\u56DE\u843D\u767E\u5206\u6BD4\u81F3\u5C11\u586B\u4E00\u9879");
      if (d2.atr != null && bad(d2.atr, 0, 50)) throw new Error("\u51B2\u9AD8\u56DE\u843D\uFF1AATR \u500D\u6570\u987B\u4E3A 0\u201350 \u7684\u6570\u5B57");
      if (d2.pct != null && bad(d2.pct, 0, 100)) throw new Error("\u51B2\u9AD8\u56DE\u843D\uFF1A\u56DE\u843D\u767E\u5206\u6BD4\u987B\u4E3A 0\u2013100%");
      if (d2.join != null && d2.join !== "and" && d2.join !== "or") throw new Error("\u51B2\u9AD8\u56DE\u843D\uFF1A\u7EC4\u5408\u65B9\u5F0F\u65E0\u6548");
      continue;
    }
    if (v.kind !== "volatility" && bad(d.atr, 0, 50)) throw new Error(`${ADDITION_VETO_LABELS[v.kind]}\uFF1AATR \u500D\u6570\u987B\u4E3A 0\u201350 \u7684\u6570\u5B57`);
    if (v.kind === "upper-wick" && bad(d.ratio, 0, 100)) throw new Error("\u957F\u4E0A\u5F71\u7EBF\uFF1A\u4E0A\u5F71\u5360\u6BD4\u987B\u4E3A 0\u2013100%");
    if (v.kind === "lower-wick" && bad(d.ratio, 0, 100)) throw new Error("\u957F\u4E0B\u5F71\u7EBF\uFF1A\u4E0B\u5F71\u5360\u6BD4\u987B\u4E3A 0\u2013100%");
    if (v.kind === "lower-spike" && bad(d.pct, 0, 100)) throw new Error("\u5411\u4E0B\u5927\u63D2\u9488\uFF1A\u8DCC\u5E45\u987B\u4E3A 0\u2013100%");
    if (v.kind === "volatility" && (bad(d.ratio, 0, 50) || bad(d.er, 0, 1))) throw new Error("\u9AD8\u9707\u8361\uFF1AATR \u500D\u6570\u987B\u4E3A 0\u201350\uFF0C\u6548\u7387\u6BD4\u987B\u4E3A 0\u20131");
  }
}
var LOWER_WICK_VETO_VERSION, VETO_HISTORY_VERSION, INDICATOR_ENTRY_VETO_VERSION, BOX_BREAK_VETO_VERSION, GUARD_DISTANCE_VETO_VERSION, GUARD_DISTANCE_1H_VETO_VERSION, isFiveMinuteShapeVeto, ADDITION_VETO_DEFAULTS, ADDITION_VETO_KINDS, ADDITION_VETO_LABELS, activeAdditionVetoes, LEGACY_PULLBACK_ATR, pullbackParams, additionVetoIdentity;
var init_qualityAdditionVeto = __esm({
  "src/lib/fish/qualityAdditionVeto.ts"() {
    init_dbl5m();
    init_qualityBoxStop();
    init_dbl5mMarketRules();
    init_qualityDoubleDrop();
    init_preEntryStallTurn5m();
    LOWER_WICK_VETO_VERSION = "addition-lower-wick-v1";
    VETO_HISTORY_VERSION = "addition-veto-history-v1";
    INDICATOR_ENTRY_VETO_VERSION = "closed-indicator-entry-veto-v1";
    BOX_BREAK_VETO_VERSION = "addition-holding-box-break-v1";
    GUARD_DISTANCE_VETO_VERSION = "guard-distance-veto-v1";
    GUARD_DISTANCE_1H_VETO_VERSION = "guard-distance-1h-v1";
    isFiveMinuteShapeVeto = (v) => v.kind === "stall-turn" || v.kind === "pullback-new-high";
    ADDITION_VETO_DEFAULTS = {
      "upper-wick": { kind: "upper-wick", enabled: false, lookbackBars: 12, atr: 1.5, ratio: 60 },
      "lower-wick": { kind: "lower-wick", enabled: false, lookbackBars: 12, atr: 1.5, ratio: 60 },
      "lower-spike": { kind: "lower-spike", enabled: false, lookbackBars: 12, atr: 2, pct: 3 },
      volatility: { kind: "volatility", enabled: false, ratio: 1.8, er: 0.25 },
      // 【用户要求】2026-11-03 默认值按「组合算法1」44 场回放定：回落 ≥2.5 ATR 且 ≥4% 只改善不伤大单（单用 2.5 ATR 会把 SAPIEN +3936 砍到 +533）；可修改
      pullback: { kind: "pullback", enabled: false, atr: 2.5, pct: 4, join: "and" },
      // 【用户要求】2026-11-03 另设一条「冲高回落 · 仅 ATR」：回放里胜率明显更高（但会砍掉 SAPIEN 这类大单），与上一条各自勾选
      "pullback-atr": { kind: "pullback-atr", enabled: false, atr: 2.5 },
      // 【用户要求】2026-11-02 持仓期间曾出现任意 1 分钟跌超 5%、5 分钟超 7%、10 分钟超 10% 等，就不再加仓（PENGU 第 3 次加仓前那根长红线）
      "fast-drop": { kind: "fast-drop", enabled: false, windows: [{ minutes: 1, pct: 5 }, { minutes: 5, pct: 7 }, { minutes: 10, pct: 10 }] },
      "double-drop": { kind: "double-drop", enabled: false, atr: 2.5, pct: 4, join: "and" },
      "stall-turn": { kind: "stall-turn", enabled: false, historyHours: 6, riseMinutes: 60, risePct: 1, stallMinutes: 15, maxProgressPct: 20, turnMinutes: 10 },
      "pullback-new-high": { kind: "pullback-new-high", enabled: false, historyHours: 6, pct: 3 },
      "guard-distance": { kind: "guard-distance", enabled: false, atr: 3 },
      "box-break": { kind: "box-break", enabled: false },
      indicator: { kind: "indicator", enabled: false }
    };
    ADDITION_VETO_KINDS = Object.keys(ADDITION_VETO_DEFAULTS);
    ADDITION_VETO_LABELS = { indicator: "\u7B97\u6CD5\u5426\u51B3", "upper-wick": "\u957F\u4E0A\u5F71\u7EBF", "lower-wick": "\u957F\u4E0B\u5F71\u7EBF", "lower-spike": "\u5411\u4E0B\u5927\u63D2\u9488", volatility: "\u9AD8\u9707\u8361", pullback: "\u51B2\u9AD8\u56DE\u843D", "pullback-atr": "\u51B2\u9AD8\u56DE\u843D\xB7\u4EC5ATR", "fast-drop": "\u6301\u4ED3\u671F\u95F4\u6025\u8DCC", "double-drop": "\u4E8C\u6B21\u6025\u8DCC\u672A\u6536\u590D", "stall-turn": "\u6EDE\u6DA8\u8F6C\u5F31\uFF085\u5206\u949F\uFF09", "pullback-new-high": "\u731B\u70C8\u56DE\u8C03\u672A\u521B\u65B0\u9AD8\uFF085\u5206\u949F\uFF09", "guard-distance": "\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC", "box-break": "\u6301\u4ED3\u671F\u95F4\u7BB1\u4F53\u65AD\u88C2" };
    activeAdditionVetoes = (vetoes) => (vetoes ?? []).filter((v) => v.enabled);
    LEGACY_PULLBACK_ATR = 2;
    pullbackParams = (raw) => raw.atr == null && raw.pct == null ? { ...raw, atr: LEGACY_PULLBACK_ATR } : { ...raw, join: raw.atr != null && raw.pct != null ? raw.join ?? "and" : void 0 };
    additionVetoIdentity = (vetoes) => activeAdditionVetoes(vetoes).map((v) => {
      if (v.kind === "indicator" && v.indicator) {
        const { version, metric, direction, threshold, snapshot } = v.indicator;
        return [v.kind, version, snapshot.featureId, snapshot.definitionKey, snapshot.interval, metric, direction, threshold];
      }
      if (v.kind === "box-break") return [v.kind, ...v.boxBreak ? boxBreakVetoIdentity(v.boxBreak) : []];
      if (v.kind === "guard-distance") return [v.kind, v.guardDistance?.version, v.guardDistance?.boxVersion, v.guardDistance?.guardVersion, DBL5_MARKET_RULE_VERSION, v.atr, v.guardDistance && dbl5ConfigHash(v.guardDistance.parameters)];
      if (v.kind === "stall-turn") return [v.kind, ENTRY_STALL_TURN_5M_VERSION, v.historyHours, v.riseMinutes, v.risePct, v.stallMinutes, v.maxProgressPct, v.turnMinutes];
      if (v.kind === "pullback-new-high") return [v.kind, PULLBACK_NEW_HIGH_5M_VERSION, v.historyHours, v.pct];
      if (v.historyHours != null) {
        const { historyHours, ...original } = v;
        return [VETO_HISTORY_VERSION, historyHours, additionVetoIdentity([original])[0]];
      }
      if (v.kind === "lower-wick") {
        const d2 = { ...ADDITION_VETO_DEFAULTS["lower-wick"], ...v };
        return [v.kind, LOWER_WICK_VETO_VERSION, d2.lookbackBars, d2.atr, d2.ratio];
      }
      if (v.kind === "double-drop") return [v.kind, DOUBLE_DROP_VERSION, v.atr ?? null, v.pct ?? null, v.join ?? "and"];
      const d = v.kind === "pullback" ? pullbackParams(v) : { ...ADDITION_VETO_DEFAULTS[v.kind], ...v };
      return [d.kind, d.lookbackBars ?? null, d.atr ?? null, d.ratio ?? null, d.pct ?? null, d.er ?? null, ...d.kind === "fast-drop" ? [(d.windows ?? []).map((w) => [w.minutes, w.pct])] : [], ...d.kind === "pullback" && d.pct != null ? ["pullback-pct-v1", d.join ?? null] : [], ...(d.kind === "pullback" || d.kind === "pullback-atr") && v.sticky ? ["pullback-sticky-v1"] : []];
    }).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
  }
});

// src/lib/fish/qualityAddition.ts
function additionExitForRound(config, round) {
  return config.roundExits?.overrides[round] ?? config;
}
function additionExitIdentity(exit) {
  const { breakevenFloor: floor, supportReduction: cut, geometricLock: lock } = exit;
  return [
    exit.kStopVersion ?? null,
    floor?.enabled ? [floor.version ?? "breakeven-floor-v1", floor.atr] : null,
    cut?.enabled ? [cut.version ?? 1, cut.minDropAtr, cut.maxPct, cut.exitAfterDrops ?? null] : null,
    lock?.enabled ? [lock.multiple, lock.pct] : null
  ];
}
function qualityAdditionConditions(rule) {
  return (rule?.conditions?.length ? rule.conditions : rule?.condition ? [rule.condition] : []).filter((f) => f.enabled !== false);
}
var ADDITION_POSITION_RACE_VERSION, ADDITION_ROUND_EXITS_VERSION, ADDITION_POSITION_FLOOR_INTRABAR_VERSION, ADDITION_PROFIT_FLOOR_VERSION, activeDetectorPrerequisite, qualityAdditionAtrSettings, atrIdentity, conditionIdentity, qualityAdditionPrerequisites, additionIncreaseIdentity, prerequisiteIdentity, timingIdentity, additionMirrorIdentity, additionIdentity;
var init_qualityAddition = __esm({
  "src/lib/fish/qualityAddition.ts"() {
    init_qualityClassifiedImpulsePosition();
    init_qualityAdditionVeto();
    init_impulse5m();
    init_dbl5GuardPlus();
    init_qualityHoldingLedger();
    init_qualityAdditionStructure();
    ADDITION_POSITION_RACE_VERSION = "addition-position-race-v1";
    ADDITION_ROUND_EXITS_VERSION = "addition-round-exits-v1";
    ADDITION_POSITION_FLOOR_INTRABAR_VERSION = "breakeven-floor-v3";
    ADDITION_PROFIT_FLOOR_VERSION = "breakeven-floor-v4";
    activeDetectorPrerequisite = (r) => r?.source !== "custom" && r?.detectorPrerequisite?.enabled ? r.detectorPrerequisite : void 0;
    qualityAdditionAtrSettings = (rule) => ({ entryBufferAtr: rule.entryBufferAtr ?? 2, supportOffsetAtr: rule.supportOffsetAtr ?? 1.5 });
    atrIdentity = (rule) => qualityAdditionAtrSettings(rule).supportOffsetAtr;
    conditionIdentity = (f) => [f.metric, f.direction, f.threshold, f.snapshot.definitionKey, f.snapshot.interval];
    qualityAdditionPrerequisites = (rule) => rule?.source === "custom" ? qualityAdditionConditions(rule).slice(1) : (rule?.prerequisites ?? []).filter((f) => f.enabled !== false);
    additionIncreaseIdentity = (rule) => [rule.version, rule.metrics.map((f) => [f.metric, f.snapshot.featureId, f.snapshot.definitionKey, f.snapshot.interval])];
    prerequisiteIdentity = (rule) => [
      ...rule.source !== "custom" && qualityAdditionPrerequisites(rule).length ? [["timing-prerequisites-v1", qualityAdditionPrerequisites(rule).map(conditionIdentity)]] : [],
      ...activeDetectorPrerequisite(rule) ? [["detector-prerequisite-v1", activeDetectorPrerequisite(rule).stricterPct, activeDetectorPrerequisite(rule).featureId ?? "all"]] : [],
      ...rule.indicatorIncrease ? [additionIncreaseIdentity(rule.indicatorIncrease)] : []
    ];
    timingIdentity = (r) => {
      const base = r.source === "structure" ? r.structure && structureAdditionIdentity(r.structure) : r.source === "detector" ? r.stricterPct : qualityAdditionConditions(r).map(conditionIdentity);
      const extra = prerequisiteIdentity(r);
      return extra.length ? [base, ...extra] : base;
    };
    additionMirrorIdentity = (addition, mirror) => addition?.positionVersion !== HOLDING_LEDGER_ADDITION_VERSION && addition?.enabled && addition.quantityMode && mirror?.enabled && mirror.sellPct !== 50 ? [["addition-after-partial-mirror-v1"]] : [];
    additionIdentity = (rule) => !rule?.enabled ? [] : [
      rule.positionVersion === HOLDING_LEDGER_ADDITION_VERSION ? HOLDING_LEDGER_ADDITION_VERSION : rule.quantityMode === "calculator" ? "holding-add-after-half-2atr-balance-v3" : rule.quantityMode ? "holding-add-once-after-half-quantity-v2" : "holding-add-once-v1",
      rule.source,
      rule.source === "structure" ? rule.structure && structureAdditionIdentity(rule.structure) : rule.source === "detector" ? rule.stricterPct : qualityAdditionConditions(rule)[0] && conditionIdentity(qualityAdditionConditions(rule)[0]),
      rule.quantityMode ?? rule.amountMode,
      ...rule.quantityMode === "calculator" ? [rule.repeat !== false] : [],
      rule.quantityMode ? rule.quantityMode === "fixed" ? rule.quantity : null : rule.amountMode === "fixed" ? rule.amountUsdt : null,
      ...rule.source === "custom" && qualityAdditionConditions(rule).length > 1 ? [["all-indicators-v1", ...qualityAdditionConditions(rule).slice(1).map(conditionIdentity)]] : [],
      ...prerequisiteIdentity(rule),
      ...[rule, ...rule.rounds ?? [], ...rule.alternativeRounds ?? []].some((r) => r.impulsePosition) ? [[ADDITION_POSITION_RACE_VERSION, rule.impulsePosition ?? null, rule.rounds?.map((r) => r.impulsePosition ?? null) ?? null, rule.alternativeRounds?.map((r) => r.impulsePosition ?? null) ?? null]] : [],
      ...[rule, ...rule.rounds ?? [], ...rule.alternativeRounds ?? []].some((r) => r.impulse1115Position) ? [[IMPULSE_1115_POSITION_VERSION, rule.impulse1115Position ?? null, rule.rounds?.map((r) => r.impulse1115Position ?? null) ?? null, rule.alternativeRounds?.map((r) => r.impulse1115Position ?? null) ?? null]] : [],
      ...[rule, ...rule.rounds ?? [], ...rule.alternativeRounds ?? []].some((r) => r.classifiedImpulsePositions?.length) ? [[CLASSIFIED_IMPULSE_POSITION_VERSION, classifiedImpulsePositionsIdentity(rule.classifiedImpulsePositions), rule.rounds?.map((r) => classifiedImpulsePositionsIdentity(r.classifiedImpulsePositions)) ?? null, rule.alternativeRounds?.map((r) => classifiedImpulsePositionsIdentity(r.classifiedImpulsePositions)) ?? null]] : [],
      ...rule.minGainPct != null ? [["closed-gain-gate-v1", rule.minGainPct, rule.quantityMode === "calculator" ? "cost-line" : "real-average"]] : [],
      ...rule.maxRounds != null || rule.rounds?.length ? [["independent-addition-rounds-v1", rule.maxRounds ?? null, rule.rounds?.map((r) => [r.source, timingIdentity(r), r.minGainPct ?? null]) ?? null]] : [],
      // 入场距离删除后结果口径变了：所有平衡公式加仓都带新标记，旧口径（含入场距离门槛）的结果不会被当成新结果
      ...rule.quantityMode === "calculator" ? [["addition-k-atr-no-entry-distance-v2", atrIdentity(rule), rule.rounds?.map(atrIdentity) ?? null]] : [],
      // 2026-11-04 恢复入场距离与「相对持仓均价」涨幅门槛：只有设了的方案身份才变，旧结果照旧复用
      ...[rule, ...rule.rounds ?? []].some((r) => r.entryDistanceAtr != null) ? [["entry-distance-v1", [rule, ...rule.rounds ?? []].map((r) => r.entryDistanceAtr ?? null)]] : [],
      ...[rule, ...rule.rounds ?? []].some((r) => r.gainBasis === "average") ? [["gain-basis-average-v1", [rule, ...rule.rounds ?? []].map((r) => r.gainBasis ?? null)]] : [],
      ...rule.geometricLock?.enabled ? [["geometric-lock-v1", rule.geometricLock.multiple, rule.geometricLock.pct]] : [],
      ...rule.roundExits ? [[ADDITION_ROUND_EXITS_VERSION, Object.entries(rule.roundExits.overrides).map(([round, exit]) => [Number(round), additionExitIdentity(exit)])]] : [],
      ...rule.atrRejectExit ? [[rule.atrRejectExit]] : [],
      ...rule.marginRejectExit ? [[rule.marginRejectExit]] : [],
      ...rule.kStopVersion ? [[rule.kStopVersion]] : [],
      ...rule.breakevenFloor?.enabled ? [[rule.breakevenFloor.version ?? "breakeven-floor-v1", rule.breakevenFloor.atr]] : [],
      // v2（2026-11-03）：减仓后再加仓时，减仓所得不再当成额外可用利润重复计入（v1 会多加）；开了减仓的方案须重算
      ...rule.supportReduction?.enabled ? [[rule.supportReduction.version === 2 ? "support-drop-reduction-v2" : "support-drop-reduction-v1", rule.supportReduction.minDropAtr, rule.supportReduction.maxPct, ...rule.supportReduction.exitAfterDrops != null ? [["exit-after-support-drops-v1", rule.supportReduction.exitAfterDrops]] : []]] : [],
      // 2026-11-02 加仓否决：只有启用了否决的方案身份才变，旧结果照旧复用
      ...[rule, ...rule.rounds ?? []].some((r) => activeAdditionVetoes(r.entryVetoes).length) ? [["addition-entry-vetoes-v1", additionVetoIdentity(rule.entryVetoes), rule.rounds?.map((r) => additionVetoIdentity(r.entryVetoes)) ?? null]] : [],
      // 2026-11-05 每轮分流：进攻备选的全部参数进身份；没有备选的方案身份不变
      ...rule.alternativeRounds?.length ? [["addition-round-race-v1", rule.alternativeRounds.map((r) => [r.source, timingIdentity(r), r.minGainPct ?? null, atrIdentity(r), r.entryDistanceAtr ?? null, r.gainBasis ?? null, additionVetoIdentity(r.entryVetoes)])]] : [],
      // 2026-11-06 结构开局：进攻备选从第 n 次起才参与；n＝1 或没有备选时身份不变
      ...rule.alternativeRounds?.length && (rule.attackFromRound ?? 1) > 1 ? [["addition-round-race-from-v1", rule.attackFromRound]] : []
    ];
  }
});

// src/lib/fish/preEntryConditions.ts
function validatePreEntryConditions(value) {
  if (!value) return;
  if (value.version !== PRE_ENTRY_CONDITIONS_VERSION) throw Error("\u52A8\u6001\u7B5B\u9009\u6761\u4EF6\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u65E7\u65B9\u6848");
  if (value.entryVetoes.some((v) => v.enabled && v.kind === "double-drop")) throw Error("\u4E8C\u6B21\u6025\u8DCC\u76EE\u524D\u7528\u4E8E\u65B0\u7248\u52A0\u4ED3\u5426\u51B3\uFF1B\u52A8\u6001\u7B5B\u9009 v4 \u4E0D\u652F\u6301\uFF0C\u8BF7\u4FDD\u7559\u539F\u8F6E\u6B21");
  validateAdditionVetoes(value.entryVetoes);
  for (const veto of activeHoldingVetoes([...value.sellVetoes, ...value.hardVetoes])) {
    if (veto.activation || veto.mirrorStage) throw Error("\u955C\u50CF\u51CF\u4ED3\u540E\u542F\u52A8\u53EA\u9002\u7528\u4E8E\u5B9E\u9645\u6301\u4ED3\uFF0C\u4E0D\u80FD\u7528\u4E8E\u4E70\u524D\u7B5B\u9009");
    if (veto.boxStop && isBoxSecondBreakExitOnly(veto.boxStop)) throw Error("\u6301\u4ED3\u671F\u95F4\u4E8C\u6B21\u65AD\u88C2\u7EC8\u6B62\u53EA\u9002\u7528\u4E8E\u5B9E\u9645\u6301\u4ED3\uFF0C\u4E0D\u80FD\u7528\u4E8E\u4E70\u524D\u7B5B\u9009");
    if (veto.boxStop && isBoxSecondBreak(veto.boxStop)) throw Error("\u9996\u6B21\u65AD\u88C2\u505C\u52A0\u4ED3\u3001\u4E8C\u6B21\u65AD\u88C2\u7EC8\u6B62\u53EA\u9002\u7528\u4E8E\u5B9E\u9645\u6301\u4ED3\uFF0C\u4E0D\u80FD\u7528\u4E8E\u4E70\u524D\u7B5B\u9009");
    if (preEntryPositionOnly(veto.kind)) throw Error("\u4E70\u524D\u7B5B\u9009\u6CA1\u6709\u5B9E\u9645\u6301\u4ED3\uFF0C\u4E0D\u80FD\u542F\u7528\u52A0\u4ED3\u4ED3\u4F4D\u3001\u76C8\u4E8F\u6BD4\u6216\u955C\u50CF\u9650\u65F6\u7EC8\u6B62\u6761\u4EF6");
    validateHoldingVeto(veto);
  }
}
function freezePreEntryConditions(value) {
  validatePreEntryConditions(value);
  const freeze = (v) => v.boxStop ? { ...v, boxStop: freezeBoxStop(v.boxStop) } : v;
  return { ...structuredClone(value), sellVetoes: value.sellVetoes.map(freeze), hardVetoes: value.hardVetoes.map(freeze) };
}
function preEntryConditionsVersion(plan, legacyBoxBreakOrder = false) {
  const value = plan.preEntryConditions;
  validatePreEntryConditions(value);
  const boxes = preEntryVetoes(value).filter((v) => v.boxStop).map((v) => [v.boxStop.version, structureVersions(v.boxStop.structure)]);
  const boxBreak = value?.entryVetoes.some((v) => v.kind === "box-break") && !legacyBoxBreakOrder;
  const channels = preEntryVetoes(value).some((v) => !!v.boxStop?.channels) && !legacyBoxBreakOrder;
  const reference = preEntryVetoes(value).some((v) => !!v.boxStop?.reference) && !legacyBoxBreakOrder;
  const payload = [value, plan.buyFilters, boxes];
  const serialized = value?.entryVetoes.some((v) => v.kind === "indicator") || boxBreak || reference || channels ? JSON.stringify(payload, (_k, item) => item && typeof item === "object" && !Array.isArray(item) ? Object.fromEntries(Object.keys(item).sort().map((key) => [key, item[key]])) : item) : JSON.stringify(payload);
  return PRE_ENTRY_CONDITIONS_VERSION + (channels ? " \xB7 holding-box-stop-independent-channels-v1" : boxBreak ? " \xB7 " + BOX_BREAK_VETO_VERSION : reference ? " \xB7 " + BOX_STOP_REFERENCE_VERSION : "") + " \xB7 \u53C2\u6570 #" + shortFishHash(serialized);
}
var PRE_ENTRY_CONDITIONS_VERSION, preEntryPositionOnly, preEntryVetoes;
var init_preEntryConditions = __esm({
  "src/lib/fish/preEntryConditions.ts"() {
    init_algorithm();
    init_qualityAdditionVeto();
    init_qualityVeto();
    init_qualityBoxStop();
    init_boxAlgorithmVersions();
    init_qualityBoxReference();
    PRE_ENTRY_CONDITIONS_VERSION = "pre-entry-conditions-v4";
    preEntryPositionOnly = (kind) => kind === "addition-geometric-profit" || kind === "payoff-ratio" || kind === "mirror-deadline" || kind === "mirror-loss-review";
    preEntryVetoes = (value) => value ? ["sellVetoes", "hardVetoes"].flatMap((section) => activeHoldingVetoes(value[section]).map((v) => ({ ...v, id: `${section}:${v.id}` }))) : [];
  }
});

// src/lib/fish/preEntryStallTurn.ts
function validateEntryStallTurn(c) {
  const integer = (n, min, max) => Number.isInteger(n) && n >= min && n <= max;
  if (c.version !== ENTRY_STALL_TURN_VERSION || typeof c.enabled !== "boolean") throw Error("\u4E0A\u6DA8\u540E\u6EDE\u6DA8\u8F6C\u5F31\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u539F\u65B9\u6848");
  if (!Number.isFinite(c.historyHours) || c.historyHours < 1 / 12 || c.historyHours > 72 || !integer(c.riseMinutes, 5, 1440) || !integer(c.stallMinutes, 2, 240) || !integer(c.turnMinutes, 2, 30) || c.turnMinutes > c.stallMinutes || !Number.isFinite(c.risePct) || c.risePct <= 0 || c.risePct >= 100 || !Number.isFinite(c.maxProgressPct) || c.maxProgressPct < 0 || c.maxProgressPct >= 100 || c.pullback != null && (typeof c.pullback.enabled !== "boolean" || !Number.isFinite(c.pullback.pct) || c.pullback.pct <= 0 || c.pullback.pct >= 100)) {
    throw Error("\u6EDE\u6DA8\u8F6C\u5F31\u53C2\u6570\u65E0\u6548\uFF1A\u5386\u53F2 5 \u5206\u949F\uFF5E72 \u5C0F\u65F6\uFF1B\u4E0A\u6DA8 5\uFF5E1440 \u5206\u949F\u3001\u6DA8\u5E45\u5927\u4E8E 0\uFF1B\u6EDE\u6DA8 2\uFF5E240 \u5206\u949F\uFF1B\u8F6C\u5F31 2\uFF5E30 \u5206\u949F\u4E14\u4E0D\u957F\u4E8E\u6EDE\u6DA8\uFF1B\u63A8\u8FDB\u901F\u5EA6\u6BD4\u4F8B 0\uFF5E\u5C0F\u4E8E100%\uFF1B\u731B\u70C8\u56DE\u8C03\u95E8\u69DB\u5927\u4E8E0\u4E14\u5C0F\u4E8E100%");
  }
}
var ENTRY_STALL_TURN_VERSION;
var init_preEntryStallTurn = __esm({
  "src/lib/fish/preEntryStallTurn.ts"() {
    init_algorithm();
    init_shared();
    init_screeningYield();
    init_timeFormat();
    ENTRY_STALL_TURN_VERSION = "entry-stall-turn-v1";
  }
});

// src/lib/fish/preEntryStallTurnRule.ts
function validateEntryStallTurnRule(c) {
  if (c.version === ENTRY_STALL_TURN_5M_VERSION) validateEntryStallTurn5m(c);
  else validateEntryStallTurn(c);
}
var init_preEntryStallTurnRule = __esm({
  "src/lib/fish/preEntryStallTurnRule.ts"() {
    init_preEntryStallTurn();
    init_preEntryStallTurn5m();
  }
});

// src/lib/fish/preEntryThreeStage.ts
function validateEntryCondition(c) {
  if (c.range) validateFishRange(c.range);
  if (!c.id || !c.metric || !c.snapshot?.definitionKey || !c.label.trim() || !Number.isFinite(c.threshold) || !["<", ">", "<=", ">="].includes(c.direction) || !["intrabar", "closed"].includes(c.timing)) throw Error("\u5E02\u573A\u6761\u4EF6\u987B\u9009\u62E9\u6307\u6807\u3001\u65B9\u5411\u3001\u6709\u9650\u95E8\u69DB\u53CA\u786E\u8BA4\u65B9\u5F0F");
}
function validatePreEntryThreeStage(c) {
  if (!c || !isPreEntryThreeStageVersion(c.version) || c.guard?.version !== PRE_ENTRY_GUARD_EVENT_VERSION) throw Error("\u4E09\u9636\u7B5B\u9009\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u539F\u65B9\u6848");
  const retry = c.version === PRE_ENTRY_RETRY_VERSION || usesSignalTimeGate(c.version);
  if (usesOptionalStages(c.version)) {
    if (!c.steps || [c.steps.required, c.steps.admission, c.steps.exclusion].some((enabled) => typeof enabled !== "boolean")) {
      throw Error("\u4E09\u6B65\u7B5B\u9009\u5F00\u5173\u4E0D\u5B8C\u6574");
    }
  } else if (c.steps !== void 0) throw Error("\u4E09\u6B65\u72EC\u7ACB\u5F00\u5173\u987B\u53E6\u5B58\u4E3A\u65B0\u65B9\u6848");
  if (usesTrackedGate(c.version)) {
    const paths = c.requiredPaths;
    if (!paths || typeof paths.static !== "boolean" || typeof paths.tracking !== "boolean" || c.steps?.required !== false && !paths.static && !paths.tracking) throw Error("\u8BF7\u81F3\u5C11\u9009\u62E9\u4E00\u79CD\u5FC5\u8981\u6761\u4EF6\u8DEF\u5F84");
  } else if (c.requiredPaths) throw Error("\u52A8\u6001\u95E8\u69DB\u987B\u53E6\u5B58\u4E3A\u65B0\u65B9\u6848");
  if (c.observationBasis !== (retry ? "retry-origin-v2" : "scan-origin-v1")) throw Error("\u4E09\u9636\u7B5B\u9009\u7248\u672C\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4FDD\u7559\u539F\u65B9\u6848");
  const ids = /* @__PURE__ */ new Set();
  const unique = (id2) => {
    if (!id2 || ids.has(id2)) throw Error("\u4E09\u9636\u6761\u4EF6\u7F16\u53F7\u91CD\u590D");
    ids.add(id2);
  };
  if (c.stallTurn) {
    if (c.version === PRE_ENTRY_THREE_STAGE_V5) throw Error("\u65E7 v5 \u4FDD\u6301\u539F\u6837\uFF0C\u6EDE\u6DA8\u8F6C\u5F31\u987B\u5728\u65B0\u65B9\u6848\u4E2D\u542F\u7528");
    validateEntryStallTurnRule(c.stallTurn);
    unique(c.stallTurn.version);
  }
  if (retry) {
    if (!c.admission || typeof c.admission.guardEnabled !== "boolean" || !Array.isArray(c.admission.algorithms) || c.steps?.admission !== false && !c.admission.guardEnabled && !c.admission.algorithms.some((f) => f.enabled)) throw Error("\u81F3\u5C11\u542F\u7528\u4E00\u6761\u5E76\u5217\u51C6\u5165\u7B97\u6CD5");
    c.admission.algorithms.forEach((f) => {
      unique(f.id);
      validateEntryCondition(f);
    });
    const combination = c.admission.combination;
    if (combination !== void 0 && (combination?.version !== ENTRY_ADMISSION_PRIORITY_VERSION || !["all", "any"].includes(combination.join) || !Number.isInteger(combination.guardIndex) || combination.guardIndex < 0 || combination.guardIndex > c.admission.algorithms.length)) throw Error("\u4E8B\u4EF6\u51C6\u5165\u7EC4\u5408\u7248\u672C\u6216\u4F18\u5148\u987A\u5E8F\u65E0\u6548");
    if (c.longDrawdown?.enabled) {
      unique("long-drawdown-v1");
      const d = c.longDrawdown;
      if (!Number.isFinite(d.hours) || d.hours < 1 / 60 || d.hours > 8784 || !Number.isFinite(d.pct) || d.pct <= 0 || d.pct >= 100 || !["current", "maximum"].includes(d.mode)) throw Error("\u957F\u5468\u671F\u56DE\u64A4\u987B\u586B\u5199\u81F3\u5C11 1 \u5206\u949F\u7684\u6709\u6548\u56DE\u770B\u65F6\u957F\u548C 0\uFF5E100% \u4E4B\u95F4\u7684\u56DE\u64A4\u9608\u503C");
    }
  } else if (c.admission !== void 0 || c.longDrawdown !== void 0) throw Error("\u65B0\u51C6\u5165\u4E0E\u56DE\u64A4\u6761\u4EF6\u987B\u53E6\u5B58\u4E3A v7 \u65B0\u65B9\u6848");
  c.required.forEach((f) => {
    unique(f.id);
    validateEntryCondition(f);
  });
  c.detectors?.forEach((d) => {
    unique(d.id);
    if (!Number.isFinite(d.stricterPct) || d.stricterPct < 0 || !["all", "any"].includes(d.match)) throw Error("\u539F\u63A2\u6D4B\u95E8\u69DB\u63D0\u9AD8\u5E45\u5EA6\u987B\u4E3A\u975E\u8D1F\u6709\u9650\u6570");
  });
  validateAdditionVetoes(c.additionVetoes);
  const checkExpression = (e, depth = 0) => {
    if (depth > 20) throw Error("\u5356\u51FA\u7EC4\u5408\u5C42\u7EA7\u8FC7\u6DF1");
    if ("condition" in e) {
      unique(e.condition.id);
      validateEntryCondition(e.condition);
      return;
    }
    if (!["all", "any"].includes(e.join) || !e.children.length) throw Error("\u5356\u51FA\u89C4\u5219\u7684\u4E14\uFF0F\u6216\u7EC4\u5408\u4E0D\u80FD\u4E3A\u7A7A");
    e.children.forEach((child) => checkExpression(child, depth + 1));
  };
  c.sellRules.forEach((r) => {
    unique(r.id);
    if (!r.enabled) return;
    if (!r.label.trim() || !Number.isInteger(r.confirmation.samples) || r.confirmation.samples < 1 || r.confirmation.samples > 100 || !Number.isInteger(r.confirmation.minutes) || r.confirmation.minutes < 1 || r.confirmation.minutes > 10080) throw Error("\u5356\u51FA\u786E\u8BA4\u987B\u8BBE\u7F6E 1\uFF5E100 \u6B21\u53CA\u6709\u6548\u7684\u5206\u949F\u5468\u671F");
    checkExpression(r.expression);
    if (!expressionConditions(r.expression).some((f) => f.enabled)) throw Error("\u5B8C\u6574\u5356\u51FA\u89C4\u5219\u81F3\u5C11\u542F\u7528\u4E00\u9879\u6761\u4EF6");
  });
  c.hardVetoes.forEach((v) => {
    unique(v.id);
    if (v.enabled) {
      if (v.activation || v.mirrorStage) throw Error("\u955C\u50CF\u51CF\u4ED3\u540E\u542F\u52A8\u53EA\u9002\u7528\u4E8E\u5B9E\u9645\u6301\u4ED3");
      if (preEntryPositionOnly(v.kind)) throw Error("\u89C2\u5BDF\u9636\u6BB5\u6CA1\u6709\u5B9E\u9645\u4ED3\u4F4D\uFF0C\u4E0D\u80FD\u542F\u7528\u76C8\u4E8F\u6BD4\u6216\u51E0\u4F55\u4ED3\u4F4D\u6761\u4EF6");
      validateHoldingVeto(v);
    }
  });
  const g = c.guard.rule;
  if (g.version !== "holding-support-break-v1" || g.confirmation !== "guard-break" || g.update !== "follow" || g.closes !== 1 || g.structure.algorithm !== "dbl5" || g.structure.kSource !== "guard" || g.structure.buffer !== 0 || g.structure.bufferUnit !== "atr" || g.structure.guardTrendOnly) throw Error("\u4E09\u9636\u51C6\u5165\u987B\u8BFB\u53D6\u5B8C\u6574\u539F\u751F DBL-5 \u9632\u5B88\u7EBF\u66F4\u65B0\uFF08\u542B\u5B9E\u865A\u548C\u4E0B\u79FB\uFF09");
  validateStructureAddition(g.structure);
}
function freezePreEntryThreeStage(c) {
  validatePreEntryThreeStage(c);
  return { ...structuredClone(c), guard: { ...c.guard, rule: freezeBoxStop(c.guard.rule) }, hardVetoes: c.hardVetoes.map((v) => v.boxStop ? { ...structuredClone(v), boxStop: freezeBoxStop(v.boxStop) } : structuredClone(v)) };
}
function stableEntryJson(value) {
  return JSON.stringify(value, (_key, item) => item && typeof item === "object" && !Array.isArray(item) ? Object.fromEntries(Object.keys(item).sort().map((key) => [key, item[key]])) : item);
}
var PRE_ENTRY_THREE_STAGE_V5, PRE_ENTRY_THREE_STAGE_VERSION, PRE_ENTRY_RETRY_VERSION, PRE_ENTRY_SIGNAL_GATE_VERSION, PRE_ENTRY_TRACKED_GATE_VERSION, PRE_ENTRY_OPTIONAL_STAGES_VERSION, PRE_ENTRY_SIGNAL_ANCHOR_VERSION, THREE_STAGE_VERSIONS, isPreEntryThreeStageVersion, PRE_ENTRY_GUARD_EVENT_VERSION, ENTRY_ADMISSION_PRIORITY_VERSION, usesOptionalStages, usesTrackedGate, usesSignalTimeGate, expressionConditions, threeStageFingerprint;
var init_preEntryThreeStage = __esm({
  "src/lib/fish/preEntryThreeStage.ts"() {
    init_thresholdRange();
    init_algorithm();
    init_qualityAdditionVeto();
    init_qualityVeto();
    init_qualityBoxStop();
    init_qualityAdditionStructure();
    init_qualityAddition();
    init_preEntryConditions();
    init_preEntryStallTurnRule();
    PRE_ENTRY_THREE_STAGE_V5 = "pre-entry-three-stage-v5";
    PRE_ENTRY_THREE_STAGE_VERSION = "pre-entry-three-stage-v6";
    PRE_ENTRY_RETRY_VERSION = "pre-entry-three-stage-v7";
    PRE_ENTRY_SIGNAL_GATE_VERSION = "pre-entry-three-stage-v8";
    PRE_ENTRY_TRACKED_GATE_VERSION = "pre-entry-three-stage-v9";
    PRE_ENTRY_OPTIONAL_STAGES_VERSION = "pre-entry-three-stage-v10";
    PRE_ENTRY_SIGNAL_ANCHOR_VERSION = "pre-entry-three-stage-v11";
    THREE_STAGE_VERSIONS = [PRE_ENTRY_THREE_STAGE_V5, PRE_ENTRY_THREE_STAGE_VERSION, PRE_ENTRY_RETRY_VERSION, PRE_ENTRY_SIGNAL_GATE_VERSION, PRE_ENTRY_TRACKED_GATE_VERSION, PRE_ENTRY_OPTIONAL_STAGES_VERSION, PRE_ENTRY_SIGNAL_ANCHOR_VERSION];
    isPreEntryThreeStageVersion = (version) => THREE_STAGE_VERSIONS.some((candidate) => candidate === version);
    PRE_ENTRY_GUARD_EVENT_VERSION = "pre-entry-guard-event-v1";
    ENTRY_ADMISSION_PRIORITY_VERSION = "entry-admission-priority-v1";
    usesOptionalStages = (version) => version === PRE_ENTRY_OPTIONAL_STAGES_VERSION || version === PRE_ENTRY_SIGNAL_ANCHOR_VERSION;
    usesTrackedGate = (version) => version === PRE_ENTRY_TRACKED_GATE_VERSION || usesOptionalStages(version);
    usesSignalTimeGate = (version) => version === PRE_ENTRY_SIGNAL_GATE_VERSION || usesTrackedGate(version);
    expressionConditions = (e) => "condition" in e ? [e.condition] : e.children.flatMap(expressionConditions);
    threeStageFingerprint = (c) => shortFishHash(stableEntryJson(freezePreEntryThreeStage(c)));
  }
});

// src/lib/fish/libraryRounds.ts
var init_libraryRounds = __esm({
  "src/lib/fish/libraryRounds.ts"() {
  }
});

// src/lib/fish/qualitySources.ts
var init_qualitySources = __esm({
  "src/lib/fish/qualitySources.ts"() {
    init_turingCupSymbol();
    init_libraryRounds();
  }
});

// src/lib/fish/qualityAdmissionTime.ts
var qualitySignalTime;
var init_qualityAdmissionTime = __esm({
  "src/lib/fish/qualityAdmissionTime.ts"() {
    init_qualitySources();
    qualitySignalTime = (source) => source.preEntryMonitor?.sourceTime ?? source.timeMs;
  }
});

// src/lib/fish/preEntryWindowLoader.ts
var init_preEntryWindowLoader = __esm({
  "src/lib/fish/preEntryWindowLoader.ts"() {
    init_shared();
  }
});

// src/lib/fish/qualityPlanRouter.ts
function raceSharedAddition(a) {
  if (!a) return a;
  const rest = { ...a };
  for (const k of RACE_ROUND_KEYS) delete rest[k];
  delete rest.roundExits;
  return rest;
}
function equivalentRouterVersion(frozen, current) {
  const prefix2 = QUALITY_ROUTER_VERSION + " \xB7 \u53C2\u6570 #";
  return current === prefix2 + "1er917g1rq0q7q" && [prefix2 + "1cmjlqy15r0lzq", prefix2 + "1kpvpw2rkvbiu"].includes(frozen);
}
function validateQualityRouter(r) {
  const n = r.afterAdditions, from = raceAttackFromRound(r);
  if (canonicalRouterJson(r.structure?.advantage) !== canonicalRouterJson(r.attack?.advantage)) throw Error("\u4E24\u4E2A\u5206\u652F\u7684\u4F18\u52BF\u7B5B\u9009\u4E0E\u9000\u51FA\u7075\u654F\u5EA6\u8BBE\u7F6E\u987B\u4E00\u81F4");
  if (n !== 0 && r.attackFromRound != null) throw Error("\u300C\u8FDB\u653B\u4ECE\u7B2C\u51E0\u6B21\u8D77\u300D\u53EA\u7528\u4E8E\u6BCF\u8F6E\u5206\u6D41");
  if (!Number.isInteger(from) || from < 1 || from > 100) throw Error("\u8FDB\u653B\u5206\u652F\u53C2\u4E0E\u7ADE\u901F\u7684\u8D77\u59CB\u6B21\u6570\u987B\u4E3A 1 \u81F3 100 \u7684\u6574\u6570");
  if (n !== 0 && n !== 1 && n !== 2 || r.version !== routerVersionFor(n, from) || !Number.isFinite(r.threshold) || r.threshold < 0 || r.threshold > 1) throw Error("\u6761\u4EF6\u5206\u652F\u7248\u672C\u6216\u95E8\u69DB\u65E0\u6548");
  if (!r.structure || !r.attack || r.structure.router || r.attack.router || r.structure.engine || r.attack.engine) throw Error("\u6761\u4EF6\u5206\u652F\u5FC5\u987B\u662F\u4E24\u5957\u72EC\u7ACB\u7684\u5F53\u524D\u5F15\u64CE\u65B9\u6848");
  if (r.structure.addition?.roundExits || r.attack.addition?.roundExits) {
    const sharedCount = n || r.attack.addition?.rounds?.length || 0;
    for (let round = 1; round <= sharedCount; round++) {
      const exits = [r.structure, r.attack].map((p) => additionExitIdentity(additionExitForRound(p.addition ?? {}, round)));
      if (canonicalRouterJson(exits[0]) !== canonicalRouterJson(exits[1])) throw Error(`\u4E24\u4E2A\u5206\u652F\u7B2C ${round} \u6B21\u52A0\u4ED3\u540E\u7684\u5356\u51FA\u6807\u51C6\u987B\u4E00\u81F4`);
    }
  }
  if (n === 0) {
    for (const p of [r.structure, r.attack]) if (!p.addition?.enabled || p.addition.quantityMode !== "calculator" || !p.addition.rounds?.length || p.addition.alternativeRounds?.length || p.addition.attackFromRound != null) throw Error("\u6BCF\u8F6E\u5206\u6D41\u7684\u4E24\u6761\u5206\u652F\u90FD\u987B\u542F\u7528\u9010\u8F6E\u72EC\u7ACB\u6761\u4EF6\u3001\u6309\u5E73\u8861\u516C\u5F0F\u5B9A\u91CF\u7684\u52A0\u4ED3");
    if (r.attack.addition.rounds.length > r.structure.addition.rounds.length) throw Error("\u8FDB\u653B\u5206\u652F\u7684\u52A0\u4ED3\u8F6E\u6570\u4E0D\u80FD\u591A\u4E8E\u7ED3\u6784\u5206\u652F");
    if (from > r.attack.addition.rounds.length) throw Error(`\u8FDB\u653B\u5206\u652F\u53EA\u6709 ${r.attack.addition.rounds.length} \u6B21\u52A0\u4ED3\uFF0C\u4E0D\u80FD\u4ECE\u7B2C ${from} \u6B21\u8D77\u53C2\u4E0E`);
    const shared = (p) => canonicalRouterJson([p.rule, p.snapshot, p.combo, p.execution, p.vetoFill, p.holdingVetoes, p.payoffRiskVersion, p.mirrorTakeProfit, p.vetoStages, p.vetoStageMode, p.vetoPeakBasis, p.sellStages, raceSharedAddition(p.addition)]);
    if (shared(r.structure) !== shared(r.attack)) throw Error("\u6BCF\u8F6E\u5206\u6D41\u7684\u4E24\u4E2A\u5206\u652F\u9664\u5404\u8F6E\u52A0\u4ED3\u6761\u4EF6\u5916\uFF0C\u521D\u59CB\u6301\u4ED3\u3001\u9000\u51FA\u6761\u4EF6\u3001\u52A0\u4ED3\u901A\u7528\u8BBE\u7F6E\u4E0E\u52A0\u4ED3\u540E\u5207\u6362\u5FC5\u987B\u5B8C\u5168\u76F8\u540C");
    r.attack.addition.rounds.forEach((round, i) => {
      const t = round.source === "custom" ? qualityAdditionConditions(round)[0] : void 0;
      if (t?.metric === "state" && (t.direction !== ">" || t.threshold < r.threshold)) throw Error(`\u8FDB\u653B\u5206\u652F\u7B2C ${i + 1} \u6B21\u52A0\u4ED3\u7684\u72B6\u6001 S \u95E8\u69DB\u987B\u4E0D\u4F4E\u4E8E\u5206\u652F\u95E8\u69DB ${r.threshold}`);
    });
    return;
  }
  for (const p of [r.structure, r.attack]) if (!p.addition?.rounds || p.addition.rounds.length < n || p.addition.rounds.slice(0, n).some((a) => a.source !== "structure")) throw Error(`\u6761\u4EF6\u5206\u652F\u7684${routerPrefixText(r)}\u5FC5\u987B\u4F7F\u7528\u7ED3\u6784\u52A0\u4ED3`);
  const prefix2 = (p) => canonicalRouterJson([p.rule, p.snapshot, p.combo, p.execution, p.vetoFill, p.holdingVetoes, p.payoffRiskVersion, p.mirrorTakeProfit, p.addition?.rounds?.slice(0, n), p.vetoStages?.filter((s) => s.afterAdditions <= n), p.vetoStageMode, p.vetoPeakBasis]);
  if (prefix2(r.structure) !== prefix2(r.attack)) throw Error(`\u4E24\u4E2A\u5206\u652F\u7684${routerPrefixText(r)}\u52A0\u4ED3\u3001\u521D\u59CB\u6301\u4ED3\u4E0E\u9000\u51FA\u6761\u4EF6\u5FC5\u987B\u5B8C\u5168\u76F8\u540C`);
}
var QUALITY_ROUTER_VERSION, QUALITY_ROUTER_FIRST_VERSION, QUALITY_ROUTER_RACE_VERSION, QUALITY_ROUTER_RACE_FROM_VERSION, raceAttackFromRound, routerVersionFor, isRaceRouter, RACE_ROUND_KEYS, raceFromText, routerVersionSummary, routerOrdinal, routerPrefixText, canonicalRouterJson, routerFingerprint;
var init_qualityPlanRouter = __esm({
  "src/lib/fish/qualityPlanRouter.ts"() {
    init_algorithm();
    init_qualityAddition();
    QUALITY_ROUTER_VERSION = "second-structural-addition-state-router-v1";
    QUALITY_ROUTER_FIRST_VERSION = "first-structural-addition-state-router-v1";
    QUALITY_ROUTER_RACE_VERSION = "per-round-structure-attack-race-v1";
    QUALITY_ROUTER_RACE_FROM_VERSION = "per-round-structure-attack-race-from-v1";
    raceAttackFromRound = (r) => r.attackFromRound ?? 1;
    routerVersionFor = (afterAdditions, attackFromRound = 1) => afterAdditions === 0 ? attackFromRound > 1 ? QUALITY_ROUTER_RACE_FROM_VERSION : QUALITY_ROUTER_RACE_VERSION : afterAdditions === 1 ? QUALITY_ROUTER_FIRST_VERSION : QUALITY_ROUTER_VERSION;
    isRaceRouter = (r) => r.afterAdditions === 0;
    RACE_ROUND_KEYS = ["classifiedImpulsePositions", "source", "structure", "stricterPct", "condition", "conditions", "prerequisites", "indicatorIncrease", "minGainPct", "entryBufferAtr", "supportOffsetAtr", "entryDistanceAtr", "gainBasis", "entryVetoes", "detectorPrerequisite", "rounds", "maxRounds", "alternativeRounds", "attackFromRound"];
    raceFromText = (r) => raceAttackFromRound(r) > 1 ? `\u524D ${raceAttackFromRound(r) - 1} \u6B21\u53EA\u8D70\u7ED3\u6784\u5206\u652F\uFF0C\u8FDB\u653B\u5206\u652F\u4ECE\u7B2C ${raceAttackFromRound(r)} \u6B21\u52A0\u4ED3\u8D77\u53C2\u4E0E\u7ADE\u901F\uFF1B` : "";
    routerVersionSummary = (r) => isRaceRouter(r) ? `${raceFromText(r)}\u6BCF\u4E00\u6B21\u52A0\u4ED3\u524D\u90FD\u5206\u6D41\uFF1A\u7ED3\u6784\u5206\u652F\u4E0E\u8FDB\u653B\u5206\u652F\u8FD9\u4E00\u6B21\u7684\u52A0\u4ED3\u89C4\u5219\u540C\u65F6\u7B49\u5019\uFF0C\u5148\u6EE1\u8DB3\u8005\u6210\u4EA4\uFF08\u540C\u4E00\u5206\u949F\u5148\u7ED3\u6784\uFF09\uFF1B\u8FDB\u653B\u5206\u652F\u5404\u6B21\u72B6\u6001 S \u95E8\u69DB\u4E0D\u4F4E\u4E8E ${r.threshold}` : `\u7B2C${routerOrdinal(r)}\u6B21\u7ED3\u6784\u52A0\u4ED3\u65F6\uFF0C\u5DF2\u6536\u76D8\u72B6\u6001 S > ${r.threshold} \u5207\u8FDB\u653B\uFF0C\u5426\u5219\u672C\u573A\u4FDD\u6301\u7ED3\u6784\u5206\u652F\uFF1B\u53EA\u9009\u62E9\u4E00\u6B21`;
    routerOrdinal = (r) => r.afterAdditions === 1 ? "\u4E00" : "\u4E8C";
    routerPrefixText = (r) => r.afterAdditions === 1 ? "\u7B2C\u4E00\u6B21" : "\u524D\u4E24\u6B21";
    canonicalRouterJson = (value) => JSON.stringify(value, (_key, item) => item && typeof item === "object" && !Array.isArray(item) ? Object.fromEntries(Object.keys(item).sort().map((k) => [k, item[k]])) : item);
    routerFingerprint = (r) => shortFishHash(canonicalRouterJson(r));
  }
});

// src/lib/fish/qualityAdvantage.ts
function validateQualityAdvantage(g) {
  if (g.router) {
    validateQualityAdvantage(g.router.structure);
    validateQualityAdvantage(g.router.attack);
  }
  const r = g.advantage;
  if (!r) return;
  if (g.engine || g.execution !== "intrabar-1m" || !g.addition?.enabled || g.addition.quantityMode !== "calculator")
    throw Error("\u4F18\u52BF\u7B5B\u9009\u6A21\u677F\u987B\u6CBF\u7528\u5F53\u524D\u5F15\u64CE\u30011 \u5206\u949F\u590D\u539F\u5356\u51FA\u4E0E\u5E73\u8861\u516C\u5F0F\u52A0\u4ED3\u7684\u539F\u65B9\u6848");
  if (r.version !== QUALITY_ADVANTAGE_VERSION) throw Error("\u4F18\u52BF\u7B5B\u9009\u4E0E\u9000\u51FA\u7075\u654F\u5EA6\u7248\u672C\u4E0D\u53EF\u7528");
  if (![1, 2].includes(r.confirmations) || [r.screenWeak, r.beforeFirst, r.afterAddition].some((v) => typeof v !== "boolean"))
    throw Error("\u4F18\u52BF\u7B5B\u9009\u5F00\u5173\u6216\u8F6F\u9000\u51FA\u786E\u8BA4\u6B21\u6570\u65E0\u6548");
  if (!r.state?.snapshot?.definitionKey || r.state.metric !== "state" || r.state.snapshot.interval !== "5m")
    throw Error("\u4F18\u52BF\u7B5B\u9009\u987B\u4FDD\u7559\u539F\u65B9\u6848\u5DF2\u51BB\u7ED3\u7684 5 \u5206\u949F\u72B6\u6001 S \u516C\u5F0F");
  validateStructureAddition(r.structure);
  if (r.structure.algorithm !== "dbl5") throw Error("\u4F18\u52BF\u5206\u7EA7\u987B\u4F7F\u7528\u539F\u65B9\u6848\u7684 DBL-5 \u7ED3\u6784");
}
var MINUTE, STEP, QUALITY_ADVANTAGE_VERSION, canonical2, qualityAdvantageIdentity, qualityAdvantageFingerprint;
var init_qualityAdvantage = __esm({
  "src/lib/fish/qualityAdvantage.ts"() {
    init_dbl5m();
    init_boxAlgorithmVersions();
    init_qualityInitialization();
    init_algorithm();
    init_quality();
    init_qualityAdditionStructure();
    init_shared();
    MINUTE = 6e4;
    STEP = 5 * MINUTE;
    QUALITY_ADVANTAGE_VERSION = "addition-advantage-soft-exit-v1";
    canonical2 = (value) => JSON.stringify(value, (_k, v) => v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, v[k]])) : v);
    qualityAdvantageIdentity = (g) => g.advantage ? [QUALITY_ADVANTAGE_VERSION, JSON.parse(canonical2(g.advantage))] : null;
    qualityAdvantageFingerprint = (g) => shortFishHash(canonical2(qualityAdvantageIdentity(g)));
  }
});

// src/lib/fish/qualityVetoStages.ts
var orderedVetoStages, qualityVetoStagesIdentity;
var init_qualityVetoStages = __esm({
  "src/lib/fish/qualityVetoStages.ts"() {
    init_qualityVeto();
    init_qualityBoxStop();
    orderedVetoStages = (g) => [...g.vetoStages ?? []].sort((a, b) => a.afterAdditions - b.afterAdditions);
    qualityVetoStagesIdentity = (g) => g.vetoStages?.length ? ["addition-count-veto-stages-v1", g.vetoStageMode ?? "overlay", g.vetoPeakBasis ?? "stage", orderedVetoStages(g).map((s) => [s.afterAdditions, s.conditions.map((v) => [v.enabled, holdingVetoIdentity([{ ...v, enabled: true }])[0]])])] : null;
  }
});

// src/lib/fish/qualitySellStages.ts
var orderedSellStages, qualitySellStagesIdentity;
var init_qualitySellStages = __esm({
  "src/lib/fish/qualitySellStages.ts"() {
    init_qualityVetoStages();
    orderedSellStages = (g) => [...g.sellStages ?? []].sort((a, b) => a.afterAdditions - b.afterAdditions);
    qualitySellStagesIdentity = (g) => g.sellStages?.length ? ["addition-count-sell-stages-v1", orderedSellStages(g).map((s) => [s.afterAdditions, s.metric, s.snapshot.featureId, s.snapshot.definitionKey, s.snapshot.interval, s.snapshot.scale, s.rule.direction, s.rule.threshold])] : null;
  }
});

// src/lib/fish/qualityMirror.ts
function mirrorExecutionIdentity(plan) {
  return plan.mirrorTakeProfit?.enabled && plan.execution !== "intrabar-1m" && !plan.holdingVetoes?.some((v) => v.enabled) && !plan.combo ? ["mirror-preserve-close-v2"] : [];
}
var DBL5_MIRROR_MODE, mirrorIdentity;
var init_qualityMirror = __esm({
  "src/lib/fish/qualityMirror.ts"() {
    DBL5_MIRROR_MODE = "mirror-dbl5-breakeven-v1";
    mirrorIdentity = (rule) => rule?.enabled ? rule.mode === DBL5_MIRROR_MODE ? [DBL5_MIRROR_MODE, rule.sellPct] : ["mirror-limit-v1", rule.gainPct, rule.sellPct] : [];
  }
});

// src/lib/fish/qualityZeroTrade.ts
var init_qualityZeroTrade = __esm({
  "src/lib/fish/qualityZeroTrade.ts"() {
  }
});

// src/lib/fish/qualityScanChunk.ts
var init_qualityScanChunk = __esm({
  "src/lib/fish/qualityScanChunk.ts"() {
    init_turingCupSymbol();
    init_shared();
  }
});

// src/lib/fish/qualityIntrabar.ts
var init_qualityIntrabar = __esm({
  "src/lib/fish/qualityIntrabar.ts"() {
    init_qualityMirror();
    init_qualityDbl5Sell();
    init_qualityBoxStop();
    init_qualityMirrorDeadline();
    init_qualityPostMirrorProtection();
    init_qualityMirrorHardStopStages();
    init_qualityInitialization();
    init_qualityZeroTrade();
    init_turingCupSymbol();
    init_features();
    init_formula();
    init_algorithm();
    init_shared();
    init_qualityScanChunk();
    init_timeFormat();
    init_qualityVeto();
    init_qualityStaticDrawdownSell();
  }
});

// src/lib/researchChartHistory.ts
var init_researchChartHistory = __esm({
  "src/lib/researchChartHistory.ts"() {
    init_dbl5m();
    init_marketData();
    init_turingCupSymbol();
    init_userStoragePrefix();
  }
});

// src/lib/btcReference.ts
var init_btcReference = __esm({
  "src/lib/btcReference.ts"() {
    init_marketData();
    init_turingCupSymbol();
    init_userStoragePrefix();
  }
});

// src/lib/dynamicSchellingPoint.ts
var DSP_BASE_INTERVAL_MS, DSP_V_STEPS;
var init_dynamicSchellingPoint = __esm({
  "src/lib/dynamicSchellingPoint.ts"() {
    init_formula();
    DSP_BASE_INTERVAL_MS = 5 * 6e4;
    DSP_V_STEPS = [
      "\u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 DSP\xB7a \u7684\u8BA1\u7B97\uFF08\u6BCF\u6839 K \u7EBF\u4E00\u6B21\uFF0C\u6210\u4EA4\u91CF\u4E00\u5F8B\u7528\u6210\u4EA4\u91D1\u989D USDT\uFF09\uFF1A",
      "\u2460 \u4E3B\u52A8\u51C0\u8D44\u91D1 N\u209C = |B\u209C \u2212 S\u209C|\uFF08B / S = \u4E3B\u52A8\u4E70\u5165 / \u5356\u51FA\u6210\u4EA4\u989D\uFF09",
      "\u2461 \u8D44\u91D1\u529B\u91CF f\u209C = ln(1 + N\u209C \xF7 EMA(B\u209C + S\u209C))\uFF1A\u8FD9\u6839\u7684\u51C0\u8D44\u91D1\u6BD4\u5E73\u65F6\u7684\u6210\u4EA4\u989D\u5F02\u5E38\u591A\u5C11",
      "\u2462 \u4E70\u65B9\u4F18\u52BF A\u209C = (B\u209C \u2212 S\u209C) \xF7 (B\u209C + S\u209C)\uFF0C\u6743\u91CD G\u209C = 1 + max(A\u209C, 0)\uFF1A\u4E70\u65B9\u5360\u4F18\u65F6\u52A0\u6743\uFF0C\u5356\u65B9\u5360\u4F18\u65F6\u4E0D\u52A0\u4E0D\u51CF",
      "\u2463 \u4EF7\u683C\u53D8\u5316 R\u209C = ln(C\u209C \xF7 C\u209C\u208B\u2081)\uFF0C\u6709\u6B63\u8D1F",
      "\u2464 \u5355\u6839\u63A8\u529B F\u209C = f\u209C \xD7 G\u209C \xD7 R\u209C",
      "\u2465 \u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 a\u209C = \u03C1\xB7a\u209C\u208B\u2081 + (1 \u2212 \u03C1)\xB7F\u209C\uFF0C\u03C1 = 2^(\u22125 \u5206\u949F \xF7 h)\uFF1Ah \u6309 5 \u5206\u949F\u56FE\u8BA1\uFF0C\u5176\u4ED6\u5468\u671F\u7684\u8BB0\u5FC6\u65F6\u95F4\u7B49\u6BD4\u4F8B\u7F29\u653E\uFF08h = 6 \u65F6 5 \u5206\u949F\u56FE 6 \u5C0F\u65F6\u300115 \u5206\u949F\u56FE 18 \u5C0F\u65F6\u30011 \u5C0F\u65F6\u56FE 72 \u5C0F\u65F6\uFF09\uFF0C\u6BCF\u6839 K \u7EBF\u90FD\u662F \u03C1 \u2248 0.9904\u3001\u65B0\u63A8\u52A8\u5360\u7EA6 0.96%\uFF0C\u534A\u8870\u671F\u90FD\u662F 72 \u6839",
      "\u2466 \u52A8\u6001\u8C22\u6797\u70B9 DSP\u209C = DSP\u209C\u208B\u2081 \xD7 e^(a\u209C)\uFF1Aa \u5C31\u662F DSP \u6BCF\u6839 K \u7EBF\u7684\u5BF9\u6570\u53D8\u5316",
      "\u8BFB\u6CD5\uFF1Aa > 0 \u5171\u8BC6\u4EF7\u4E0A\u79FB\u3001a < 0 \u4E0B\u79FB\uFF0C|a| \u8D8A\u5927\u79FB\u5F97\u8D8A\u5FEB\uFF1B\u526F\u56FE\u6309 \u57FA\u70B9 / \u6839 \u663E\u793A\uFF08\xD7 10\u2074\uFF09\uFF0C5 \u5206\u949F\u56FE\u4E0A 1 \u57FA\u70B9 / \u6839 \u2248 \u6BCF\u5C0F\u65F6 0.12%\u3002",
      "\u4F8B\uFF1AB = 60 \u4E07\u3001S = 40 \u4E07\u3001EMA(B + S) = 80 \u4E07\u3001\u6536\u76D8\u4ECE 1.000 \u5230 1.010\u3001\u4E0A\u4E00\u6839 a = 2 \u57FA\u70B9 \u2192 f = 0.223\u3001A = 0.2\u3001G = 1.2\u3001R = 0.995%\u3001F = 26.6 \u57FA\u70B9\u3001a = 2.24 \u57FA\u70B9 / \u6839\u3002"
    ].join("\n");
  }
});

// src/lib/avgHighlight.ts
var AVG_CALIBRATION_CUTOFF;
var init_avgHighlight = __esm({
  "src/lib/avgHighlight.ts"() {
    init_cdaPeriods();
    init_formula();
    AVG_CALIBRATION_CUTOFF = Date.parse("2026-10-23T08:30:00Z");
  }
});

// src/lib/researchIndicators.ts
var IMPULSE_1115_CHART_ID, IMPULSE_1115_CHART, GUARD_1115_CHART_ID, GUARD_1115_CHART, DBL5_GUARD_CHART, DBL5_HOURLY_CHART, GUARD_PLUS_0_CHART_ID, GUARD_PLUS_0_CHART, IMPULSE_1115_CLASSIFICATION_CHART, RESEARCH_INDICATORS, BUYER_RESEARCH_INDICATORS, CUSTOM_RESEARCH_INDICATORS, bssComponentCharts;
var init_researchIndicators = __esm({
  "src/lib/researchIndicators.ts"() {
    init_impulse1115ClassificationDisplay();
    init_impulse1115Classification();
    init_cdaPeriods();
    init_turingCupSymbol();
    init_dbl5mMarketRules();
    init_dbl5m();
    init_dbl5GuardPlus();
    init_sbs5m();
    init_prs6h();
    init_ati6hMarketData();
    init_features();
    init_sellerRetention();
    init_featureSource();
    init_features();
    init_ctba();
    init_featureSource();
    init_features();
    init_researchChartHistory();
    init_btcReference();
    init_dynamicSchellingPoint();
    init_chartComputeClient();
    init_avgHighlight();
    init_researchAverageFormula();
    IMPULSE_1115_CHART_ID = "DBL5_IMPULSE_1115";
    IMPULSE_1115_CHART = {
      id: IMPULSE_1115_CHART_ID,
      featureId: DBL5_GUARD_PLUS_VERSION,
      core: "DBL5P_impulse",
      short: IMPULSE_1115_DISPLAY_NAME,
      name: IMPULSE_1115_DISPLAY_NAME,
      period: 3,
      parameter: "\u6025\u62C9\u786E\u8BA4",
      neutral: 0,
      min: 0,
      max: 0,
      seller: false,
      marketEvidence: true,
      rawOnly: true,
      priceOverlay: true
    };
    GUARD_1115_CHART_ID = "DBL5_GUARD_1115";
    GUARD_1115_CHART = {
      ...IMPULSE_1115_CHART,
      id: GUARD_1115_CHART_ID,
      core: "DBL5P_base",
      short: DBL5_GUARD_1115_DISPLAY_NAME,
      name: DBL5_GUARD_1115_DISPLAY_NAME,
      parameter: "\u9632\u5B88\u7EBF"
    };
    DBL5_GUARD_CHART = { id: "DBL5", featureId: DBL5_ID, core: "DBL5", short: DBL5_PROFILES["5m"].label, name: DBL5_PROFILES["5m"].label + " \u9632\u5B88\u7EBF", period: 3, parameter: "\u786E\u8BA4\u53C2\u6570\uFF08\u5B9A\u4E49\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true, priceOverlay: true, components: [...DBL5_FIELDS.filter((n) => n !== "DBL5"), ...DBL5_RENDER_FIELDS] };
    DBL5_HOURLY_CHART = {
      ...DBL5_GUARD_CHART,
      id: "DBL5_1H",
      featureId: DBL5_PROFILES["1h"].id,
      short: DBL5_PROFILES["1h"].label,
      name: DBL5_PROFILES["1h"].label + " \u9632\u5B88\u7EBF"
    };
    GUARD_PLUS_0_CHART_ID = "DBL5_GUARD_PLUS_0";
    GUARD_PLUS_0_CHART = {
      ...DBL5_GUARD_CHART,
      id: GUARD_PLUS_0_CHART_ID,
      short: "DBL-5-\u9632\u5B88\u7EBF+\u6025\u62C9\u7EBF-0",
      name: "DBL-5-\u9632\u5B88\u7EBF+\u6025\u62C9\u7EBF-0"
    };
    IMPULSE_1115_CLASSIFICATION_CHART = {
      id: IMPULSE_1115_CLASSIFICATION_CHART_ID,
      featureId: IMPULSE_1115_CLASSIFICATION_VERSION,
      core: "DBL5C",
      short: IMPULSE_1115_CLASSIFICATION_LABEL,
      name: IMPULSE_1115_CLASSIFICATION_LABEL,
      period: 3,
      parameter: "\u5206\u7C7B\u53C2\u6570\uFF08\u7F16\u8F91\u5B9A\u4E49\uFF09",
      neutral: 0,
      min: 0,
      max: 0,
      seller: false,
      marketEvidence: true,
      rawOnly: true,
      priceOverlay: true,
      components: [...IMPULSE_1115_CLASSIFICATION_FIELDS.filter((n) => n !== "DBL5C"), ...IMPULSE_1115_CLASSIFICATION_RENDER_FIELDS]
    };
    RESEARCH_INDICATORS = [
      ...BSS_COMPONENT_FEATURES.map((def) => ({
        id: def.chartCore.toUpperCase(),
        featureId: def.id,
        core: def.chartCore,
        short: def.short,
        name: def.name,
        period: 1,
        parameter: "\u8FD1\u671F\u7A97\u53E3",
        neutral: 0,
        avgNeutral: 0,
        min: -1,
        max: 1,
        avgRange: [-1, 1],
        seller: false
      })),
      DBL5_GUARD_CHART,
      DBL5_HOURLY_CHART,
      { id: "DBL5_GUARD_PLUS", featureId: DBL5_GUARD_PLUS_VERSION, core: "DBL5P", short: DBL5_GUARD_PLUS_DISPLAY_NAME, name: DBL5_GUARD_PLUS_DISPLAY_NAME, period: 3, parameter: "\u786E\u8BA4\u53C2\u6570\uFF08\u5B9A\u4E49\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true, priceOverlay: true, components: [...DBL5_GUARD_PLUS_NUMERIC.slice(1), ...DBL5_GUARD_PLUS_RENDER, "_DBL5_guard_segment"] },
      ...[{ id: "DBL5_DISTANCE", featureId: "darvas_5m_distance_bps", core: "DBL5_distance_bps", short: "DBL\xB7\u8DDD\u79BB", name: "DBL-5-5mins\uFF5C\u8DDD\u4E0B\u8F68\u57FA\u70B9" }, { id: "DBL5_WIDTH", featureId: "darvas_5m_width_bps", core: "DBL5_width_bps", short: "DBL\xB7\u7BB1\u5BBD", name: "DBL-5-5mins\uFF5C\u7BB1\u5BBD\u57FA\u70B9" }, { id: "DBL5_AGE", featureId: "darvas_5m_age_minutes", core: "DBL5_age_minutes", short: "DBL\xB7\u5E74\u9F84", name: "DBL-5-5mins\uFF5C\u786E\u8BA4\u5E74\u9F84" }].map((d) => ({ ...d, period: 3, parameter: "\u786E\u8BA4\u53C2\u6570\uFF08\u5B9A\u4E49\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true, components: [...DBL5_FIELDS.filter((n) => n !== "DBL5" && n !== "DBL5_upper"), ...DBL5_RENDER_FIELDS] })),
      ...[{ id: "DBL5_1H_DISTANCE", featureId: "darvas_1h_distance_bps", core: "DBL5_distance_bps", short: "DBL-5-1h\xB7\u8DDD\u79BB", name: "DBL-5-1h\uFF5C\u8DDD\u4E0B\u8F68\u57FA\u70B9" }, { id: "DBL5_1H_WIDTH", featureId: "darvas_1h_width_bps", core: "DBL5_width_bps", short: "DBL-5-1h\xB7\u7BB1\u5BBD", name: "DBL-5-1h\uFF5C\u7BB1\u5BBD\u57FA\u70B9" }, { id: "DBL5_1H_AGE", featureId: "darvas_1h_age_minutes", core: "DBL5_age_minutes", short: "DBL-5-1h\xB7\u5E74\u9F84", name: "DBL-5-1h\uFF5C\u786E\u8BA4\u5E74\u9F84" }].map((d) => ({ ...d, period: 3, parameter: "\u786E\u8BA4\u53C2\u6570\uFF08\u5B9A\u4E49\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true, components: [...DBL5_FIELDS.filter((n) => n !== "DBL5" && n !== "DBL5_upper"), ...DBL5_RENDER_FIELDS] })),
      { id: "SBS5M", featureId: SBS5M_ID, core: "SBS5M", short: "SBS-5M", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491", period: 6, parameter: "\u6709\u6548\u671F\uFF08\u5B9A\u4E49\u914D\u7F6E\uFF09", parameterUnit: "h", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true, priceOverlay: true, components: SBS5M_FIELDS.filter((n) => n !== "SBS5M") },
      { id: "SBS5M_QUALITY", featureId: "sbs_5m_quality", core: "SBS5M_support_quality", short: "SBS\xB7\u8BC1\u636E", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u8BC1\u636E\u5206", period: 6, parameter: "\u6709\u6548\u671F\uFF08\u5B9A\u4E49\u914D\u7F6E\uFF09", neutral: 0, min: 0, max: 100, seller: false, marketEvidence: true, rawOnly: true },
      { id: "SBS5M_DISTANCE", featureId: "sbs_5m_distance", core: "SBS5M_distance_to_support", short: "SBS\xB7\u8DDD\u79BB", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u6807\u51C6\u5316\u8DDD\u79BB", period: 6, parameter: "\u6709\u6548\u671F\uFF08\u5B9A\u4E49\u914D\u7F6E\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true },
      { id: "SBS5M_STEP", featureId: "sbs_5m_step", core: "SBS5M_step_height_atr", short: "SBS\xB7\u53F0\u9636", name: "\u53F0\u9636\u7BB1\u4F53\u652F\u6491\uFF5C\u53F0\u9636\u5E45\u5EA6", period: 6, parameter: "\u6709\u6548\u671F\uFF08\u5B9A\u4E49\u914D\u7F6E\uFF09", neutral: 0, min: 0, max: 0, seller: false, marketEvidence: true, rawOnly: true },
      { id: "PRS6H", featureId: PRS6H_ID, core: "PRS6H", short: "PRS-6H", name: "\u65E5\u5185\u987A\u52BF\u52A0\u4ED3\u8BC1\u636E", period: 0.5, parameter: "\u8FD1\u671F\u8BC1\u636E\u534A\u8870\u671F", parameterUnit: "h", neutral: 0, neutralLabel: "0\uFF5C\u672A\u6EE1\u8DB3\u672C\u6307\u6807\u8BC1\u636E\uFF08\u975E\u770B\u7A7A\uFF09", min: 0, max: 100, seller: false, marketEvidence: true, avgRange: [0, 100], components: PRS6H_FIELDS.filter((n) => n !== "PRS6H") },
      { id: "ATI6H", featureId: "ati6h", core: "ATI6H", short: "ATI-6H", name: "ATI-6H\uFF5C\u52A0\u4ED3\u652F\u6301\u8BC1\u636E\u6307\u6570", period: 1, parameter: "\u8BC1\u636E\u534A\u8870\u671F", parameterUnit: "h", neutral: 0, neutralLabel: "0\uFF5C\u8BC1\u636E\u5F52\u96F6\uFF08\u975E\u6267\u884C\u95E8\u69DB\uFF09", min: 0, max: 1, seller: false, marketEvidence: true, avgRange: [0, 1], components: ["ATI6H_sA", "ATI6H_sB", "ATI6H_sC", "ATI6H_sD", "ATI6H_sE", "ATI6H_sF", "ATI6H_min", "ATI6H_support_price", "ATI6H_support_failure_price", "ATI6H_breakout_price", "ATI6H_nearest_resistance_price", "ATI6H_structure_status_code"] },
      { id: "STATE", featureId: "state", core: "state", short: "\u72B6\u6001 S", name: "\u591A\u7A7A\u72B6\u6001 S\uFF080\u20131\uFF09", period: 24, parameter: "\u57FA\u7EBF\u65F6\u957F", neutral: 0.6, avgNeutral: 0.6, min: 0, max: 1, avgRange: [0, 1], seller: false },
      // 【用户要求】2026-10-22 橘色线（线上绿、线下红）：原始值与两条均值线都在 0.6
      { id: "STATE2", featureId: "state2", core: "state2", short: "\u72B6\u6001 S2", name: "\u591A\u7A7A\u72B6\u6001 S2\uFF080\u20131\uFF09", period: 24, parameter: "\u57FA\u7EBF\u65F6\u957F", neutral: 0.6, avgNeutral: 0.6, min: 0, max: 1, avgRange: [0, 1], seller: false },
      { id: "CDI2", featureId: "cdi2", core: "CDI2", short: "CDI2", name: "\u4E70\u65B9\u5931\u63A7\u7A0B\u5EA6 CDI2", period: 24, parameter: "\u57FA\u7EBF\u65F6\u957F", neutral: 0, min: -1, max: 1, avgRange: [-1, 1], seller: true },
      { id: "SELLER_CONTROL", featureId: "seller-control", core: "bc", short: "DSP\xB7bc", name: "\u5356\u65B9\u63A7\u5236\u529B DSP\xB7bc", period: 6, parameter: "\u534A\u8870\u671F", neutral: 0, min: 0, max: 0, seller: true },
      { id: "DSS", featureId: "dss", core: "DSS", short: "DSS", name: "\u4E70\u65B9\u72B6\u6001\u6076\u5316 DSS", period: 1, parameter: "\u8FD1\u671F\u7A97\u53E3", neutral: 0, avgNeutral: 0, min: -1, max: 1, avgRange: [-1, 1], seller: true },
      { id: "CDA", featureId: "cda", core: "CDA", short: CDA_FIVE_MINUTE_LABEL, name: "\u4E70\u65B9\u963B\u529B " + CDA_FIVE_MINUTE_LABEL, period: 6, parameter: "\u534A\u8870\u671F", neutral: 0, min: 0, max: 0, avgRange: [-100, 100], seller: true },
      {
        id: CDA_HOURLY_CHART_ID,
        featureId: CDA_HOURLY_ID,
        core: "CDA",
        short: CDA_HOURLY_LABEL,
        name: "\u4E70\u65B9\u963B\u529B " + CDA_HOURLY_LABEL,
        period: 6 * CDA_HOURLY_TIME_SCALE,
        parameter: "\u534A\u8870\u671F",
        neutral: 0,
        min: 0,
        max: 0,
        avgRange: [-100, 100],
        seller: true
      },
      { id: "MBI_BEAR", featureId: "mbi-bear", core: "MBI_bear", short: "MBI\xB7\u7A7A\u65B9", name: "MBI \u7A7A\u65B9\u8D8B\u52BF", period: 25, parameter: "\u8870\u51CF\u6839\u6570", neutral: 0, min: -1, max: 1, avgRange: [-1, 1], seller: true },
      { id: "CTBA_BEAR", featureId: "ctba-bear", core: "CTBA_bear", short: "CTBA\xB7\u7A7A\u65B9", name: "CTBA \u7A7A\u65B9\u8D8B\u52BF", period: CTBA_DEFAULTS.N, parameter: "\u7A97\u53E3\u6839\u6570", neutral: 0, min: -100, max: 100, avgRange: [-100, 100], seller: true },
      { id: "MBI2", featureId: "mbi2", core: "MBI2", short: "MBI2", name: "MBI2 \u8FC8\u514B\u5C14\u4E70\u65B9\u4F18\u52BF\uFF08\u53EF\u8C03\u7248\uFF09", period: 25 * 5 / 60, parameter: "\u65E5\u5386\u65F6\u957F", parameterUnit: "h", neutral: 0, min: -1, max: 1, avgRange: [-1, 1], components: ["MBI2_state", "MBI2_lead_h", "MBI2_confirm_h"], seller: false },
      { id: "CTBA_12H", featureId: "ctba_12h", core: "CTBA", short: "CTBA-12H", name: "CTBA-12H\uFF5C\u8D8B\u52BF\u4E70\u65B9\u4F18\u52BF\uFF0812\u5C0F\u65F6\uFF09", period: 144, parameter: "\u7A97\u53E3\u6839\u6570", parameterUnit: "\u6839", neutral: 0, neutralLabel: "0\uFF5C\u7EFC\u5408\u5747\u8861\u57FA\u51C6", min: -CTBA_ABSOLUTE_BOUND, max: CTBA_ABSOLUTE_BOUND, avgRange: [-CTBA_ABSOLUTE_BOUND, CTBA_ABSOLUTE_BOUND], components: ["T", "M", "F"], seller: false },
      { id: "MBI2_BEAR", featureId: "mbi2-bear", core: "MBI2_bear", short: "MBI2\xB7\u5356\u65B9", name: "MBI2 \u5356\u65B9\u8D8B\u52BF\uFF08\u53EF\u8C03\u7248\uFF09", period: 25 * 5 / 60, parameter: "\u65E5\u5386\u65F6\u957F", parameterUnit: "h", neutral: 0, min: -1, max: 1, avgRange: [-1, 1], components: ["MBI2_bear_state", "MBI2_bear_lead_h", "MBI2_bear_confirm_h"], seller: true },
      { id: "CTBA_12H_BEAR", featureId: "ctba_12h-bear", core: "CTBA_12H_bear", short: "CTBA-12H\xB7\u5356\u65B9", name: "CTBA-12H \u5356\u65B9\u8D8B\u52BF\uFF0812\u5C0F\u65F6\uFF09", period: 144, parameter: "\u7A97\u53E3\u6839\u6570", parameterUnit: "\u6839", neutral: 0, neutralLabel: "0\uFF5C\u7EFC\u5408\u5747\u8861\u57FA\u51C6", min: -100, max: 100, avgRange: [-100, 100], components: ["T", "M", "F"], seller: true },
      ...SELLER_RETENTION_SPECS.map((s) => ({ id: s.chartId, featureId: s.id, core: s.core, short: s.label + "\xB7\u4FDD\u7559", name: s.label + "\uFF5C\u6210\u4EA4\u4FDD\u7559\u589E\u5F3A", period: 6, parameter: "\u539F\u7B97\u6CD5\u53C2\u6570", parameterUnit: ["mbi-bear", "ctba-bear", "ctba_12h-bear"].includes(s.sourceId) ? "\u6839" : "h", neutral: 0, min: -s.bound, max: s.bound, avgRange: [-s.bound, s.bound], seller: true, components: retentionComponents() }))
    ];
    BUYER_RESEARCH_INDICATORS = [
      { id: "DSP_VA", featureId: "drift-speed", core: "a", short: "DSP\xB7a", name: "\u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 DSP\xB7a", period: 6, parameter: "\u534A\u8870\u671F", neutral: 0, min: 0, max: 0, seller: false },
      { id: "BSS", featureId: "bss", core: "BSS", short: "BSS", name: "\u4E70\u5356\u5F3A\u5EA6\u7EFC\u5408\u5206 BSS", period: 1, parameter: "\u8FD1\u671F\u7A97\u53E3", neutral: 0, min: -1, max: 1, seller: false },
      { id: "CBA", featureId: "cba", core: "CBA", short: "CBA", name: "\u4E70\u65B9\u5B9A\u4EF7\u4F18\u52BF\u6307\u6570 CBA", period: 6, parameter: "\u534A\u8870\u671F", neutral: 0, min: 0, max: 0, seller: false },
      { id: "DSP_Z", featureId: "drift-speed-z", core: "az", short: "DSP\xB7az", name: "\u4E70\u65B9\u63A8\u529B\u6F02\u79FB\u901F\u5EA6 DSP\xB7az\uFF08\u6CE2\u52A8\u7387\u5F52\u4E00\u5316\uFF09", period: 6, parameter: "\u534A\u8870\u671F", neutral: 0, min: 0, max: 0, seller: false },
      { id: "CBI2", featureId: "cbi2", core: "CBI2", short: "CBI-2", name: "\u4E70\u65B9\u4F18\u52BF\u6307\u6570 CBI-2", period: 24, parameter: "\u57FA\u7EBF\u65F6\u957F", neutral: 0, min: -1, max: 1, seller: false },
      { id: "MBI", featureId: "mbi", core: "MBI", short: "MBI", name: "MBI \u8FC8\u514B\u5C14\u4E70\u65B9\u4F18\u52BF", period: 25, parameter: "\u8870\u51CF\u6839\u6570", neutral: 0, min: -1, max: 1, seller: false },
      { id: "CTBA", featureId: "ctba", core: "CTBA", short: "CTBA", name: "CTBA\uFF5C\u8D8B\u52BF\u4E70\u65B9\u4F18\u52BF", period: CTBA_DEFAULTS.N, parameter: "\u7A97\u53E3\u6839\u6570", neutral: 0, min: -100, max: 100, seller: false }
    ];
    CUSTOM_RESEARCH_INDICATORS = [...BUYER_RESEARCH_INDICATORS, ...RESEARCH_INDICATORS];
    bssComponentCharts = new Set(BSS_COMPONENT_FEATURES.map((def) => def.chartCore.toUpperCase()));
  }
});

// src/lib/fish/qualityEntry.ts
var init_qualityEntry = __esm({
  "src/lib/fish/qualityEntry.ts"() {
    init_qualityInitialization();
    init_quality();
    init_algorithm();
    init_qualityIntrabar();
    init_qualityVeto();
    init_qualityStaticDrawdownSell();
    init_shared();
    init_researchIndicators();
  }
});

// src/lib/fish/qualityIndicatorEntryVeto.ts
var init_qualityIndicatorEntryVeto = __esm({
  "src/lib/fish/qualityIndicatorEntryVeto.ts"() {
    init_marketData();
    init_qualityEntry();
    init_qualityAdditionVeto();
    init_qualityVeto();
  }
});

// src/lib/fish/qualityAdditionIncrease.ts
var init_qualityAdditionIncrease = __esm({
  "src/lib/fish/qualityAdditionIncrease.ts"() {
    init_marketData();
    init_timeFormat();
    init_qualityEntry();
    init_shared();
  }
});

// src/lib/fish/qualityImpulseAddition.ts
var init_qualityImpulseAddition = __esm({
  "src/lib/fish/qualityImpulseAddition.ts"() {
    init_impulse5m();
    init_dbl5m();
    init_dbl5mMarketRules();
    init_turingCupSymbol();
    init_algorithm();
    init_shared();
  }
});

// src/lib/fish/preEntryGuardEvent.ts
var init_preEntryGuardEvent = __esm({
  "src/lib/fish/preEntryGuardEvent.ts"() {
    init_algorithm();
    init_features();
    init_dbl5m();
    init_qualityInitialization();
    init_shared();
    init_preEntryThreeStage();
  }
});

// src/lib/fish/qualityGuardDistance.ts
var guardChoices, guardDistanceSignalChoices;
var init_qualityGuardDistance = __esm({
  "src/lib/fish/qualityGuardDistance.ts"() {
    init_features();
    init_dbl5m();
    init_timeFormat();
    init_algorithm();
    init_preEntryGuardEvent();
    init_qualityAdditionVeto();
    init_shared();
    guardChoices = [
      { metric: "guard-distance-atr-v1", version: DBL5_GUARD_VERSION, name: "\u9632\u5B88\u7EBF v1" },
      { metric: "guard-distance-atr-retest-v1", version: DBL5_RETEST_GUARD_VERSION, name: "\u9632\u5B88\u7EBF-20261112" }
    ];
    guardDistanceSignalChoices = ["5m", "1h"].flatMap((timeframe) => guardChoices.map((choice) => {
      const { id: id2, label } = DBL5_PROFILES[timeframe];
      return {
        ...choice,
        timeframe,
        key: id2 + ":" + choice.metric,
        featureId: id2,
        label: "\u8DDD " + label + " \u9632\u5B88\u7EBF\uFF08ATR\uFF09 \xB7 " + choice.name,
        group: label + " \u9632\u5B88\u7EBF"
      };
    }));
  }
});

// src/lib/fish/qualityBoxBreakVeto.ts
var init_qualityBoxBreakVeto = __esm({
  "src/lib/fish/qualityBoxBreakVeto.ts"() {
    init_features();
    init_timeFormat();
    init_algorithm();
    init_qualityAdditionVeto();
    init_qualityInitialization();
    init_shared();
    init_screeningYield();
    init_qualityBoxMarketRepair();
  }
});

// src/lib/fish/qualityVetoHistory.ts
var M2, FIVE2;
var init_qualityVetoHistory = __esm({
  "src/lib/fish/qualityVetoHistory.ts"() {
    init_qualityIndicatorEntryVeto();
    init_atr();
    init_algorithm();
    init_qualityAdditionVeto();
    init_preEntryStallTurn5m();
    init_qualityGuardDistance();
    init_qualityBoxBreakVeto();
    init_qualityInitialization();
    init_qualityDoubleDrop();
    init_shared();
    init_screeningYield();
    M2 = 6e4;
    FIVE2 = 5 * M2;
  }
});

// src/lib/fish/qualityAdditionScan.ts
var init_qualityAdditionScan = __esm({
  "src/lib/fish/qualityAdditionScan.ts"() {
    init_thresholdRange();
    init_qualityInitialization();
    init_qualityIndicatorEntryVeto();
    init_qualityVetoHistory();
    init_algorithm();
    init_shared();
  }
});

// src/lib/fish/qualityAdditionCalculator.ts
var MINUTE2, STEP2, PERIOD, WARM;
var init_qualityAdditionCalculator = __esm({
  "src/lib/fish/qualityAdditionCalculator.ts"() {
    init_features();
    init_timeFormat();
    init_qualityClassifiedImpulsePosition();
    init_qualityMirrorHardStopStages();
    init_dbl5m();
    init_qualityHoldingLedger();
    init_qualityIndicatorEntryVeto();
    init_qualityAdditionIncrease();
    init_qualityImpulseAddition();
    init_qualityVetoHistory();
    init_qualityInitialization();
    init_atr();
    init_addPositionCoverage();
    init_algorithm();
    init_shared();
    init_qualityAdditionScan();
    init_qualityAddition();
    init_qualityAdditionStructure();
    init_qualityAdditionVeto();
    init_qualityVeto();
    init_dbl5GuardPlus();
    MINUTE2 = 6e4;
    STEP2 = 5 * MINUTE2;
    PERIOD = 14;
    WARM = PERIOD * 20 + 1;
  }
});

// src/lib/entryPeriodSignals.ts
var marketByName, knownMarkets;
var init_entryPeriodSignals = __esm({
  "src/lib/entryPeriodSignals.ts"() {
    init_timeFormat();
    marketByName = /* @__PURE__ */ new Map();
    knownMarkets = {
      crypto: "A AAVE ADA AVAX BGB BNB BTC CRV DOGE EOS ETH FARTCOIN HYPE KAITO LDO LINK LTC ONDO PEPE PUMP SEI SOL SUI UNI VIRTUAL WLD ZEC \u5E01\u5E02\u6D41\u52A8\u6027",
      us: "AAOI AAPL AMZN AXTI BABA CIRCLE COIN GLW GOOG HOOD MSFT MU NVDA PLTR SNDK SPCX TSLA",
      cn: "MLCC PCB",
      indicator: "\u671F\u6743\u6CE2\u52A8\u7387",
      commodity: "XAG \u5E03\u4F26\u7279\u539F\u6CB9"
    };
    for (const [market, names] of Object.entries(knownMarkets)) {
      for (const name of names.split(" ")) marketByName.set(name, market);
    }
    marketByName.set("\u7F8E\u80A1\u7EB3\u6307 OTC", "us");
    marketByName.set("\u9EC4\u91D1 OTC", "commodity");
  }
});

// src/lib/fish/exchanges.ts
var init_exchanges = __esm({
  "src/lib/fish/exchanges.ts"() {
  }
});

// src/lib/defaultSignalLibrary.ts
var init_defaultSignalLibrary = __esm({
  "src/lib/defaultSignalLibrary.ts"() {
  }
});

// src/lib/fish/defaultRules.ts
var FISH_DEFAULT_RULES;
var init_defaultRules = __esm({
  "src/lib/fish/defaultRules.ts"() {
    FISH_DEFAULT_RULES = [
      { id: "first", featureId: "cbi2", statistic: "avg_CBI2_2", threshold: "0.04" },
      { id: "default-cba", featureId: "cba", statistic: "avg_CBA_2", threshold: "8" },
      { id: "default-cbi2-avg", featureId: "cbi2", statistic: "avg_CBI2", threshold: "0.04" },
      { id: "default-cba-avg", featureId: "cba", statistic: "avg_CBA", threshold: "8" }
    ];
  }
});

// src/lib/fish/accountSettings.ts
var init_accountSettings = __esm({
  "src/lib/fish/accountSettings.ts"() {
    init_userStoragePrefix();
    init_persistedStateStorage();
  }
});

// src/lib/fish/instantPositionSettings.ts
var init_instantPositionSettings = __esm({
  "src/lib/fish/instantPositionSettings.ts"() {
    init_persistedStateStorage();
    init_userStoragePrefix();
  }
});

// src/lib/fish/instantMonitorSettings.ts
var init_instantMonitorSettings = __esm({
  "src/lib/fish/instantMonitorSettings.ts"() {
    init_persistedStateStorage();
    init_userStoragePrefix();
    init_quality();
    init_qualityPlanVersions();
  }
});

// src/lib/signalLibrary.ts
var init_signalLibrary = __esm({
  "src/lib/signalLibrary.ts"() {
    init_userStoragePrefix();
    init_signalMarket();
    init_entryPeriodSignals();
    init_turingCupSymbol();
    init_exchanges();
    init_defaultSignalLibrary();
    init_persistedStateStorage();
  }
});

// src/lib/fish/records.ts
function savedResultMetric(key) {
  const cached = savedResultMetrics.get(key);
  if (cached) return cached;
  let result = {};
  try {
    const saved = JSON.parse(key);
    if (Array.isArray(saved) && typeof saved[0] === "string") {
      const last = compileFeatureFormula(saved[0]).program.statements.at(-1);
      if (last) result = { name: last.name ?? void 0, metric: last.name ?? (last.expr.k === "var" ? last.expr.name : saved[0].split("\n")[last.line - 1]?.split("//")[0].split(";").at(-1)?.trim()) };
    }
  } catch {
  }
  if (savedResultMetrics.size >= 128) savedResultMetrics.clear();
  savedResultMetrics.set(key, result);
  return result;
}
function savedFishMetric(a) {
  const key = a.algorithmKey?.split("|");
  const selected = a.statistic ?? (key?.length === 6 ? key[1] : void 0);
  return selected && selected !== "\u7ED3\u679C" ? selected : savedResultMetric(a.definitionKey ?? "null").metric;
}
function fishSourceLabel(a) {
  if (!a) return "\u2014";
  const key = a.algorithmKey?.split("|"), parts = key?.length === 6 ? key : void 0;
  const id2 = a.featureId ?? parts?.[0];
  const state = id2 === "state" || id2 == null && a.featureShort === "S";
  const short = state ? "S" : a.featureShort || a.featureName || id2 || "\u2014";
  const H = a.H ?? (parts && parts[2] !== "=" ? Number(parts[2]) : void 0);
  const metric = savedFishMetric(a);
  const average = metric ? /^avg_(.+?)(?:_(\d+))?$/.exec(metric) : null;
  const normalize = (name) => name.replace(/[-_\s]/g, "").toLowerCase();
  const aliases = state ? ["state"] : id2 === "drift-speed-z" ? ["az", "a"] : id2 === "drift-speed" ? ["a"] : id2 === "seller-control" ? ["bc"] : [];
  const raw = !!metric && [id2, short, ...aliases].some((name) => name && normalize(name) === normalize(metric));
  const label = average ? `${short}\xB7avg${average[2]?.replace(/\d/g, (d) => "\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089"[Number(d)]) ?? ""}` : raw ? `${short} \u539F\u503C` : metric ? `${short} [${metric}]` : state ? "S\uFF08\u5E8F\u5217\u4E0D\u8BE6\uFF09" : short;
  if (H != null && Number.isFinite(H) && H > 0) return `${raw || !metric ? short : label}\xB7avg(${H}h)`;
  return label;
}
function caughtBy(s, label) {
  const r = s.fish;
  if (!r) return ["CBI-2"];
  if (r.algorithms?.length) {
    const picked = r.combination === "or" ? (r.hitAlgorithms ?? []).map((i) => r.algorithms[i - 1]) : r.algorithms;
    return [...new Set(picked.filter(Boolean).map(label))];
  }
  return [label({ ...r, featureShort: r.featureShort ?? "CBI-2" })];
}
var savedResultMetrics, fishCaughtBy;
var init_records = __esm({
  "src/lib/fish/records.ts"() {
    init_signalMarket();
    init_signalLibrary();
    init_features();
    init_algorithm();
    savedResultMetrics = /* @__PURE__ */ new Map();
    fishCaughtBy = (s) => caughtBy(s, fishSourceLabel);
  }
});

// src/lib/turingReplaySamples.ts
var init_turingReplaySamples = __esm({
  "src/lib/turingReplaySamples.ts"() {
    init_timeFormat();
    init_turingCupReplayArchive();
    init_turingCupSymbol();
  }
});

// src/lib/fish/qualityLegacyEngine.ts
function stable(value) {
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).filter((k) => value[k] !== void 0).sort().map((k) => `${JSON.stringify(k)}:${stable(value[k])}`).join(",")}}`;
  return JSON.stringify(value) ?? "null";
}
function legacyParamsFingerprint(plan) {
  const { id: _id, label: _label, frozenVersions: _frozen, ...params } = plan;
  return "\u53C2\u6570 #" + shortFishHash(stable(params));
}
function legacyPlanVersions(plan) {
  return [
    {
      key: "engine",
      part: "\u8BA1\u7B97\u5F15\u64CE",
      name: LEGACY_ENGINE_LABEL,
      version: `${LEGACY_QUALITY_ENGINE} \xB7 ${LEGACY_ENGINE_COMMIT}`,
      summary: "\u51BB\u7ED3\u7684 10-31 \u5F15\u64CE\uFF1A\u52A0\u4ED3\u6309\u81EA\u9009\u6307\u6807\uFF0B\u5165\u573A\u8DDD\u79BB T \u2265 S\uFF0Bn\xD7ATR\u3001K\uFF1DT\u2212m\xD7ATR\uFF0C\u6DA8\u5E45\u95E8\u69DB\u76F8\u5BF9\u6301\u4ED3\u5747\u4EF7"
    },
    { key: "legacy-params", part: "\u5168\u90E8\u53C2\u6570", name: "\u65B9\u6848\u53C2\u6570", version: legacyParamsFingerprint(plan), summary: "\u65E7\u5F15\u64CE\u65B9\u6848\u53EA\u8BFB\uFF1A\u4EFB\u4F55\u53C2\u6570\u53D8\u52A8\u90FD\u4F1A\u88AB\u62E6\u4E0B" }
  ];
}
var LEGACY_QUALITY_ENGINE, LEGACY_ENGINE_COMMIT, LEGACY_ENGINE_LABEL, isLegacyQualityPlan;
var init_qualityLegacyEngine = __esm({
  "src/lib/fish/qualityLegacyEngine.ts"() {
    init_algorithm();
    LEGACY_QUALITY_ENGINE = "quality-engine-2026-10-31";
    LEGACY_ENGINE_COMMIT = "bb003e0c";
    LEGACY_ENGINE_LABEL = "2026-10-31 \u65E7\u5F15\u64CE";
    isLegacyQualityPlan = (plan) => plan?.engine === LEGACY_QUALITY_ENGINE;
  }
});

// ../../../dev/veil-of-ignorance/node_modules/decimal.js-light/decimal.js
var require_decimal = __commonJS({
  "../../../dev/veil-of-ignorance/node_modules/decimal.js-light/decimal.js"(exports, module) {
    (function(globalScope) {
      "use strict";
      var MAX_DIGITS = 1e9, Decimal2 = {
        // These values must be integers within the stated ranges (inclusive).
        // Most of these values can be changed during run-time using `Decimal.config`.
        // The maximum number of significant digits of the result of a calculation or base conversion.
        // E.g. `Decimal.config({ precision: 20 });`
        precision: 20,
        // 1 to MAX_DIGITS
        // The rounding mode used by default by `toInteger`, `toDecimalPlaces`, `toExponential`,
        // `toFixed`, `toPrecision` and `toSignificantDigits`.
        //
        // ROUND_UP         0 Away from zero.
        // ROUND_DOWN       1 Towards zero.
        // ROUND_CEIL       2 Towards +Infinity.
        // ROUND_FLOOR      3 Towards -Infinity.
        // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
        // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
        // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
        // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
        // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
        //
        // E.g.
        // `Decimal.rounding = 4;`
        // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
        rounding: 4,
        // 0 to 8
        // The exponent value at and beneath which `toString` returns exponential notation.
        // JavaScript numbers: -7
        toExpNeg: -7,
        // 0 to -MAX_E
        // The exponent value at and above which `toString` returns exponential notation.
        // JavaScript numbers: 21
        toExpPos: 21,
        // 0 to MAX_E
        // The natural logarithm of 10.
        // 115 digits
        LN10: "2.302585092994045684017991454684364207601101488628772976033327900967572609677352480235997205089598298341967784042286"
      }, external = true, decimalError = "[DecimalError] ", invalidArgument = decimalError + "Invalid argument: ", exponentOutOfRange = decimalError + "Exponent out of range: ", mathfloor = Math.floor, mathpow = Math.pow, isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, ONE, BASE = 1e7, LOG_BASE = 7, MAX_SAFE_INTEGER = 9007199254740991, MAX_E = mathfloor(MAX_SAFE_INTEGER / LOG_BASE), P2 = {};
      P2.absoluteValue = P2.abs = function() {
        var x = new this.constructor(this);
        if (x.s) x.s = 1;
        return x;
      };
      P2.comparedTo = P2.cmp = function(y) {
        var i, j, xdL, ydL, x = this;
        y = new x.constructor(y);
        if (x.s !== y.s) return x.s || -y.s;
        if (x.e !== y.e) return x.e > y.e ^ x.s < 0 ? 1 : -1;
        xdL = x.d.length;
        ydL = y.d.length;
        for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) {
          if (x.d[i] !== y.d[i]) return x.d[i] > y.d[i] ^ x.s < 0 ? 1 : -1;
        }
        return xdL === ydL ? 0 : xdL > ydL ^ x.s < 0 ? 1 : -1;
      };
      P2.decimalPlaces = P2.dp = function() {
        var x = this, w = x.d.length - 1, dp = (w - x.e) * LOG_BASE;
        w = x.d[w];
        if (w) for (; w % 10 == 0; w /= 10) dp--;
        return dp < 0 ? 0 : dp;
      };
      P2.dividedBy = P2.div = function(y) {
        return divide(this, new this.constructor(y));
      };
      P2.dividedToIntegerBy = P2.idiv = function(y) {
        var x = this, Ctor = x.constructor;
        return round(divide(x, new Ctor(y), 0, 1), Ctor.precision);
      };
      P2.equals = P2.eq = function(y) {
        return !this.cmp(y);
      };
      P2.exponent = function() {
        return getBase10Exponent(this);
      };
      P2.greaterThan = P2.gt = function(y) {
        return this.cmp(y) > 0;
      };
      P2.greaterThanOrEqualTo = P2.gte = function(y) {
        return this.cmp(y) >= 0;
      };
      P2.isInteger = P2.isint = function() {
        return this.e > this.d.length - 2;
      };
      P2.isNegative = P2.isneg = function() {
        return this.s < 0;
      };
      P2.isPositive = P2.ispos = function() {
        return this.s > 0;
      };
      P2.isZero = function() {
        return this.s === 0;
      };
      P2.lessThan = P2.lt = function(y) {
        return this.cmp(y) < 0;
      };
      P2.lessThanOrEqualTo = P2.lte = function(y) {
        return this.cmp(y) < 1;
      };
      P2.logarithm = P2.log = function(base) {
        var r, x = this, Ctor = x.constructor, pr = Ctor.precision, wpr = pr + 5;
        if (base === void 0) {
          base = new Ctor(10);
        } else {
          base = new Ctor(base);
          if (base.s < 1 || base.eq(ONE)) throw Error(decimalError + "NaN");
        }
        if (x.s < 1) throw Error(decimalError + (x.s ? "NaN" : "-Infinity"));
        if (x.eq(ONE)) return new Ctor(0);
        external = false;
        r = divide(ln(x, wpr), ln(base, wpr), wpr);
        external = true;
        return round(r, pr);
      };
      P2.minus = P2.sub = function(y) {
        var x = this;
        y = new x.constructor(y);
        return x.s == y.s ? subtract(x, y) : add(x, (y.s = -y.s, y));
      };
      P2.modulo = P2.mod = function(y) {
        var q, x = this, Ctor = x.constructor, pr = Ctor.precision;
        y = new Ctor(y);
        if (!y.s) throw Error(decimalError + "NaN");
        if (!x.s) return round(new Ctor(x), pr);
        external = false;
        q = divide(x, y, 0, 1).times(y);
        external = true;
        return x.minus(q);
      };
      P2.naturalExponential = P2.exp = function() {
        return exp(this);
      };
      P2.naturalLogarithm = P2.ln = function() {
        return ln(this);
      };
      P2.negated = P2.neg = function() {
        var x = new this.constructor(this);
        x.s = -x.s || 0;
        return x;
      };
      P2.plus = P2.add = function(y) {
        var x = this;
        y = new x.constructor(y);
        return x.s == y.s ? add(x, y) : subtract(x, (y.s = -y.s, y));
      };
      P2.precision = P2.sd = function(z) {
        var e, sd, w, x = this;
        if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
        e = getBase10Exponent(x) + 1;
        w = x.d.length - 1;
        sd = w * LOG_BASE + 1;
        w = x.d[w];
        if (w) {
          for (; w % 10 == 0; w /= 10) sd--;
          for (w = x.d[0]; w >= 10; w /= 10) sd++;
        }
        return z && e > sd ? e : sd;
      };
      P2.squareRoot = P2.sqrt = function() {
        var e, n, pr, r, s, t, wpr, x = this, Ctor = x.constructor;
        if (x.s < 1) {
          if (!x.s) return new Ctor(0);
          throw Error(decimalError + "NaN");
        }
        e = getBase10Exponent(x);
        external = false;
        s = Math.sqrt(+x);
        if (s == 0 || s == 1 / 0) {
          n = digitsToString(x.d);
          if ((n.length + e) % 2 == 0) n += "0";
          s = Math.sqrt(n);
          e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
          if (s == 1 / 0) {
            n = "5e" + e;
          } else {
            n = s.toExponential();
            n = n.slice(0, n.indexOf("e") + 1) + e;
          }
          r = new Ctor(n);
        } else {
          r = new Ctor(s.toString());
        }
        pr = Ctor.precision;
        s = wpr = pr + 3;
        for (; ; ) {
          t = r;
          r = t.plus(divide(x, t, wpr + 2)).times(0.5);
          if (digitsToString(t.d).slice(0, wpr) === (n = digitsToString(r.d)).slice(0, wpr)) {
            n = n.slice(wpr - 3, wpr + 1);
            if (s == wpr && n == "4999") {
              round(t, pr + 1, 0);
              if (t.times(t).eq(x)) {
                r = t;
                break;
              }
            } else if (n != "9999") {
              break;
            }
            wpr += 4;
          }
        }
        external = true;
        return round(r, pr);
      };
      P2.times = P2.mul = function(y) {
        var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
        if (!x.s || !y.s) return new Ctor(0);
        y.s *= x.s;
        e = x.e + y.e;
        xdL = xd.length;
        ydL = yd.length;
        if (xdL < ydL) {
          r = xd;
          xd = yd;
          yd = r;
          rL = xdL;
          xdL = ydL;
          ydL = rL;
        }
        r = [];
        rL = xdL + ydL;
        for (i = rL; i--; ) r.push(0);
        for (i = ydL; --i >= 0; ) {
          carry = 0;
          for (k = xdL + i; k > i; ) {
            t = r[k] + yd[i] * xd[k - i - 1] + carry;
            r[k--] = t % BASE | 0;
            carry = t / BASE | 0;
          }
          r[k] = (r[k] + carry) % BASE | 0;
        }
        for (; !r[--rL]; ) r.pop();
        if (carry) ++e;
        else r.shift();
        y.d = r;
        y.e = e;
        return external ? round(y, Ctor.precision) : y;
      };
      P2.toDecimalPlaces = P2.todp = function(dp, rm) {
        var x = this, Ctor = x.constructor;
        x = new Ctor(x);
        if (dp === void 0) return x;
        checkInt32(dp, 0, MAX_DIGITS);
        if (rm === void 0) rm = Ctor.rounding;
        else checkInt32(rm, 0, 8);
        return round(x, dp + getBase10Exponent(x) + 1, rm);
      };
      P2.toExponential = function(dp, rm) {
        var str, x = this, Ctor = x.constructor;
        if (dp === void 0) {
          str = toString(x, true);
        } else {
          checkInt32(dp, 0, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
          x = round(new Ctor(x), dp + 1, rm);
          str = toString(x, true, dp + 1);
        }
        return str;
      };
      P2.toFixed = function(dp, rm) {
        var str, y, x = this, Ctor = x.constructor;
        if (dp === void 0) return toString(x);
        checkInt32(dp, 0, MAX_DIGITS);
        if (rm === void 0) rm = Ctor.rounding;
        else checkInt32(rm, 0, 8);
        y = round(new Ctor(x), dp + getBase10Exponent(x) + 1, rm);
        str = toString(y.abs(), false, dp + getBase10Exponent(y) + 1);
        return x.isneg() && !x.isZero() ? "-" + str : str;
      };
      P2.toInteger = P2.toint = function() {
        var x = this, Ctor = x.constructor;
        return round(new Ctor(x), getBase10Exponent(x) + 1, Ctor.rounding);
      };
      P2.toNumber = function() {
        return +this;
      };
      P2.toPower = P2.pow = function(y) {
        var e, k, pr, r, sign2, yIsInt, x = this, Ctor = x.constructor, guard = 12, yn = +(y = new Ctor(y));
        if (!y.s) return new Ctor(ONE);
        x = new Ctor(x);
        if (!x.s) {
          if (y.s < 1) throw Error(decimalError + "Infinity");
          return x;
        }
        if (x.eq(ONE)) return x;
        pr = Ctor.precision;
        if (y.eq(ONE)) return round(x, pr);
        e = y.e;
        k = y.d.length - 1;
        yIsInt = e >= k;
        sign2 = x.s;
        if (!yIsInt) {
          if (sign2 < 0) throw Error(decimalError + "NaN");
        } else if ((k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
          r = new Ctor(ONE);
          e = Math.ceil(pr / LOG_BASE + 4);
          external = false;
          for (; ; ) {
            if (k % 2) {
              r = r.times(x);
              truncate(r.d, e);
            }
            k = mathfloor(k / 2);
            if (k === 0) break;
            x = x.times(x);
            truncate(x.d, e);
          }
          external = true;
          return y.s < 0 ? new Ctor(ONE).div(r) : round(r, pr);
        }
        sign2 = sign2 < 0 && y.d[Math.max(e, k)] & 1 ? -1 : 1;
        x.s = 1;
        external = false;
        r = y.times(ln(x, pr + guard));
        external = true;
        r = exp(r);
        r.s = sign2;
        return r;
      };
      P2.toPrecision = function(sd, rm) {
        var e, str, x = this, Ctor = x.constructor;
        if (sd === void 0) {
          e = getBase10Exponent(x);
          str = toString(x, e <= Ctor.toExpNeg || e >= Ctor.toExpPos);
        } else {
          checkInt32(sd, 1, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
          x = round(new Ctor(x), sd, rm);
          e = getBase10Exponent(x);
          str = toString(x, sd <= e || e <= Ctor.toExpNeg, sd);
        }
        return str;
      };
      P2.toSignificantDigits = P2.tosd = function(sd, rm) {
        var x = this, Ctor = x.constructor;
        if (sd === void 0) {
          sd = Ctor.precision;
          rm = Ctor.rounding;
        } else {
          checkInt32(sd, 1, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
        }
        return round(new Ctor(x), sd, rm);
      };
      P2.toString = P2.valueOf = P2.val = P2.toJSON = function() {
        var x = this, e = getBase10Exponent(x), Ctor = x.constructor;
        return toString(x, e <= Ctor.toExpNeg || e >= Ctor.toExpPos);
      };
      function add(x, y) {
        var carry, d, e, i, k, len, xd, yd, Ctor = x.constructor, pr = Ctor.precision;
        if (!x.s || !y.s) {
          if (!y.s) y = new Ctor(x);
          return external ? round(y, pr) : y;
        }
        xd = x.d;
        yd = y.d;
        k = x.e;
        e = y.e;
        xd = xd.slice();
        i = k - e;
        if (i) {
          if (i < 0) {
            d = xd;
            i = -i;
            len = yd.length;
          } else {
            d = yd;
            e = k;
            len = xd.length;
          }
          k = Math.ceil(pr / LOG_BASE);
          len = k > len ? k + 1 : len + 1;
          if (i > len) {
            i = len;
            d.length = 1;
          }
          d.reverse();
          for (; i--; ) d.push(0);
          d.reverse();
        }
        len = xd.length;
        i = yd.length;
        if (len - i < 0) {
          i = len;
          d = yd;
          yd = xd;
          xd = d;
        }
        for (carry = 0; i; ) {
          carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
          xd[i] %= BASE;
        }
        if (carry) {
          xd.unshift(carry);
          ++e;
        }
        for (len = xd.length; xd[--len] == 0; ) xd.pop();
        y.d = xd;
        y.e = e;
        return external ? round(y, pr) : y;
      }
      function checkInt32(i, min, max) {
        if (i !== ~~i || i < min || i > max) {
          throw Error(invalidArgument + i);
        }
      }
      function digitsToString(d) {
        var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
        if (indexOfLastWord > 0) {
          str += w;
          for (i = 1; i < indexOfLastWord; i++) {
            ws = d[i] + "";
            k = LOG_BASE - ws.length;
            if (k) str += getZeroString(k);
            str += ws;
          }
          w = d[i];
          ws = w + "";
          k = LOG_BASE - ws.length;
          if (k) str += getZeroString(k);
        } else if (w === 0) {
          return "0";
        }
        for (; w % 10 === 0; ) w /= 10;
        return str + w;
      }
      var divide = /* @__PURE__ */ (function() {
        function multiplyInteger(x, k) {
          var temp, carry = 0, i = x.length;
          for (x = x.slice(); i--; ) {
            temp = x[i] * k + carry;
            x[i] = temp % BASE | 0;
            carry = temp / BASE | 0;
          }
          if (carry) x.unshift(carry);
          return x;
        }
        function compare2(a, b, aL, bL) {
          var i, r;
          if (aL != bL) {
            r = aL > bL ? 1 : -1;
          } else {
            for (i = r = 0; i < aL; i++) {
              if (a[i] != b[i]) {
                r = a[i] > b[i] ? 1 : -1;
                break;
              }
            }
          }
          return r;
        }
        function subtract2(a, b, aL) {
          var i = 0;
          for (; aL--; ) {
            a[aL] -= i;
            i = a[aL] < b[aL] ? 1 : 0;
            a[aL] = i * BASE + a[aL] - b[aL];
          }
          for (; !a[0] && a.length > 1; ) a.shift();
        }
        return function(x, y, pr, dp) {
          var cmp, e, i, k, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign2 = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
          if (!x.s) return new Ctor(x);
          if (!y.s) throw Error(decimalError + "Division by zero");
          e = x.e - y.e;
          yL = yd.length;
          xL = xd.length;
          q = new Ctor(sign2);
          qd = q.d = [];
          for (i = 0; yd[i] == (xd[i] || 0); ) ++i;
          if (yd[i] > (xd[i] || 0)) --e;
          if (pr == null) {
            sd = pr = Ctor.precision;
          } else if (dp) {
            sd = pr + (getBase10Exponent(x) - getBase10Exponent(y)) + 1;
          } else {
            sd = pr;
          }
          if (sd < 0) return new Ctor(0);
          sd = sd / LOG_BASE + 2 | 0;
          i = 0;
          if (yL == 1) {
            k = 0;
            yd = yd[0];
            sd++;
            for (; (i < xL || k) && sd--; i++) {
              t = k * BASE + (xd[i] || 0);
              qd[i] = t / yd | 0;
              k = t % yd | 0;
            }
          } else {
            k = BASE / (yd[0] + 1) | 0;
            if (k > 1) {
              yd = multiplyInteger(yd, k);
              xd = multiplyInteger(xd, k);
              yL = yd.length;
              xL = xd.length;
            }
            xi = yL;
            rem = xd.slice(0, yL);
            remL = rem.length;
            for (; remL < yL; ) rem[remL++] = 0;
            yz = yd.slice();
            yz.unshift(0);
            yd0 = yd[0];
            if (yd[1] >= BASE / 2) ++yd0;
            do {
              k = 0;
              cmp = compare2(yd, rem, yL, remL);
              if (cmp < 0) {
                rem0 = rem[0];
                if (yL != remL) rem0 = rem0 * BASE + (rem[1] || 0);
                k = rem0 / yd0 | 0;
                if (k > 1) {
                  if (k >= BASE) k = BASE - 1;
                  prod = multiplyInteger(yd, k);
                  prodL = prod.length;
                  remL = rem.length;
                  cmp = compare2(prod, rem, prodL, remL);
                  if (cmp == 1) {
                    k--;
                    subtract2(prod, yL < prodL ? yz : yd, prodL);
                  }
                } else {
                  if (k == 0) cmp = k = 1;
                  prod = yd.slice();
                }
                prodL = prod.length;
                if (prodL < remL) prod.unshift(0);
                subtract2(rem, prod, remL);
                if (cmp == -1) {
                  remL = rem.length;
                  cmp = compare2(yd, rem, yL, remL);
                  if (cmp < 1) {
                    k++;
                    subtract2(rem, yL < remL ? yz : yd, remL);
                  }
                }
                remL = rem.length;
              } else if (cmp === 0) {
                k++;
                rem = [0];
              }
              qd[i++] = k;
              if (cmp && rem[0]) {
                rem[remL++] = xd[xi] || 0;
              } else {
                rem = [xd[xi]];
                remL = 1;
              }
            } while ((xi++ < xL || rem[0] !== void 0) && sd--);
          }
          if (!qd[0]) qd.shift();
          q.e = e;
          return round(q, dp ? pr + getBase10Exponent(q) + 1 : pr);
        };
      })();
      function exp(x, sd) {
        var denominator, guard, pow, sum, t, wpr, i = 0, k = 0, Ctor = x.constructor, pr = Ctor.precision;
        if (getBase10Exponent(x) > 16) throw Error(exponentOutOfRange + getBase10Exponent(x));
        if (!x.s) return new Ctor(ONE);
        if (sd == null) {
          external = false;
          wpr = pr;
        } else {
          wpr = sd;
        }
        t = new Ctor(0.03125);
        while (x.abs().gte(0.1)) {
          x = x.times(t);
          k += 5;
        }
        guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
        wpr += guard;
        denominator = pow = sum = new Ctor(ONE);
        Ctor.precision = wpr;
        for (; ; ) {
          pow = round(pow.times(x), wpr);
          denominator = denominator.times(++i);
          t = sum.plus(divide(pow, denominator, wpr));
          if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
            while (k--) sum = round(sum.times(sum), wpr);
            Ctor.precision = pr;
            return sd == null ? (external = true, round(sum, pr)) : sum;
          }
          sum = t;
        }
      }
      function getBase10Exponent(x) {
        var e = x.e * LOG_BASE, w = x.d[0];
        for (; w >= 10; w /= 10) e++;
        return e;
      }
      function getLn10(Ctor, sd, pr) {
        if (sd > Ctor.LN10.sd()) {
          external = true;
          if (pr) Ctor.precision = pr;
          throw Error(decimalError + "LN10 precision limit exceeded");
        }
        return round(new Ctor(Ctor.LN10), sd);
      }
      function getZeroString(k) {
        var zs = "";
        for (; k--; ) zs += "0";
        return zs;
      }
      function ln(y, sd) {
        var c, c0, denominator, e, numerator, sum, t, wpr, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, pr = Ctor.precision;
        if (x.s < 1) throw Error(decimalError + (x.s ? "NaN" : "-Infinity"));
        if (x.eq(ONE)) return new Ctor(0);
        if (sd == null) {
          external = false;
          wpr = pr;
        } else {
          wpr = sd;
        }
        if (x.eq(10)) {
          if (sd == null) external = true;
          return getLn10(Ctor, wpr);
        }
        wpr += guard;
        Ctor.precision = wpr;
        c = digitsToString(xd);
        c0 = c.charAt(0);
        e = getBase10Exponent(x);
        if (Math.abs(e) < 15e14) {
          while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
            x = x.times(y);
            c = digitsToString(x.d);
            c0 = c.charAt(0);
            n++;
          }
          e = getBase10Exponent(x);
          if (c0 > 1) {
            x = new Ctor("0." + c);
            e++;
          } else {
            x = new Ctor(c0 + "." + c.slice(1));
          }
        } else {
          t = getLn10(Ctor, wpr + 2, pr).times(e + "");
          x = ln(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
          Ctor.precision = pr;
          return sd == null ? (external = true, round(x, pr)) : x;
        }
        sum = numerator = x = divide(x.minus(ONE), x.plus(ONE), wpr);
        x2 = round(x.times(x), wpr);
        denominator = 3;
        for (; ; ) {
          numerator = round(numerator.times(x2), wpr);
          t = sum.plus(divide(numerator, new Ctor(denominator), wpr));
          if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
            sum = sum.times(2);
            if (e !== 0) sum = sum.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
            sum = divide(sum, new Ctor(n), wpr);
            Ctor.precision = pr;
            return sd == null ? (external = true, round(sum, pr)) : sum;
          }
          sum = t;
          denominator += 2;
        }
      }
      function parseDecimal(x, str) {
        var e, i, len;
        if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
        if ((i = str.search(/e/i)) > 0) {
          if (e < 0) e = i;
          e += +str.slice(i + 1);
          str = str.substring(0, i);
        } else if (e < 0) {
          e = str.length;
        }
        for (i = 0; str.charCodeAt(i) === 48; ) ++i;
        for (len = str.length; str.charCodeAt(len - 1) === 48; ) --len;
        str = str.slice(i, len);
        if (str) {
          len -= i;
          e = e - i - 1;
          x.e = mathfloor(e / LOG_BASE);
          x.d = [];
          i = (e + 1) % LOG_BASE;
          if (e < 0) i += LOG_BASE;
          if (i < len) {
            if (i) x.d.push(+str.slice(0, i));
            for (len -= LOG_BASE; i < len; ) x.d.push(+str.slice(i, i += LOG_BASE));
            str = str.slice(i);
            i = LOG_BASE - str.length;
          } else {
            i -= len;
          }
          for (; i--; ) str += "0";
          x.d.push(+str);
          if (external && (x.e > MAX_E || x.e < -MAX_E)) throw Error(exponentOutOfRange + e);
        } else {
          x.s = 0;
          x.e = 0;
          x.d = [0];
        }
        return x;
      }
      function round(x, sd, rm) {
        var i, j, k, n, rd, doRound, w, xdi, xd = x.d;
        for (n = 1, k = xd[0]; k >= 10; k /= 10) n++;
        i = sd - n;
        if (i < 0) {
          i += LOG_BASE;
          j = sd;
          w = xd[xdi = 0];
        } else {
          xdi = Math.ceil((i + 1) / LOG_BASE);
          k = xd.length;
          if (xdi >= k) return x;
          w = k = xd[xdi];
          for (n = 1; k >= 10; k /= 10) n++;
          i %= LOG_BASE;
          j = i - LOG_BASE + n;
        }
        if (rm !== void 0) {
          k = mathpow(10, n - j - 1);
          rd = w / k % 10 | 0;
          doRound = sd < 0 || xd[xdi + 1] !== void 0 || w % k;
          doRound = rm < 4 ? (rd || doRound) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || doRound || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
          (i > 0 ? j > 0 ? w / mathpow(10, n - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
        }
        if (sd < 1 || !xd[0]) {
          if (doRound) {
            k = getBase10Exponent(x);
            xd.length = 1;
            sd = sd - k - 1;
            xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
            x.e = mathfloor(-sd / LOG_BASE) || 0;
          } else {
            xd.length = 1;
            xd[0] = x.e = x.s = 0;
          }
          return x;
        }
        if (i == 0) {
          xd.length = xdi;
          k = 1;
          xdi--;
        } else {
          xd.length = xdi + 1;
          k = mathpow(10, LOG_BASE - i);
          xd[xdi] = j > 0 ? (w / mathpow(10, n - j) % mathpow(10, j) | 0) * k : 0;
        }
        if (doRound) {
          for (; ; ) {
            if (xdi == 0) {
              if ((xd[0] += k) == BASE) {
                xd[0] = 1;
                ++x.e;
              }
              break;
            } else {
              xd[xdi] += k;
              if (xd[xdi] != BASE) break;
              xd[xdi--] = 0;
              k = 1;
            }
          }
        }
        for (i = xd.length; xd[--i] === 0; ) xd.pop();
        if (external && (x.e > MAX_E || x.e < -MAX_E)) {
          throw Error(exponentOutOfRange + getBase10Exponent(x));
        }
        return x;
      }
      function subtract(x, y) {
        var d, e, i, j, k, len, xd, xe, xLTy, yd, Ctor = x.constructor, pr = Ctor.precision;
        if (!x.s || !y.s) {
          if (y.s) y.s = -y.s;
          else y = new Ctor(x);
          return external ? round(y, pr) : y;
        }
        xd = x.d;
        yd = y.d;
        e = y.e;
        xe = x.e;
        xd = xd.slice();
        k = xe - e;
        if (k) {
          xLTy = k < 0;
          if (xLTy) {
            d = xd;
            k = -k;
            len = yd.length;
          } else {
            d = yd;
            e = xe;
            len = xd.length;
          }
          i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
          if (k > i) {
            k = i;
            d.length = 1;
          }
          d.reverse();
          for (i = k; i--; ) d.push(0);
          d.reverse();
        } else {
          i = xd.length;
          len = yd.length;
          xLTy = i < len;
          if (xLTy) len = i;
          for (i = 0; i < len; i++) {
            if (xd[i] != yd[i]) {
              xLTy = xd[i] < yd[i];
              break;
            }
          }
          k = 0;
        }
        if (xLTy) {
          d = xd;
          xd = yd;
          yd = d;
          y.s = -y.s;
        }
        len = xd.length;
        for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
        for (i = yd.length; i > k; ) {
          if (xd[--i] < yd[i]) {
            for (j = i; j && xd[--j] === 0; ) xd[j] = BASE - 1;
            --xd[j];
            xd[i] += BASE;
          }
          xd[i] -= yd[i];
        }
        for (; xd[--len] === 0; ) xd.pop();
        for (; xd[0] === 0; xd.shift()) --e;
        if (!xd[0]) return new Ctor(0);
        y.d = xd;
        y.e = e;
        return external ? round(y, pr) : y;
      }
      function toString(x, isExp, sd) {
        var k, e = getBase10Exponent(x), str = digitsToString(x.d), len = str.length;
        if (isExp) {
          if (sd && (k = sd - len) > 0) {
            str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
          } else if (len > 1) {
            str = str.charAt(0) + "." + str.slice(1);
          }
          str = str + (e < 0 ? "e" : "e+") + e;
        } else if (e < 0) {
          str = "0." + getZeroString(-e - 1) + str;
          if (sd && (k = sd - len) > 0) str += getZeroString(k);
        } else if (e >= len) {
          str += getZeroString(e + 1 - len);
          if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
        } else {
          if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
          if (sd && (k = sd - len) > 0) {
            if (e + 1 === len) str += ".";
            str += getZeroString(k);
          }
        }
        return x.s < 0 ? "-" + str : str;
      }
      function truncate(arr, len) {
        if (arr.length > len) {
          arr.length = len;
          return true;
        }
      }
      function clone(obj) {
        var i, p, ps;
        function Decimal3(value) {
          var x = this;
          if (!(x instanceof Decimal3)) return new Decimal3(value);
          x.constructor = Decimal3;
          if (value instanceof Decimal3) {
            x.s = value.s;
            x.e = value.e;
            x.d = (value = value.d) ? value.slice() : value;
            return;
          }
          if (typeof value === "number") {
            if (value * 0 !== 0) {
              throw Error(invalidArgument + value);
            }
            if (value > 0) {
              x.s = 1;
            } else if (value < 0) {
              value = -value;
              x.s = -1;
            } else {
              x.s = 0;
              x.e = 0;
              x.d = [0];
              return;
            }
            if (value === ~~value && value < 1e7) {
              x.e = 0;
              x.d = [value];
              return;
            }
            return parseDecimal(x, value.toString());
          } else if (typeof value !== "string") {
            throw Error(invalidArgument + value);
          }
          if (value.charCodeAt(0) === 45) {
            value = value.slice(1);
            x.s = -1;
          } else {
            x.s = 1;
          }
          if (isDecimal.test(value)) parseDecimal(x, value);
          else throw Error(invalidArgument + value);
        }
        Decimal3.prototype = P2;
        Decimal3.ROUND_UP = 0;
        Decimal3.ROUND_DOWN = 1;
        Decimal3.ROUND_CEIL = 2;
        Decimal3.ROUND_FLOOR = 3;
        Decimal3.ROUND_HALF_UP = 4;
        Decimal3.ROUND_HALF_DOWN = 5;
        Decimal3.ROUND_HALF_EVEN = 6;
        Decimal3.ROUND_HALF_CEIL = 7;
        Decimal3.ROUND_HALF_FLOOR = 8;
        Decimal3.clone = clone;
        Decimal3.config = Decimal3.set = config;
        if (obj === void 0) obj = {};
        if (obj) {
          ps = ["precision", "rounding", "toExpNeg", "toExpPos", "LN10"];
          for (i = 0; i < ps.length; ) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
        }
        Decimal3.config(obj);
        return Decimal3;
      }
      function config(obj) {
        if (!obj || typeof obj !== "object") {
          throw Error(decimalError + "Object expected");
        }
        var i, p, v, ps = [
          "precision",
          1,
          MAX_DIGITS,
          "rounding",
          0,
          8,
          "toExpNeg",
          -1 / 0,
          0,
          "toExpPos",
          0,
          1 / 0
        ];
        for (i = 0; i < ps.length; i += 3) {
          if ((v = obj[p = ps[i]]) !== void 0) {
            if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
            else throw Error(invalidArgument + p + ": " + v);
          }
        }
        if ((v = obj[p = "LN10"]) !== void 0) {
          if (v == Math.LN10) this[p] = new this(v);
          else throw Error(invalidArgument + p + ": " + v);
        }
        return this;
      }
      Decimal2 = clone(Decimal2);
      Decimal2["default"] = Decimal2.Decimal = Decimal2;
      ONE = new Decimal2(1);
      if (typeof define == "function" && define.amd) {
        define(function() {
          return Decimal2;
        });
      } else if (typeof module != "undefined" && module.exports) {
        module.exports = Decimal2;
      } else {
        if (!globalScope) {
          globalScope = typeof self != "undefined" && self && self.self == self ? self : Function("return this")();
        }
        globalScope.Decimal = Decimal2;
      }
    })(exports);
  }
});

// src/lib/fish/dblDistancePct.ts
var import_decimal;
var init_dblDistancePct = __esm({
  "src/lib/fish/dblDistancePct.ts"() {
    import_decimal = __toESM(require_decimal(), 1);
  }
});

// src/lib/fish/qualityPositionManagement.ts
function validateQualityPositionManagement(settings) {
  const { version, leverage, notional } = settings;
  if (version !== QUALITY_POSITION_MANAGEMENT_VERSION) throw Error("\u65E0\u6CD5\u8BC6\u522B\u4ED3\u4F4D\u7BA1\u7406\u7248\u672C");
  if (!Number.isFinite(leverage) || leverage < 1) throw Error("\u6760\u6746\u987B\u4E3A\u4E0D\u4F4E\u4E8E 1 \u7684\u6709\u9650\u6570\u5B57");
  if (!Number.isFinite(notional) || notional <= 0 || notional / leverage <= 0) throw Error("\u540D\u4E49\u4ED3\u4F4D\u987B\u4E3A\u5927\u4E8E 0 \u7684\u6709\u9650\u6570\u5B57");
}
function qualityPositionIdentity(settings) {
  return [settings.version, settings.leverage, settings.notional];
}
var QUALITY_POSITION_MANAGEMENT_VERSION;
var init_qualityPositionManagement = __esm({
  "src/lib/fish/qualityPositionManagement.ts"() {
    QUALITY_POSITION_MANAGEMENT_VERSION = "holding-position-management-v1";
  }
});

// src/lib/fish/quality.ts
var qualityComboIdentity, qualityVetoVersion;
var init_quality = __esm({
  "src/lib/fish/quality.ts"() {
    init_preEntryThreeStage();
    init_thresholdRange();
    init_holdingImpulse1115Classification();
    init_qualityHoldingLedger();
    init_qualityBoxStop();
    init_qualityAdmissionTime();
    init_preEntryWindowLoader();
    init_qualityInitialization();
    init_qualityPlanRouter();
    init_qualityAdvantage();
    init_qualityVetoStages();
    init_qualitySellStages();
    init_qualityAdditionCalculator();
    init_qualityAddition();
    init_qualityAdditionScan();
    init_features();
    init_marketData();
    init_algorithm();
    init_records();
    init_signalLibrary();
    init_qualitySources();
    init_turingReplaySamples();
    init_qualityLegacyEngine();
    init_shared();
    init_qualityScanChunk();
    init_campaignMainPriceChange();
    init_qualityIntrabar();
    init_qualityStaticDrawdownSell();
    init_qualityMirrorDeadline();
    init_qualityMirrorLossReview();
    init_qualityVeto();
    init_qualityMirror();
    init_dblDistancePct();
    init_qualityDbl5Sell();
    init_qualityBoxMarketRepair();
    init_qualityPositionManagement();
    qualityComboIdentity = (g) => g.combo ? [
      "combo-v1",
      g.combo.switchPct,
      g.combo.after.metric,
      g.combo.after.snapshot.featureId,
      g.combo.after.snapshot.definitionKey,
      g.combo.after.snapshot.interval,
      g.combo.after.snapshot.scale,
      g.combo.after.rule.direction,
      g.combo.after.rule.threshold,
      ...g.combo.after.rule.version ? [g.combo.after.rule.version] : [],
      ...g.combo.after.rule.bandThresholds ? [g.combo.after.rule.bandThresholds] : [],
      ...g.combo.after.rule.mirrorScopeVersion ? [g.combo.after.rule.mirrorScopeVersion] : [],
      ...g.combo.after.rule.boxSell ? [g.combo.after.rule.boxSell] : []
    ] : null;
    qualityVetoVersion = (g) => g.vetoFill === "stop" ? "holding-veto-v3" : "holding-veto-v2";
  }
});

// src/lib/fish/qualityAdditionMetric.ts
function timedDefinitionFields(snapshot) {
  if (!snapshot.definitionKey?.includes(ADDITION_INDICATOR_TIME_VERSION)) return [];
  try {
    const parts = JSON.parse(snapshot.definitionKey);
    return Array.isArray(parts) ? parts.slice(4).filter((value) => typeof value === "string") : [];
  } catch {
    return [];
  }
}
var ADDITION_INDICATOR_TIME_VERSION, INDICATOR_PERIOD_VERSION, INDICATOR_FORMULA_TIME_VERSION, hasAdditionMetricTime, hasMetricPeriodOverride, hasMetricFormulaTimeOverride;
var init_qualityAdditionMetric = __esm({
  "src/lib/fish/qualityAdditionMetric.ts"() {
    init_cdaPeriods();
    init_features();
    init_marketData();
    init_algorithm();
    init_quality();
    ADDITION_INDICATOR_TIME_VERSION = "addition-indicator-time-v1";
    INDICATOR_PERIOD_VERSION = "indicator-period-v1";
    INDICATOR_FORMULA_TIME_VERSION = "indicator-formula-time-v1";
    hasAdditionMetricTime = (snapshot) => timedDefinitionFields(snapshot).includes(ADDITION_INDICATOR_TIME_VERSION);
    hasMetricPeriodOverride = (snapshot) => timedDefinitionFields(snapshot).includes(INDICATOR_PERIOD_VERSION);
    hasMetricFormulaTimeOverride = (snapshot) => timedDefinitionFields(snapshot).includes(INDICATOR_FORMULA_TIME_VERSION);
  }
});

// src/lib/fish/qualityPlanParameterCompatibility.ts
function compatibleHoldingParameterOrder(vetoes, frozen) {
  const orders = [
    ["guard_trend_atr", "guard_range_atr", "guard_range_closes"],
    ["guard_range_atr", "guard_trend_atr", "guard_range_closes"]
  ];
  return orders.some((order) => {
    let reordered = false;
    const candidate = (vetoes ?? []).map((v) => {
      if (!v.enabled || v.kind !== "box-stop" || v.boxStop?.structure.algorithm !== "dbl5") return v;
      const rule = v.boxStop, structure = rule.structure, definition = structure.definition, config = definition.DBL5_config;
      if (!config || !order.some((key) => Object.prototype.hasOwnProperty.call(config, key))) return v;
      reordered = true;
      const ordered = Object.fromEntries([
        ...Object.entries(config).filter(([key]) => !order.includes(key)),
        ...order.filter((key) => Object.prototype.hasOwnProperty.call(config, key)).map((key) => [key, config[key]])
      ]);
      return { ...v, boxStop: { ...rule, structure: { ...structure, definition: { ...definition, DBL5_config: ordered } } } };
    });
    return reordered && frozen === "\u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(candidate)));
  });
}
function compatibleAdditionParameterOrder(plan, key, frozen) {
  const rounds = plan.addition?.enabled ? [plan.addition, ...plan.addition.rounds ?? [], ...plan.addition.alternativeRounds ?? []] : [];
  const vetoes = [...plan.preEntryThreeStage?.additionVetoes ?? [], ...plan.preEntryConditions?.entryVetoes ?? [], ...rounds.flatMap((r) => r.entryVetoes ?? [])];
  let value, version;
  if (key === "lower-wick-veto") {
    value = vetoes.filter((v) => v.enabled && v.kind === "lower-wick");
    version = LOWER_WICK_VETO_VERSION;
  } else if (key === "veto-history") {
    value = vetoes.filter((v) => v.enabled && v.historyHours != null && !isFiveMinuteShapeVeto(v));
    version = VETO_HISTORY_VERSION;
  } else if (key === "addition-support-quality") {
    value = rounds.map((r) => (r.entryVetoes ?? []).filter((v) => v.enabled && v.kind === "double-drop")).filter((r) => r.length);
    version = DOUBLE_DROP_VERSION;
  } else return false;
  const editorOrder = ["kind", "enabled", "historyHours", "lookbackBars", "atr", "ratio", "pct", "er", "windows", "join", "sticky"];
  const reorder = (raw, cloud) => {
    if (Array.isArray(raw)) return raw.map((v) => reorder(v, cloud));
    if (!raw || typeof raw !== "object") return raw;
    const object = raw, keys = Object.keys(object);
    const known = "kind" in object ? editorOrder : ["minutes", "pct"];
    const order = cloud ? keys.sort((a, b) => a.length - b.length || (a < b ? -1 : a > b ? 1 : 0)) : [...known.filter((k) => keys.includes(k)), ...keys.filter((k) => !known.includes(k))];
    return Object.fromEntries(order.map((k) => [k, reorder(object[k], cloud)]));
  };
  return [false, true].some((cloud) => frozen === version + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(reorder(value, cloud))));
}
var init_qualityPlanParameterCompatibility = __esm({
  "src/lib/fish/qualityPlanParameterCompatibility.ts"() {
    init_qualityVeto();
    init_algorithm();
    init_qualityAdditionVeto();
    init_qualityDoubleDrop();
  }
});

// src/lib/fish/algorithmMetricMenu.ts
var init_algorithmMetricMenu = __esm({
  "src/lib/fish/algorithmMetricMenu.ts"() {
    init_features();
    init_researchIndicators();
  }
});

// src/lib/fish/qualityFilters.ts
var init_qualityFilters = __esm({
  "src/lib/fish/qualityFilters.ts"() {
    init_qualityMirrorHardStopStages();
    init_qualityMirrorDeadline();
    init_qualityMirrorLossReview();
    init_cdaPeriods();
    init_qualityPostMirrorProtection();
    init_algorithmMetricMenu();
    init_qualityAdditionVeto();
    init_qualityGuardDistance();
    init_qualityBoxStop();
    init_features();
    init_featureSource();
    init_researchIndicators();
    init_algorithm();
    init_qualityVeto();
    init_qualityAdditionMetric();
  }
});

// src/lib/fish/qualityCampaignArchive.ts
var init_qualityCampaignArchive = __esm({
  "src/lib/fish/qualityCampaignArchive.ts"() {
    init_holdingImpulse1115Classification();
    init_qualityAdmissionTime();
    init_qualityAdvantage();
    init_qualityPlanRouter();
    init_qualityVetoStages();
    init_qualityLegacyEngine();
    init_qualityVetoStages();
    init_qualitySellStages();
    init_qualityStaticDrawdownSell();
    init_qualityVeto();
    init_qualityAddition();
    init_qualityMirror();
    init_qualityPositionManagement();
    init_quality();
    init_qualityVeto();
    init_algorithm();
  }
});

// src/lib/fish/qualitySellPlans.ts
var init_qualitySellPlans = __esm({
  "src/lib/fish/qualitySellPlans.ts"() {
    init_holdingImpulse1115Classification();
    init_qualityVetoStages();
    init_qualitySellStages();
    init_features();
    init_qualityFilters();
    init_qualityCampaignArchive();
    init_quality();
    init_qualityPlanVersions();
    init_qualityStaticDrawdownSell();
    init_qualityDbl5Sell();
  }
});

// src/lib/fish/qualityTuringPlan.ts
var init_qualityTuringPlan = __esm({
  "src/lib/fish/qualityTuringPlan.ts"() {
    init_features();
    init_quality();
    init_qualityInitialization();
    init_qualityPlanVersions();
    init_qualitySellPlans();
    init_qualityAdditionMetric();
    init_researchIndicators();
    init_preEntryThreeStage();
  }
});

// src/lib/fish/qualityStaticFilterPlan.ts
var STATIC_FILTER_VERSION;
var init_qualityStaticFilterPlan = __esm({
  "src/lib/fish/qualityStaticFilterPlan.ts"() {
    init_algorithm();
    init_qualityInitialization();
    init_qualityPlanVersions();
    init_qualityTuringPlan();
    STATIC_FILTER_VERSION = "static-filter-v1";
  }
});

// src/lib/fish/qualityPlanVersions.ts
function versionTags(value) {
  const out = [];
  const walk = (x) => {
    if (typeof x === "string") {
      if (VERSION_TAG.test(x) && !out.includes(x)) out.push(x);
    } else if (Array.isArray(x)) x.forEach(walk);
  };
  walk(value);
  return out;
}
function qualityPlanVersions(plan) {
  validateQualityAdvantage(plan);
  const initialization = plan.initialization ? [{ key: "initialization", part: "\u5386\u53F2\u521D\u59CB\u5316", name: "\u56FE\u7075\u676F\u9996\u6839\u884C\u60C5\u521D\u59CB\u5316", version: plan.initialization, summary: "\u4ECE\u5DF2\u6709\u9996\u6839\u5B8C\u6574 K \u7EBF\u521D\u59CB\u5316\uFF1B\u521D\u671F\u65E0\u5B9A\u4E49\u7684\u6307\u6807\u7B49\u5F85\uFF0C\u4E0D\u8865\u9020\u5386\u53F2\u3002\u4E0E\u5B8C\u6574\u5386\u53F2\u9884\u70ED\u8BFB\u6570\u4E0D\u540C\uFF0C\u539F\u65B9\u6848\u4FDD\u7559\u3002" }] : [];
  if (plan.staticFilter) return [...initialization, {
    key: "static-filter",
    part: "\u9759\u6001\u8FC7\u6EE4",
    name: "\u4E70\u524D\u8FC7\u6EE4\u4E0E\u4FE1\u53F7\u65F6\u70B9\u8BFB\u6570",
    version: STATIC_FILTER_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(plan.staticFilter)),
    summary: "\u51BB\u7ED3\u5404\u6761\u8FC7\u6EE4\u6761\u4EF6\u53CA\u4FE1\u53F7\u8BFB\u6570\u7684\u516C\u5F0F\u3001\u53C2\u6570\u3001\u5468\u671F\u548C\u542F\u7528\u72B6\u6001\u3002\u8FC7\u6EE4\u4F7F\u7528\u4E70\u5165\u524D\u6700\u540E\u4E00\u6839\u5DF2\u6536\u76D8 K \u7EBF\u3002"
  }];
  if (plan.firstEntryVetoes?.length) {
    if (plan.firstEntryVetoes.some((rule) => rule.kind !== "indicator")) throw Error("\u9996\u4ED3\u5426\u51B3\u987B\u4F7F\u7528\u6307\u6807\u7B97\u6CD5");
    validateAdditionVetoes(plan.firstEntryVetoes);
    initialization.push({ key: "first-entry-veto", part: "\u9996\u4ED3", name: "\u62D2\u7EDD\u5F00\u4ED3", version: "holding-first-entry-veto-v1 \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(plan.firstEntryVetoes)), summary: "\u9996\u4ED3\u65F6\u8BFB\u53D6\u5404\u7B97\u6CD5\u6700\u8FD1\u5DF2\u6536\u76D8\u503C\uFF0C\u4EFB\u4E00\u542F\u7528\u6761\u4EF6\u547D\u4E2D\u5373\u8DF3\u8FC7\u672C\u6B21\u5F00\u4ED3\u3002" });
  }
  if (plan.positionManagement && !isLegacyQualityPlan(plan)) {
    validateQualityPositionManagement(plan.positionManagement);
    const { version, leverage, notional } = plan.positionManagement;
    initialization.push({
      key: "position-management",
      part: "\u4ED3\u4F4D\u7BA1\u7406",
      name: "\u9996\u4ED3\u540D\u4E49\u4ED3\u4F4D\u4E0E\u6760\u6746",
      version: version + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(qualityPositionIdentity(plan.positionManagement))),
      summary: "\u9996\u4ED3 " + notional + " USDT \xB7 " + leverage + " \u500D\u6760\u6746\u3002\u6309\u540D\u4E49\u91D1\u989D\u8BA1\u7B97\u6210\u4EA4\u6570\u91CF\u3001\u76C8\u4E8F\u4E0E\u52A0\u4ED3\uFF0C\u4FDD\u8BC1\u91D1\u6309\u6760\u6746\u6298\u7B97\u3002"
    });
  }
  if (plan.router) {
    validateQualityRouter(plan.router);
    return [...initialization, { key: "router", part: "\u6761\u4EF6\u5206\u652F", name: "\u7ED3\u6784\u4E3A\u5E95\xB7\u5F3A\u52BF\u8FDB\u653B", version: plan.router.version + " \xB7 \u53C2\u6570 #" + routerFingerprint(plan.router), summary: routerVersionSummary(plan.router) }, ...["structure", "attack"].flatMap((branch) => qualityPlanVersions(plan.router[branch]).map((e) => ({ ...e, key: branch + ":" + e.key, part: (branch === "structure" ? "\u7ED3\u6784\u5206\u652F \xB7 " : "\u8FDB\u653B\u5206\u652F \xB7 ") + e.part })))];
  }
  if (isLegacyQualityPlan(plan)) return legacyPlanVersions(plan);
  const out = [...initialization];
  const stallTurn = plan.preEntryThreeStage?.stallTurn;
  if (stallTurn?.enabled) out.push({ key: "entry-stall-turn", part: "\u52A8\u6001\u7B5B\u9009\xB7\u4E00\u7968\u5426\u51B3", name: "\u4E0A\u6DA8\u540E\u6EDE\u6DA8\u8F6C\u5F31\uFF0F\u731B\u70C8\u56DE\u8C03\u672A\u521B\u65B0\u9AD8", version: stallTurn.version + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(stallTurn)), summary: stallTurn.version === ENTRY_STALL_TURN_5M_VERSION ? "\u4EC5\u7528\u5DF2\u6536\u76D85\u5206\u949FK\u7EBF\uFF1B\u4E09\u6BB5\u65F6\u95F4\u4E3A5\u5206\u949F\u6574\u6570\u500D\uFF0C\u6DA8\u4E0D\u52A8\u4E14\u8F6C\u5F31\u65F6\u9501\u5B9A\uFF1B\u8FDE\u7EED5\u5206\u949F\u6536\u76D8\u9012\u5347\u5E76\u6536\u590D\u5C40\u90E8\u9AD8\u70B9\u624D\u89E3\u9664\u3002\u731B\u70C8\u56DE\u8C03\u9501\u5B9A\u987B5\u5206\u949F\u6536\u76D8\u4E25\u683C\u7A81\u7834\u51BB\u7ED3\u524D\u9AD8\u3002\u76D8\u4E2D\u4E0D\u66F4\u65B0\u89E6\u53D1\u6216\u89E3\u9664\uFF0C\u72EC\u7ACB\u5386\u53F2\u91CD\u5EFA\uFF1B\u539F1\u5206\u949F\u6A21\u677F\u7EE7\u7EED\u6309\u539F\u7248\u672C\u6267\u884C\u3002" : "\u4E0A\u6DA8\u3001\u6EDE\u6DA8\u3001\u8F6C\u5F31\u4F9D\u6B21\u6210\u7ACB\u65F6\u9501\u5B9A\uFF0C\u8FDE\u7EED\u6536\u76D8\u9012\u5347\u4E14\u6536\u590D\u5C40\u90E8\u6536\u76D8\u9AD8\u70B9\u624D\u89E3\u9664\uFF1B\u53EF\u540C\u65F6\u542F\u7528\u731B\u70C8\u56DE\u8C03\u9501\u5B9A\uFF0C\u987B\u5206\u949F\u6536\u76D8\u4E25\u683C\u7A81\u7834\u51BB\u7ED3\u524D\u9AD8\u624D\u89E3\u9664\u3002\u4E24\u8005\u4EFB\u4E00\u6210\u7ACB\u5373\u5426\u51B3\uFF0C\u4EC5\u7528\u5DF2\u6536\u76D8\u5206\u949F\uFF0C\u72EC\u7ACB\u5386\u53F2\u91CD\u5EFA\u3002\u7814\u7A76\u521D\u503C\uFF0C\u4E0D\u6539\u53D8\u65E7\u6A21\u677F\u3002" });
  const sharedVetoes = [...plan.preEntryThreeStage?.additionVetoes ?? [], ...plan.preEntryConditions?.entryVetoes ?? [], ...plan.addition?.enabled ? [plan.addition, ...plan.addition.rounds ?? [], ...plan.addition.alternativeRounds ?? []].flatMap((r) => r.entryVetoes ?? []) : []].filter((v) => v.enabled);
  const historicalVetoes = sharedVetoes.filter((v) => v.historyHours != null && !isFiveMinuteShapeVeto(v));
  if (historicalVetoes.length) out.push({ key: "veto-history", part: "\u4E00\u7968\u5426\u51B3", name: "\u72EC\u7ACB\u5386\u53F2\u626B\u63CF\u8303\u56F4", version: VETO_HISTORY_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(historicalVetoes)), summary: "\u6309\u6BCF\u6B21\u5224\u65AD\u65F6\u70B9\u5411\u524D\u56DE\u770B\uFF0C\u5305\u542B\u5165\u9009\u548C\u6301\u4ED3\u4E4B\u524D\u7684\u884C\u60C5\uFF1B\u5F71\u7EBF\u4E0E\u63D2\u9488\u626B\u63CF\u6574\u4E2A\u5386\u53F2\u7A97\u53E3\uFF0C\u9AD8\u9707\u8361\u68C0\u67E5\u7A97\u53E3\u5185\u89C2\u6D4B\uFF0C\u6025\u8DCC\u68C0\u67E5\u7A97\u53E3\u5185\u5206\u949F\u7EBF\uFF1B\u672A\u6536\u590D\u9AD8\u70B9\u9501\u5B9A\u4E0D\u56E0\u91CD\u7B5B\u6216\u7A97\u53E3\u6ED1\u52A8\u6E05\u9664\u3002\u65E7\u8303\u56F4\u53E6\u884C\u4FDD\u7559\u3002" });
  const indicators = sharedVetoes.filter((v) => v.kind === "indicator");
  if (indicators.length) out.push({ key: "shared-indicator-veto", part: "\u5171\u7528\u4E00\u7968\u5426\u51B3", name: "\u7B97\u6CD5\u5426\u51B3", version: INDICATOR_ENTRY_VETO_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(additionVetoIdentity(indicators))), summary: "\u6309\u5404\u7B97\u6CD5\u51BB\u7ED3\u7684\u5468\u671F\u548C\u516C\u5F0F\u8BFB\u53D6\u6700\u8FD1\u5DF2\u6536\u76D8\u503C\u3002\u4EFB\u4E00\u6761\u4EF6\u6210\u7ACB\u5373\u8DF3\u8FC7\u5F53\u524D\u5019\u9009\u3002" });
  const distances = sharedVetoes.filter((v) => v.kind === "guard-distance");
  if (distances.length) out.push({ key: "shared-guard-distance", part: "\u5171\u7528\u4E00\u7968\u5426\u51B3", name: distances.some((v) => v.guardDistance?.parameters.timeframe === "1h") ? "\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC\uFF08\u6309\u6240\u9009\u5468\u671F\uFF09" : "\u8DDD DBL-5 \u9632\u5B88\u7EBF\u8FC7\u8FDC", version: [...new Set(distances.map((v) => v.guardDistance?.version ?? GUARD_DISTANCE_VETO_VERSION))].join(" \xB7 ") + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(additionVetoIdentity(distances))), summary: "\u5019\u9009\u65F6\u70B9\u6700\u8FD1\u7684 1 \u5206\u949F\u6536\u76D8\u4EF7\u9AD8\u51FA\u6240\u9009\u5468\u671F\u9632\u5B88\u7EBF\u8D85\u8FC7 N \u500D\u539F\u751F ATR(14) \u5373\u5426\u51B3\uFF1B\u7F3A\u6709\u6548\u8BFB\u6570\u65F6\u6682\u4E0D\u653E\u884C\u3002" });
  const shapeVetoes = sharedVetoes.filter(isFiveMinuteShapeVeto);
  const boxBreaks = sharedVetoes.filter((v) => v.kind === "box-break");
  validateAdditionVetoes(boxBreaks);
  if (boxBreaks.length) out.push({ key: "shared-box-break", part: "\u5171\u7528\u4E00\u7968\u5426\u51B3", name: "\u6301\u4ED3\uFF0F\u7B5B\u9009\u671F\u95F4\u7BB1\u4F53\u65AD\u88C2", version: BOX_BREAK_VETO_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(additionVetoIdentity(boxBreaks))), summary: "\u6309\u51BB\u7ED3\u5468\u671F\u548C\u9632\u5B88\u7EBF\u53C2\u6570\uFF0C\u4ECE\u672C\u6B21\u6301\u4ED3\u6216\u7B5B\u9009\u8D77\u70B9\u7D2F\u8BA1\u539F\u751F\u7EA2\u53C9\u3002\u9996\u6B21\u5DF2\u786E\u8BA4\u65AD\u88C2\u540E\uFF0C\u52FE\u9009\u8BE5\u6761\u4EF6\u7684\u52A0\u4ED3\u5206\u652F\u6216\u7B5B\u9009\u6301\u7EED\u5426\u51B3\uFF1B\u9884\u70ED\u4E8B\u4EF6\u4E0D\u8BA1\u5165\u3001\u91CD\u5EFA\u4E0E\u91CD\u7B5B\u4E0D\u89E3\u9664\u3001\u6062\u590D\u65F6\u91CD\u5EFA\u539F\u59CB\u5386\u53F2\u3002\u672C\u6761\u4EF6\u672C\u8EAB\u4E0D\u5356\u51FA\uFF0C\u4E3B\u5206\u652F\u4E0E\u5907\u9009\u5206\u652F\u5404\u81EA\u52FE\u9009\u3002" });
  for (const kind of ["stall-turn", "pullback-new-high"]) {
    const rules2 = shapeVetoes.filter((v) => v.kind === kind);
    if (rules2.length) out.push({ key: "shared-" + kind, part: "\u5171\u7528\u4E00\u7968\u5426\u51B3", name: kind === "stall-turn" ? "\u6EDE\u6DA8\u8F6C\u5F31\uFF085\u5206\u949F\uFF09" : "\u731B\u70C8\u56DE\u8C03\u672A\u521B\u65B0\u9AD8\uFF085\u5206\u949F\uFF09", version: (kind === "stall-turn" ? ENTRY_STALL_TURN_5M_VERSION : PULLBACK_NEW_HIGH_5M_VERSION) + " \xB7 \u53C2\u6570 #" + shortFishHash(stableEntryJson(rules2)), summary: "\u52A8\u6001\u7B5B\u9009\u4E0E\u6301\u4ED3\u52A0\u4ED3\u5171\u7528\u3001\u72EC\u7ACB\u5F00\u5173\uFF1B\u53EA\u57285\u5206\u949F\u6536\u76D8\u540E\u66F4\u65B0\uFF0C\u72EC\u7ACB\u56DE\u770B\u548C\u6062\u590D\u9501\u5B9A\uFF0C\u4E0D\u6539\u5199\u65E7\u6A21\u677F\u3002" });
  }
  const lowerWicks = [...plan.preEntryThreeStage?.additionVetoes ?? [], ...plan.preEntryConditions?.entryVetoes ?? [], ...plan.addition?.enabled ? [plan.addition, ...plan.addition.rounds ?? [], ...plan.addition.alternativeRounds ?? []].flatMap((r) => r.entryVetoes ?? []) : []].filter((v) => v.enabled && v.kind === "lower-wick");
  if (lowerWicks.length) out.push({ key: "lower-wick-veto", part: "\u4E00\u7968\u5426\u51B3", name: "\u957F\u4E0B\u5F71\u7EBF", version: LOWER_WICK_VETO_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(lowerWicks)), summary: "\u53EA\u8BFB\u5DF2\u6536\u76D8 5 \u5206\u949F K \u7EBF\uFF1B\u4E0B\u5F71\uFF1Dmin(\u5F00\u76D8,\u6536\u76D8)\u2212\u6700\u4F4E\u4EF7\uFF0C\u957F\u5EA6\u8FBE\u5230 ATR \u500D\u6570\u4E14\u5360\u6574\u6839\u632F\u5E45\u8FBE\u5230\u6BD4\u4F8B\u65F6\u5426\u51B3\uFF0C\u4E0E\u957F\u4E0A\u5F71\u7EBF\u5BF9\u79F0\u3002" });
  const combination = plan.preEntryThreeStage?.admission?.combination;
  if (combination) out.push({ key: "entry-admission-combination", part: "\u52A8\u6001\u7B5B\u9009", name: combination.join === "all" ? "\u4E8B\u4EF6\u51C6\u5165 \xB7 \u4F18\u5148\u4EA4\u96C6" : "\u4E8B\u4EF6\u51C6\u5165 \xB7 \u5E76\u96C6", version: combination.version, summary: "\u4EA4\u96C6\u6309\u9996\u4F4D\u542F\u7528\u4E8B\u4EF6\u7684\u65B0\u89E6\u53D1\u65F6\u70B9\uFF0C\u4F9D\u6B21\u6838\u5BF9\u5176\u4F59\u4E8B\u4EF6\uFF1B\u5E76\u96C6\u6CBF\u7528\u5404\u4E8B\u4EF6\u72EC\u7ACB\u51C6\u5165\u3002" });
  if (plan.preEntryThreeStage?.admission?.algorithms.some((rule) => rule.range)) out.push({ key: "entry-admission-range", part: "\u52A8\u6001\u7B5B\u9009", name: "\u4E8B\u4EF6\u51C6\u5165\u533A\u95F4", version: "entry-admission-range-v1", summary: "\u533A\u95F4\u5305\u542B\u8FB9\u754C\uFF0C\u5141\u8BB8\u53EA\u586B\u4E00\u7AEF\u3002" });
  if (plan.preEntryThreeStage) out.push({ key: "pre-entry-three-stage", part: "\u52A8\u6001\u7B5B\u9009", name: "\u4E09\u9636\u540C\u523B\u51C6\u5165", version: plan.preEntryThreeStage.version + " \xB7 \u53C2\u6570 #" + threeStageFingerprint(plan.preEntryThreeStage), summary: plan.preEntryThreeStage.version === PRE_ENTRY_SIGNAL_ANCHOR_VERSION ? "\u8DF3\u8FC7\u4E8B\u4EF6\u51C6\u5165\u65F6\uFF0C\u6309\u539F\u4FE1\u53F7\u65F6\u70B9\u6216\u52A8\u6001\u95E8\u69DB\u9996\u6B21\u8FBE\u6807\u65F6\u70B9\u68C0\u67E5\u6392\u9664\uFF0C\u68C0\u67E5\u901A\u8FC7\u540E\u5728\u8BE5\u65F6\u70B9\u5165\u9009\u3002\u542F\u7528\u4E8B\u4EF6\u51C6\u5165\u65F6\uFF0C\u6309\u901A\u8FC7\u6392\u9664\u68C0\u67E5\u7684\u5019\u9009\u4E8B\u4EF6\u65F6\u70B9\u5165\u9009\u3002" : plan.preEntryThreeStage.version === PRE_ENTRY_OPTIONAL_STAGES_VERSION ? "\u5FC5\u8981\u6761\u4EF6\u3001\u4E8B\u4EF6\u51C6\u5165\u3001\u6392\u9664\u68C0\u67E5\u5404\u81EA\u542F\u7528\u6216\u8DF3\u8FC7\u3002\u9996\u6B21\u5177\u5907\u8D44\u683C\u65F6\uFF0C\u5DF2\u8FBE\u6807\u7684\u51C6\u5165\u6307\u6807\u53EF\u7ACB\u5373\u4EA7\u751F\u5019\u9009\u3002\u5426\u51B3\u540E\u7EE7\u7EED\u89C2\u5BDF\uFF0C\u6CBF\u7528\u539F\u603B\u622A\u6B62\u65F6\u95F4\u3002" : plan.preEntryThreeStage.version === "pre-entry-three-stage-v9" ? "\u4E24\u9879\u5747\u542F\u7528\u65F6\u5148\u5224\u9759\u6001\u95E8\u69DB\u3002\u9759\u6001\u8FBE\u6807\u5373\u89C2\u5BDF\u65B0\u4E8B\u4EF6\uFF0C\u672A\u901A\u8FC7\u624D\u8FDB\u5165\u52A8\u6001\u8FFD\u8E2A\uFF0C\u6CBF\u7528\u539F\u603B\u622A\u6B62\u65F6\u95F4\u3002" : plan.preEntryThreeStage.version === "pre-entry-three-stage-v8" ? "\u5FC5\u8981\u6761\u4EF6\u53EA\u5728\u539F\u4FE1\u53F7\u65F6\u70B9\u5224\u5B9A\u4E00\u6B21\uFF1B\u4EFB\u4E00\u65B0\u4E8B\u4EF6\u89E6\u53D1\u5019\u9009\u540E\u5411\u524D\u68C0\u67E5\u6392\u9664\u6761\u4EF6\uFF0C\u5426\u51B3\u540E\u7EE7\u7EED\u627E\u4E0B\u4E00\u6B21\u65B0\u4E8B\u4EF6\u3002\u9996\u6B21\u6EE1\u8DB3\u65F6\u95F4\u4E3A\u901A\u8FC7\u6392\u9664\u68C0\u67E5\u7684\u65B0\u4E8B\u4EF6\u65F6\u523B\u3002" : plan.preEntryThreeStage.observationBasis === "retry-origin-v2" ? "\u591A\u6761\u51C6\u5165\u7B97\u6CD5\u53D6\u6216\uFF0C\u5FC5\u8981\u6761\u4EF6\u548C\u6392\u9664\u95E8\u69DB\u4ECD\u987B\u540C\u523B\u901A\u8FC7\uFF1B\u5426\u51B3\u540E\u4ECE\u4E0B\u4E00\u5206\u949F\u91CD\u5EFA\u89C2\u5BDF\u8D77\u70B9\uFF1B\u539F\u95E8\u69DB\u548C\u603B\u622A\u6B62\u65F6\u95F4\u4E0D\u53D8\uFF1B\u6307\u6807\u4FDD\u7559\u9884\u70ED\uFF0C\u539F\u751F\u9632\u5B88\u7EBF\u4E0D\u91CD\u542F\u3001\u65E7\u4E8B\u4EF6\u4E0D\u5EF6\u671F\u5151\u73B0\u3002" : "\u52A0\u4ED3\u5171\u7528\u8D44\u683C\u3001\u5B8C\u6574\u5356\u51FA\u6392\u9664\u53CA\u539F\u751F\u9632\u5B88\u7EBF\u66F4\u65B0\u540C\u523B\u5224\u65AD\uFF1B\u89C2\u5BDF\u8D77\u70B9\u56FA\u5B9A\uFF0C\u65E7\u4E8B\u4EF6\u4E0D\u5EF6\u671F\u5151\u73B0\u3002" });
  if (plan.preEntryConditions) out.push({ key: "pre-entry-conditions", part: "\u52A8\u6001\u7B5B\u9009", name: "\u5165\u9009\u6761\u4EF6\u4E0E\u4E09\u7EC4\u5426\u51B3", version: preEntryConditionsVersion(plan), summary: "\u540C\u4E00\u5206\u949F\u5165\u9009\u6761\u4EF6\u5168\u90E8\u6EE1\u8DB3\u4E14\u65E0\u5426\u51B3\uFF1B\u4ECE\u7B5B\u9009\u8D77\u70B9\u7D2F\u8BA1\u89C2\u5BDF\uFF0C\u4E0D\u6A21\u62DF\u6301\u4ED3\uFF0C\u65E7\u8F6E\u6B21\u4E0D\u5347\u7EA7\u3002" });
  const add = (key, part, name, version, summary) => out.push({ key, part, name, version, summary });
  if (plan.impulse1115Classification) add(
    "holding-impulse-1115-classification",
    "\u6301\u4ED3\u76D1\u6D4B",
    "\u6025\u62C9\u7EBF1115\u6301\u4ED3\u5206\u7C7B",
    HOLDING_IMPULSE_1115_CLASSIFICATION_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingImpulse1115Identity(plan.impulse1115Classification))),
    "\u53EA\u8BFB\u53D6\u539F\u751F\u5DF2\u6536\u76D85m\u5206\u7C7B\uFF0C\u9010\u65B9\u6848\u51BB\u7ED3\u53C2\u6570\u548C\u7248\u672C\uFF1B\u6682\u505C\u7EED\u7B97\u4FDD\u7559\u6BCF\u6761\u7EBF\u7684\u5386\u53F2\uFF0C\u4E0D\u4EA7\u751F\u4EFB\u4F55\u4EA4\u6613\u52A8\u4F5C\u3002"
  );
  const s = plan.snapshot;
  const screening = plan.preEntryThreeStage;
  const metricSnapshots = [
    s,
    plan.combo?.after.snapshot,
    ...(plan.buyFilters ?? []).map((rule) => rule.snapshot),
    ...(plan.holdingVetoes ?? []).map((rule) => rule.snapshot),
    ...(plan.vetoStages ?? []).flatMap((stage) => stage.conditions.map((rule) => rule.snapshot)),
    ...(plan.sellStages ?? []).map((stage) => stage.snapshot),
    ...[plan.addition, ...plan.addition?.rounds ?? [], ...plan.addition?.alternativeRounds ?? []].flatMap((round) => round ? [
      ...qualityAdditionConditions(round),
      ...qualityAdditionPrerequisites(round),
      ...round.indicatorIncrease?.metrics ?? []
    ].map((rule) => rule.snapshot) : []),
    ...(screening?.required ?? []).map((rule) => rule.snapshot),
    ...(screening?.admission?.algorithms ?? []).map((rule) => rule.snapshot),
    ...(screening?.sellRules ?? []).flatMap((rule) => expressionConditions(rule.expression).map((condition) => condition.snapshot)),
    ...(screening?.hardVetoes ?? []).map((rule) => rule.snapshot)
  ].filter((snapshot) => !!snapshot);
  const impulseClassifications = metricSnapshots.filter((s2) => s2.definitionKey?.includes(IMPULSE_1115_CLASSIFICATION_VERSION));
  if (impulseClassifications.length) add(
    "impulse-1115-classification",
    "\u6301\u4ED3\u6307\u6807",
    IMPULSE_1115_CLASSIFICATION_LABEL,
    join2([IMPULSE_1115_CLASSIFICATION_VERSION, ...new Set(impulseClassifications.map(formulaFingerprint))]),
    "\u51BB\u7ED3\u6BCF\u6761\u6025\u62C9\u7EBF\u7684\u4E00\u7C7B/\u4E8C\u7C7B\u3001\u7EC6\u5206\u53CA\u8FC7\u6E21\u72B6\u6001\uFF0C\u4FDD\u7559\u523A\u7A7F\u3001\u8DCC\u7834\u3001\u6536\u590D\u548C\u72EC\u7ACB\u6D4B\u8BD5\u8BC1\u636E\uFF1B\u5206\u7C7B\u4E0D\u81EA\u884C\u89E6\u53D1\u4EA4\u6613\u3002"
  );
  const hourlyCda = metricSnapshots.filter((s2) => s2.featureId === CDA_HOURLY_ID || s2.definitionKey?.includes('"chart=' + CDA_HOURLY_ID + '"'));
  if (hourlyCda.length) add(
    "cda-hourly",
    "\u6307\u6807\u5468\u671F",
    CDA_HOURLY_LABEL,
    join2([CDA_HOURLY_ID, ...new Set(hourlyCda.map(formulaFingerprint))]),
    "\u539F\u751F 1 \u5C0F\u65F6 K \u7EBF\uFF0C\u72EC\u7ACB\u51BB\u7ED3\u516C\u5F0F\u3001\u56DE\u770B\u7A97\u53E3\u548C\u534A\u8870\u671F\u3002"
  );
  const periodSnapshots = metricSnapshots.filter(hasMetricPeriodOverride);
  if (periodSnapshots.length) add(
    "indicator-period",
    "\u6307\u6807\u5468\u671F",
    "\u9010\u6761\u51BB\u7ED3 K \u7EBF\u5468\u671F",
    join2([INDICATOR_PERIOD_VERSION, ...new Set(periodSnapshots.map(formulaFingerprint))]),
    "\u6309\u6BCF\u6761\u6307\u6807\u4FDD\u5B58\u7684\u5468\u671F\u8BFB\u6570\u6216\u9010\u5206\u949F\u590D\u539F\uFF0C\u65F6\u95F4\u53C2\u6570\u968F\u516C\u5F0F\u5FEB\u7167\u51BB\u7ED3\u3002"
  );
  const formulaTimes = metricSnapshots.filter(hasMetricFormulaTimeOverride);
  if (formulaTimes.length) add(
    "indicator-formula-time",
    "\u6307\u6807\u65F6\u95F4\u53C2\u6570",
    "\u9010\u6761\u51BB\u7ED3\u8BA1\u7B97\u7A97\u53E3\u4E0E\u516C\u5F0F\u53C2\u6570",
    join2([INDICATOR_FORMULA_TIME_VERSION, ...new Set(formulaTimes.map(formulaFingerprint))]),
    "\u540C\u4E00\u6761\u5747\u503C\u5E8F\u5217\u53EF\u72EC\u7ACB\u8BBE\u7F6E\u516C\u5F0F\u672C\u8EAB\u7684\u56DE\u770B\u6216\u534A\u8870\u671F\uFF0C\u4EE5\u53CA\u5747\u503C\u7A97\u53E3\u3002"
  );
  if (plan.advantage) add(
    "advantage",
    "\u4F18\u52BF\u7B5B\u9009\u4E0E\u9000\u51FA\u7075\u654F\u5EA6",
    "\u9010\u6B21\u7B5B\u9009 \xB7 \u8F6F\u9000\u51FA\u52A8\u6001\u786E\u8BA4",
    QUALITY_ADVANTAGE_VERSION + " \xB7 \u53C2\u6570 #" + qualityAdvantageFingerprint(plan),
    `W \u540C\u6B65\u8D70\u5F31\u7B5B\u9009${plan.advantage.screenWeak ? "\u5F00" : "\u5173"}\uFF1B\u9996\u52A0\u524D\u786E\u8BA4${plan.advantage.beforeFirst ? "\u5F00" : "\u5173"}\uFF0C\u52A0\u4ED3\u540E A \u7EA7\u786E\u8BA4${plan.advantage.afterAddition ? "\u5F00" : "\u5173"}\uFF0C${plan.advantage.confirmations} \u6839\u5DF2\u5B8C\u6210 1 \u5206\u949F\uFF1B\u5176\u4F59\u5355\u6B21\uFF0C\u539F\u5B9A\u91CF/K/\u786C\u6B62\u635F\u4E0D\u53D8\uFF1B\u5019\u9009\u672A\u9A8C\u8BC1\u6536\u76CA\u3002`
  );
  if (isStaticDrawdownSell(plan.rule)) add(
    "sell",
    "\u5356\u51FA\u7B97\u6CD5",
    `${STATIC_DRAWDOWN_SELL_LABEL} ${qualityExitThresholdText(plan.rule)}`,
    `${plan.rule.version} \xB7 \u53C2\u6570 #${shortFishHash(JSON.stringify(plan.rule))}`,
    "\u6309\u9996\u4ED3\u4E70\u5165\u4EF7\u8BA1\u7B97\u6B62\u635F\u7EBF\uFF0C\u6309\u5206\u949F\u884C\u60C5\u89E6\u4EF7\u6216\u8DF3\u7A7A\u5F00\u76D8\u4EF7\u6210\u4EA4\u3002"
  );
  else if (plan.rule || plan.combo) add(
    "sell",
    "\u5356\u51FA\u7B97\u6CD5",
    `${s.featureShort ?? plan.label} ${plan.rule ? `${plan.rule.direction} ${plan.rule.threshold}` : ""}`.trim(),
    formulaFingerprint(s),
    `${plan.definitionSource === "account" ? "\u8D26\u53F7\u516C\u5F0F\uFF08\u4FDD\u5B58\u65F6\u51BB\u7ED3\u5168\u6587\uFF09" : "\u5386\u53F2\u516C\u5F0F"} \xB7 ${s.interval ?? "5m"}`
  );
  for (const [key, configured] of [["sell-dbl5", plan.rule], ["sell-after-dbl5", plan.combo?.after.rule]]) {
    if (isDbl5Sell(configured)) add(
      key,
      "DBL-5 \u4EF7\u7EBF\u5356\u51FA",
      qualityExitThresholdText(configured),
      `${configured.version} \xB7 \u53C2\u6570 #${shortFishHash(JSON.stringify(configured))}`,
      "\u6309\u5DF2\u786E\u8BA4\u7684\u539F\u751F\u4EF7\u7EBF\u51CF\u53BB\u6240\u8BBE ATR \u5197\u4F59\uFF0C\u5206\u949F\u89E6\u7EBF\u9000\u51FA\u3002"
    );
  }
  const mirrorScoped = [plan.rule, plan.combo?.after.rule].filter((rule) => isStaticDrawdownSell(rule) && rule.mirrorScopeVersion);
  if (mirrorScoped.length) add(
    "sell-mirror-scope",
    "\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4\u751F\u6548\u8303\u56F4",
    "\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u6210\u4EA4\u524D",
    mirrorScoped[0].mirrorScopeVersion,
    "\u4EE5\u5B9E\u9645\u955C\u50CF\u6210\u4EA4\u4E3A\u754C\u3002\u955C\u50CF\u6210\u4EA4\u540E\u6309\u65B9\u6848\u914D\u7F6E\u7684\u955C\u50CF\u540E\u786C\u6027\u7EC8\u6B62\u548C\u5176\u4ED6\u5356\u51FA\u6761\u4EF6\u6267\u884C\u3002"
  );
  if (plan.combo) {
    const a2 = plan.combo.after;
    add(
      "combo",
      "\u7EC4\u5408\u5207\u6362",
      `\u6DA8 ${plan.combo.switchPct}% \u540E\u6539\u7528 ${a2.snapshot.featureShort ?? a2.label} ${qualityExitThresholdText(a2.rule)}`,
      join2([...versionTags(qualityComboIdentity(plan)), formulaFingerprint(a2.snapshot)]),
      "\u6301\u4ED3\u6700\u9AD8\u4EF7\u9996\u6B21\u6BD4\u4E70\u5165\u4EF7\u9AD8\u51FA\u5207\u6362\u6DA8\u5E45\u7684\u90A3\u4E00\u5206\u949F\u6536\u76D8\u8D77\uFF0C\u6539\u7528\u540E\u6BB5\u7B97\u6CD5"
    );
  }
  if (isStaticDrawdownSell(plan.combo?.after.rule)) add(
    "sell-after-static",
    "\u5356\u51FA\u7B97\u6CD5\u540E\u6BB5",
    STATIC_DRAWDOWN_SELL_LABEL,
    `${plan.combo.after.rule.version} \xB7 \u53C2\u6570 #${shortFishHash(JSON.stringify(plan.combo.after.rule))}`,
    "\u5207\u6362\u540E\u7684\u9996\u6839\u5206\u949F\u8D77\uFF0C\u6309\u9996\u4ED3\u4E70\u5165\u4EF7\u7684\u56FA\u5B9A\u6B62\u635F\u7EBF\u6A21\u62DF\u6210\u4EA4\u3002"
  );
  const closePeriod = hasMetricPeriodOverride(s) || hourlyCda.includes(s) ? s.interval : void 0;
  add(
    "execution",
    "\u5356\u51FA\u6267\u884C",
    plan.execution === "intrabar-1m" ? "\u76D8\u4E2D\u8FBE\u6807 \xB7 1 \u5206\u949F\u590D\u539F" : (closePeriod ?? "5 \u5206\u949F") + "\u6536\u76D8\u786E\u8BA4",
    plan.execution === "intrabar-1m" ? "intrabar-1m-v1" : "close-confirm",
    plan.execution === "intrabar-1m" ? periodSnapshots.length || hourlyCda.length ? "\u7528 1 \u5206\u949F\u7EBF\u590D\u539F\u6240\u9009\u5468\u671F\u6307\u6807\uFF0C\u76D8\u4E2D\u8FBE\u6807\u5373\u5356" : "\u7528 1 \u5206\u949F\u7EBF\u590D\u539F 5 \u5206\u949F\u6307\u6807\uFF0C\u76D8\u4E2D\u8FBE\u6807\u5373\u5356" : "\u53EA\u8BA4 " + (closePeriod ?? "5 \u5206\u949F") + "\u6536\u76D8\u8BFB\u6570"
  );
  const mirror = [...versionTags(mirrorIdentity(plan.mirrorTakeProfit)), ...versionTags(mirrorExecutionIdentity(plan))];
  if (plan.mirrorTakeProfit?.enabled) add("mirror", "\u955C\u50CF\u5E73\u8861\u51CF\u4ED3", plan.mirrorTakeProfit.mode === DBL5_MIRROR_MODE ? `DBL-5 \u53CD\u63A8\u89E6\u53D1\u4EF7 \xB7 \u5356 ${plan.mirrorTakeProfit.sellPct}%` : `\u6DA8 ${plan.mirrorTakeProfit.gainPct}% \u5356 ${plan.mirrorTakeProfit.sellPct}%`, join2(mirror), "\u9650\u4EF7\u955C\u50CF\u6B62\u76C8\uFF0C\u53EA\u5356\u4E00\u6B21");
  if (isSelectedL0(plan.payoffRiskVersion)) add("payoff-initial-risk", "L0 \u9009\u62E9", plan.payoffRiskVersion === L0_DBL5 ? "DBL-5 \u7EBF" : "\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4", plan.payoffRiskVersion, "\u9996\u4ED3\u98CE\u9669\u540C\u65F6\u7528\u4E8E\u76C8\u4E8F\u6BD4\u6B62\u76C8\u548C\u7ED3\u7B97\u76C8\u4E8F\u6BD4\u3002");
  else if (plan.payoffRiskVersion) add(
    "payoff-initial-risk",
    "\u76C8\u4E8F\u6BD4\u6B62\u76C8",
    plan.payoffRiskVersion === "payoff-stop-dbl5-initial-risk-v3" ? "\u9996\u4ED3 DBL-5 \u6267\u884C\u7EBF\u8DDD\u79BB" : "\u6CBF\u7528\u9996\u4ED3\u9650\u5236\u9759\u6001\u6700\u5927\u56DE\u64A4",
    plan.payoffRiskVersion,
    plan.payoffRiskVersion === "payoff-stop-dbl5-initial-risk-v3" ? "\u6309\u5F00\u4ED3\u65F6\u5DF2\u786E\u8BA4\u4E14\u4F4E\u4E8E\u4E70\u5165\u4EF7\u7684\u6267\u884C\u7EBF\u8BA1\u7B97\uFF0C\u53D6\u6700\u5C0F\u6B63\u8DDD\u79BB\u4F5C\u4E3A L\u2080 \u6BD4\u4F8B\u3002" : "\u4EE5\u9996\u4ED3\u9650\u5236\u56DE\u64A4\u9608\u503C\u8BA1\u7B97 L\u2080\uFF0C\u5206\u6BB5\u5207\u6362\u540E\u4ECD\u6CBF\u7528\u5F00\u4ED3\u9608\u503C\u3002"
  );
  const vetoes = activeHoldingVetoes(plan.holdingVetoes);
  const lossReviews = [...vetoes, ...(plan.vetoStages ?? []).flatMap((s2) => activeHoldingVetoes(s2.conditions))].filter((v) => v.kind === MIRROR_LOSS_REVIEW_KIND);
  lossReviews.forEach(validateHoldingVeto);
  if (lossReviews.length) add(
    "hard-stop-mirror-loss-review",
    "\u786C\u6027\u7EC8\u6B62",
    "\u672A\u955C\u50CF\u4E14\u4E8F\u635F\u5B9A\u65F6\u7EC8\u6B62",
    [...new Set(lossReviews.map((v) => v.mirrorDeadlineVersion))].sort().join(" \xB7 ") + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(lossReviews))),
    lossReviews.some((v) => v.mirrorDeadlineVersion === "holding-mirror-pnl-threshold-v6") ? "\u76C8\u4E8F\u95E8\u69DB\u5E26\u6B63\u8D1F\u53F7\u3002\u672A\u955C\u50CF\u65F6\uFF0C\u6574\u7B14\u76C8\u4E8F\u4F4E\u4E8E\u95E8\u69DB\u5373\u5E02\u4EF7\u5E73\u4ED3\u3002\u767E\u5206\u6BD4\u4EE5\u7D2F\u8BA1\u6295\u5165\u91D1\u989D\u4E3A\u5206\u6BCD\u3002" : lossReviews.some((v) => v.mirrorReviewSchedule) ? "\u5F00\u59CB\u68C0\u67E5\u65F6\u95F4\u3001\u5224\u65AD\u95F4\u9694\u548C\u4E8F\u635F\u95E8\u69DB\u72EC\u7ACB\u51BB\u7ED3\uFF1B\u6309\u6240\u8BBE\u95F4\u9694\u68C0\u67E5\u81F3\u6301\u4ED3 12 \u5C0F\u65F6\uFF0C\u4EC5\u672A\u955C\u50CF\u4E14\u8FBE\u5230\u4E8F\u635F\u95E8\u69DB\u65F6\u5168\u4F59\u4ED3\u5E02\u4EF7\u5E73\u4ED3\u3002\u767E\u5206\u6BD4\u4EE5\u7D2F\u8BA1\u6295\u5165\u91D1\u989D\u4E3A\u5206\u6BCD\uFF0C\u65E7\u91D1\u989D\u6761\u4EF6\u4FDD\u7559 USDT \u53E3\u5F84\u3002" : lossReviews.some((v) => v.mirrorLossThreshold) ? "\u4ECE\u9996\u6B21\u5EFA\u4ED3\u8BA1\u65F6\uFF0C\u6BCF 0.5 \u5C0F\u65F6\u68C0\u67E5\u81F3 12 \u5C0F\u65F6\u3002\u4EC5\u672A\u5B9E\u9645\u955C\u50CF\u4E14\u6574\u7B14\u4E8F\u635F\u8FBE\u5230\u6240\u8BBE\u95E8\u69DB\u65F6\u5168\u4F59\u4ED3\u5E02\u4EF7\u9000\u51FA\uFF1B\u4E8F\u635F\u767E\u5206\u6BD4\u4EE5\u7D2F\u8BA1\u6295\u5165\u91D1\u989D\u4E3A\u5206\u6BCD\uFF0C\u91D1\u989D\u5355\u4F4D\u4E3A USDT\uFF1B\u95E8\u69DB\u4E3A 0 \u65F6\u4EC5\u5B9E\u9645\u4E8F\u635F\u89E6\u53D1\uFF0C\u6301\u5E73\u7EE7\u7EED\u89C2\u5BDF\u3002\u5355\u4F4D\u3001\u6570\u503C\u548C\u6267\u884C\u7248\u672C\u72EC\u7ACB\u51BB\u7ED3\u3002" : "\u4ECE\u9996\u6B21\u5EFA\u4ED3\u8BA1\u65F6\uFF0C\u9ED8\u8BA4 1 \u5C0F\u65F6\u9996\u6B21\u68C0\u67E5\uFF0C\u6B64\u540E\u6BCF 0.5 \u5C0F\u65F6\u68C0\u67E5\u81F3 12 \u5C0F\u65F6\u3002\u4EC5\u672A\u5B9E\u9645\u955C\u50CF\u4E14\u6574\u7B14\u8D26\u9762\u76C8\u4E8F < 0 \u65F6\u5168\u4F59\u4ED3\u5E02\u4EF7\u9000\u51FA\uFF1B\u76C8\u5229\u548C\u6301\u5E73\u7EE7\u7EED\u89C2\u5BDF\uFF0C\u5DF2\u955C\u50CF\u540E\u505C\u6B62\u672C\u9879\uFF0C\u68C0\u67E5\u533A\u95F4\u7ED3\u675F\u4E0D\u5F3A\u5236\u6E05\u4ED3\u3002\u65E7\u9650\u65F6\u7248\u672C\u4FDD\u6301\u539F\u8BED\u4E49\u3002"
  );
  const deadlines = [...vetoes, ...(plan.vetoStages ?? []).flatMap((s2) => activeHoldingVetoes(s2.conditions))].filter((v) => v.kind === MIRROR_DEADLINE_KIND);
  deadlines.forEach(validateHoldingVeto);
  if (deadlines.length) add(
    "hard-stop-mirror-deadline",
    "\u786C\u6027\u7EC8\u6B62",
    "\u9650\u65F6\u672A\u5B9E\u73B0\u955C\u50CF\u5E73\u8861\u51CF\u4ED3",
    MIRROR_DEADLINE_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(deadlines))),
    "\u4ECE\u9996\u6B21\u5EFA\u4ED3\u8BA1\u65F6\uFF0C\u6309\u5206\u949F\u68C0\u67E5\u3002\u5230\u65F6\u672A\u6709\u955C\u50CF\u5B9E\u9645\u6210\u4EA4\u5373\u5168\u4ED3\u9000\u51FA\uFF0C\u5DF2\u6210\u4EA4\u5219\u4E0D\u5F71\u54CD\u4F59\u4ED3\uFF1B\u52A0\u4ED3\u4E0D\u91CD\u7F6E\u65F6\u949F\u3002"
  );
  const limitedStatic = [...vetoes, ...(plan.vetoStages ?? []).flatMap((s2) => activeHoldingVetoes(s2.conditions))].filter(isLimitedStaticDrawdownVeto);
  if (limitedStatic.length) add("hard-stop-limited-static", "\u786C\u6027\u7EC8\u6B62", LIMITED_STATIC_DRAWDOWN_LABEL, LIMITED_STATIC_DRAWDOWN_VETO_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(limitedStatic))), "\u4EE5\u9996\u4ED3\u4E70\u5165\u4EF7\u5EFA\u7ACB\u56FA\u5B9A\u6B62\u635F\u7EBF\uFF0C\u6309\u5404\u6761\u4EF6\u6240\u5C5E\u9636\u6BB5\u89E6\u4EF7\u6216\u8DF3\u7A7A\u9000\u51FA\uFF1B\u8D77\u59CB\u9650\u5236\u9608\u503C\u53EF\u4F5C\u4E3A\u521D\u59CB\u98CE\u9669\u4F9D\u636E\u3002");
  const mirrorStages = [...vetoes, ...(plan.vetoStages ?? []).flatMap((s2) => activeHoldingVetoes(s2.conditions))].filter((v) => v.mirrorStage);
  if (mirrorStages.length) add(
    "hard-stop-mirror-stages",
    "\u786C\u6027\u7EC8\u6B62",
    "\u955C\u50CF\u5E73\u8861\u51CF\u4ED3\u524D\uFF0F\u540E\u4E24\u4E2A\u9636\u6BB5",
    MIRROR_HARD_STOP_STAGES_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(mirrorStages))),
    "\u6309\u955C\u50CF\u5B9E\u9645\u6210\u4EA4\u5207\u6362\uFF1A\u524D\u6BB5\u505C\u6B62\u751F\u6548\uFF0C\u540E\u6BB5\u72EC\u7ACB\u5F00\u59CB\u89C2\u5BDF\uFF1B\u4E0D\u56DE\u653E\u542F\u52A8\u524D\u65AD\u88C2\u3001\u8DCC\u5E45\u6216\u5DF2\u7ED3\u675F\u7684\u89E6\u4EF7\u3002\u539F\u5168\u7A0B\u6761\u4EF6\u53CA\u65E7\u7248\u51CF\u4ED3\u540E\u6761\u4EF6\u4E0D\u81EA\u52A8\u8F6C\u6362\u3002"
  );
  const postMirror = [...vetoes, ...(plan.vetoStages ?? []).flatMap((s2) => activeHoldingVetoes(s2.conditions))].filter((v) => v.activation);
  if (postMirror.length) add(
    "hard-stop-after-mirror",
    "\u786C\u6027\u7EC8\u6B62",
    POST_MIRROR_PROTECTION_LABEL,
    POST_MIRROR_PROTECTION_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(postMirror))),
    "\u4EC5\u51ED\u672C\u6B21\u6301\u4ED3\u955C\u50CF\u51CF\u4ED3\u6210\u4EA4\u8BB0\u5F55\u542F\u7528\uFF1B\u76D8\u4E2D\u6210\u4EA4\u540E\u7684\u9632\u5B88\u7EBF\u4ECE\u4E0B\u4E00\u5206\u949F\u68C0\u67E5\uFF0CCDA\u4ECE\u9996\u4E2A\u540E\u7EED\u8BFB\u6570\u68C0\u67E5\uFF0C\u4E0D\u8FFD\u8865\u542F\u52A8\u524D\u8BC1\u636E\u3002\u6682\u505C\u7EED\u7B97\u4FDD\u7559\u6210\u4EA4\u4E0E\u72EC\u7ACB\u72B6\u6001\uFF0C\u539F\u7EA6\u675F\u4E0D\u53D8\u3002"
  );
  if (vetoes.length) add(
    "hard-stop",
    "\u786C\u6027\u7EC8\u6B62",
    vetoes.map((v) => holdingVetoLabel(v)).join(" \u6216 "),
    join2([qualityVetoVersion(plan), ...vetoes.filter((v) => v.snapshot?.definitionKey).map((v) => formulaFingerprint(v.snapshot))]),
    plan.vetoFill === "stop" ? "\u56DE\u64A4\u6B62\u635F\u76D8\u4E2D\u89E6\u53CA\u6309\u6B62\u635F\u4EF7\u6210\u4EA4" : "\u56DE\u64A4\u5426\u51B3\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u6210\u4EA4"
  );
  vetoes.filter((v) => v.kind === BOX_STOP_KIND).forEach((v, i) => {
    const r = v.boxStop;
    if (r.channels) {
      const children = boxStopRuleEntries(r).map((c) => {
        const versions2 = structureVersions(c.rule.structure);
        return join2([c.rule.version, c.rule.reference?.version, versions2.box, versions2.guard]);
      });
      add(`hard-stop-box-${i}`, "\u786C\u6027\u7EC8\u6B62", boxStopLabel(r), join2([r.version, ...children, "\u53C2\u6570 #" + shortFishHash(JSON.stringify(boxStopIdentity(r)))]), BOX_K_EXECUTION_VERSIONS.find((item) => item.id === r.version).summary);
      return;
    }
    const versions = structureVersions(r.structure);
    const version = join2([r.version, r.reference?.version, versions.box, versions.guard, (r.guardRegime || isBoxSecondBreak(r) || r.reference) && "\u53C2\u6570 #" + shortFishHash(JSON.stringify(boxStopIdentity(r)))]);
    const summary = BOX_K_EXECUTION_VERSIONS.find((item) => item.id === r.version)?.summary ?? (isBoxBreak(r) ? `\u4EC5\u5728\u539F\u751F ${boxStopAlgorithmLabel(r)} \u9632\u5B88\u7EBF\u7EA2\u53C9\u786E\u8BA4\u540E\uFF0C\u6309\u4E0B\u4E00\u5206\u949F\u5F00\u76D8\u4EF7\u5168\u4ED3\u5356\u51FA\uFF1B\u4E0D\u5C06\u5F71\u7EBF\u6216\u7F3A\u5931\u7EBF\u5F53\u65AD\u88C2` : `\u72EC\u7ACB\u7BB1\u4F53\u6B62\u635F\uFF1B\u53EA\u7528\u5DF2\u6536\u76D8 ${INTERVAL_LABEL[r.structure.definition.interval ?? "5m"]}\u7ED3\u6784\uFF0C\u89E6\u4EF7\u6216\u6536\u76D8\u786E\u8BA4\u7531\u7528\u6237\u9009\u62E9`);
    add(`hard-stop-box-${i}`, "\u786C\u6027\u7EC8\u6B62", boxStopLabel(r), version, summary);
  });
  const a = plan.addition;
  if (a?.enabled) {
    const doubleDrops = [a, ...a.rounds ?? [], ...a.alternativeRounds ?? []].map((r) => (r.entryVetoes ?? []).filter((v) => v.enabled && v.kind === "double-drop")).filter((r) => r.length);
    if (doubleDrops.length) add("addition-support-quality", "\u52A0\u4ED3\u5426\u51B3", "\u4E8C\u6B21\u6025\u8DCC\u672A\u6536\u590D\u524D\u9AD8", DOUBLE_DROP_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(doubleDrops)), "\u9996\u6B21\u6025\u8DCC\u524D\u9AD8\u4E0E ATR \u56FA\u5B9A\uFF1B\u8FDE\u7EED\u4E0B\u8DCC\u53EA\u8BA1\u4E00\u6B21\uFF0C\u53CD\u5F39\u8131\u79BB\u6025\u8DCC\u533A\u540E\u518D\u8DCC\u8BA1\u7B2C\u4E8C\u6B21\uFF1B5 \u5206\u949F\u6536\u76D8\u6536\u590D\u524D\u9AD8\u624D\u6062\u590D\u3002\u539F\u7BB1\u4F53\u548C\u9632\u5B88\u7EBF\u8F93\u51FA\u4E0D\u53D8\u3002");
    if (a.roundExits) for (const [round, exit] of Object.entries({ default: a, ...a.roundExits.overrides })) {
      const signature = JSON.stringify(additionExitIdentity(exit));
      add("addition-round-exit-" + round, "\u52A0\u4ED3\u540E\u5356\u51FA", round === "default" ? "\u5176\u4ED6\u6B21\u6570\u7684\u5356\u51FA\u6807\u51C6" : `\u7B2C ${round} \u6B21\u6210\u4EA4\u540E`, ADDITION_ROUND_EXITS_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(signature), "\u672C\u6B21\u5B9E\u9645\u6210\u4EA4\u540E\uFF0C\u6309\u8BE5\u6B21\u7684 K\u3001\u4FDD\u672C\u5E95\u7EBF\u3001\u652F\u6491\u4E0B\u79FB\u53CA\u6709\u6548\u6DA8\u5E45\u8BBE\u7F6E\u6267\u884C\u3002");
    }
    if (a.breakevenFloor?.enabled && a.breakevenFloor.version) add(
      "addition-position-floor",
      "\u4FDD\u672C\u5E95\u7EBF",
      "\u8DDF\u968F\u6700\u8FD1\u4E00\u6B21\u52A0\u4ED3 K \xB7 F\uFF1DK" + (a.breakevenFloor.version === ADDITION_PROFIT_FLOOR_VERSION ? "\uFF0B" : "\u2212") + a.breakevenFloor.atr + " ATR",
      a.breakevenFloor.version,
      a.breakevenFloor.version === ADDITION_PROFIT_FLOOR_VERSION ? "\u6309\u6574\u573A\u6301\u4ED3\u8D26\u5728 K \u5B9A\u91CF\u3002F\uFF1DK\uFF0B\u500D\u6570\xD7ATR\uFF0C\u76D8\u4E2D\u89E6\u53CA F \u5168\u4ED3\u9000\u51FA\uFF0C\u8DF3\u7A7A\u6309\u5F00\u76D8\u4EF7\u3002" : a.breakevenFloor.version === ADDITION_POSITION_FLOOR_INTRABAR_VERSION ? "\u4EE5\u5B9E\u9645\u6210\u4EA4\u7684 K \u7B97 F \u5E76\u5B9A\u91CF\uFF1BF \u72EC\u7ACB\u76D8\u4E2D\u89E6\u4EF7\u5168\u4ED3\u5356\u51FA\uFF0C\u96F6 ATR \u4E5F\u751F\u6548\uFF0C\u4E0D\u7B49 K \u6536\u76D8\u786E\u8BA4\uFF1B\u8DF3\u7A7A\u6309\u5F00\u76D8\u4EF7\u3002" : "\u4EE5\u5B9E\u9645\u89E6\u53D1\u4F4D\u7F6E\u7684 K \u7B97\u4FDD\u672C\u5E95\u7EBF F\uFF1B\u6309 F \u5B9A\u91CF\uFF0CK \u4E0E F \u5206\u5F00\u8BB0\u5F55\u3002"
    );
    if (a.kStopVersion) add("addition-k-stop", "\u52A0\u4ED3 K \u6B62\u635F", "K / K\u2032 \u5373\u65F6\u89E6\u4EF7\u5168\u4ED3\u5356\u51FA", a.kStopVersion, a.breakevenFloor?.version === ADDITION_PROFIT_FLOOR_VERSION ? "K \u7528\u4E8E\u5B9A\u91CF\uFF0C\u56DE\u843D\u5148\u89E6\u53CA\u4E0A\u65B9 F \u5373\u5168\u4ED3\u9000\u51FA\u3002" : a.breakevenFloor?.version ? "\u76D8\u4E2D\u4F4E\u4E8E\u6216\u7B49\u4E8E K \u5373\u89E6\u53D1\uFF0C\u5F00\u76D8\u8D8A\u7EBF\u6309\u5F00\u76D8\u4EF7\u3002F \u7EE7\u7EED\u7528\u4E8E\u5B9A\u91CF\u3002" : "\u76D8\u4E2D\u4F4E\u4E8E\u6216\u7B49\u4E8E K \u5373\u89E6\u53D1\uFF0C\u5F71\u7EBF\u8BA1\u5165\uFF1B\u5F00\u76D8\u8D8A\u7EBF\u6309\u5F00\u76D8\u4EF7\uFF0C\u5426\u5219\u6309 K\u3002\u4FDD\u672C\u5E95\u7EBF\u4ECD\u7528\u4E8E\u539F\u5B9A\u91CF\uFF0C\u9632\u5B88\u7EBF\u6536\u76D8\u786E\u8BA4\u4E0D\u518D\u5EF6\u8FDF K\u3002");
    const rounds = a.rounds?.length ? a.rounds : [a];
    [...rounds, ...a.alternativeRounds ?? []].forEach((round, index) => {
      const position = round.impulsePosition;
      if (!position) return;
      const label = index < rounds.length ? "\u7B2C " + (index + 1) + " \u6B21\u52A0\u4ED3" : "\u7B2C " + (index - rounds.length + 1) + " \u6B21\u52A0\u4ED3 \xB7 \u8FDB\u653B\u5907\u9009";
      add(
        "addition-impulse-" + index,
        label + " \xB7 \u4F4D\u7F6E",
        "\u6025\u62C9\u7EBF 5m \xB7 \u4F4E\u70B9 \u2212 " + position.bufferAtr + " ATR",
        position.version + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(position)),
        position.skipNative ? "\u4EC5\u6025\u62C9\u7EBF\u30025 \u5206\u949F\u6536\u76D8\u786E\u8BA4\uFF0C\u4F7F\u7528\u540C\u4E00\u6301\u4ED3\u8D26\u3002" : "\u6025\u62C9\u7EBF\u4E0E\u539F\u4F4D\u7F6E\u540C\u65F6\u7B49\u5F85\uFF0C\u6700\u591A\u6210\u4EA4\u4E00\u6B21\uFF0C\u6210\u4EA4\u540E\u8FDB\u5165\u4E0B\u4E00\u8F6E\u3002"
      );
    });
    const timed = [
      ...[...rounds, ...a.alternativeRounds ?? []].flatMap((round) => [
        ...round.source === "custom" ? qualityAdditionConditions(round) : qualityAdditionPrerequisites(round),
        ...round.indicatorIncrease?.metrics ?? []
      ]),
      ...plan.sellStages ?? []
    ].filter((metric) => hasAdditionMetricTime(metric.snapshot));
    if (timed.length) add(
      "addition-indicator-time",
      "\u52A0\u4ED3\u6307\u6807\u65F6\u95F4",
      [...new Set(timed.map((metric) => metric.label))].join("\u3001"),
      ADDITION_INDICATOR_TIME_VERSION + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(timed.map((metric) => [metric.metric, metric.snapshot.definitionKey]))),
      "\u5728\u5355\u6761\u6761\u4EF6\u4E2D\u51BB\u7ED3\u516C\u5F0F\u65F6\u95F4\u53C2\u6570\u3002avg\u2082 \u4F7F\u7528\u8FD1\u5230\u8FDC 4\u22363\u22362\u22361 \u56DB\u6BB5\u52A0\u6743\uFF0C\u9012\u589E\u6BD4\u8F83\u7684\u4E24\u4E2A\u65F6\u70B9\u4F7F\u7528\u540C\u4E00\u4EFD\u516C\u5F0F\u3002"
    );
    add(
      "addition",
      "\u52A0\u4ED3\u89C4\u5219",
      `\u6700\u591A ${a.maxRounds ?? rounds.length} \u6B21`,
      join2([...versionTags(additionIdentity({ ...a, structure: void 0, rounds: a.rounds?.map((r) => ({ ...r, structure: void 0 })) })), ...versionTags(additionMirrorIdentity(a, plan.mirrorTakeProfit))]),
      a.positionVersion === HOLDING_LEDGER_ADDITION_VERSION ? "\u901A\u7528\u6301\u4ED3\u8D26\uFF1AQ\xD7K\u2212\u5269\u4F59\u6210\u672C\uFF0B\u5DF2\u5B9E\u73B0\u51C0\u76C8\u4E8F\uFF1D\u65B0\u589E\u5E01\u6570\xD7(T\u2212K)\uFF1B\u955C\u50CF\u53EF\u9009\uFF0C\u5B9E\u9645\u6210\u4EA4\u540E\u624D\u8BA1\u5165\u8D26\u672C" : "\u955C\u50CF\u6B62\u76C8\u540E\u6309\u5E73\u8861\u516C\u5F0F Q\xD7(K\u2212S)+P\uFF1D\u65B0\u589E\u5E01\u6570\xD7(T\u2212K) \u5B9A\u91CF\uFF0C\u78B0\u5230 K \u5356\u51FA"
    );
    const addIncreaseVersions = (rules2, alternative = false) => {
      rules2.forEach((round, index) => {
        const growth = round.indicatorIncrease;
        if (!growth) return;
        add(
          `addition-increase-${alternative ? "alternative-" : ""}${index + 1}`,
          `\u7B2C ${index + 1} \u6B21\u52A0\u4ED3 \xB7 ${alternative ? "\u8FDB\u653B\u5907\u9009 \xB7 " : ""}\u65B9\u5411`,
          growth.metrics.map((metric) => metric.label).join("\u3001"),
          growth.version + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify(additionIncreaseIdentity(growth))),
          "\u6240\u9009\u6307\u6807\u7684\u5DF2\u6536\u76D8\u8BFB\u6570\u5747\u987B\u4E25\u683C\u9AD8\u4E8E\u4E0A\u4E00\u6B21\u5B9E\u9645\u52A0\u4ED3\u65F6\u7684\u540C\u7B97\u6CD5\u8BFB\u6570\u3002\u9996\u6B21\u52A0\u4ED3\u4EE5\u9996\u4ED3\u4E70\u5165\u65F6\u4E3A\u57FA\u51C6\u3002"
        );
      });
    };
    addIncreaseVersions(rounds);
    if (a.alternativeRounds) addIncreaseVersions(a.alternativeRounds, true);
    const addGuardPlusVersions = (rules2, lane) => {
      rules2.forEach((round, index) => {
        const version = round.source === "structure" ? round.structure?.guardPlusVersion : void 0;
        if (version) add(
          `addition-guard-plus-${lane}-${index + 1}`,
          `\u7B2C ${index + 1} \u6B21\u52A0\u4ED3 \xB7 ${lane === "primary" ? "\u4E3B\u5206\u652F" : "\u8FDB\u653B\u5907\u9009"}`,
          DBL5_GUARD_PLUS_LABEL,
          version + " \xB7 \u53C2\u6570 #" + shortFishHash(JSON.stringify([round.structure?.definition.DBL5_config, dbl5GuardPlusParams(round.structure?.guardPlusImpulseBufferAtr)])),
          boxAlgorithmVersion(version)?.summary
        );
      });
    };
    addGuardPlusVersions(rounds, "primary");
    addGuardPlusVersions(a.alternativeRounds ?? [], "alternative");
    for (const [lane, rules2] of [["\u4E3B\u5206\u652F", rounds], ["\u8FDB\u653B\u5907\u9009", a.alternativeRounds ?? []]]) {
      rules2.forEach((round, index) => {
        for (const classified of round.classifiedImpulsePositions ?? []) add(`addition-impulse-class-${lane === "\u4E3B\u5206\u652F" ? "primary" : "alternative"}-${index + 1}-${classified.mainClass}`, `\u7B2C ${index + 1} \u6B21\u52A0\u4ED3 \xB7 ${lane}`, classifiedImpulsePositionLabel(classified.mainClass), join2([classified.version, IMPULSE_1115_CLASSIFICATION_VERSION, DBL5_GUARD_PLUS_VERSION, "\u53C2\u6570 #" + shortFishHash(JSON.stringify(classifiedImpulsePositionsIdentity([classified])))]), classified.version === CLASSIFIED_IMPULSE_ORIGIN_K_POSITION_VERSION ? "K\uFF1D\u8D77\u6DA8\u70B9\uFF08\u8D77\u6DA8\u4F4E\u70B9\uFF09\u2212N\xD7\u6025\u62C9\u5F00\u59CB\u524D\u51BB\u7ED3\u76845m ATR(14)\uFF0C\u4E0E\u539F1115\u4F4D\u7F6E\u540C\u4E00\u57FA\u51C6\uFF0C\u53EA\u6263\u4E00\u6B21N\u500D\u3002\u5206\u7C7B\u4EC5\u51B3\u5B9A\u89E6\u53D1\u65F6\u673A\uFF1BN\u3001\u6700\u5C0F\u8DDD\u79BB\u9010\u8F6E\u3001\u5206\u7C7B\u548C\u5206\u652F\u72EC\u7ACB\u4FDD\u5B58\uFF0C\u5B9A\u91CF\u4E0E\u9000\u51FA\u5171\u7528K\uFF1B\u65E7\u65B9\u6848\u4E0D\u8F6C\u6362\u3002" : classified.version === CLASSIFIED_IMPULSE_LINE_K_POSITION_VERSION ? "K\uFF1D\u6025\u62C9\u7EBF\uFF08\u4E00\u7C7B\uFF0F\u4E8C\u7C7B\uFF09\u2212N\xD7\u8BE5\u7EBF\u51BB\u7ED3 ATR\uFF1BN \u9010\u8F6E\u3001\u5206\u7C7B\u548C\u5206\u652F\u72EC\u7ACB\u8BBE\u7F6E\u3002\u4EC5\u5DF2\u786E\u8BA4\u65B0\u5206\u7C7B\u72B6\u6001\u751F\u6210\u673A\u4F1A\uFF0C\u6CBF\u7528\u65B9\u5411\u3001\u5426\u51B3\u3001\u5B9A\u91CF\u4E0E\u9000\u51FA\uFF1B\u65E7\u65B9\u6848\u4E0D\u8F6C\u6362\u3002" : "\u4EC5\u6700\u65B0\u6025\u62C9\u7EBF\u57285\u5206\u949F\u6536\u76D8\u786E\u8BA4\u4E00\uFF0F\u4E8C\u7C7B\u7684\u65B0\u72B6\u6001\u65F6\u751F\u6210\u4E00\u6B21\u4F4D\u7F6E\u673A\u4F1A\uFF1B\u8FC7\u6E21\u548C\u6301\u7EED\u540C\u72B6\u6001\u4E0D\u91CD\u590D\u3002\u6CBF\u7528\u65B9\u5411\u3001\u5426\u51B3\u3001K\u3001\u5B9A\u91CF\u4E0E\u9000\u51FA\uFF1B\u65E7\u4F4D\u7F6E\u4E0D\u8F6C\u6362\u3002");
        const position = round.impulse1115Position;
        const race = position && !position.skipNative && round.source === "structure" && round.structure?.guardPlusVersion ? DBL5_1115_POSITION_RACE_VERSION : void 0;
        if (position) add(
          `addition-impulse-1115-${lane === "\u4E3B\u5206\u652F" ? "primary" : "alternative"}-${index + 1}`,
          `\u7B2C ${index + 1} \u6B21\u52A0\u4ED3 \xB7 ${lane}`,
          position.version === IMPULSE_1115_CONFIGURABLE_K_VERSION ? IMPULSE_1115_DISPLAY_NAME : IMPULSE_1115_POSITION_LABEL,
          join2([position.version, DBL5_GUARD_PLUS_VERSION, race, "\u53C2\u6570 #" + shortFishHash(JSON.stringify([position, DBL5_GUARD_PLUS_PARAMS]))]),
          join2([boxAlgorithmVersion(position.version)?.summary, race && boxAlgorithmVersion(race)?.summary])
        );
      });
    }
    rounds.forEach((r, i) => {
      if (r.source === "structure" && r.structure) {
        const v = structureVersions(r.structure), box = boxAlgorithmVersion(v.box), guard = v.guard ? boxAlgorithmVersion(v.guard) : void 0;
        const k = structureKSourceLabel(r.structure);
        add(
          `box-${i + 1}`,
          `\u7B2C ${i + 1} \u6B21\u52A0\u4ED3 \xB7 \u7BB1\u4F53\u7B97\u6CD5`,
          join2([box?.label ?? v.box, guard?.label, `K\uFF1D${k}\u2212${r.structure.buffer}${r.structure.bufferUnit === "atr" ? "ATR" : "%"}${r.structure.minDistancePct != null ? `\uFF08\u79BB\u73B0\u4EF7 \u2265 ${r.structure.minDistancePct}%\uFF09` : ""}`]),
          join2([v.box, v.guard, ...versionTags(additionIdentity({ ...a, rounds: void 0, source: "structure", structure: r.structure })).filter((t) => t.startsWith("k-from") || t.startsWith("box-addition") || t.startsWith("k-min-distance") || t.startsWith("guard-trend-only"))]),
          join2([box?.summary, guard?.summary])
        );
      }
      if (r.source === "custom") {
        const t = qualityAdditionConditions(r)[0];
        if (t) add(`trigger-${i + 1}`, `\u7B2C ${i + 1} \u6B21\u52A0\u4ED3 \xB7 \u4F4D\u7F6E`, `${t.label} ${t.direction} ${t.threshold}${r.entryDistanceAtr != null ? ` \xB7 T\u2265S+${r.entryDistanceAtr}ATR` : ""} \xB7 K=T\u2212${r.supportOffsetAtr ?? 1.5}ATR`, formulaFingerprint(t.snapshot), "\u6307\u6807 \xB7 S / T / K\uFF1A\u6307\u6807\u8FBE\u6807\u4E14\u5165\u573A\u8DDD\u79BB\u591F\u65F6\u52A0\u4ED3");
      }
      const dp = activeDetectorPrerequisite(r);
      if (dp) add(`detector-${i + 1}`, `\u7B2C ${i + 1} \u6B21\u52A0\u4ED3 \xB7 \u65B9\u5411`, `${dp.featureId ?? "\u539F\u63A2\u6D4B\u7B97\u6CD5\uFF08\u5168\u90E8\uFF09"} \u63A2\u6D4B\u503C\u63D0\u9AD8 \u2265 ${dp.stricterPct}%`, "detector-prerequisite-v1", "\u52A0\u4ED3\u90A3\u4E00\u523B\uFF0C\u63A2\u6D4B\u8BFB\u6570\u987B\u8FBE\u5230\u539F\u95E8\u69DB\u518D\u63D0\u9AD8\u8FD9\u4E2A\u767E\u5206\u6BD4");
      qualityAdditionPrerequisites(r).forEach((f, j) => add(`direction-${i + 1}-${j + 1}`, `\u7B2C ${i + 1} \u6B21\u52A0\u4ED3 \xB7 \u65B9\u5411`, `${f.label} ${f.direction} ${f.threshold}`, formulaFingerprint(f.snapshot), "\u52A0\u4ED3\u90A3\u4E00\u523B\u987B\u6EE1\u8DB3\uFF08\u53EA\u8BFB\u6700\u540E\u4E00\u6839\u5DF2\u6536\u76D8 K \u7EBF\uFF09"));
    });
  }
  if (plan.vetoStages?.length) add(
    "veto-stages",
    "\u52A0\u4ED3\u540E\u5426\u51B3",
    plan.vetoStages.map((st) => `\u7B2C ${st.afterAdditions} \u6B21\u540E ${st.conditions.filter((c) => c.enabled).length} \u6761`).join("\uFF1B"),
    join2([...versionTags(qualityVetoStagesIdentity(plan)), ...plan.vetoStages.flatMap((st) => st.conditions.filter((c) => c.enabled && c.snapshot?.definitionKey).map((c) => formulaFingerprint(c.snapshot)))]),
    "\u67D0\u6B21\u52A0\u4ED3\u6210\u4EA4\u540E\u6362\u7528\u7684\u786C\u6027\u7EC8\u6B62\u6761\u4EF6"
  );
  if (plan.sellStages?.length) add(
    "sell-stages",
    "\u52A0\u4ED3\u540E\u6539\u7528\u5356\u51FA",
    plan.sellStages.map((st) => `\u7B2C ${st.afterAdditions} \u6B21\u540E ${st.label}`).join("\uFF1B"),
    join2([...versionTags(qualitySellStagesIdentity(plan)), ...plan.sellStages.map((st) => formulaFingerprint(st.snapshot))]),
    "\u67D0\u6B21\u52A0\u4ED3\u6210\u4EA4\u540E\u6362\u7528\u7684\u5356\u51FA\u7B97\u6CD5"
  );
  if (vetoes.length) out.push({ key: "hard-stop-params", part: "\u786C\u6027\u7EC8\u6B62", name: "\u6761\u4EF6\u53C2\u6570", version: "\u53C2\u6570 #" + shortFishHash(JSON.stringify(holdingVetoIdentity(plan.holdingVetoes))), summary: "\u5404\u6761\u786C\u6027\u7EC8\u6B62\u7684\u7C7B\u522B\u3001\u65B9\u5411\u3001\u95E8\u69DB" });
  return out;
}
function comparePlanVersions(frozen, current) {
  const now = new Map(current.map((e) => [e.key, e])), was = new Map(frozen.map((e) => [e.key, e])), out = [];
  for (const e of frozen) {
    const c = now.get(e.key);
    if (!c || c.version !== e.version && !(e.key === "router" && equivalentRouterVersion(e.version, c.version))) out.push({ key: e.key, part: e.part, name: e.name, from: e.version, to: c?.version ?? null });
  }
  for (const c of current) if (!was.has(c.key)) out.push({ key: c.key, part: c.part, name: c.name, from: null, to: c.version });
  return out;
}
function withFrozenStructures(plan) {
  if (plan.preEntryThreeStage) plan = { ...plan, preEntryThreeStage: freezePreEntryThreeStage(plan.preEntryThreeStage) };
  if (plan.preEntryConditions) plan = { ...plan, preEntryConditions: freezePreEntryConditions(plan.preEntryConditions) };
  if (plan.router) return { ...plan, router: { ...plan.router, structure: withFrozenStructures(plan.router.structure), attack: withFrozenStructures(plan.router.attack) } };
  const freezeVeto = (v) => v.boxStop ? { ...v, boxStop: freezeBoxStop(v.boxStop) } : v;
  if (plan.holdingVetoes?.some((v) => v.boxStop) || plan.vetoStages?.some((s) => s.conditions.some((v) => v.boxStop))) plan = { ...plan, holdingVetoes: plan.holdingVetoes?.map(freezeVeto), vetoStages: plan.vetoStages?.map((s) => ({ ...s, conditions: s.conditions.map(freezeVeto) })) };
  const a = plan.addition;
  if (!a) return plan;
  const fix = (r) => r.structure ? { ...r, structure: freezeStructureVersions(r.structure) } : r;
  return { ...plan, addition: { ...fix(a), ...a.rounds ? { rounds: a.rounds.map(fix) } : {} } };
}
function planVersionChanges(plan) {
  if (!plan.frozenVersions) return [];
  const current = body(plan);
  return comparePlanVersions(plan.frozenVersions, qualityPlanVersions(current)).filter((change) => {
    const path = change.key.split(":"), key = path.pop();
    if (!key || !["hard-stop-params", "lower-wick-veto", "veto-history", "addition-support-quality", "pre-entry-conditions"].includes(key) || !change.from || !change.to) return true;
    let branch = current;
    for (const part of path) {
      if (!branch.router || part !== "structure" && part !== "attack") return true;
      branch = branch.router[part];
    }
    if (key === "pre-entry-conditions") return !(branch.preEntryConditions?.entryVetoes.some((v) => v.kind === "box-break") && change.from === preEntryConditionsVersion(branch, true));
    return !(key === "hard-stop-params" ? compatibleHoldingParameterOrder(branch.holdingVetoes, change.from) : compatibleAdditionParameterOrder(branch, key, change.from));
  });
}
var VERSION_TAG, formulaFingerprint, join2, body;
var init_qualityPlanVersions = __esm({
  "src/lib/fish/qualityPlanVersions.ts"() {
    init_qualityVeto();
    init_qualityMirrorDeadline();
    init_qualityMirrorLossReview();
    init_qualityClassifiedImpulsePosition();
    init_holdingImpulse1115Classification();
    init_qualityPostMirrorProtection();
    init_qualityMirrorHardStopStages();
    init_impulse1115Classification();
    init_cdaPeriods();
    init_features();
    init_qualityAdditionMetric();
    init_preEntryThreeStage();
    init_dbl5GuardPlus();
    init_qualityHoldingLedger();
    init_qualityBoxStop();
    init_preEntryConditions();
    init_qualityPlanRouter();
    init_qualityAdvantage();
    init_qualityDoubleDrop();
    init_qualityAdditionVeto();
    init_qualityPlanParameterCompatibility();
    init_preEntryThreeStage();
    init_preEntryStallTurn5m();
    init_qualityStaticFilterPlan();
    init_qualityPositionManagement();
    init_algorithm();
    init_quality();
    init_qualityDbl5Sell();
    init_qualityStaticDrawdownSell();
    init_qualityVeto();
    init_qualityMirror();
    init_qualityAddition();
    init_qualityVetoStages();
    init_qualitySellStages();
    init_boxAlgorithmVersions();
    init_qualityAdditionStructure();
    init_qualityLegacyEngine();
    VERSION_TAG = /^[a-z][a-z0-9]*(?:-[a-z0-9.]+)*-v\d+$/;
    formulaFingerprint = (s) => "\u516C\u5F0F #" + shortFishHash(JSON.stringify([s.definitionKey, s.interval ?? null, s.scale ?? null, s.statistic ?? null]));
    join2 = (parts) => parts.filter(Boolean).join(" \xB7 ");
    body = (plan) => {
      const { frozenVersions: _, ...rest } = withFrozenStructures(plan);
      return rest;
    };
  }
});

// src/lib/fish/libraryDirectoryEdits.ts
var init_libraryDirectoryEdits = __esm({
  "src/lib/fish/libraryDirectoryEdits.ts"() {
  }
});

// src/lib/fish/preEntryTableClears.ts
var init_preEntryTableClears = __esm({
  "src/lib/fish/preEntryTableClears.ts"() {
  }
});

// src/lib/fish/preEntryMonitor.ts
var isAutomaticPreEntryRound;
var init_preEntryMonitor = __esm({
  "src/lib/fish/preEntryMonitor.ts"() {
    init_libraryDirectoryEdits();
    init_preEntryTableClears();
    init_timeFormat();
    init_algorithm();
    init_quality();
    init_shared();
    init_preEntryConditions();
    init_preEntryThreeStage();
    init_qualityAdmissionTime();
    isAutomaticPreEntryRound = (round) => !!(round.automatic || round.instantTrading || round.instantMonitor);
  }
});

// src/lib/fish/usdtPositionMirror.ts
var usdtMirrorKey = (position) => position.symbol + ":" + position.positionSide;
var usdtMirrorRevision = (position) => JSON.stringify([usdtMirrorKey(position), position.quantity, position.direction, position.entryPrice, position.updatedAt]);
var amountFormat = new Intl.NumberFormat("en-US", { maximumFractionDigits: 8 });
function usdtPositionDecimal(text) {
  return text.includes(".") ? text.replace(/0+$/, "").replace(/\.$/, "") : text;
}

// scripts/usdt-position-reader.ts
var validSymbol = (symbol2) => typeof symbol2 === "string" && /^[A-Z0-9_]{3,32}$/.test(symbol2);
var validSide = (side) => side === "BOTH" || side === "LONG" || side === "SHORT";
var validId = (id2) => (typeof id2 === "string" || typeof id2 === "number" && Number.isSafeInteger(id2)) && /^\d{1,25}$/.test(String(id2));
var decimal = /^-?\d{1,30}(?:\.\d{1,18})?$/;
var decimalText = (value) => {
  if (typeof value !== "string" || !decimal.test(value)) throw Error("\u5E01\u5B89\u8FD4\u56DE\u7684\u4ED3\u4F4D\u6216\u6210\u4EA4\u91D1\u989D\u65E0\u6548");
  return value;
};
var asUnits = (value) => {
  const [whole, fraction = ""] = value.replace(/^-/, "").split(".");
  return (value.startsWith("-") ? -1n : 1n) * BigInt(whole + fraction.padEnd(18, "0"));
};
var quantityText = (value) => {
  const digits = String(value < 0n ? -value : value).padStart(19, "0");
  const fraction = digits.slice(-18).replace(/0+$/, "");
  return digits.slice(0, -18) + (fraction ? "." + fraction : "");
};
var day = 24 * 60 * 60 * 1e3;
var pageSize = 1e3;
var positionTradeCaughtUp = (fillAt, positionUpdatedAt) => fillAt >= positionUpdatedAt - 1;
function decodePositions(value) {
  if (!Array.isArray(value)) throw Error("\u5E01\u5B89 U \u672C\u4F4D\u6301\u4ED3\u56DE\u62A5\u65E0\u6548");
  const positions = /* @__PURE__ */ new Map();
  for (const row of value) {
    const amount = decimalText(row?.positionAmt);
    const net = asUnits(amount);
    if (net === 0n) continue;
    if (!validSymbol(row.symbol) || !validSide(row.positionSide) || !Number.isSafeInteger(row.updateTime) || row.updateTime < 0 || row.positionSide === "LONG" && net < 0n || row.positionSide === "SHORT" && net > 0n) {
      throw Error("\u5E01\u5B89 U \u672C\u4F4D\u6301\u4ED3\u65B9\u5411\u6216\u66F4\u65B0\u65F6\u95F4\u65E0\u6548");
    }
    const position = {
      symbol: row.symbol,
      positionSide: row.positionSide,
      direction: net > 0n ? "long" : "short",
      quantity: amount.replace(/^-/, ""),
      entryPrice: decimalText(row.entryPrice),
      markPrice: decimalText(row.markPrice),
      unrealizedPnl: decimalText(row.unRealizedProfit),
      updatedAt: row.updateTime
    };
    for (const key2 of ["breakEvenPrice", "liquidationPrice", "positionInitialMargin", "isolatedWallet", "maintMargin", "notional"]) {
      if (typeof row[key2] === "string" && decimal.test(row[key2])) position[key2] = row[key2];
    }
    const leverage = Number(row.leverage);
    if (Number.isSafeInteger(leverage) && leverage > 0) position.leverage = leverage;
    if (row.marginType === "isolated" || row.marginType === "cross") position.marginMode = row.marginType;
    else if (row.marginType === "crossed") position.marginMode = "cross";
    else if (Number(position.isolatedWallet) > 0) position.marginMode = "isolated";
    const key = usdtMirrorKey(position);
    if (positions.has(key)) throw Error("\u5E01\u5B89\u6301\u4ED3\u56DE\u62A5\u91CD\u590D");
    positions.set(key, position);
  }
  return [...positions.values()].sort((a, b) => a.symbol.localeCompare(b.symbol) || a.positionSide.localeCompare(b.positionSide));
}
function decodeTrade(row, position, start, end) {
  if (row?.symbol !== position.symbol || !validSide(row.positionSide)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u4E0E\u4ED3\u4F4D\u4E0D\u7B26");
  if (row.positionSide !== position.positionSide) return;
  if (!Number.isSafeInteger(row.time) || row.time < start || row.time > end || !validId(row.id) || !validId(row.orderId) || row.side !== "BUY" && row.side !== "SELL") throw Error("\u5E01\u5B89\u6210\u4EA4\u65F6\u95F4\u6216\u8EAB\u4EFD\u65E0\u6548");
  const quantity2 = decimalText(row.qty), price = decimalText(row.price);
  if (asUnits(quantity2) <= 0n || asUnits(price) <= 0n) throw Error("\u5E01\u5B89\u6210\u4EA4\u6570\u91CF\u6216\u4EF7\u683C\u65E0\u6548");
  return { id: String(row.id), orderId: String(row.orderId), at: row.time, side: row.side, price, quantity: quantity2 };
}
var descending = (a, b) => b.at - a.at || (BigInt(a.id) > BigInt(b.id) ? -1 : a.id === b.id ? 0 : 1);
function createUsdtPositionReader(read, clock = Date.now) {
  let snapshot;
  let loading;
  const histories = /* @__PURE__ */ new Map();
  const working = /* @__PURE__ */ new Map();
  const positions = () => {
    if (loading) return loading;
    if (snapshot && clock() - snapshot.observedAt < 4e3 && clock() >= snapshot.observedAt) return Promise.resolve(snapshot);
    loading = (async () => {
      const positions2 = decodePositions(await read("GET", "/fapi/v3/positionRisk"));
      const keys = new Set(positions2.map(usdtMirrorKey));
      for (const key of histories.keys()) if (!keys.has(key)) histories.delete(key);
      return snapshot = { positions: positions2, observedAt: clock() };
    })().finally(() => {
      loading = void 0;
    });
    return loading;
  };
  const rebuild = async (position) => {
    const now = clock();
    let requests = 0;
    let end = Math.max(now, position.updatedAt);
    const oldest = now - 89 * day;
    let remaining = asUnits(position.quantity) * (position.direction === "long" ? 1n : -1n);
    const fills = [];
    const seen = /* @__PURE__ */ new Set();
    const page = async (start, stop) => {
      if (++requests > 40) throw Error("\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
      const rows = await read("GET", "/fapi/v1/userTrades", { symbol: position.symbol, startTime: String(start), endTime: String(stop), limit: String(pageSize) });
      if (!Array.isArray(rows)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u65E0\u6548");
      if (rows.length >= pageSize) {
        if (start === stop) throw Error("\u540C\u4E00\u6BEB\u79D2\u7684\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
        const mid = start + Math.floor((stop - start) / 2);
        return await page(mid + 1, stop) ?? await page(start, mid);
      }
      const ordered = rows.map((row) => decodeTrade(row, position, start, stop)).filter((trade) => !!trade).sort(descending);
      for (const fill of ordered) {
        if (seen.has(fill.id)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u91CD\u590D");
        seen.add(fill.id);
        const delta2 = asUnits(fill.quantity) * (fill.side === "BUY" ? 1n : -1n);
        const before = remaining - delta2;
        if (before === 0n || before > 0n !== remaining > 0n) {
          fills.push({ ...fill, positionQuantity: quantityText(remaining), action: "open" });
          return { openedAt: fill.at, fills: fills.reverse() };
        }
        if (fills.length >= 5e3) throw Error("\u6210\u4EA4\u8FC7\u591A\uFF0C\u672A\u80FD\u5B8C\u6574\u6838\u5BF9\u5F00\u4ED3\u65F6\u95F4");
        fills.push({ ...fill, positionQuantity: fill.quantity, action: remaining > 0n === delta2 > 0n ? "add" : "reduce" });
        remaining = before;
      }
    };
    let history2;
    try {
      while (end >= oldest && !history2) {
        const start = Math.max(oldest, end - 7 * day + 1);
        history2 = await page(start, end);
        end = start - 1;
      }
      if (!history2) history2 = { fills: [], issue: "\u5386\u53F2\u6210\u4EA4\u4E0D\u8DB3\uFF0C\u65E0\u6CD5\u6838\u5BF9\u5B9E\u9645\u5F00\u4ED3\u65F6\u95F4" };
    } catch (error) {
      return { fills: [], issue: error instanceof Error ? error.message : "\u65E0\u6CD5\u8BFB\u53D6\u5B9E\u9645\u6210\u4EA4" };
    }
    if (history2.openedAt && position.updatedAt && !positionTradeCaughtUp(history2.fills.at(-1).at, position.updatedAt)) {
      return { fills: [], issue: "\u6210\u4EA4\u8BB0\u5F55\u5C1A\u65E0\u6CD5\u4E0E\u5F53\u524D\u4ED3\u4F4D\u6838\u5BF9\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
    }
    const current = decodePositions(await read("GET", "/fapi/v3/positionRisk", { symbol: position.symbol })).find((row) => row.positionSide === position.positionSide);
    if (!current || usdtMirrorRevision(current) !== usdtMirrorRevision(position)) return { fills: [], issue: "\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u7B49\u5F85\u4E0B\u6B21\u540C\u6B65" };
    return history2;
  };
  const history = async (symbol2, side, revision) => {
    if (!validSymbol(symbol2) || !validSide(side) || typeof revision !== "string" || revision.length > 300) throw Error("\u8BF7\u5148\u5237\u65B0\u5E01\u5B89\u4ED3\u4F4D");
    const key = usdtMirrorKey({ symbol: symbol2, positionSide: side });
    const position = (await positions()).positions.find((row) => usdtMirrorKey(row) === key);
    if (!position || usdtMirrorRevision(position) !== revision) return { fills: [], issue: "\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u7B49\u5F85\u4E0B\u6B21\u540C\u6B65" };
    const cached = histories.get(key);
    if (cached?.revision === revision) return cached.history;
    if (working.has(revision)) return working.get(revision);
    if (working.size >= 2) return { fills: [], issue: "\u6B63\u5728\u540C\u6B65\u5176\u4ED6\u4ED3\u4F4D\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
    const task = rebuild(position).then((result) => {
      if (result.openedAt) {
        histories.delete(key);
        histories.set(key, { revision, history: result });
        if (histories.size > 64) histories.delete(histories.keys().next().value);
      }
      return result;
    }).finally(() => {
      working.delete(revision);
    });
    working.set(revision, task);
    return task;
  };
  return { positions, history, invalidate: () => {
    snapshot = void 0;
  } };
}

// scripts/usdt-executor-context.ts
import { createHash as createHash2 } from "node:crypto";
import { execFileSync as execFileSync2 } from "node:child_process";
import { readFileSync, openSync, closeSync, writeFileSync, unlinkSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// scripts/usdt-macos-credentials.ts
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
var service = "app.veil-of-ignorance.usdt-executor";
var identity = (directory) => createHash("sha256").update(resolve(directory)).digest("hex");
var security = (args, input) => execFileSync("/usr/bin/security", args, {
  input,
  stdio: ["pipe", "pipe", "ignore"],
  timeout: 3e4
});
function readMacUsdtCredentials(directory, run = security) {
  let buffer;
  try {
    buffer = run(["find-generic-password", "-s", service, "-a", identity(directory), "-w"]);
    const data = JSON.parse(Buffer.from(buffer.toString("utf8").trim(), "base64").toString("utf8"));
    if (!/^[a-zA-Z0-9]{16,256}$/.test(data.apiKey) || !/^[a-zA-Z0-9]{16,256}$/.test(data.secret)) throw Error();
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6 Mac \u94A5\u5319\u4E32\u4E2D\u7684\u5E01\u5B89\u51ED\u8BC1\uFF0C\u8BF7\u5148\u914D\u7F6E\u5E76\u5141\u8BB8\u672C\u673A\u94A5\u5319\u4E32\u8BBF\u95EE\u3002");
  } finally {
    buffer?.fill(0);
  }
}

// scripts/usdt-executor-context.ts
import { DatabaseSync } from "node:sqlite";
function loadUsdtCredentials(directory) {
  if (process.platform === "darwin") return readMacUsdtCredentials(directory);
  if (process.platform !== "win32") throw Error("\u6B64\u6267\u884C\u5668\u53EA\u652F\u6301 Windows \u548C Mac");
  const script = [
    '$ErrorActionPreference="Stop"',
    "$saved = Get-Content -LiteralPath $env:VEIL_BINANCE_CREDENTIAL_FILE -Raw | ConvertFrom-Json",
    "$key = $saved.apiKey | ConvertTo-SecureString",
    "$secret = $saved.secretKey | ConvertTo-SecureString",
    'try { @{apiKey=[net.networkcredential]::new("",$key).Password;secret=[net.networkcredential]::new("",$secret).Password} | ConvertTo-Json -Compress }',
    "finally { $key.Dispose(); $secret.Dispose() }"
  ].join("\n");
  let buffer;
  try {
    buffer = execFileSync2("pwsh.exe", ["-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(script, "utf16le").toString("base64")], {
      windowsHide: true,
      timeout: 1e4,
      env: { ...process.env, VEIL_BINANCE_CREDENTIAL_FILE: join(directory, "account.dpapi") },
      stdio: ["ignore", "pipe", "ignore"]
    });
  } catch {
    throw Error("\u65E0\u6CD5\u8BFB\u53D6\u672C\u673A\u52A0\u5BC6\u7684\u5E01\u5B89 API \u51ED\u8BC1");
  }
  try {
    const data = JSON.parse(buffer.toString("utf8"));
    if (typeof data.apiKey !== "string" || typeof data.secret !== "string" || !data.apiKey || !data.secret) throw Error("\u5E01\u5B89\u51ED\u8BC1\u683C\u5F0F\u9519\u8BEF");
    return { apiKey: data.apiKey, secret: Buffer.from(data.secret) };
  } finally {
    buffer.fill(0);
  }
}
function readUsdtConfig(directory) {
  const value = JSON.parse(readFileSync(join(directory, "usdt-follow.json"), "utf8").replace(/^\uFEFF/, ""));
  if (!/^[a-f0-9-]{36}$/i.test(value.owner) || !/^[0-9a-f]{64}$/i.test(value.token) || !/^[0-9a-f]{64}$/.test(value.account))
    throw Error("\u672C\u673A\u914D\u5BF9\u914D\u7F6E\u65E0\u6548");
  return value;
}
function usdtRuntime() {
  return createHash2("sha256").update(readFileSync(join(dirname(fileURLToPath(import.meta.url)), "usdt-follow-server.mjs"))).digest("hex");
}
function lockUsdtDirectory(directory) {
  const path = join(directory, "usdt-follow.lock");
  let fd;
  try {
    fd = openSync(path, "wx", 384);
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    const pid = Number(readFileSync(path, "utf8"));
    if (!Number.isSafeInteger(pid) || pid <= 0) throw Error("\u672C\u673A\u6267\u884C\u9501\u65E0\u6548\uFF0C\u8BF7\u4EBA\u5DE5\u6838\u5BF9\u8FDB\u7A0B");
    try {
      process.kill(pid, 0);
      throw Error("\u672C\u673A\u6267\u884C\u5668\u4ECD\u5728\u8FD0\u884C\uFF0C\u8BF7\u5148\u51BB\u7ED3\u5E76\u505C\u6B62\u539F\u8FDB\u7A0B");
    } catch (cause) {
      if (cause.code !== "ESRCH") throw cause;
      unlinkSync(path);
    }
    fd = openSync(path, "wx", 384);
  }
  writeFileSync(fd, String(process.pid));
  return () => {
    closeSync(fd);
    unlinkSync(path);
  };
}

// scripts/usdt-handoff.ts
import { createHash as createHash3, generateKeyPairSync, randomUUID, sign, verify } from "node:crypto";
var HANDOFF_PROTOCOL = "veil-usdt-handoff-v1";
var handoffHash = (value) => createHash3("sha256").update(JSON.stringify(value)).digest("hex");
function requireValue(ok, message) {
  if (!ok) throw Error(message);
}
function checked(envelope) {
  requireValue(envelope && typeof envelope.publicKey === "string" && typeof envelope.signature === "string", "\u4EA4\u63A5\u7B7E\u540D\u7F3A\u5931");
  try {
    requireValue(verify(null, Buffer.from(JSON.stringify(envelope.payload)), envelope.publicKey, Buffer.from(envelope.signature, "base64")), "\u4EA4\u63A5\u6587\u4EF6\u7B7E\u540D\u4E0D\u7B26");
  } catch {
    throw Error("\u4EA4\u63A5\u6587\u4EF6\u7B7E\u540D\u65E0\u6548\u6216\u5DF2\u635F\u574F");
  }
  return envelope.payload;
}
function createUsdtHandoff(store, account, owner, runtime) {
  let device = store.local("device");
  if (!device) {
    const pair = generateKeyPairSync("ed25519", { publicKeyEncoding: { type: "spki", format: "pem" }, privateKeyEncoding: { type: "pkcs8", format: "pem" } });
    device = { id: handoffHash(pair.publicKey), publicKey: pair.publicKey, privateKey: pair.privateKey };
    store.setLocal("device", device);
  }
  const local = device;
  const seal = (payload) => ({
    payload,
    publicKey: local.publicKey,
    signature: sign(null, Buffer.from(JSON.stringify(payload)), local.privateKey).toString("base64")
  });
  const state = () => store.local("authority") ?? { stage: "empty", epoch: 0, chain: "" };
  const save = (value) => store.setLocal("authority", value);
  const assertActive = () => requireValue(state().stage === "active", "\u6267\u884C\u6743\u5C1A\u672A\u6838\u5BF9\u6216\u5DF2\u7ECF\u4EA4\u51FA\uFF1B\u672C\u7AEF\u7981\u6B62\u4EA4\u6613");
  return {
    device: local.id,
    state,
    assertActive,
    initializeSource() {
      requireValue(state().stage === "empty" && !store.local("receive-request"), "\u672C\u7AEF\u5DF2\u6709\u4EA4\u63A5\u8BB0\u5F55\uFF0C\u4E0D\u80FD\u91CD\u65B0\u521D\u59CB\u5316");
      save({ stage: "active", epoch: 0, chain: handoffHash(randomUUID()) });
    },
    receiveRequest() {
      const current = state();
      requireValue(["empty", "outgoing", "cancelled"].includes(current.stage), "\u672C\u7AEF\u5C1A\u672A\u4EA4\u51FA\u6267\u884C\u6743\uFF0C\u4E0D\u80FD\u7533\u8BF7\u63A5\u7BA1");
      const previous = store.local("receive-request");
      if (previous && !store.local("consumed:" + previous.payload.nonce)) return previous;
      const request = seal({
        protocol: HANDOFF_PROTOCOL,
        kind: "receive",
        nonce: randomUUID(),
        device: local.id,
        account,
        owner,
        epoch: current.epoch,
        runtime,
        ...current.chain ? { chain: current.chain } : {}
      });
      store.setLocal("receive-request", request);
      return request;
    },
    freeze() {
      const current = state();
      if (current.stage === "frozen") return;
      requireValue(current.stage === "active", "\u672C\u7AEF\u6CA1\u6709\u53EF\u51BB\u7ED3\u7684\u6267\u884C\u6743");
      save({ ...current, stage: "frozen", wasPaused: store.paused() });
      store.setPaused(true);
    },
    export(request, evidence, frozenAt) {
      const current = state(), receive = checked(request);
      requireValue(receive.protocol === HANDOFF_PROTOCOL && receive.kind === "receive" && receive.account === account && receive.owner === owner && receive.device === handoffHash(request.publicKey) && receive.device !== local.id && receive.runtime === runtime && /^[a-f0-9-]{36}$/i.test(receive.nonce), "\u63A5\u7BA1\u8BF7\u6C42\u7684\u8D26\u6237\u3001\u8BBE\u5907\u6216\u6267\u884C\u4EE3\u7801\u7248\u672C\u4E0D\u7B26");
      if (current.stage === "outgoing") {
        requireValue(handoffHash(current.bundle.payload.request) === handoffHash(request), "\u672C\u7AEF\u5DF2\u4EA4\u51FA\u6267\u884C\u6743\uFF0C\u4E0D\u80FD\u518D\u5BFC\u51FA\u7ED9\u53E6\u4E00\u53F0\u8BBE\u5907");
        return current.bundle;
      }
      requireValue(current.stage === "frozen", "\u5FC5\u987B\u5148\u505C\u6B62\u6267\u884C\u5E76\u51BB\u7ED3\u8D26\u672C");
      requireValue(current.epoch >= receive.epoch && (!receive.chain || receive.chain === current.chain), "\u63A5\u7BA1\u8BF7\u6C42\u5C5E\u4E8E\u65E7\u4EA4\u63A5\u94FE");
      const bundle = seal({
        protocol: HANDOFF_PROTOCOL,
        kind: "handoff",
        id: randomUUID(),
        epoch: current.epoch + 1,
        parent: current.chain,
        request,
        frozenAt,
        wasPaused: current.wasPaused ?? true,
        ledger: store.snapshot(),
        evidence,
        runtime
      });
      save({ stage: "outgoing", epoch: bundle.payload.epoch, chain: handoffHash(bundle), bundle, wasPaused: current.wasPaused });
      return bundle;
    },
    import(bundle) {
      const value = checked(bundle), current = state();
      const receive = checked(value.request);
      const ownRequest = store.local("receive-request");
      requireValue(value.protocol === HANDOFF_PROTOCOL && value.kind === "handoff" && value.runtime === runtime, "\u4EA4\u63A5\u534F\u8BAE\u6216\u6267\u884C\u4EE3\u7801\u7248\u672C\u4E0D\u4E00\u81F4");
      requireValue(ownRequest && handoffHash(ownRequest) === handoffHash(value.request) && value.request.publicKey === local.publicKey && receive.device === local.id && receive.account === account && receive.owner === owner && !store.local("consumed:" + receive.nonce), "\u4EA4\u63A5\u6587\u4EF6\u4E0D\u5C5E\u4E8E\u672C\u6B21\u63A5\u7BA1\u8BF7\u6C42\uFF0C\u6216\u5DF2\u7ECF\u4F7F\u7528/\u4F5C\u5E9F");
      requireValue(["empty", "outgoing", "cancelled"].includes(current.stage) && value.epoch > current.epoch && (!current.chain || value.parent === current.chain), "\u672C\u7AEF\u5DF2\u6709\u6267\u884C\u6743\u6216\u4EA4\u63A5\u6587\u4EF6\u5DF2\u8FC7\u671F");
      requireValue(current.stage !== "empty" || store.readAll().length === 0 && store.snapshot().tables.position_controls.length === 0 && store.snapshot().tables.desk_orders.length === 0, "\u76EE\u6807\u7AEF\u5DF2\u6709\u672A\u7EB3\u5165\u4EA4\u63A5\u7684\u65E7\u8D26\u672C\uFF0C\u5FC5\u987B\u5148\u6838\u5BF9\u5386\u53F2\uFF0C\u7981\u6B62\u76F4\u63A5\u8986\u76D6");
      if (current.stage === "outgoing") requireValue(bundle.publicKey === current.bundle.payload.request.publicKey, "\u9000\u56DE\u8D26\u672C\u5E76\u975E\u6765\u81EA\u63A5\u7BA1\u8BBE\u5907");
      requireValue(createHash3("sha256").update(value.ledger.account).digest("hex") === account && value.ledger.owner === owner, "\u4EA4\u63A5\u8D26\u672C\u7684\u8D26\u6237\u4E0D\u7B26");
      const next = {
        stage: "staged",
        epoch: value.epoch,
        chain: handoffHash(bundle),
        bundle,
        request: ownRequest,
        wasPaused: value.wasPaused
      };
      store.importSnapshot(value.ledger, next);
      store.setLocal("consumed:" + receive.nonce, true);
    },
    activateAfterReconciliation() {
      const current = state();
      requireValue(current.stage === "staged" || current.stage === "frozen", "\u672C\u7AEF\u4E0D\u80FD\u6062\u590D\uFF1A\u5DF2\u4EA4\u51FA\u7684\u6267\u884C\u6743\u9700\u8981\u63A5\u6536\u7AEF\u4F5C\u5E9F\u51ED\u636E\u6216\u53CD\u5411\u4EA4\u63A5");
      if (current.bundle) store.setLocal("activated:" + current.bundle.payload.id, true);
      save({ ...current, stage: "active" });
      store.setPaused(current.wasPaused ?? true);
    },
    cancelIncoming(bundle) {
      const current = state(), incoming = bundle ?? current.bundle;
      requireValue(incoming, "\u9700\u8981\u539F\u4EA4\u63A5\u6587\u4EF6\u624D\u80FD\u751F\u6210\u4F5C\u5E9F\u51ED\u636E");
      const value = checked(incoming), receive = checked(value.request);
      const own = store.local("receive-request");
      const prior = store.local("cancel:" + value.id);
      if (prior) return prior;
      requireValue(
        !store.local("activated:" + value.id) && current.stage !== "active" && current.stage !== "frozen" && own && handoffHash(own) === handoffHash(value.request) && value.request.publicKey === local.publicKey && createHash3("sha256").update(value.ledger.account).digest("hex") === account && value.ledger.owner === owner,
        "\u5DF2\u7ECF\u6267\u884C\u8FC7\u7684\u63A5\u7BA1\u5FC5\u987B\u53CD\u5411\u4EA4\u63A5\uFF0C\u4E0D\u80FD\u751F\u6210\u4F5C\u5E9F\u51ED\u636E"
      );
      const receipt = seal({
        protocol: HANDOFF_PROTOCOL,
        kind: "cancel",
        transfer: value.id,
        nonce: receive.nonce,
        bundleHash: handoffHash(incoming)
      });
      store.setLocal("consumed:" + receive.nonce, true);
      save({ ...current, stage: "cancelled" });
      store.setLocal("cancel:" + value.id, receipt);
      return receipt;
    },
    acceptCancellation(receipt) {
      const value = checked(receipt), current = state(), bundle = current.bundle;
      requireValue(current.stage === "outgoing" && bundle && value.protocol === HANDOFF_PROTOCOL && value.kind === "cancel" && receipt.publicKey === bundle.payload.request.publicKey && value.transfer === bundle.payload.id && value.nonce === bundle.payload.request.payload.nonce && value.bundleHash === handoffHash(bundle), "\u4F5C\u5E9F\u51ED\u636E\u4E0E\u672C\u6B21\u4EA4\u63A5\u4E0D\u7B26");
      save({ ...current, stage: "frozen" });
    }
  };
}

// scripts/usdt-handoff-reconcile.ts
init_qualityPlanVersions();
import { createHash as createHash5 } from "node:crypto";

// src/lib/fish/instantCampaign.ts
init_campaignRealizedPnl();
init_algorithm();
init_records();
init_qualityAdmissionTime();

// src/lib/fish/screenedCda.ts
init_features();
init_featureSource();
init_dbl5m();
init_algorithm();
init_qualityInitialization();
init_quality();
init_qualityFilters();
init_shared();
init_instantMonitorSettings();

// src/lib/tpSlOrders.ts
init_tradingSettlement();

// src/lib/fish/screenedCda.ts
var GUARD_DEF = { ...DBL5_DEF, DBL5_config: dbl5Parameters({ guard_version: DBL5_RETEST_GUARD_VERSION }) };

// src/lib/fish/instantCampaign.ts
init_qualityMirror();
init_shared();
init_preEntryMonitor();

// src/lib/fish/instantCampaignMetadata.ts
init_records();
function instantCampaignMetadata(record, round) {
  const fish = record.sample.source.fish;
  let matched = [];
  if (fish?.algorithms?.length) {
    matched = fish.combination === "or" ? [...new Set(fish.hitAlgorithms ?? [])].map((index) => fish.algorithms[index - 1]).filter(Boolean) : fish.algorithms;
  } else if (fish) matched = [fish];
  const algorithms = matched.map((value) => {
    const reading = value.average * (value.scale ?? 1);
    return {
      label: fishSourceLabel({ ...value, featureShort: value.featureShort ?? value.featureName ?? value.featureId ?? "CBI-2" }),
      ...Number.isFinite(reading) ? { reading } : {},
      unit: value.unit,
      interval: value.interval
    };
  });
  const plan = round.plans?.find((value) => value.id === record.planId) ?? (round.plans?.length === 1 ? round.plans[0] : void 0);
  return {
    ...round.instantPosition ? { position: round.instantPosition } : {},
    ...algorithms.length ? { fishing: { algorithms, combination: fish?.algorithms?.length ? fish.combination ?? "and" : void 0 } } : {},
    screening: {
      ...round.directAdmission ? { directAdmission: true } : {},
      plan,
      hours: round.hours,
      engine: round.engine,
      matchedAt: record.matchedAt,
      ...record.threeStage ? { evidence: { admission: record.threeStage.admission, readings: record.threeStage.readings } } : {}
    }
  };
}

// src/lib/fish/instantCampaign.ts
init_instantMonitorSettings();

// src/lib/fish/instantMonitorExecution.ts
init_quality();
init_qualityLegacyEngine();
init_qualityPositionManagement();
init_qualityPlanVersions();
init_qualityAddition();
init_preEntryWindowLoader();
init_qualityInitialization();
init_instantMonitorSettings();

// src/lib/fish/instantLegacyPosition.ts
init_qualityPositionManagement();

// src/lib/fish/instantMonitorExecution.ts
init_instantPositionSettings();
init_qualityMirrorLossReview();

// src/lib/fish/instantCampaign.ts
init_quality();

// src/lib/fish/qualityCampaignProjection.ts
init_qualityPlanRouter();
init_qualitySellStages();
init_qualityAddition();

// src/lib/fish/qualityAdditionCampaign.ts
init_qualityAdditionStructure();
init_qualityHoldingLedger();
init_qualityAddition();

// src/lib/fish/qualityCampaignProjection.ts
init_qualitySources();

// src/lib/fish/qualityPresentation.ts
init_qualityHoldingLedger();
init_qualityAddition();
init_qualityMirror();
init_timeFormat();
init_qualityStaticDrawdownSell();
init_qualityVeto();

// src/lib/fish/qualityCampaignProjection.ts
init_campaignSections();
init_qualityCampaignArchive();

// src/lib/fish/cards.ts
init_accountSettings();
init_userStoragePrefix();
init_persistedStateStorage();

// src/lib/fish/preferences.ts
init_userStoragePrefix();
init_persistedStateStorage();
init_features();
init_featureSource();

// src/lib/fish/cards.ts
init_shared();
init_defaultRules();
init_defaultRules();
var FISH_DEFAULT_ALGORITHMS = FISH_DEFAULT_RULES.map((rule) => rule.featureId);

// src/lib/fish/qualityCampaignProjection.ts
init_qualityPositionManagement();
init_quality();
init_qualityVeto();
init_qualityDbl5Sell();
init_qualityStaticDrawdownSell();

// src/lib/fish/qualityComparison.ts
init_cdaPeriods();
init_qualityAdmissionTime();
init_researchIndicators();
init_qualityLegacyEngine();
init_features();
init_qualityAdditionMetric();
init_features();
init_featureSource();
init_quality();

// src/lib/fish/qualityMonitorCampaign.ts
init_qualityCampaignArchive();

// src/lib/fish/instantCampaign.ts
init_qualityAddition();
init_qualityCampaignArchive();

// src/lib/fish/instantManualCampaign.ts
init_campaignRealizedPnl();

// src/lib/fish/instantCampaign.ts
function instantPositionInput(record, round) {
  const buyAt = record.matchedAt;
  if (record.roundId !== round.id || record.status !== "matched" || !isAutomaticPreEntryRound(round) || round.state !== "complete" || !Number.isSafeInteger(buyAt) || buyAt <= 0) return;
  const { id: id2, symbol: symbol2, market, exchange, underlying, binanceSymbol } = record.sample.source;
  return {
    id: "fish-instant-" + shortFishHash(record.id),
    recordId: record.id,
    buyAt,
    source: { id: id2, symbol: symbol2, market, exchange, underlying, binanceSymbol, timeMs: qualitySignalTime(record.sample.source) },
    planLabel: round.plans?.find((plan) => plan.id === record.planId)?.label,
    ...round.instantPosition ? { instantPosition: round.instantPosition } : {},
    ...round.instantMonitor ? { monitor: round.instantMonitor } : {},
    detectors: record.sample.source.fish ? fishCaughtBy(record.sample.source) : [],
    metadata: instantCampaignMetadata(record, round)
  };
}

// scripts/usdt-exchange.ts
import { createHash as createHash4, createHmac } from "node:crypto";
var spot = "https://api.binance.com";
var futures = "https://fapi.binance.com";
var tradingPaths = /* @__PURE__ */ new Set(["/fapi/v1/order", "/fapi/v1/algoOrder", "/fapi/v1/leverage", "/fapi/v1/marginType", "/fapi/v1/positionMargin"]);
var UsdtApiError = class extends Error {
  status;
  code;
  constructor(status, code) {
    super("\u5E01\u5B89 U \u672C\u4F4D\u8BF7\u6C42\u5931\u8D25\uFF08HTTP " + status + (code == null ? "" : "\uFF0C\u4EE3\u7801 " + code) + "\uFF09");
    this.status = status;
    this.code = code;
  }
};
var usdtOrderId = (owner, campaign, action) => "veil-" + createHash4("sha256").update(JSON.stringify([owner, campaign, action])).digest("hex").slice(0, 30);
var quantityText2 = /^\d+(?:\.\d+)?$/;
function quantityUnits(raw, step) {
  if (!quantityText2.test(raw) || !quantityText2.test(step)) throw Error("\u5E01\u5B89\u59D4\u6258\u6570\u91CF\u683C\u5F0F\u65E0\u6548");
  const decimals = Math.max(raw.split(".")[1]?.length ?? 0, step.split(".")[1]?.length ?? 0);
  const scaled = (value) => BigInt(value.replace(".", "") + "0".repeat(decimals - (value.split(".")[1]?.length ?? 0)));
  const size = scaled(step);
  const units2 = scaled(raw);
  if (size <= 0n || units2 % size !== 0n || units2 / size > BigInt(Number.MAX_SAFE_INTEGER)) throw Error("\u5E01\u5B89\u6570\u91CF\u4E0E\u4EA4\u6613\u6B65\u957F\u4E0D\u4E00\u81F4");
  return Number(units2 / size);
}
function formatQuantity(units2, step) {
  if (!Number.isSafeInteger(units2) || units2 < 0 || !quantityText2.test(step)) throw Error("\u5E01\u5B89\u59D4\u6258\u6570\u91CF\u65E0\u6548");
  const decimals = step.split(".")[1]?.length ?? 0;
  const digits = String(BigInt(units2) * BigInt(step.replace(".", ""))).padStart(decimals + 1, "0");
  return decimals ? digits.slice(0, -decimals) + "." + digits.slice(-decimals) : digits;
}
function createUsdtRequest(credentials, fetcher = fetch, authorizeWrite) {
  const clocks = /* @__PURE__ */ new Map();
  const send = async (method, path, params) => {
    const base = path.startsWith("/fapi/") ? futures : spot;
    if (!/^\/(?:fapi|sapi|api)\/v\d+\/(?:[a-zA-Z]+\/)*[a-zA-Z0-9]+$/.test(path) || method === "POST" && !tradingPaths.has(path) || method === "DELETE" && path !== "/fapi/v1/algoOrder" && path !== "/fapi/v1/order")
      throw Error("\u5E01\u5B89\u7B7E\u540D\u8BF7\u6C42\u8DEF\u5F84\u65E0\u6548");
    const signal = AbortSignal.timeout(1e4);
    let clock = clocks.get(base);
    if (!clock || Date.now() - clock.sampled >= 3e4 || Date.now() < clock.sampled) {
      const response2 = await fetcher(base + (base === futures ? "/fapi/v1/time" : "/api/v3/time"), { redirect: "error", signal });
      if (!response2.ok) throw new UsdtApiError(response2.status);
      const { serverTime } = await response2.json();
      if (!Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u949F\u4E0D\u53EF\u7528");
      clock = { sampled: Date.now(), offset: serverTime - Date.now() };
      clocks.set(base, clock);
    }
    if (method !== "GET") authorizeWrite?.();
    const query = new URLSearchParams({ ...params, recvWindow: method === "GET" ? "12000" : "5000", timestamp: String(Date.now() + clock.offset) });
    query.set("signature", createHmac("sha256", credentials.secret).update(query.toString()).digest("hex"));
    const response = await fetcher(base + path + (method === "POST" ? "" : "?" + query), {
      method,
      redirect: "error",
      signal,
      headers: { "X-MBX-APIKEY": credentials.apiKey, ...method === "POST" ? { "Content-Type": "application/x-www-form-urlencoded" } : {} },
      ...method === "POST" ? { body: query.toString() } : {}
    });
    const body2 = await response.text().then((text) => JSON.parse(
      text,
      (key, value, context) => ["orderId", "uid", "id", "algoId"].includes(key) && typeof value === "number" && /^\d+$/.test(context?.source ?? "") ? context.source : value
    )).catch(() => void 0);
    if (body2?.code === -1021) clocks.delete(base);
    if (!response.ok || body2?.code < 0) throw new UsdtApiError(response.status, typeof body2?.code === "number" ? body2.code : void 0);
    if (body2 == null) throw Error("\u5E01\u5B89\u54CD\u5E94\u4E0D\u53EF\u8BC6\u522B");
    return body2;
  };
  return async (method, path, params = {}) => {
    try {
      return await send(method, path, params);
    } catch (error) {
      if (method === "GET" && (error instanceof TypeError || error instanceof DOMException || error instanceof UsdtApiError && (error.code === -1021 || error.status >= 500))) return send(method, path, params);
      throw error;
    }
  };
}
async function readUsdtMarket(symbol2, fetcher = fetch) {
  if (!/^[A-Z0-9]{2,24}USDT$/.test(symbol2)) return;
  const response = await fetcher(futures + "/fapi/v1/exchangeInfo", { signal: AbortSignal.timeout(9e3), redirect: "error" });
  if (!response.ok) throw new UsdtApiError(response.status);
  const body2 = await response.json();
  if (!Array.isArray(body2.symbols)) throw Error("\u65E0\u6CD5\u8BFB\u53D6\u5E01\u5B89\u5408\u7EA6\u89C4\u683C");
  const contract = body2.symbols.find((row) => row.symbol === symbol2 && row.quoteAsset === "USDT" && row.marginAsset === "USDT" && row.contractType === "PERPETUAL" && row.status === "TRADING");
  if (!contract) return;
  const lot = contract.filters?.find((row) => row.filterType === "LOT_SIZE");
  const marketLot = contract.filters?.find((row) => row.filterType === "MARKET_LOT_SIZE");
  const minimum = contract.filters?.find((row) => row.filterType === "MIN_NOTIONAL");
  const price = contract.filters?.find((row) => row.filterType === "PRICE_FILTER");
  const step = lot?.stepSize;
  const minNotional = Number(minimum?.notional);
  if (typeof step !== "string" || Number(step) <= 0 || !Number.isFinite(minNotional) || minNotional < 0) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u89C4\u683C\u4E0D\u5B8C\u6574");
  const min = Math.max(1, Math.ceil(Math.max(Number(lot.minQty), Number(marketLot.minQty)) / Number(step) - 1e-9));
  const max = Math.floor(Math.min(Number(lot.maxQty), Number(marketLot.maxQty)) / Number(step) + 1e-9);
  if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max < min) throw Error("\u5408\u7EA6\u5E02\u4EF7\u5355\u6570\u91CF\u8303\u56F4\u4E0D\u53EF\u7528");
  return { symbol: symbol2, step, min, max, minNotional, marketStep: marketLot?.stepSize, priceTick: price?.tickSize };
}
async function readUsdtMark(symbol2, fetcher = fetch) {
  const query = new URLSearchParams({ symbol: symbol2 });
  const reply = await fetcher(
    futures + "/fapi/v1/premiumIndex?" + query,
    { signal: AbortSignal.timeout(8e3), redirect: "error" }
  );
  if (!reply.ok) throw new UsdtApiError(reply.status);
  const mark = await reply.json();
  if (mark.symbol !== symbol2 || typeof mark.markPrice !== "string" || !quantityText2.test(mark.markPrice) || !Number.isFinite(Number(mark.markPrice)) || Number(mark.markPrice) <= 0) throw Error("\u5E01\u5B89\u6807\u8BB0\u4EF7\u683C\u65E0\u6548");
  return mark.markPrice;
}
function createUsdtExchange(request, fetcher = fetch) {
  const positionSide = (mode) => mode === "hedge" ? "LONG" : "BOTH";
  return {
    async account() {
      const [user, key, account, mode] = await Promise.all([
        request("GET", "/api/v3/account", { omitZeroBalances: "true" }),
        request("GET", "/sapi/v1/account/apiRestrictions"),
        request("GET", "/fapi/v3/account"),
        request("GET", "/fapi/v1/positionSide/dual")
      ]);
      if (!/^[1-9]\d*$/.test(String(user.uid)) || key.enableReading !== true || key.enableFutures !== true || key.ipRestrict !== true || typeof mode.dualSidePosition !== "boolean" || !Array.isArray(account.assets) || !Array.isArray(account.positions) || account.canTrade === false) throw Error("\u5E01\u5B89 U \u672C\u4F4D\u8D26\u6237\u3001\u5408\u7EA6\u6743\u9650\u6216 IP \u767D\u540D\u5355\u672A\u901A\u8FC7\u9A8C\u8BC1");
      return { id: String(user.uid), mode: mode.dualSidePosition ? "hedge" : "one-way" };
    },
    async market(symbol2) {
      return readUsdtMarket(symbol2, fetcher);
    },
    async book(symbol2, side) {
      const p = new URLSearchParams({ symbol: symbol2 });
      const response = await fetcher(
        futures + "/fapi/v1/ticker/bookTicker?" + p,
        { signal: AbortSignal.timeout(8e3), redirect: "error" }
      );
      if (!response.ok) throw new UsdtApiError(response.status);
      const quote = await response.json();
      const price = String(side === "BUY" ? quote.askPrice : quote.bidPrice);
      if (quote.symbol !== symbol2 || !quantityText2.test(price) || !Number.isFinite(Number(price)) || Number(price) <= 0) throw Error("\u5E01\u5B89\u76D8\u53E3\u4EF7\u683C\u65E0\u6548");
      return price;
    },
    async check(market, mode, held, entry, opening, leverage, managed, knownProtection, unsettledBuyId, confirmOpening, openingNotional) {
      const { symbol: symbol2 } = market;
      const [positions, regular, algo, settings, modes, tiers] = await Promise.all([
        request("GET", "/fapi/v3/positionRisk", { symbol: symbol2 }),
        request("GET", "/fapi/v1/openOrders", { symbol: symbol2 }),
        request("GET", "/fapi/v1/openAlgoOrders", { symbol: symbol2 }),
        request("GET", "/fapi/v1/symbolConfig", { symbol: symbol2 }),
        request("GET", "/fapi/v1/positionSide/dual"),
        opening && openingNotional !== void 0 ? request("GET", "/fapi/v1/leverageBracket", { symbol: symbol2 }) : void 0
      ]);
      if (modes.dualSidePosition !== (mode === "hedge")) throw Error("\u5E01\u5B89\u6301\u4ED3\u6A21\u5F0F\u5DF2\u53D8\u5316");
      if (![positions, regular, algo, settings].every(Array.isArray)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6216\u6302\u5355\u8BFB\u6570\u4E0D\u53EF\u7528");
      if (unsettledBuyId && regular.some((order) => order.clientOrderId === unsettledBuyId))
        throw Error("\u5E01\u5B89\u4ECD\u6709\u8FD9\u7B14\u4E70\u5165\u59D4\u6258\u5728\u6302\u5355\u4E2D\uFF0C\u7B49\u5F85\u5B8C\u6210\u540E\u9000\u51FA");
      if ((regular.length || algo.some((row2) => !knownProtection?.includes(row2.clientAlgoId))) && (leverage !== 0 || managed))
        throw Error("\u8BE5\u5408\u7EA6\u6709\u5916\u90E8\u6302\u5355\uFF0C\u9700\u6838\u5BF9\u4ED3\u4F4D");
      const active = positions.filter((row2) => Number(row2.positionAmt) !== 0);
      const row = active.find((item) => item.symbol === symbol2 && item.positionSide === positionSide(mode));
      if (active.some((item) => item !== row && !(managed && mode === "hedge" && item.positionSide === "SHORT")) || (row && Number(row.positionAmt) > 0 ? quantityUnits(String(row.positionAmt), market.step) : row ? -1 : 0) !== held || held > 0 && (!Number.isFinite(Number(row.entryPrice)) || Math.abs(Number(row.entryPrice) - entry) > Math.max(1e-8, entry * 1e-5))) {
        throw Error("\u5E01\u5B89\u5B9E\u9645\u4ED3\u4F4D\u4E0E\u672C\u673A\u6210\u4EA4\u8BB0\u5F55\u4E0D\u4E00\u81F4");
      }
      if (leverage === 0 || managed === "existing-position") return;
      const config = settings.find((item) => item.symbol === symbol2);
      if (!config) throw Error("\u5E01\u5B89\u5408\u7EA6\u914D\u7F6E\u4E0D\u53EF\u7528");
      if (opening) {
        let target = leverage;
        if (openingNotional !== void 0) {
          const brackets = Array.isArray(tiers) && tiers.find((item) => item.symbol === symbol2)?.brackets;
          const tier = Array.isArray(brackets) && brackets.find((item) => openingNotional >= Number(item.notionalFloor) && openingNotional < Number(item.notionalCap));
          const maximum = Number(tier?.initialLeverage);
          if (!Number.isSafeInteger(maximum) || maximum < 1) throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u8BA1\u5212\u540D\u4E49\u4ED3\u4F4D\u9002\u7528\u7684\u6760\u6746\u6863\u4F4D\uFF0C\u672A\u63D0\u4EA4\u4E70\u5355");
          target = Math.min(leverage, maximum);
        }
        if (config.marginType !== "ISOLATED") {
          confirmOpening?.();
          try {
            await request("POST", "/fapi/v1/marginType", { symbol: symbol2, marginType: "ISOLATED" });
          } catch (error) {
            if (!(error instanceof UsdtApiError) || error.code !== -4046) throw error;
          }
        }
        if (Number(config.leverage) !== target) {
          confirmOpening?.();
          try {
            const result = await request("POST", "/fapi/v1/leverage", { symbol: symbol2, leverage: String(target) });
            if (result.symbol !== symbol2 || Number(result.leverage) !== target) throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u5B9E\u76D8\u6760\u6746");
          } catch (error) {
            if (!(error instanceof UsdtApiError) || error.code !== -4028) throw error;
            const settings2 = await request("GET", "/fapi/v1/symbolConfig", { symbol: symbol2 });
            const actual = Array.isArray(settings2) && settings2.find((item) => item.symbol === symbol2);
            if (actual?.marginType !== "ISOLATED" || Number(actual.leverage) !== target)
              throw Error(`${symbol2} \u65B9\u6848\u6760\u6746 ${leverage} \u500D\uFF0C\u5E01\u5B89\u672A\u786E\u8BA4\u5B9E\u76D8\u6760\u6746 ${target} \u500D\uFF08-4028\uFF09\uFF0C\u672A\u63D0\u4EA4\u4E70\u5355`);
          }
        }
        return target;
      } else if (config.marginType !== "ISOLATED" || Number(config.leverage) !== leverage) {
        throw Error("\u5E01\u5B89\u9010\u4ED3\u6216\u6760\u6746\u8BBE\u7F6E\u4E0E\u51BB\u7ED3\u65B9\u6848\u4E0D\u4E00\u81F4");
      }
    },
    async order(market, mode, order, send) {
      const { symbol: symbol2 } = market;
      const position = positionSide(mode);
      let report;
      if (send) {
        try {
          report = await request("POST", "/fapi/v1/order", {
            symbol: symbol2,
            side: order.side,
            positionSide: position,
            ...order.limitPrice ? { type: "LIMIT", timeInForce: "IOC", price: order.limitPrice } : { type: "MARKET" },
            quantity: order.quantity,
            newClientOrderId: order.id,
            newOrderRespType: "RESULT",
            ...mode === "one-way" && order.side === "SELL" ? { reduceOnly: "true" } : {}
          });
        } catch (error) {
          if (error instanceof UsdtApiError && [-1013, -1021, -1102, -1111, -2014, -2015, -2018, -2019, -2022, -4164].includes(error.code ?? 0)) {
            return { terminal: true, fills: [], ...error.code === -2018 || error.code === -2019 ? { insufficientMargin: true } : {}, issue: error.message };
          }
        }
      }
      if (!report) {
        try {
          report = await request("GET", "/fapi/v1/order", { symbol: symbol2, origClientOrderId: order.id });
        } catch (error) {
          if (error instanceof UsdtApiError && error.code === -2013) return;
          throw error;
        }
      }
      if (report.symbol !== symbol2 || report.clientOrderId !== order.id || report.side !== order.side || report.positionSide !== position || !/^\d+$/.test(String(report.orderId)) || quantityUnits(String(report.origQty), market.step) !== quantityUnits(order.quantity, market.step)) {
        throw Error("\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u4E0E\u59D4\u6258\u4E0D\u4E00\u81F4");
      }
      const terminal = ["FILLED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED", "REJECTED"].includes(report.status);
      const filled = quantityUnits(String(report.executedQty), market.step);
      if (!terminal && !["NEW", "PARTIALLY_FILLED"].includes(report.status)) throw Error("\u5E01\u5B89\u8BA2\u5355\u72B6\u6001\u4E0D\u53EF\u8BC6\u522B");
      if (filled > quantityUnits(order.quantity, market.step) || report.status === "FILLED" && filled !== quantityUnits(order.quantity, market.step)) throw Error("\u5E01\u5B89\u7D2F\u8BA1\u6210\u4EA4\u91CF\u8D85\u8FC7\u59D4\u6258");
      const trades = filled ? await request("GET", "/fapi/v1/userTrades", { symbol: symbol2, orderId: String(report.orderId), limit: "1000" }) : [];
      if (!Array.isArray(trades)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u56DE\u62A5\u65E0\u6548");
      const ids = /* @__PURE__ */ new Set();
      const fills = trades.map((trade) => {
        const id2 = String(trade.id), price = Number(trade.price), at = Number(trade.time);
        const quantity2 = quantityUnits(String(trade.qty), market.step), commission = Number(trade.commission), realized = Number(trade.realizedPnl);
        if (trade.symbol !== symbol2 || String(trade.orderId) !== String(report.orderId) || trade.side !== order.side || trade.positionSide !== position || !/^\d+$/.test(id2) || ids.has(id2) || quantity2 <= 0 || !Number.isFinite(price) || price <= 0 || !Number.isSafeInteger(at) || at <= 0 || !Number.isFinite(commission) || !Number.isFinite(realized) || typeof trade.commissionAsset !== "string" || !trade.commissionAsset) throw Error("\u5E01\u5B89\u6210\u4EA4\u8EAB\u4EFD\u6216\u91D1\u989D\u4E0D\u7B26");
        ids.add(id2);
        return { id: id2, quantity: quantity2, price, at, commission, commissionAsset: trade.commissionAsset, realized };
      });
      if (fills.reduce((units2, fill) => units2 + fill.quantity, 0) !== filled) return;
      return { exchangeId: String(report.orderId), terminal, fills, issue: terminal && !filled ? "\u5E01\u5B89\u8BA2\u5355\u5DF2\u7EC8\u6B62\uFF0C\u672A\u6210\u4EA4" : void 0 };
    }
  };
}

// scripts/usdt-handoff-reconcile.ts
var numeric = /^-?\d{1,30}(?:\.\d{1,18})?$/;
var symbol = /^[A-Z0-9_]{2,32}$/;
var id = /^\d{1,25}$/;
var fail = (message) => {
  throw Error("\u4EA4\u63A5\u5BF9\u8D26\u672A\u901A\u8FC7\uFF1A" + message);
};
var array = (raw) => Array.isArray(raw) ? raw : fail("\u5E01\u5B89\u8FD4\u56DE\u7684\u6570\u636E\u4E0D\u5B8C\u6574");
var stable2 = (rows) => [...rows].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
var decimal2 = (value) => typeof value === "string" && numeric.test(value) ? value : fail("\u6570\u91CF\u6216\u91D1\u989D\u683C\u5F0F\u65E0\u6548");
var readOnlyUsdtRequest = (request) => (method, path, params) => {
  if (method !== "GET") return Promise.reject(Error("\u4EA4\u63A5\u5BF9\u8D26\u53EA\u5141\u8BB8\u8BFB\u53D6\u5E01\u5B89"));
  return request(method, path, params);
};
var compare = (a, b, message) => {
  if (handoffHash(a) !== handoffHash(b)) fail(message);
};
async function reconcileUsdtHandoff(store, exchange, request, owner, expected, clock = Date.now) {
  const read = readOnlyUsdtRequest(request), identity2 = await exchange.account();
  const remoteClock = async () => {
    const value = await read("GET", "/fapi/v1/time");
    if (!Number.isSafeInteger(value?.serverTime) || value.serverTime <= 0) fail("\u5E01\u5B89\u65F6\u95F4\u63A5\u53E3\u6682\u4E0D\u53EF\u7528");
    return value.serverTime;
  };
  const beganAt = await remoteClock();
  const snapshot = store.snapshot();
  if (snapshot.account !== identity2.id || snapshot.owner !== owner) fail("\u5E01\u5B89\u8D26\u6237\u6216\u7F51\u7AD9\u8D26\u53F7\u4E0D\u7B26");
  if (expected && (expected.account !== createHash5("sha256").update(identity2.id).digest("hex") || expected.owner !== owner || expected.mode !== identity2.mode))
    fail("\u539F\u7AEF\u4E0E\u65B0\u7AEF\u7684\u8D26\u6237\u6216\u6301\u4ED3\u6A21\u5F0F\u4E0D\u7B26");
  const take = async () => {
    const [rawPositions, rawRegular, rawAlgo, rawConfig] = await Promise.all([
      read("GET", "/fapi/v3/positionRisk"),
      read("GET", "/fapi/v1/openOrders"),
      read("GET", "/fapi/v1/openAlgoOrders"),
      read("GET", "/fapi/v1/symbolConfig")
    ]);
    const positions = array(rawPositions).filter((row) => Number(decimal2(row.positionAmt)) !== 0).map((row) => {
      if (!symbol.test(row.symbol) || !["LONG", "SHORT", "BOTH"].includes(row.positionSide)) fail("\u4ED3\u4F4D\u8EAB\u4EFD\u65E0\u6548");
      return { symbol: row.symbol, positionSide: row.positionSide, positionAmt: decimal2(row.positionAmt), entryPrice: decimal2(row.entryPrice) };
    });
    if (new Set(positions.map((row) => row.symbol + ":" + row.positionSide)).size !== positions.length) fail("\u5E01\u5B89\u8FD4\u56DE\u91CD\u590D\u4ED3\u4F4D");
    const regular = array(rawRegular).map((row) => {
      if (!symbol.test(row.symbol) || !id.test(String(row.orderId)) || typeof row.clientOrderId !== "string" || !["BUY", "SELL"].includes(row.side) || !["LONG", "SHORT", "BOTH"].includes(row.positionSide)) fail("\u666E\u901A\u6302\u5355\u8EAB\u4EFD\u65E0\u6548");
      return {
        symbol: row.symbol,
        orderId: String(row.orderId),
        clientOrderId: row.clientOrderId,
        side: row.side,
        positionSide: row.positionSide,
        status: row.status,
        type: row.type,
        timeInForce: row.timeInForce,
        origQty: decimal2(row.origQty),
        executedQty: decimal2(row.executedQty),
        price: decimal2(row.price),
        reduceOnly: row.reduceOnly,
        closePosition: row.closePosition
      };
    });
    const algo = array(rawAlgo).map((row) => {
      if (!symbol.test(row.symbol) || !id.test(String(row.algoId)) || typeof row.clientAlgoId !== "string" || !["BUY", "SELL"].includes(row.side) || !["LONG", "SHORT", "BOTH"].includes(row.positionSide)) fail("\u6761\u4EF6\u6302\u5355\u8EAB\u4EFD\u65E0\u6548");
      return {
        symbol: row.symbol,
        algoId: String(row.algoId),
        clientAlgoId: row.clientAlgoId,
        side: row.side,
        positionSide: row.positionSide,
        algoStatus: row.algoStatus,
        orderType: row.orderType,
        quantity: decimal2(row.quantity ?? "0"),
        triggerPrice: decimal2(row.triggerPrice),
        price: row.price,
        reduceOnly: row.reduceOnly,
        closePosition: row.closePosition,
        workingType: row.workingType
      };
    });
    const activeSymbols = new Set([...positions, ...regular, ...algo].map((row) => row.symbol));
    const config = array(rawConfig).filter((row) => activeSymbols.has(row.symbol)).map((row) => ({ symbol: row.symbol, marginType: row.marginType, leverage: Number(row.leverage) }));
    if ([...activeSymbols].some((s) => !config.some((row) => row.symbol === s))) fail("\u5408\u7EA6\u6760\u6746\u6216\u4FDD\u8BC1\u91D1\u914D\u7F6E\u7F3A\u5931");
    return { positions: stable2(positions), regular: stable2(regular), algo: stable2(algo), config: stable2(config) };
  };
  const before = await take();
  const rows = store.readAll(), active = rows.filter((row) => !["closed", "ignored"].includes(row.status.state));
  const known = new Set([...before.positions, ...before.regular, ...before.algo].map((row) => row.symbol));
  for (const row of rows) known.add(row.campaign.source.symbol);
  for (const row of [...snapshot.tables.desk_orders, ...snapshot.tables.position_controls]) {
    const value = JSON.parse(String(row.payload));
    if (value.symbol) known.add(value.symbol);
    if (value.target?.symbol) known.add(value.target.symbol);
    if (value.steps?.some((step) => step.state === "sent" && !["/fapi/v1/order", "/fapi/v1/algoOrder"].includes(step.path)))
      fail("\u5B58\u5728\u672A\u67E5\u660E\u7684\u6760\u6746\u3001\u4FDD\u8BC1\u91D1\u6216\u64A4\u5355\u64CD\u4F5C\uFF1B\u5148\u5728\u539F\u7AEF\u6309\u539F\u64CD\u4F5C\u6838\u5BF9");
    if (value.steps?.some((step) => !step.state && !step.retired)) fail("\u5B58\u5728\u5C1A\u672A\u5B8C\u6210\u7684\u591A\u6B65\u5B9E\u76D8\u64CD\u4F5C");
  }
  for (const row of active) {
    const frozen = row.campaign.frozenMonitor;
    const monitor = row.managed?.monitor ?? frozen?.admission?.round.instantMonitor;
    if (!monitor?.plan?.frozenVersions?.length || planVersionChanges(monitor.plan).length) fail("\u6301\u4ED3\u7F3A\u5C11\u539F\u51BB\u7ED3\u6A21\u677F\u6216\u539F\u6267\u884C\u7248\u672C");
    if (!row.managed && (!frozen || instantPositionInput(frozen.admission.record, frozen.admission.round)?.id !== row.campaign.id))
      fail("\u666E\u901A\u8DDF\u5355\u7F3A\u5C11\u539F\u4FE1\u53F7\u4E0E\u76D1\u6D4B\u72B6\u6001\uFF0C\u8BF7\u5148\u8BA9\u539F\u7F51\u9875\u540C\u6B65\u540E\u91CD\u65B0\u51BB\u7ED3");
    if (!row.managed && row.orders.open?.fills?.length && !frozen?.checkpoint && clock() - row.campaign.actions[0].at > 12e4) fail("\u5DF2\u6301\u6709\u6218\u5F79\u7F3A\u5C11\u76D1\u6D4B\u68C0\u67E5\u70B9");
  }
  const cursors = {};
  const held = /* @__PURE__ */ new Map();
  for (const s of [...known].sort()) {
    if (!symbol.test(s)) fail("\u8D26\u672C\u5B58\u5728\u672A\u77E5\u5408\u7EA6\u4EE3\u7801");
    const relevant = active.filter((row) => row.campaign.source.symbol === s);
    const market = relevant.length ? await exchange.market(s) : void 0;
    if (relevant.length && !market) fail("\u539F\u5408\u7EA6\u4EA4\u6613\u89C4\u683C\u6682\u4E0D\u53EF\u7528");
    let trades = [];
    const recorded = relevant.flatMap((row) => Object.values(row.orders).flatMap((order) => order.fills ?? []));
    let from = recorded.length ? recorded.reduce((a, b) => BigInt(a.id) < BigInt(b.id) ? a : b).id : void 0;
    for (let page = 0; ; page++) {
      if (page >= 100) fail("\u6210\u4EA4\u8BB0\u5F55\u8D85\u8FC7\u5B89\u5168\u5206\u9875\u4E0A\u9650\uFF0C\u8BF7\u5148\u4E13\u9879\u6838\u5BF9");
      const part = array(await read("GET", "/fapi/v1/userTrades", { symbol: s, limit: "1000", ...from ? { fromId: from } : {} }));
      const seen = new Set(trades.map((t) => String(t.id)));
      for (const trade of part) {
        if (trade.symbol !== s || !id.test(String(trade.id)) || !id.test(String(trade.orderId)) || !["BUY", "SELL"].includes(trade.side) || !["LONG", "SHORT", "BOTH"].includes(trade.positionSide) || !Number.isSafeInteger(trade.time) || !numeric.test(String(trade.qty)) || Number(trade.qty) <= 0) fail("\u9010\u7B14\u6210\u4EA4\u8EAB\u4EFD\u6216\u6570\u91CF\u65E0\u6548");
        if (seen.has(String(trade.id))) fail("\u9010\u7B14\u6210\u4EA4\u5206\u9875\u91CD\u590D\u6216\u672A\u524D\u8FDB");
        seen.add(String(trade.id));
        trades.push(trade);
      }
      if (part.length < 1e3) break;
      const last = part.reduce((a, b) => BigInt(a.id) > BigInt(b.id) ? a : b);
      const next = String(BigInt(last.id) + 1n);
      if (from && BigInt(next) <= BigInt(from)) fail("\u9010\u7B14\u6210\u4EA4\u5206\u9875\u672A\u524D\u8FDB");
      from = next;
    }
    cursors[s] = trades.length ? trades.reduce((a, b) => BigInt(a) > BigInt(b.id) ? a : String(b.id), "0") : "0";
    if (!market) continue;
    for (const row of relevant) {
      let balance = 0, average = 0;
      const fills = [];
      const side = row.managed?.anchor.positionSide ?? (identity2.mode === "hedge" ? "LONG" : "BOTH");
      for (const order of Object.values(row.orders)) {
        if (!order.terminal) {
          const report = await exchange.order(market, identity2.mode, order, false);
          if (!report || report.terminal || report.exchangeId !== order.exchangeId || handoffHash(report.fills) !== handoffHash(order.fills ?? [])) fail("\u672A\u51B3\u8BA2\u5355\u5C1A\u672A\u7A33\u5B9A\uFF0C\u539F\u7F16\u53F7\u9700\u7EE7\u7EED\u6838\u5BF9");
        }
        for (const fill of order.fills ?? []) {
          const actual2 = trades.find((t) => String(t.id) === fill.id);
          if (!actual2 || String(actual2.orderId) !== order.exchangeId || actual2.positionSide !== side || actual2.side !== order.side || quantityUnits(String(actual2.qty), market.step) !== fill.quantity || Number(actual2.price) !== fill.price || actual2.time !== fill.at || Number(actual2.commission) !== fill.commission || actual2.commissionAsset !== fill.commissionAsset || Number(actual2.realizedPnl) !== fill.realized) fail("\u8D26\u672C\u9010\u7B14\u6210\u4EA4\u4E0E\u5E01\u5B89\u4E0D\u4E00\u81F4");
          fills.push({ ...fill, side: order.side });
        }
      }
      if (new Set(fills.map((fill) => fill.id)).size !== fills.length) fail("\u540C\u4E00\u7B14\u6210\u4EA4\u5728\u8D26\u672C\u4E2D\u91CD\u590D\u8BB0\u8F7D");
      for (const fill of fills.sort((a, b) => a.at - b.at || (BigInt(a.id) < BigInt(b.id) ? -1 : 1))) {
        if (fill.side === "BUY") average = (average * balance + fill.price * fill.quantity) / (balance + fill.quantity);
        balance += fill.side === "BUY" ? fill.quantity : -fill.quantity;
        if (balance < 0) fail("\u8D26\u672C\u51CF\u4ED3\u987A\u5E8F\u8D85\u8FC7\u539F\u4F59\u4ED3");
      }
      if (balance < 0) fail("\u8D26\u672C\u51CF\u4ED3\u8D85\u8FC7\u539F\u4F59\u4ED3");
      const key = s + ":" + side;
      if (held.has(key) && balance) fail("\u540C\u4E00\u4ED3\u4F4D\u5B58\u5728\u591A\u4E2A\u6D3B\u52A8\u6218\u5F79");
      held.set(key, (held.get(key) ?? 0) + balance);
      const actual = before.positions.find((p) => p.symbol === s && p.positionSide === side);
      if (quantityUnits(actual?.positionAmt ?? "0", market.step) !== balance) fail("\u539F\u6218\u5F79\u4F59\u4ED3\u4E0E\u5E01\u5B89\u4E0D\u4E00\u81F4\uFF0C\u4E0D\u80FD\u5F53\u4F5C\u65B0\u6218\u5F79");
      if (balance && (!actual || Math.abs(Number(actual.entryPrice) - average) > Math.max(1e-8, average * 1e-5)))
        fail("\u539F\u6218\u5F79\u5269\u4F59\u6210\u672C\u4E0E\u5E01\u5B89\u5165\u573A\u5747\u4EF7\u4E0D\u4E00\u81F4");
      if (row.managed?.checkpoint?.remainingQuantity != null && !row.managed.pending && Number(formatQuantity(balance, market.step)) !== row.managed.checkpoint.remainingQuantity) fail("\u51BB\u7ED3\u76D1\u6D4B\u8FDB\u5EA6\u4E0E\u5B9E\u9645\u4F59\u4ED3\u4E0D\u4E00\u81F4");
    }
  }
  if (expected) {
    if (!Number.isSafeInteger(expected.at) || expected.at > beganAt + 1e3 || beganAt - expected.at > 7 * 24 * 36e5)
      fail("\u4EA4\u63A5\u51BB\u7ED3\u65F6\u95F4\u65E0\u6548\u6216\u5DF2\u8D85\u8FC7\u4E03\u5929\uFF0C\u9700\u8981\u539F\u7AEF\u91CD\u65B0\u51BB\u7ED3");
    for (let page = 1; ; page++) {
      if (page > 100) fail("\u4EA4\u63A5\u671F\u95F4\u8D26\u6237\u6D41\u6C34\u5206\u9875\u8D85\u8FC7\u4E0A\u9650");
      const income = array(await read("GET", "/fapi/v1/income", {
        startTime: String(Math.max(1, expected.at - 1e4)),
        endTime: String(beganAt),
        limit: "1000",
        page: String(page)
      }));
      if (income.some((t) => t.symbol && t.tradeId && (t.incomeType === "COMMISSION" || t.incomeType === "REALIZED_PNL") && (!expected.cursors[t.symbol] || BigInt(t.tradeId) > BigInt(expected.cursors[t.symbol])))) fail("\u4EA4\u63A5\u671F\u95F4\u51FA\u73B0\u4E86\u65B0\u589E\u6210\u4EA4\uFF0C\u8BF7\u4F5C\u5E9F\u63A5\u7BA1\u6216\u53CD\u5411\u4EA4\u63A5\u540E\u7531\u539F\u7AEF\u6838\u5BF9");
      if (income.length < 1e3) break;
    }
    compare(cursors, expected.cursors, "\u4EA4\u63A5\u671F\u95F4\u6210\u4EA4\u8BB0\u5F55\u53D1\u751F\u53D8\u5316\uFF0C\u4FDD\u6301\u53EA\u8BFB\u5E76\u6309\u6062\u590D\u6D41\u7A0B\u5904\u7406");
  }
  const after = await take();
  compare(before, after, "\u5BF9\u8D26\u8FC7\u7A0B\u4E2D\u4F59\u4ED3\u6216\u6302\u5355\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6");
  if (expected) compare(
    before,
    { positions: expected.positions, regular: expected.regular, algo: expected.algo, config: expected.config },
    "\u4EA4\u63A5\u671F\u95F4\u4F59\u4ED3\u3001\u6302\u5355\u6216\u5408\u7EA6\u914D\u7F6E\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u5148\u6062\u590D\u539F\u7AEF\u6838\u5BF9"
  );
  for (const row of snapshot.tables.desk_orders) {
    const value = JSON.parse(String(row.payload));
    if (!row.pending) continue;
    const conditional = value.wire?.path === "/fapi/v1/algoOrder";
    const params = conditional ? { clientAlgoId: value.wire.params.clientAlgoId } : { symbol: value.symbol, origClientOrderId: value.wire?.params.newClientOrderId };
    const report = await read("GET", value.wire?.path, params);
    if (report?.symbol !== value.symbol || report?.side !== value.side || report?.positionSide !== value.positionSide || Number(conditional ? report?.quantity : report?.origQty) !== Number(value.quantity) || !["NEW", "PARTIALLY_FILLED", "FILLED", "TRIGGERING", "TRIGGERED", "FINISHED", "REJECTED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED"].includes(conditional ? report?.algoStatus : report?.status) || (conditional ? report?.clientAlgoId !== params.clientAlgoId : report?.clientOrderId !== params.origClientOrderId)) fail("\u624B\u52A8\u5F00\u4ED3\u7684\u539F\u59D4\u6258\u5C1A\u672A\u67E5\u660E");
  }
  for (const row of snapshot.tables.position_controls) {
    const value = JSON.parse(String(row.payload));
    for (const step of value.steps ?? []) {
      if (step.state !== "sent") continue;
      const conditional = step.path === "/fapi/v1/algoOrder";
      const params = conditional ? { clientAlgoId: step.params.clientAlgoId } : { symbol: step.params.symbol, origClientOrderId: step.params.newClientOrderId };
      const report = await read("GET", step.path, params);
      if (report?.symbol !== value.target.symbol || report?.positionSide !== value.target.positionSide || step.params.side && report?.side !== step.params.side || step.params.quantity && Number(conditional ? report?.quantity : report?.origQty) !== Number(step.params.quantity) || (conditional ? report?.clientAlgoId !== params.clientAlgoId : report?.clientOrderId !== params.origClientOrderId)) fail("\u4ED3\u4F4D\u64CD\u4F5C\u7684\u539F\u59D4\u6258\u5C1A\u672A\u67E5\u660E");
    }
  }
  const at = await remoteClock();
  if (at < beganAt) fail("\u5E01\u5B89\u65F6\u95F4\u8BFB\u6570\u5012\u9000");
  return { account: createHash5("sha256").update(identity2.id).digest("hex"), owner, mode: identity2.mode, at, ...before, cursors };
}

// scripts/usdt-handoff-service.ts
import { createHash as createHash6 } from "node:crypto";
function createUsdtHandoffService(store, account, owner, runtime, exchange, read) {
  const machine = createUsdtHandoff(store, createHash6("sha256").update(account).digest("hex"), owner, runtime);
  let authorized = false, busy = false;
  let issue = "";
  const assertWritable = () => {
    machine.assertActive();
    if (!authorized) throw Error("\u672C\u6B21\u542F\u52A8\u5C1A\u672A\u5B8C\u6210\u4EA4\u63A5\u5BF9\u8D26\uFF0C\u7981\u6B62\u4EA4\u6613");
  };
  const describe = () => ({
    protocol: 1,
    device: machine.device,
    stage: machine.state().stage,
    epoch: machine.state().epoch,
    authorized,
    ...issue ? { issue } : {}
  });
  const begin = async (follower) => {
    await follower.quiesce();
    if (machine.state().stage !== "active") return;
    busy = true;
    try {
      await follower.reconcileForHandoff();
      await reconcileUsdtHandoff(store, exchange, read, owner);
      if (machine.state().stage === "active") {
        authorized = true;
        issue = "";
        follower.thaw();
      }
    } catch (error) {
      issue = error instanceof Error ? error.message : "\u542F\u52A8\u5BF9\u8D26\u5931\u8D25";
    } finally {
      busy = false;
    }
  };
  return {
    machine,
    assertWritable,
    describe,
    begin,
    capturable: () => !busy && ["empty", "frozen"].includes(machine.state().stage),
    async stop(follower) {
      if (machine.state().stage === "active") machine.freeze();
      authorized = false;
      await follower.quiesce();
    },
    async command(content, follower) {
      if (busy) throw Error("\u4EA4\u63A5\u64CD\u4F5C\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u7A0D\u540E\u8BFB\u53D6\u72B6\u6001");
      busy = true;
      try {
        if (content.command === "handoff-request") return { request: machine.receiveRequest(), handoff: describe() };
        if (content.command === "handoff-initialize") {
          if (content.confirmed !== true || !store.local("legacy-windows-stopped") || machine.state().stage !== "empty")
            throw Error("\u9996\u6B21\u6267\u884C\u6743\u53EA\u80FD\u7531\u5DF2\u7ECF\u505C\u7528\u65E7\u8BA1\u5212\u4EFB\u52A1\u7684 Windows \u539F\u7AEF\u5EFA\u7ACB");
          await follower.quiesce();
          await follower.reconcileForHandoff();
          await reconcileUsdtHandoff(store, exchange, read, owner);
          machine.initializeSource();
          authorized = true;
          issue = "";
          follower.thaw();
          return { handoff: describe() };
        }
        if (content.command === "handoff-freeze" || content.command === "handoff-export") {
          if (machine.state().stage === "outgoing" && content.command === "handoff-export")
            return { bundle: machine.export(content.request, null, 0), handoff: describe() };
          machine.freeze();
          authorized = false;
          await follower.quiesce();
          if (content.command === "handoff-freeze") return { handoff: describe() };
          await follower.reconcileForHandoff();
          const evidence = await reconcileUsdtHandoff(store, exchange, read, owner);
          const bundle = machine.export(content.request, evidence, evidence.at);
          return { bundle, handoff: describe() };
        }
        if (content.command === "handoff-resume") {
          if (content.confirmed !== true || machine.state().stage !== "frozen") throw Error("\u53EA\u6709\u51BB\u7ED3\u539F\u7AEF\u53EF\u660E\u786E\u786E\u8BA4\u6062\u590D\uFF1B\u5DF2\u4EA4\u51FA\u7AEF\u9700\u8981\u63A5\u6536\u7AEF\u4F5C\u5E9F\u51ED\u636E");
          await follower.reconcileForHandoff();
          await reconcileUsdtHandoff(store, exchange, read, owner);
          machine.activateAfterReconciliation();
          authorized = true;
          issue = "";
          follower.thaw();
          return { handoff: describe() };
        }
        if (content.command === "handoff-cancellation") {
          machine.acceptCancellation(content.receipt);
          authorized = false;
          await follower.quiesce();
          return { handoff: describe() };
        }
        throw Error("\u672A\u77E5\u4EA4\u63A5\u6307\u4EE4");
      } catch (error) {
        issue = error instanceof Error ? error.message : "\u4EA4\u63A5\u5931\u8D25\uFF1B\u672C\u7AEF\u4FDD\u6301\u51BB\u7ED3";
        throw error;
      } finally {
        busy = false;
      }
    }
  };
}

// scripts/usdt-campaign-reader.ts
var DAY = 864e5;
var WINDOW = 7 * DAY;
var LIMIT = 1e3;
var symbolPattern = /^[A-Z0-9_]{3,32}$/;
var decimal3 = /^-?\d{1,30}(?:\.\d{1,18})?$/;
var idPattern = /^\d{1,25}$/;
function units(raw) {
  if (!decimal3.test(raw)) throw Error("\u5E01\u5B89\u6210\u4EA4\u6570\u91CF\u65E0\u6548");
  const [whole, fraction = ""] = raw.replace(/^-/, "").split(".");
  return BigInt(whole + fraction.padEnd(18, "0")) * (raw.startsWith("-") ? -1n : 1n);
}
function quantity(value) {
  const n = (value < 0n ? -value : value).toString().padStart(19, "0");
  const fraction = n.slice(-18).replace(/0+$/, "");
  return n.slice(0, -18) + (fraction ? "." + fraction : "");
}
function money(raw) {
  if (typeof raw !== "string" || !decimal3.test(raw)) throw Error("\u5E01\u5B89\u6210\u4EA4\u91D1\u989D\u65E0\u6548");
  return Number(raw);
}
function readTrade(raw, symbol2, start, end) {
  const row = raw;
  if (!row || row.symbol !== symbol2 || row.positionSide !== "BOTH" && row.positionSide !== "LONG" && row.positionSide !== "SHORT" || row.side !== "BUY" && row.side !== "SELL" || typeof row.time !== "number" || !Number.isSafeInteger(row.time) || row.time < start || row.time > end || !idPattern.test(String(row.id)) || !idPattern.test(String(row.orderId)) || typeof row.qty !== "string" || units(row.qty) <= 0n || typeof row.price !== "string" || money(row.price) <= 0 || typeof row.commissionAsset !== "string" || !symbolPattern.test(row.commissionAsset)) throw Error("\u5E01\u5B89\u9010\u7B14\u6210\u4EA4\u683C\u5F0F\u6709\u8BEF");
  const asset = typeof row.marginAsset === "string" && symbolPattern.test(row.marginAsset) ? row.marginAsset : symbol2.split("_")[0].endsWith("USDC") ? "USDC" : "USDT";
  return {
    id: String(row.id),
    orderId: String(row.orderId),
    at: row.time,
    quantity: row.qty,
    price: row.price,
    side: row.side,
    positionSide: row.positionSide,
    asset,
    realized: money(row.realizedPnl),
    commission: money(row.commission),
    commissionAsset: row.commissionAsset
  };
}
var compareId = (a, b) => BigInt(a) < BigInt(b) ? -1 : BigInt(a) > BigInt(b) ? 1 : 0;
var delta = (row) => units(row.quantity) * (row.side === "BUY" ? 1n : -1n);
function startingBalances(positions, trades) {
  const balances = /* @__PURE__ */ new Map();
  for (const pos of positions) balances.set(pos.positionSide, units(pos.quantity) * (pos.direction === "short" ? -1n : 1n));
  for (const trade of trades) balances.set(trade.positionSide, (balances.get(trade.positionSide) ?? 0n) - delta(trade));
  return balances;
}
function reconstructUsdtCampaigns(symbol2, positions, trades) {
  const rows = [...new Map(trades.map((trade) => [trade.id, trade])).values()].sort((a, b) => a.at - b.at || compareId(a.id, b.id));
  const balances = startingBalances(positions, rows);
  const open = /* @__PURE__ */ new Map();
  const campaigns = [];
  for (const trade of rows) {
    const { positionSide, asset, ...raw } = trade;
    const before = balances.get(positionSide) ?? 0n;
    const after = before + delta(trade);
    if (positionSide === "LONG" && (before < 0n || after < 0n) || positionSide === "SHORT" && (before > 0n || after > 0n))
      throw Error("\u5E01\u5B89\u6210\u4EA4\u4E0E\u6301\u4ED3\u65B9\u5411\u6682\u672A\u5BF9\u9F50");
    balances.set(positionSide, after);
    const flipped = before !== 0n && after !== 0n && before < 0n !== after < 0n;
    const campaign = open.get(positionSide);
    const closed = before !== 0n && (flipped || after === 0n);
    const closeFee = flipped ? raw.commission * (Number(quantity(before)) / Number(raw.quantity)) : raw.commission;
    if (campaign) {
      const increases = before < 0n === delta(trade) < 0n;
      const action = increases ? raw.orderId === campaign.fills[0].orderId ? "open" : "add" : "reduce";
      campaign.fills.push({
        ...raw,
        action,
        positionQuantity: flipped ? quantity(before) : raw.quantity,
        commission: closeFee
      });
      campaign.quantity = closed ? "0" : quantity(after);
      if (closed) {
        campaign.closedAt = raw.at;
        open.delete(positionSide);
      }
    }
    if (before === 0n || flipped) {
      const initial = {
        symbol: symbol2,
        asset,
        positionSide,
        direction: after > 0n ? "long" : "short",
        quantity: quantity(after),
        openedAt: raw.at,
        fills: [{
          ...raw,
          action: "open",
          positionQuantity: quantity(after),
          ...flipped ? { realized: 0, commission: raw.commission - closeFee } : {}
        }]
      };
      campaigns.push(initial);
      open.set(positionSide, initial);
    }
  }
  return campaigns;
}
function createUsdtCampaignReader(read, clock = Date.now) {
  let running;
  let cached;
  async function scan(since, known, target) {
    const params = target ? { symbol: target } : void 0;
    const positions = decodePositions(await read("GET", "/fapi/v3/positionRisk", params));
    const observedAt = clock();
    const earliest = Math.max(1, observedAt - 89 * DAY);
    const start = Math.max(earliest, Math.min(since, observedAt));
    const groups = /* @__PURE__ */ new Map();
    for (const position of positions) groups.set(position.symbol, [...groups.get(position.symbol) ?? [], position]);
    let budget = 140;
    let incomplete = since < earliest;
    const windows2 = async (path, from, through, params2) => {
      if (from > through) return [];
      if (through - from >= WINDOW) {
        const cutoff = from + WINDOW - 1;
        return [...await windows2(path, from, cutoff, params2), ...await windows2(path, cutoff + 1, through, params2)];
      }
      if (--budget < 0) throw Error("\u672C\u8F6E\u6210\u4EA4\u8FC7\u591A\uFF0C\u6218\u5F79\u540C\u6B65\u7A0D\u540E\u91CD\u8BD5");
      const rows = await read("GET", path, { ...params2, startTime: String(from), endTime: String(through), limit: String(LIMIT) });
      if (!Array.isArray(rows)) throw Error("\u5E01\u5B89\u8FD4\u56DE\u7684\u8BA2\u5355\u6216\u6210\u4EA4\u4E0D\u53EF\u8BC6\u522B");
      if (rows.length < LIMIT) return rows;
      if (from === through) throw Error("\u540C\u4E00\u6BEB\u79D2\u5185\u7684\u5E01\u5B89\u6210\u4EA4\u8FC7\u591A");
      const middle = Math.floor((from + through) / 2);
      return [...await windows2(path, from, middle, params2), ...await windows2(path, middle + 1, through, params2)];
    };
    const orders = target ? [] : await windows2("/fapi/v1/allOrders", start, observedAt);
    const symbols = /* @__PURE__ */ new Set([...groups.keys(), ...known.keys()]);
    for (const order of orders) {
      const item = order;
      if (item.symbol && symbolPattern.test(item.symbol) && item.executedQty && units(item.executedQty) > 0n) symbols.add(item.symbol);
    }
    const campaigns = [];
    const scanSymbol = async (symbol2) => {
      const current2 = groups.get(symbol2) ?? [];
      const openingTimes = known.get(symbol2);
      let from = Math.max(earliest, Math.min(start, ...openingTimes ?? []));
      const recent = (a, b) => windows2("/fapi/v1/userTrades", a, b, { symbol: symbol2 }).then((rows) => rows.map((row) => readTrade(row, symbol2, a, b)));
      let trades = await recent(from, observedAt);
      const unique = () => [...new Map(trades.map((trade) => [trade.id, trade])).values()];
      const before = () => [...startingBalances(current2, unique()).values()].some((value) => value !== 0n);
      while (from > earliest && before()) {
        const prior = Math.max(earliest, from - WINDOW);
        trades = [...await recent(prior, from - 1), ...trades];
        from = prior;
      }
      if (before()) incomplete = true;
      if (current2.some((pos) => pos.updatedAt >= from && !trades.some((trade) => trade.positionSide === pos.positionSide && positionTradeCaughtUp(trade.at, pos.updatedAt))))
        throw Error("\u5E01\u5B89\u6700\u65B0\u6210\u4EA4\u8FD8\u672A\u8FD4\u56DE\uFF0C\u6B63\u5728\u91CD\u65B0\u6838\u5BF9");
      campaigns.push(...reconstructUsdtCampaigns(symbol2, current2, unique()).filter((row) => !row.closedAt || row.closedAt >= start || openingTimes?.has(row.openedAt)));
    };
    const queue = [...symbols];
    for (let i = 0; i < queue.length; i += 3) await Promise.all(queue.slice(i, i + 3).map(scanSymbol));
    const current = decodePositions(await read("GET", "/fapi/v3/positionRisk", params));
    const anchor = (rows) => JSON.stringify(rows.map((p) => [p.symbol, p.positionSide, p.direction, p.quantity, p.updatedAt]));
    if (anchor(positions) !== anchor(current)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u521A\u53D1\u751F\u53D8\u5316\uFF0C\u6B63\u5728\u91CD\u65B0\u6838\u5BF9\u6210\u4EA4");
    return { observedAt, campaigns, ...incomplete ? { incomplete } : {} };
  }
  const readBatch = (since, open, target) => {
    if (typeof since !== "number" || !Number.isSafeInteger(since) || since < 1 || since > clock() + 6e4 || !Array.isArray(open) || open.length > 200) throw Error("\u5E01\u5B89\u6218\u5F79\u540C\u6B65\u8BF7\u6C42\u65E0\u6548");
    const known = /* @__PURE__ */ new Map();
    for (const anchor of open) {
      if (typeof anchor?.symbol !== "string" || !symbolPattern.test(anchor.symbol) || !Number.isSafeInteger(anchor.openedAt) || anchor.openedAt < 1 || anchor.openedAt > clock() + 6e4) throw Error("\u5E01\u5B89\u6218\u5F79\u5F00\u4ED3\u65F6\u95F4\u65E0\u6548");
      const openingTimes = known.get(anchor.symbol) ?? /* @__PURE__ */ new Set();
      openingTimes.add(anchor.openedAt);
      known.set(anchor.symbol, openingTimes);
    }
    if (target) return scan(since, known, target);
    const key = JSON.stringify([since, target, [...known].map(([symbol2, openingTimes]) => [symbol2, [...openingTimes]])]);
    if (cached?.key === key && clock() - cached.data.observedAt < 4e3) return Promise.resolve(cached.data);
    if (running) return running.then(() => readBatch(since, open, target), () => readBatch(since, open, target));
    running = scan(since, known, target).then((data) => {
      cached = { key, data };
      return data;
    }).finally(() => {
      running = void 0;
    });
    return running;
  };
  return readBatch;
}

// scripts/usdt-follow-server.ts
init_usdtLiveCampaign();

// src/lib/fish/usdtFollowMonitorBasis.ts
var USDT_FOLLOW_MONITOR_BASIS = "binance-follow-monitor-basis-v1";

// scripts/usdt-follow-server.ts
import { createHash as createHash7, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";
import { join as join3 } from "node:path";
import { writeFileSync as writeFileSync2 } from "node:fs";

// scripts/usdt-follow-store.ts
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
var USDT_LEDGER_TABLES = ["settings", "campaigns", "managed_campaigns", "position_controls", "desk_orders"];
function decodeLedger(payload) {
  const row = JSON.parse(String(payload));
  if (!("switchedMonitor" in row)) return row;
  const { switchedMonitor, switchedStatus, ...rest } = row;
  return { ...rest, managed: switchedMonitor, status: switchedStatus };
}
function openUsdtFollowStore(file, account, owner) {
  const db = new DatabaseSync2(file);
  try {
    db.exec("PRAGMA busy_timeout=4000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL");
    db.exec("CREATE TABLE IF NOT EXISTS connection (id INTEGER PRIMARY KEY CHECK(id=1), account TEXT NOT NULL, owner TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS campaigns (id TEXT PRIMARY KEY, payload TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS managed_campaigns (id TEXT PRIMARY KEY, payload TEXT NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS position_controls (id TEXT PRIMARY KEY, payload TEXT NOT NULL, pending INTEGER NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS desk_orders (id TEXT PRIMARY KEY, payload TEXT NOT NULL, pending INTEGER NOT NULL)");
    db.exec("CREATE TABLE IF NOT EXISTS handoff_local (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    db.prepare("INSERT OR IGNORE INTO connection VALUES (1, ?, ?)").run(account, owner);
    const connection = db.prepare("SELECT account, owner FROM connection WHERE id=1").get();
    if (connection?.account !== account || connection.owner !== owner) throw Error("\u672C\u673A\u5B9E\u76D8\u8D26\u672C\u7ED1\u5B9A\u4E86\u53E6\u4E00\u4E2A\u8D26\u6237");
  } catch (error) {
    db.close();
    throw error;
  }
  const read = db.prepare("SELECT payload FROM campaigns ORDER BY rowid");
  const readManaged = db.prepare("SELECT payload FROM managed_campaigns ORDER BY rowid");
  const save = db.prepare("INSERT INTO campaigns VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload");
  const saveManaged = db.prepare("INSERT INTO managed_campaigns VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload");
  const getControl = db.prepare("SELECT payload FROM position_controls WHERE id=?");
  const listControls = db.prepare("SELECT payload FROM position_controls WHERE pending=1 ORDER BY rowid");
  const saveControl = db.prepare("INSERT INTO position_controls VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, pending=excluded.pending");
  const getDesk = db.prepare("SELECT payload FROM desk_orders WHERE id=?");
  const listDesk = db.prepare("SELECT payload FROM desk_orders WHERE pending=1");
  const saveDesk = db.prepare("INSERT INTO desk_orders VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, pending=excluded.pending");
  const readSetting = db.prepare("SELECT value FROM settings WHERE key=?");
  const saveSetting = db.prepare("INSERT INTO settings VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const controlRevision = () => Number(readSetting.get("follow-control-revision")?.value ?? 0);
  const localGet = db.prepare("SELECT value FROM handoff_local WHERE key=?");
  const localSet = db.prepare("INSERT INTO handoff_local VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const transaction = (run) => {
    db.exec("BEGIN IMMEDIATE");
    try {
      const result = run();
      db.exec("COMMIT");
      return result;
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  };
  const snapshot = () => {
    const known = /* @__PURE__ */ new Set([...USDT_LEDGER_TABLES, "connection", "handoff_local"]);
    if (db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().some((row) => !known.has(String(row.name))))
      throw Error("\u8D26\u672C\u5305\u542B\u5F53\u524D\u4EA4\u63A5\u7248\u672C\u672A\u8BC6\u522B\u7684\u6570\u636E\u8868\uFF0C\u7981\u6B62\u9057\u6F0F\u5BFC\u51FA");
    const tables = Object.fromEntries(USDT_LEDGER_TABLES.map((table) => [table, db.prepare("SELECT * FROM " + table + " ORDER BY rowid").all()]));
    if (tables.settings.some((row) => !/^(paused|follow-control-revision|position-leverage:.+)$/.test(String(row.key))))
      throw Error("\u8D26\u672C\u5305\u542B\u672A\u8BC6\u522B\u7684\u6267\u884C\u8BBE\u7F6E\uFF0C\u9700\u5148\u786E\u8BA4\u7528\u9014\uFF1B\u4E0D\u4F1A\u628A\u672A\u77E5\u914D\u7F6E\u6216\u51ED\u8BC1\u653E\u5165\u4EA4\u63A5\u5305");
    return { version: 1, account, owner, tables };
  };
  return {
    local(key) {
      const row = localGet.get(key);
      return row && JSON.parse(String(row.value));
    },
    setLocal(key, value) {
      localSet.run(key, JSON.stringify(value));
    },
    snapshot: () => transaction(snapshot),
    importSnapshot(value, localState) {
      if (value.version !== 1 || value.account !== account || value.owner !== owner || Object.keys(value.tables ?? {}).sort().join() !== [...USDT_LEDGER_TABLES].sort().join()) throw Error("\u4EA4\u63A5\u8D26\u672C\u7684\u7248\u672C\u6216\u8D26\u6237\u4E0D\u7B26");
      transaction(() => {
        for (const table of USDT_LEDGER_TABLES) {
          const columns = table === "settings" ? ["key", "value"] : ["id", "payload", ...["position_controls", "desk_orders"].includes(table) ? ["pending"] : []];
          const rows = value.tables[table];
          if (!Array.isArray(rows)) throw Error("\u4EA4\u63A5\u8D26\u672C\u6570\u636E\u8868\u65E0\u6548");
          db.exec("DELETE FROM " + table);
          const insert = db.prepare("INSERT INTO " + table + " (" + columns.join() + ") VALUES (" + columns.map(() => "?").join() + ")");
          for (const row of rows) {
            if (!row || Object.keys(row).sort().join() !== [...columns].sort().join() || columns.some((key) => key === "pending" ? row[key] !== 0 && row[key] !== 1 : typeof row[key] !== "string")) throw Error("\u4EA4\u63A5\u8D26\u672C\u884C\u683C\u5F0F\u65E0\u6548");
            if ("payload" in row) JSON.parse(String(row.payload));
            insert.run(...columns.map((key) => row[key]));
          }
        }
        localSet.run("authority", JSON.stringify(localState));
        for (const row of [...read.all(), ...readManaged.all()].map((row2) => decodeLedger(row2.payload))) {
          if (!row.managed && !["closed", "ignored"].includes(row.status.state))
            localSet.run("imported-monitor:" + row.campaign.id, "true");
        }
        saveSetting.run("paused", "1");
        saveSetting.run("follow-control-revision", String(controlRevision() + 1));
      });
    },
    paused: () => db.prepare("SELECT 1 FROM settings WHERE key='paused'").get() != null,
    controlRevision,
    setPaused(paused) {
      db.exec("BEGIN IMMEDIATE");
      try {
        if (paused) saveSetting.run("paused", "1");
        else db.prepare("DELETE FROM settings WHERE key='paused'").run();
        saveSetting.run("follow-control-revision", String(controlRevision() + 1));
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
    },
    readAll: () => [...read.all(), ...readManaged.all()].map((row) => decodeLedger(row.payload)),
    save(row) {
      if (row.managed?.followBasis) {
        const { managed, status, ...rest } = row;
        const payload = { ...rest, status: { ...status, state: "ignored" }, switchedMonitor: managed, switchedStatus: status };
        save.run(row.campaign.id, JSON.stringify(payload));
      } else (row.managed ? saveManaged : save).run(row.campaign.id, JSON.stringify(row));
    },
    getPositionControl(id2) {
      const row = getControl.get(id2);
      return row && JSON.parse(String(row.payload));
    },
    pendingPositionControls() {
      return listControls.all().map((row) => JSON.parse(String(row.payload)));
    },
    savePositionControl(id2, value, pending) {
      saveControl.run(id2, JSON.stringify(value), Number(pending));
    },
    getDeskOrder(id2) {
      const row = getDesk.get(id2);
      return row && JSON.parse(String(row.payload));
    },
    pendingDeskOrders() {
      return listDesk.all().map((row) => JSON.parse(String(row.payload)));
    },
    saveDeskOrder(id2, value, pending) {
      saveDesk.run(id2, JSON.stringify(value), Number(pending));
    },
    positionLeverage(id2) {
      const row = readSetting.get("position-leverage:" + id2);
      return row && JSON.parse(String(row.value));
    },
    savePositionLeverage(id2, value) {
      const key = "position-leverage:" + id2;
      const old = readSetting.get(key);
      if (!old || Number(JSON.parse(String(old.value)).at) < value.at) saveSetting.run(key, JSON.stringify(value));
    },
    close: () => db.close()
  };
}

// src/lib/fish/binanceManualMonitor.ts
var BINANCE_MANUAL_MONITOR_VERSION = "binance-manual-monitor-v1";
var MANAGED_MINUTE = 6e4;
var binanceManualId = (anchor) => ["fish-instant-live", anchor.symbol, anchor.positionSide, "long", anchor.openingTradeId, anchor.openingOrderId].join("-");
function initialBinanceManualCheckpoint(position, key = "") {
  if (position.checkpoint) return position.checkpoint;
  const { entryPrice, entryQuantity, armedAt, monitor, exchangeReduction } = position;
  const entryTime = position.followBasis?.effectiveAt ?? Math.ceil(position.anchor.openedAt / MANAGED_MINUTE) * MANAGED_MINUTE;
  const remainingQuantity = exchangeReduction?.quantity ?? entryQuantity;
  const averageEntryPrice = exchangeReduction?.entryPrice ?? entryPrice;
  return {
    status: "open",
    key,
    sampleId: binanceManualId(position.anchor),
    groupId: monitor.plan.id,
    evaluatedAt: armedAt,
    entryPrice,
    entryTime,
    endPrice: entryPrice,
    endTime: Math.max(entryTime, Math.ceil(Math.max(armedAt, exchangeReduction?.at ?? 0) / MANAGED_MINUTE) * MANAGED_MINUTE),
    initialNotional: entryPrice * entryQuantity,
    remainingQuantity,
    remainingCost: averageEntryPrice * remainingQuantity,
    averageEntryPrice,
    realizedPnl: exchangeReduction?.realized ?? 0,
    followBasis: position.followBasis
  };
}

// scripts/usdt-follow-engine.ts
init_usdtLiveCampaign();

// scripts/usdt-managed-execution.ts
var minuteCeiling = (at) => Math.ceil(at / MANAGED_MINUTE) * MANAGED_MINUTE;
function matchesManualAnchor(anchor, actual) {
  const entry = actual?.fills[0];
  return !!entry && !!actual && actual.symbol === anchor.symbol && actual.positionSide === anchor.positionSide && actual.direction === "long" && actual.asset === "USDT" && actual.openedAt === anchor.openedAt && entry.id === anchor.openingTradeId && entry.orderId === anchor.openingOrderId && entry.action === "open" && entry.side === "BUY";
}
function actualFill(fill, market) {
  return {
    id: fill.id,
    at: fill.at,
    quantity: quantityUnits(fill.positionQuantity, market.step),
    price: Number(fill.price),
    realized: fill.realized,
    commission: fill.commission,
    commissionAsset: fill.commissionAsset
  };
}
function createManagedUsdtLedger(anchor, monitor, actual, market, now) {
  if (!matchesManualAnchor(anchor, actual) || actual.closedAt || market.symbol !== anchor.symbol || actual.fills.some((fill) => fill.action !== "open" || fill.side !== "BUY" || fill.orderId !== anchor.openingOrderId)) {
    throw Error("\u53EA\u80FD\u63A5\u624B\u9996\u4ED3\u9010\u7B14\u6210\u4EA4\u5DF2\u7ECF\u6838\u5B9E\u4E14\u4ECD\u5728\u6301\u6709\u7684\u5E01\u5B89\u591A\u4ED3");
  }
  const fills = actual.fills.map((fill) => actualFill(fill, market));
  const units2 = fills.reduce((sum, fill) => sum + fill.quantity, 0);
  const entryQuantity = Number(formatQuantity(units2, market.step));
  const entryPrice = fills.reduce((sum, fill) => sum + fill.price * fill.quantity, 0) / units2;
  const notional = entryQuantity * entryPrice;
  if (!Number.isSafeInteger(units2) || units2 <= 0 || units2 !== quantityUnits(actual.quantity, market.step) || !Number.isFinite(notional) || notional <= 0) throw Error("\u5E01\u5B89\u9996\u4ED3\u6570\u91CF\u6216\u6210\u4EA4\u91D1\u989D\u65E0\u6CD5\u6838\u5BF9");
  const id2 = binanceManualId(anchor);
  const managed = {
    version: BINANCE_MANUAL_MONITOR_VERSION,
    anchor,
    monitor,
    armedAt: Math.max(now, ...fills.map((fill) => fill.at)),
    entryQuantity,
    entryPrice,
    revision: 0
  };
  const open = {
    id: anchor.openingOrderId,
    exchangeId: anchor.openingOrderId,
    side: "BUY",
    terminal: true,
    quantity: formatQuantity(units2, market.step),
    fills
  };
  return {
    campaign: {
      id: id2,
      source: { symbol: anchor.symbol, exchange: "binance" },
      admittedAt: now,
      notional,
      leverage: 1,
      actions: [{ id: "open", action: "open", at: anchor.openedAt }]
    },
    managed,
    orders: { open },
    skipped: [],
    status: { id: id2, symbol: anchor.symbol, state: "tracking" }
  };
}
function mergeUsdtExitFills(row, actual, market, allowPartial) {
  const present = new Set(actual.fills.map((fill) => fill.id));
  const recorded = Object.values(row.orders).flatMap((order) => order.fills ?? []);
  if (recorded.some((fill) => !present.has(fill.id))) throw Error("\u5E01\u5B89\u6210\u4EA4\u56DE\u62A5\u8FD8\u672A\u540C\u6B65\u5B8C\u6210");
  const known = new Set(recorded.map((fill) => fill.id));
  const external = actual.fills.filter((fill) => !known.has(fill.id));
  if (external.length && !actual.closedAt && (!allowPartial || external.some((fill) => fill.action !== "reduce" || fill.side !== "SELL")))
    throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6709\u65B0\u7684\u624B\u52A8\u52A0\u51CF\u4ED3\uFF0C\u7B49\u5F85\u6838\u5BF9\u540E\u518D\u7EE7\u7EED\u7B56\u7565");
  for (const fill of external) {
    row.orders["binance:" + fill.id] = {
      id: fill.id,
      exchangeId: fill.orderId,
      side: fill.side,
      terminal: true,
      quantity: fill.positionQuantity,
      fills: [actualFill(fill, market)]
    };
  }
  return external;
}
function verifyManagedUsdtFills(row, actual, market) {
  if (!row.managed || !matchesManualAnchor(row.managed.anchor, actual)) throw Error("\u5E01\u5B89\u6301\u4ED3\u5DF2\u6362\u6210\u53E6\u4E00\u7B14\u9996\u4ED3");
  mergeUsdtExitFills(row, actual, market, false);
  return !!actual.closedAt;
}
function settleManagedUsdtDecision(row, key, market, remaining, insufficientMargin = false) {
  const managed = row.managed, pending = managed?.pending, order = row.orders[key];
  if (!managed || !pending || !order?.terminal || pending.action.id !== key && !key.startsWith(pending.action.id + ":")) return;
  if (pending.kind === "close" && remaining.held > 0) {
    if (!order.fills?.length) {
      row.status.state = "blocked";
      row.status.issue = order.exchangeId ? "\u672C\u6B21\u5E73\u4ED3\u672A\u6210\u4EA4\uFF0C\u7B49\u5F85\u91CD\u65B0\u6838\u5BF9\u4F59\u4ED3" : "\u5E01\u5B89\u62D2\u7EDD\u4E86\u672C\u6B21\u5E73\u4ED3\uFF0C\u7B49\u5F85\u91CD\u65B0\u6838\u5BF9\u4F59\u4ED3";
    }
    return;
  }
  const prior = managed.checkpoint;
  if (!prior) throw Error("\u624B\u52A8\u6258\u7BA1\u7F3A\u5C11\u6301\u4ED3\u7B56\u7565\u68C0\u67E5\u70B9");
  const fills = Object.values(row.orders).flatMap((o) => o.fills ?? []);
  const actual = order.fills ?? [];
  const units2 = actual.reduce((sum, fill) => sum + fill.quantity, 0);
  const through = Math.max(prior.endTime ?? 0, pending.through, minuteCeiling(Math.max(...fills.map((f) => f.at))));
  let checkpoint = {
    ...prior,
    endTime: through,
    pendingExit: void 0,
    remainingQuantity: Number(formatQuantity(remaining.held, market.step)),
    averageEntryPrice: remaining.entry,
    remainingCost: Number(formatQuantity(remaining.held, market.step)) * remaining.entry,
    realizedPnl: remaining.realized - (managed.followBasis?.realizedBefore ?? 0)
  };
  if (!units2 && insufficientMargin && pending.kind === "add" && managed.monitor.plan.addition?.marginRejectExit === "margin-reject-exit-v1") {
    const rejected = [...prior.marginRejectedAdditions ?? [], pending.evidence];
    const round = (managed.followBasis?.carriedAdditions ?? 0) + (prior.additionFills?.length ?? (prior.additionFill ? 1 : 0)) + rejected.length + (prior.atrRejectedAdditions?.length ?? 0);
    checkpoint.marginRejectedAdditions = rejected;
    checkpoint.additionSkips = [...prior.additionSkips ?? [], {
      at: pending.evidence.at,
      round,
      kind: "margin-rejected",
      label: "\u672C\u91D1\u4E0D\u8DB3\uFF0C\u5DF2\u542F\u7528\u672C\u8F6E\u5356\u51FA\u8BBE\u7F6E",
      reading: "\u5E01\u5B89\u62D2\u5355\uFF0C\u5B9E\u9645\u52A0\u4ED3\u6570\u91CF\u4E3A 0"
    }];
    checkpoint.sellStageSwitches = pending.sellStageSwitches ?? prior.sellStageSwitches;
    checkpoint.vetoStageSwitches = pending.vetoStageSwitches ?? prior.vetoStageSwitches;
    const stage = pending.vetoStageSwitches?.at(-1);
    if (stage?.afterAdditions === round) {
      const price = pending.evidence.price;
      checkpoint.vetoPath = { entry: managed.entryPrice, peak: stage.peakBasis === "holding" ? Math.max(price, prior.vetoPath?.peak ?? managed.entryPrice * (1 + (prior.peakPct ?? 0) / 100)) : price, minimum: price, dynamic: 0 };
    }
  }
  if (units2 > 0) {
    const quantity2 = Number(formatQuantity(units2, market.step));
    const price = actual.reduce((sum, fill) => sum + fill.price * fill.quantity, 0) / units2;
    const at = Math.max(...actual.map((fill) => fill.at));
    checkpoint = { ...checkpoint, endPrice: price };
    if (pending.kind === "add") {
      const addition = { ...pending.evidence, executedAt: Math.max(...actual.map((fill) => fill.at)), price, quantity: quantity2, notional: price * quantity2 };
      const additions = [...prior.additionFills ?? (prior.additionFill ? [prior.additionFill] : []), addition];
      const newVetoStage = pending.vetoStageSwitches?.at(-1);
      const peak = Math.max(price, prior.vetoPath?.peak ?? managed.entryPrice * (1 + (prior.peakPct ?? 0) / 100));
      checkpoint = {
        ...checkpoint,
        additionFill: additions[0],
        additionFills: additions,
        routeDecision: pending.routeDecision ?? prior.routeDecision,
        sellStageSwitches: pending.sellStageSwitches ?? prior.sellStageSwitches,
        vetoStageSwitches: pending.vetoStageSwitches ?? prior.vetoStageSwitches,
        ...newVetoStage?.afterAdditions === (managed.followBasis?.carriedAdditions ?? 0) + (prior.marginRejectedAdditions?.length ?? 0) + (prior.atrRejectedAdditions?.length ?? 0) + additions.length ? { vetoPath: {
          entry: managed.entryPrice,
          peak: newVetoStage.peakBasis === "holding" ? peak : price,
          minimum: price,
          dynamic: 0
        } } : {}
      };
    } else if (pending.kind === "mirror") {
      checkpoint.mirrorFill = {
        ...pending.evidence,
        executedAt: Math.max(...actual.map((fill) => fill.at)),
        price,
        fraction: Math.min(1, quantity2 / managed.entryQuantity),
        gainPct: (price / managed.entryPrice - 1) * 100
      };
    } else if (pending.kind === "support-reduction") {
      const costRemoved = quantity2 * remaining.entry;
      const reduction = {
        ...pending.evidence,
        executedAt: Math.max(...actual.map((fill) => fill.at)),
        price,
        quantity: quantity2,
        costRemoved,
        fraction: units2 / (remaining.held + units2),
        realizedPnl: actual.reduce((sum, fill) => sum + fill.realized, 0)
      };
      checkpoint.additionReductions = [...prior.additionReductions ?? [], reduction];
    } else if (!remaining.held) {
      checkpoint = { ...checkpoint, status: "closed", complete: true, endTime: at, reason: pending.reason };
    }
  }
  managed.checkpoint = checkpoint;
  managed.pending = void 0;
  managed.revision++;
}

// scripts/usdt-follow-engine.ts
init_qualityHoldingLedger();

// src/lib/fish/usdtLiveEntry.ts
var USDT_ENTRY_MAX_AGE_MS = 12e4;
var USDT_EXECUTION_SAFETY = 2;
var USDT_EXECUTION_PATH = "/api/usdt-follow/safe";
function timelyCaptureConfirmation(capturedAt, confirmedAt) {
  return Number.isSafeInteger(capturedAt) && capturedAt > 0 && Number.isSafeInteger(confirmedAt) && confirmedAt >= capturedAt && confirmedAt - capturedAt <= USDT_ENTRY_MAX_AGE_MS;
}
function validUsdtLiveEntry(campaign) {
  const entry = campaign.liveEntry;
  return !!entry && entry.version === 1 && Number.isSafeInteger(entry.capturedAt) && entry.capturedAt > 0 && (entry.confirmedAt === void 0 || entry.confirmedAt === campaign.admittedAt && timelyCaptureConfirmation(entry.capturedAt, entry.confirmedAt)) && entry.capturedAt <= campaign.admittedAt && typeof entry.templateId === "string" && !!entry.templateId.trim() && entry.templateId.length <= 200 && Number.isFinite(entry.notional) && entry.notional > 0 && entry.notional === campaign.notional && Number.isInteger(entry.leverage) && entry.leverage >= 1 && entry.leverage <= 125 && entry.leverage === campaign.leverage;
}

// src/lib/fish/instantMonitorSwitchCheckpoint.ts
function rebaseInstantMonitorCheckpoint(current, initialNotional, from, to, at, key = current.key) {
  if (to.plan.engine || to.plan.initialization) throw Error("\u8BE5\u6A21\u677F\u987B\u4ECE\u5F00\u4ED3\u5F00\u59CB\u8FD0\u884C\uFF0C\u65E0\u6CD5\u63A5\u624B\u5DF2\u6709\u6301\u4ED3");
  if (current.status !== "open" || !current.entryPrice || !current.endTime || current.mirrorFill?.fraction === 1 || !Number.isFinite(initialNotional) || initialNotional <= 0) {
    throw Error("\u8BE5\u6301\u4ED3\u5DF2\u7ED3\u675F\u6216\u9996\u4ED3\u5C1A\u672A\u6838\u5BF9");
  }
  if (current.pendingExit) throw Error("\u539F\u65B9\u6848\u5DF2\u6709\u5F85\u6210\u4EA4\u7684\u5356\u51FA\uFF0C\u8BF7\u7B49\u6210\u4EA4\u6838\u5BF9\u5B8C\u6210");
  const route = to.plan.router;
  if (route?.afterAdditions && (current.additionFills?.length || (current.additionFill ? 1 : 0)) >= route.afterAdditions) {
    throw Error("\u8FD9\u7B14\u4ED3\u4F4D\u5DF2\u8D8A\u8FC7\u65B0\u6A21\u677F\u7684\u5206\u6D41\u8F6E\u6B21\uFF0C\u8BF7\u9009\u62E9\u53EF\u63A5\u7EED\u5F53\u524D\u8F6E\u6B21\u7684\u65B9\u6848");
  }
  const effectiveAt = Math.max(current.endTime, Math.ceil(at / 6e4) * 6e4);
  return {
    ...current,
    ...current.atrRejectedAdditions ? { atrRejectedAdditions: void 0 } : {},
    ...current.marginRejectedAdditions ? { marginRejectedAdditions: void 0 } : {},
    key,
    groupId: to.plan.id,
    evaluatedAt: at,
    endTime: effectiveAt,
    initialNotional,
    instantMonitorSwitches: [...current.instantMonitorSwitches ?? [], {
      at,
      effectiveAt,
      from,
      to,
      ...!current.instantMonitorSwitches?.length && current.selectedL0Pct !== void 0 ? { openingSelectedL0Pct: current.selectedL0Pct } : {}
    }],
    routeDecision: void 0,
    activeSellStage: void 0,
    sellStageSwitches: void 0,
    activeVetoStage: void 0,
    vetoStageSwitches: void 0,
    vetoPath: void 0,
    advantageState: void 0,
    boxStopStates: void 0,
    ...current.impulse1115Classification ? { impulse1115Classification: void 0 } : {},
    ...current.selectedL0Pct !== void 0 ? { selectedL0Pct: void 0 } : {},
    ...current.openingImpulseDecision ? { openingImpulseDecision: void 0 } : {},
    ...current.openingAdditionPreview ? { openingAdditionPreview: void 0 } : {},
    additionGuardPlus: void 0,
    additionNote: void 0,
    boxMarketRepair: void 0,
    exitSnapshot: void 0,
    exitReading: void 0
  };
}

// scripts/usdt-follow-engine.ts
var increaseAgeMs = 12e4;
var positionTimeout = 45e3;
var unsettledBuyIssue = "\u4E70\u5355\u56DE\u62A5\u5C1A\u672A\u6838\u5B9E\uFF0C\u7EE7\u7EED\u6309\u539F\u8BA2\u5355\u7F16\u53F7\u5BF9\u8D26";
var externalReductionIssue = "\u5E01\u5B89\u51FA\u73B0\u7B56\u7565\u5916\u51CF\u4ED3\uFF0C\u8BF7\u6309\u5B9E\u9645\u4F59\u4ED3\u91CD\u65B0\u786E\u8BA4\u5207\u6362";
var freshIncrease = (action, at) => action.action === "add" && action.impulseFreshUntil !== void 0 ? action.at <= at && at < action.impulseFreshUntil : action.at <= at && at - action.at <= increaseAgeMs;
function createUsdtFollower(store, exchange, owner, mode, startedAt, readManaged, managedClock = Date.now, protectionIds, readPositions, protection) {
  const rows = new Map(store.readAll().map((row) => [row.campaign.id, row]));
  const markets = /* @__PURE__ */ new Map();
  const cooldown = /* @__PURE__ */ new Map();
  const managedChecked = /* @__PURE__ */ new Map();
  let active = false;
  let manual = false;
  let frozen = false;
  let finishTick;
  let lastContactAt = 0;
  let accepting = !store.paused();
  let entryAfter = startedAt;
  const write = (row) => {
    store.save(row);
    rows.set(row.campaign.id, row);
  };
  const ingest = (campaigns, now = Date.now(), recovering = false) => {
    for (const incoming of campaigns) {
      const row = rows.get(incoming.id);
      if (row && store.local("imported-monitor:" + incoming.id) && !recovering) continue;
      if (row?.managed) continue;
      if (!row) {
        const open = incoming.actions[0];
        if (!validUsdtLiveEntry(incoming) || incoming.liveEntry.capturedAt < entryAfter || !accepting || incoming.admittedAt < entryAfter || open.at < entryAfter || now - incoming.admittedAt > USDT_ENTRY_MAX_AGE_MS || now - open.at > USDT_ENTRY_MAX_AGE_MS || incoming.actions.some((action) => action.action === "close")) continue;
        write({ campaign: incoming, orders: {}, skipped: [], status: { id: incoming.id, symbol: incoming.source.symbol, state: "waiting" } });
        continue;
      }
      if (row.campaign.notional !== incoming.notional || row.campaign.leverage !== incoming.leverage || row.campaign.source.symbol !== incoming.source.symbol || row.campaign.admittedAt !== incoming.admittedAt || row.campaign.source.exchange !== incoming.source.exchange || row.campaign.source.market !== incoming.source.market) {
        throw Error("\u540C\u4E00\u5373\u65F6\u4EA4\u6613\u6218\u5F79\u7684\u51BB\u7ED3\u53C2\u6570\u4E0D\u4E00\u81F4");
      }
      if (row.status.state === "closed" || row.status.state === "ignored") continue;
      if (row.campaign.frozenMonitor && incoming.frozenMonitor && JSON.stringify(row.campaign.frozenMonitor.admission.round.instantMonitor) !== JSON.stringify(incoming.frozenMonitor.admission.round.instantMonitor))
        throw Error("\u540C\u4E00\u5B9E\u76D8\u6218\u5F79\u7684\u51BB\u7ED3\u76D1\u6D4B\u6A21\u677F\u4E0D\u4E00\u81F4");
      const prior = new Map(row.campaign.actions.map((action) => [action.id, action]));
      let changed = false;
      for (const action of incoming.actions) {
        const saved = prior.get(action.id);
        if (saved && JSON.stringify(saved) !== JSON.stringify(action)) throw Error("\u540C\u4E00\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u7684\u5DF2\u8BB0\u8F7D\u6761\u4EF6\u4E0D\u4E00\u81F4");
        if (!saved) {
          prior.set(action.id, action);
          changed = true;
        }
      }
      if (changed) {
        row.campaign.actions = [...incoming.actions, ...[...prior.values()].filter((old) => !incoming.actions.some((action) => action.id === old.id))];
        write(row);
      }
      if (incoming.frozenMonitor && !store.local("imported-monitor:" + row.campaign.id)) {
        const previous = row.campaign.frozenMonitor?.checkpoint?.endTime ?? 0;
        if ((incoming.frozenMonitor.checkpoint?.endTime ?? 0) >= previous) {
          row.campaign.frozenMonitor = incoming.frozenMonitor;
          write(row);
        }
      }
    }
    lastContactAt = now;
  };
  const mayIncrease = (row, action, at, signalTime) => accepting && at - lastContactAt <= positionTimeout && action.at >= entryAfter && (row.managed || validUsdtLiveEntry(row.campaign) && (action.action !== "open" || row.campaign.liveEntry.capturedAt >= entryAfter)) && freshIncrease(action, signalTime);
  function balance(row) {
    let held = 0, entry = 0, initial = 0, realized = 0, fee = 0;
    const feesByAsset = /* @__PURE__ */ Object.create(null);
    const fills = Object.entries(row.orders).flatMap(([key, order]) => (order.fills ?? []).map((fill) => ({ ...fill, opening: key === "open", side: order.side })));
    fills.sort((a, b) => a.at - b.at || a.id.length - b.id.length || a.id.localeCompare(b.id));
    for (const fill of fills) {
      if (fill.side === "BUY") {
        entry = (entry * held + fill.price * fill.quantity) / (held + fill.quantity);
        held += fill.quantity;
        if (fill.opening) initial += fill.quantity;
      } else {
        held -= fill.quantity;
        if (held < 0) throw Error("\u5B9E\u76D8\u51CF\u4ED3\u91CF\u8D85\u8FC7\u6218\u5F79\u4F59\u4ED3");
      }
      realized += fill.realized;
      feesByAsset[fill.commissionAsset] = (feesByAsset[fill.commissionAsset] ?? 0) + fill.commission;
      if (fill.commissionAsset === "USDT") fee += fill.commission;
    }
    return { held, entry, initial, realized, fee, feesByAsset };
  }
  const syncBalance = (row, market) => {
    const current = balance(row);
    Object.assign(row.status, {
      market: market.symbol,
      asset: market.symbol.slice(0, -4),
      quantity: Number(formatQuantity(current.held, market.step)),
      entryPrice: current.held ? current.entry : void 0,
      realizedUsdt: current.realized,
      feeUsdt: current.fee,
      feesByAsset: current.feesByAsset,
      limitUsdt: row.campaign.notional,
      executions: Object.entries(row.orders).flatMap(([actionId, order]) => order.exchangeId && order.fills?.length ? [{
        actionId,
        orderId: order.exchangeId,
        side: order.side,
        fills: order.fills.map((fill) => ({ ...fill, quantity: Number(formatQuantity(fill.quantity, market.step)) }))
      }] : [])
    });
    return current;
  };
  async function readMarket(symbol2) {
    const cached = markets.get(symbol2);
    if (cached && Date.now() - cached.at < 10 * 6e4) return cached.value;
    const value = await exchange.market(symbol2);
    if (value) markets.set(symbol2, { value, at: Date.now() });
    return value;
  }
  async function adopt(anchor, monitor, revision = store.controlRevision()) {
    if (!readManaged || !accepting) throw Error("\u8BF7\u5148\u5F00\u542F\u672C\u673A\u5B9E\u76D8\u8DDF\u968F");
    if (anchor.positionSide !== (mode === "hedge" ? "LONG" : "BOTH")) throw Error("\u5E01\u5B89\u6301\u4ED3\u6A21\u5F0F\u4E0E\u624B\u52A8\u4ED3\u4F4D\u4E0D\u7B26");
    const id2 = binanceManualId(anchor);
    if (rows.has(id2)) return rows.get(id2).managed;
    const [actual, market] = await Promise.all([readManaged(anchor), readMarket(anchor.symbol)]);
    if (!market) throw Error("\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6\u65E0\u6CD5\u6838\u5BF9");
    const row = createManagedUsdtLedger(anchor, monitor, actual, market, managedClock());
    const initial = syncBalance(row, market);
    await exchange.check(market, mode, initial.held, initial.entry, false, 0, "existing-position", protectionIds?.(market.symbol, usdtLiveCampaignId(actual)));
    if (rows.has(id2)) return rows.get(id2).managed;
    if (!accepting || revision !== store.controlRevision()) throw Error("\u5B9E\u76D8\u8DDF\u968F\u72B6\u6001\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u7B56\u7565\u6258\u7BA1");
    if ([...rows.values()].some((row2) => row2.campaign.source.symbol === anchor.symbol && (balance(row2).held > 0 || Object.values(row2.orders).some((order) => !order.terminal)))) {
      throw Error("\u8BE5\u5E01\u5B89\u5408\u7EA6\u5DF2\u6709\u4E00\u7B14\u7531\u672C\u673A\u8DDF\u968F\u7684\u4EA4\u6613");
    }
    row.managed.armedAt = Math.max(row.managed.armedAt, managedClock());
    write(row);
    return row.managed;
  }
  async function switchManaged(id2, epoch, monitor) {
    const current = rows.get(id2);
    if (!current?.managed || current.managed.followBasis || current.status.state !== "tracking" || !readManaged) throw Error("\u53EA\u53EF\u5207\u6362\u5BF9\u8D26\u5B8C\u6210\u7684\u624B\u52A8\u6258\u7BA1\u6301\u4ED3");
    const row = structuredClone(current);
    const managed = row.managed;
    if ((managed.planEpoch ?? 0) !== epoch) throw Error("\u6301\u4ED3\u65B9\u6848\u5DF2\u5728\u522B\u5904\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9");
    if (managed.monitor.templateId === monitor.templateId) throw Error("\u5F53\u524D\u6301\u4ED3\u5DF2\u4F7F\u7528\u6B64\u6A21\u677F");
    if (managed.pending || Object.values(row.orders).some((order) => !order.terminal)) throw Error("\u6B63\u5728\u6838\u5BF9\u5B9E\u76D8\u59D4\u6258\uFF0C\u8BF7\u7B49\u6210\u4EA4\u56DE\u62A5");
    const [actual, market] = await Promise.all([readManaged(managed.anchor), readMarket(managed.anchor.symbol)]);
    if (!market || verifyManagedUsdtFills(row, actual, market)) throw Error("\u5B9E\u76D8\u4ED3\u4F4D\u5DF2\u5E73\u4ED3\u6216\u7B49\u5F85\u5BF9\u8D26");
    const held = balance(row);
    if (!held.held || quantityUnits(actual.quantity, market.step) !== held.held) throw Error("\u5B9E\u76D8\u4ED3\u4F4D\u6570\u91CF\u5DF2\u53D8\u5316\uFF0C\u8BF7\u7B49\u5F85\u5BF9\u8D26");
    await exchange.check(market, mode, held.held, held.entry, false, 0, "existing-position", protectionIds?.(market.symbol, id2));
    if (rows.get(id2) !== current) throw Error("\u4ED3\u4F4D\u6B63\u5728\u540C\u6B65\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u5207\u6362");
    const checkpoint = initialBinanceManualCheckpoint(managed);
    const initialNotional = managed.entryPrice * managed.entryQuantity;
    const expected = replayQualityHoldingLedger({
      notional: initialNotional,
      entryPrice: managed.entryPrice,
      entryAt: checkpoint.entryTime,
      additions: checkpoint.additionFills ?? (checkpoint.additionFill ? [checkpoint.additionFill] : []),
      mirror: checkpoint.mirrorFill,
      reductions: checkpoint.additionReductions,
      details: false
    });
    if (Math.abs(expected.held - Number(formatQuantity(held.held, market.step))) > Math.max(1e-9, expected.held * 1e-12) || Math.abs(expected.cost / expected.held - held.entry) > Math.max(1e-8, held.entry * 1e-5)) {
      throw Error("\u7B56\u7565\u6210\u4EA4\u4E0E\u5E01\u5B89\u4F59\u4ED3\u7684\u6570\u91CF\u6216\u5747\u4EF7\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u5148\u6838\u5BF9");
    }
    managed.checkpoint = rebaseInstantMonitorCheckpoint(checkpoint, initialNotional, managed.monitor, monitor, managedClock());
    managed.monitor = monitor;
    managed.planEpoch = epoch + 1;
    managed.revision++;
    write(row);
    return managed;
  }
  async function switchFollowMonitor(id2, anchor, epoch, monitor, original, followSample) {
    const current = rows.get(id2);
    if (!current?.campaign.liveEntry || !readManaged || !readPositions || current.status.state !== "tracking" && current.status.issue !== externalReductionIssue || current.managed && !current.managed.followBasis) throw Error("\u627E\u4E0D\u5230\u53EF\u6838\u5BF9\u7684\u7CFB\u7EDF\u8DDF\u5355\u5B9E\u76D8\u4ED3\u4F4D");
    const previous = current.managed;
    if ((previous?.planEpoch ?? 0) !== epoch) throw Error("\u6301\u4ED3\u65B9\u6848\u5DF2\u5728\u522B\u5904\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9");
    const originalId = current.campaign.liveEntry.templateId;
    const from = previous?.monitor ?? (original?.templateId === originalId ? original : { templateId: originalId, name: "\u539F\u8DDF\u5355\u65B9\u6848" });
    if (from.templateId === monitor.templateId && current.status.issue !== externalReductionIssue) throw Error("\u5F53\u524D\u6301\u4ED3\u5DF2\u4F7F\u7528\u6B64\u6A21\u677F");
    if (monitor.plan.engine || monitor.plan.initialization) throw Error("\u8BE5\u6A21\u677F\u987B\u4ECE\u5F00\u4ED3\u5F00\u59CB\u8FD0\u884C\uFF0C\u65E0\u6CD5\u63A5\u624B\u5DF2\u6709\u6301\u4ED3");
    const unsettled = () => current.managed?.pending || Object.values(current.orders).some((order) => !order.terminal) || current.campaign.actions.some((action) => !current.orders[action.id] && !current.skipped.includes(action.id));
    if (unsettled()) throw Error("\u539F\u65B9\u6848\u6709\u59D4\u6258\u6216\u4FE1\u53F7\u7B49\u5F85\u5904\u7406\uFF0C\u8BF7\u7B49\u6210\u4EA4\u6838\u5BF9\u5B8C\u6210");
    const market = await readMarket(anchor.symbol);
    const opening = market && openAnchor(current, market);
    if (!market || !opening || binanceManualId(opening) !== binanceManualId(anchor) || opening.openedAt !== anchor.openedAt)
      throw Error("\u5B9E\u76D8\u9996\u4ED3\u7F16\u53F7\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u540C\u6B65");
    const actual = await readOriginalPosition(current, market);
    const row = structuredClone(current);
    mergeUsdtExitFills(row, actual, market, true);
    const held = syncBalance(row, market);
    if (actual.closedAt || held.held <= 0 || quantityUnits(actual.quantity, market.step) !== held.held) throw Error("\u5B9E\u76D8\u4F59\u4ED3\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u540C\u6B65");
    const position = (await readPositions()).positions.find((p) => p.symbol === anchor.symbol && p.positionSide === anchor.positionSide && p.direction === "long");
    const entryPrice = Number(position?.entryPrice);
    if (!position || quantityUnits(position.quantity, market.step) !== held.held || !(entryPrice > 0) || !Number.isFinite(entryPrice) || Math.abs(entryPrice - held.entry) > Math.max(1e-8, held.entry * 1e-5)) throw Error("\u5E01\u5B89\u4F59\u4ED3\u6216\u6210\u672C\u5747\u4EF7\u6682\u672A\u5BF9\u9F50");
    await exchange.check(market, mode, held.held, entryPrice, false, 0, "existing-position", protectionIds?.(market.symbol, binanceManualId(anchor)));
    if (rows.get(id2) !== current || unsettled()) throw Error("\u539F\u65B9\u6848\u51FA\u73B0\u65B0\u7684\u5F85\u5904\u7406\u4FE1\u53F7\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u5207\u6362");
    const carriedAdditions = row.campaign.actions.filter((action) => action.action === "add" && row.orders[action.id]?.fills?.length).length;
    if (monitor.plan.router?.afterAdditions && carriedAdditions >= monitor.plan.router.afterAdditions)
      throw Error("\u5DF2\u8D8A\u8FC7\u65B0\u6A21\u677F\u4E00\u6B21\u6027\u5206\u6D41\u7684\u8F6E\u6B21\uFF0C\u8BF7\u9009\u62E9\u80FD\u63A5\u7EED\u5F53\u524D\u8F6E\u6B21\u7684\u65B9\u6848");
    const at = managedClock();
    const latestFill = Math.max(at, ...Object.values(row.orders).flatMap((order) => (order.fills ?? []).map((fill) => fill.at)));
    const effectiveAt = Math.max(previous?.checkpoint?.endTime ?? 0, Math.ceil(latestFill / MANAGED_MINUTE) * MANAGED_MINUTE);
    const quantity2 = Number(formatQuantity(held.held, market.step));
    const followBasis = { version: USDT_FOLLOW_MONITOR_BASIS, effectiveAt, carriedAdditions, quantity: quantity2, entryPrice, realizedBefore: held.realized };
    const managed = {
      version: BINANCE_MANUAL_MONITOR_VERSION,
      anchor,
      monitor,
      armedAt: at,
      entryPrice,
      entryQuantity: quantity2,
      planEpoch: epoch + 1,
      revision: (previous?.revision ?? 0) + 1,
      followBasis,
      followSample: previous?.followSample ?? followSample
    };
    managed.checkpoint = { ...initialBinanceManualCheckpoint(managed), instantMonitorSwitches: [
      ...previous?.checkpoint?.instantMonitorSwitches ?? [],
      { at, effectiveAt, from, to: monitor, followBasis }
    ] };
    row.managed = managed;
    row.status.state = "tracking";
    row.status.issue = void 0;
    write(row);
    return managed;
  }
  function updateManaged(id2, revision, checkpoint, decision, planEpoch, followBasisVersion) {
    const current = rows.get(id2);
    if (!current?.managed || current.status.state === "closed") throw Error("\u627E\u4E0D\u5230\u4ECD\u5728\u6301\u6709\u7684\u624B\u52A8\u6258\u7BA1\u4ED3\u4F4D");
    if (current.managed.revision !== revision || current.managed.pending || current.managed.planEpoch !== planEpoch) return current.managed;
    if (current.managed.followBasis && followBasisVersion !== USDT_FOLLOW_MONITOR_BASIS) throw Error("\u8BF7\u66F4\u65B0\u7F51\u9875\u540E\u7EE7\u7EED\u5B9E\u76D8\u7B56\u7565");
    if (current.status.state !== "tracking") throw Error("\u5E01\u5B89\u5B9E\u76D8\u4ED3\u4F4D\u7B49\u5F85\u5BF9\u8D26");
    const row = structuredClone(current);
    const managed = row.managed;
    const entry = managed.followBasis?.effectiveAt ?? Math.ceil(managed.anchor.openedAt / MANAGED_MINUTE) * MANAGED_MINUTE;
    const earliest = Math.max(entry, managed.checkpoint?.endTime ?? Math.ceil(managed.armedAt / MANAGED_MINUTE) * MANAGED_MINUTE);
    const now = managedClock();
    if (checkpoint.status !== "open" || checkpoint.entryPrice !== managed.entryPrice || checkpoint.entryTime !== entry || !Number.isSafeInteger(checkpoint.endTime) || checkpoint.endTime % MANAGED_MINUTE !== 0 || checkpoint.endTime < earliest || checkpoint.endTime > now + MANAGED_MINUTE) {
      throw Error("\u624B\u52A8\u6258\u7BA1\u68C0\u67E5\u70B9\u672A\u4E0E\u540C\u4E00\u7B14\u6210\u4EA4\u5BF9\u9F50");
    }
    if (JSON.stringify(checkpoint.marginRejectedAdditions ?? []) !== JSON.stringify(managed.checkpoint?.marginRejectedAdditions ?? []))
      throw Error("\u672C\u91D1\u4E0D\u8DB3\u7684\u52A0\u4ED3\u8F6E\u6B21\u987B\u4EE5\u6267\u884C\u5668\u8BB0\u5F55\u4E3A\u51C6");
    if (managed.followBasis) {
      const prior = managed.checkpoint;
      const realizedReductions = (value) => (value.additionReductions ?? []).filter((fill) => fill.fraction > 0);
      if (checkpoint.initialNotional !== prior.initialNotional || JSON.stringify(checkpoint.additionFills ?? (checkpoint.additionFill ? [checkpoint.additionFill] : [])) !== JSON.stringify(prior.additionFills ?? (prior.additionFill ? [prior.additionFill] : [])) || JSON.stringify(checkpoint.mirrorFill) !== JSON.stringify(prior.mirrorFill) || JSON.stringify(realizedReductions(checkpoint)) !== JSON.stringify(realizedReductions(prior))) {
        throw Error("\u5B9E\u76D8\u7B56\u7565\u8FDB\u5EA6\u4E0E\u5DF2\u786E\u8BA4\u7684\u6210\u4EA4\u4E0D\u4E00\u81F4");
      }
    }
    if (decision) {
      const action = decision.action;
      if (!action || action.id !== "managed-" + revision || !["add", "mirror", "support-reduction", "close"].includes(decision.kind) || decision.kind !== action.action || !Number.isSafeInteger(action.at) || action.at < earliest || action.at > now + 1e3 || decision.through < action.at || !Number.isSafeInteger(decision.through) || decision.through > now + MANAGED_MINUTE || decision.through % MANAGED_MINUTE !== 0) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u52A8\u4F5C\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if (action.action === "add" && (decision.kind !== "add" || !(action.notional > 0 && Number.isFinite(action.notional)) || action.at !== decision.evidence?.at || action.notional !== decision.evidence.notional || action.impulseFreshUntil !== void 0 && (action.at % 3e5 !== 0 || action.impulseFreshUntil !== action.at + 3e5))) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u52A0\u4ED3\u91D1\u989D\u6216\u65F6\u70B9\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if ((action.action === "mirror" || action.action === "support-reduction") && (decision.kind !== "mirror" && decision.kind !== "support-reduction" || !(action.fraction > 0 && action.fraction < 1) || action.fraction !== decision.evidence?.fraction || action.at !== decision.evidence.at)) {
        throw Error("\u624B\u52A8\u6258\u7BA1\u51CF\u4ED3\u6BD4\u4F8B\u6216\u65F6\u70B9\u672A\u901A\u8FC7\u6838\u5BF9");
      }
      if (checkpoint.endTime > action.at) throw Error("\u624B\u52A8\u6258\u7BA1\u52A8\u4F5C\u65E9\u4E8E\u5DF2\u786E\u8BA4\u8FDB\u5EA6");
      managed.pending = decision;
      row.campaign.actions.push(action);
    }
    managed.checkpoint = managed.planEpoch == null ? checkpoint : {
      ...checkpoint,
      instantMonitorSwitches: managed.checkpoint.instantMonitorSwitches,
      followBasis: managed.followBasis
    };
    managed.revision++;
    lastContactAt = Date.now();
    write(row);
    return managed;
  }
  function skipManagedAction(row, market, action, current) {
    if (row.managed?.pending?.action.id !== action.id) return;
    row.orders[action.id] = {
      id: usdtOrderId(owner, row.campaign.id, action.id),
      side: action.action === "add" ? "BUY" : "SELL",
      quantity: "0",
      terminal: true,
      fills: []
    };
    settleManagedUsdtDecision(row, action.id, market, current);
  }
  function reconcileExit(row, actual, market) {
    const next = structuredClone(row);
    const pendingBuy = Object.values(next.orders).some((order) => order.side === "BUY" && !order.terminal);
    if (pendingBuy) {
      const known = new Set(Object.values(next.orders).flatMap((order) => (order.fills ?? []).map((fill) => fill.id)));
      if (actual.fills.some((fill) => fill.side === "BUY" && !known.has(fill.id))) {
        throw Error("\u5E01\u5B89\u6709\u5C1A\u672A\u5F52\u5C5E\u7684\u4E70\u5165\u6210\u4EA4\uFF0C\u7B49\u5F85\u6838\u5BF9\u5B9E\u76D8\u4F59\u4ED3");
      }
    }
    const fills = mergeUsdtExitFills(next, actual, market, true);
    if (!fills.length && !actual.closedAt) return false;
    const held = syncBalance(next, market);
    if (held.held !== quantityUnits(actual.quantity, market.step)) throw Error("\u5E01\u5B89\u5B9E\u9645\u6210\u4EA4\u4E0E\u5F53\u524D\u4F59\u4ED3\u6682\u672A\u5BF9\u9F50");
    const managed = next.managed;
    if (managed) {
      if (managed.pending) next.skipped.push(managed.pending.action.id);
      managed.pending = void 0;
      managed.revision++;
      if (fills.length) {
        const at = fills.at(-1).at;
        const quantity2 = Number(formatQuantity(held.held, market.step));
        const prior = managed.checkpoint;
        if (prior && !actual.closedAt) {
          managed.checkpoint = {
            ...prior,
            remainingQuantity: quantity2,
            remainingCost: held.entry * quantity2,
            averageEntryPrice: held.entry,
            realizedPnl: held.realized,
            pendingExit: void 0,
            endTime: Math.max(prior.endTime ?? 0, Math.ceil(at / MANAGED_MINUTE) * MANAGED_MINUTE)
          };
        } else if (!prior && !actual.closedAt) {
          managed.exchangeReduction = { at, quantity: quantity2, entryPrice: held.entry, realized: held.realized };
        }
      }
    }
    const pausedAfterReduction = !!managed?.followBasis && !!fills.length && !actual.closedAt;
    next.status.state = pendingBuy || pausedAfterReduction ? "blocked" : actual.closedAt ? "closed" : "tracking";
    next.status.issue = pendingBuy ? unsettledBuyIssue : pausedAfterReduction ? externalReductionIssue : void 0;
    write(next);
    return true;
  }
  function openAnchor(row, market) {
    const open = row.orders.open;
    const first = [...open?.fills ?? []].sort((a, b) => a.at - b.at || a.id.length - b.id.length || a.id.localeCompare(b.id))[0];
    return row.managed?.anchor ?? (open?.exchangeId && first ? {
      symbol: market.symbol,
      positionSide: mode === "hedge" ? "LONG" : "BOTH",
      openedAt: first.at,
      openingTradeId: first.id,
      openingOrderId: open.exchangeId
    } : void 0);
  }
  async function readOriginalPosition(row, market) {
    const anchor = openAnchor(row, market);
    if (!anchor || !readManaged) throw Error("\u7F3A\u5C11\u53EF\u6838\u5BF9\u7684\u5E01\u5B89\u9996\u4ED3\u6210\u4EA4\uFF0C\u6682\u7F13\u5B9E\u76D8\u64CD\u4F5C");
    const actual = await readManaged(anchor);
    if (!matchesManualAnchor(anchor, actual)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u5DF2\u6362\u6210\u53E6\u4E00\u7B14\u9996\u4ED3\uFF0C\u6682\u7F13\u5B9E\u76D8\u64CD\u4F5C");
    return actual;
  }
  async function step(row, now) {
    if (row.status.state === "closed" || row.status.state === "ignored") return;
    const { campaign } = row;
    const opened = row.orders.open;
    const outstanding = Object.entries(row.orders).filter(([, order2]) => !order2.terminal);
    const existing = outstanding.find(([, order2]) => order2.side === "SELL") ?? outstanding[0];
    const closing = row.managed ? row.managed.pending?.action.action === "close" ? row.managed.pending.action : void 0 : campaign.actions.find((action2) => action2.action === "close");
    if (!opened && !existing && (closing || !accepting || campaign.actions[0].at < entryAfter || !validUsdtLiveEntry(campaign) || campaign.liveEntry.capturedAt < entryAfter || now > campaign.actions[0].at + USDT_ENTRY_MAX_AGE_MS)) {
      const previousIssue = row.status.state === "blocked" ? row.status.issue : void 0;
      row.status.state = "ignored";
      row.status.issue = [previousIssue, "\u5F00\u4ED3\u4FE1\u53F7\u5DF2\u8FC7\u65F6\u6216\u5DF2\u5E73\u4ED3\uFF0C\u672A\u8FFD\u5355"].filter(Boolean).join("\u3002");
      return write(row);
    }
    const market = !campaign.source.market && (!campaign.source.exchange || campaign.source.exchange === "binance") ? await readMarket(campaign.source.symbol) : void 0;
    if (!market) {
      if (opened) throw Error("\u5B9E\u76D8\u6301\u4ED3\u7684\u539F\u5408\u7EA6\u89C4\u683C\u6682\u4E0D\u53EF\u7528");
      row.status.state = "ignored";
      row.status.issue = "\u5F53\u524D\u6807\u7684\u7F3A\u5C11\u540C\u4E00\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6";
      return write(row);
    }
    let current = syncBalance(row, market);
    let unsettledBuyId;
    if (existing) {
      const [key2, order2] = existing;
      const canCheckExit = closing && order2.side === "BUY" && order2.limitPrice && current.held > 0;
      const report2 = await exchange.order(market, mode, order2, false).catch((error) => {
        if (!canCheckExit) throw error;
        return void 0;
      });
      if (report2) applyReport(row, key2, market, report2);
      if (report2?.terminal) return;
      if (!canCheckExit) {
        if (!report2) throw Error(order2.side === "BUY" ? unsettledBuyIssue : "\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u672A\u9F50\uFF0C\u6B63\u5728\u6309\u539F\u7F16\u53F7\u6838\u5BF9");
        return;
      }
      unsettledBuyId = order2.id;
      current = syncBalance(row, market);
    }
    if (row.managed) {
      if (!readManaged) throw Error("\u5F53\u524D\u6267\u884C\u5668\u65E0\u6CD5\u6838\u5BF9\u624B\u52A8\u6258\u7BA1\u4ED3\u4F4D");
      const pending = row.managed.pending;
      if (!pending && (managedChecked.get(campaign.id) ?? 0) + 12e3 > now) return;
      const actual = await readManaged(row.managed.anchor);
      if (row !== rows.get(campaign.id)) return;
      managedChecked.set(campaign.id, now);
      if (readPositions && reconcileExit(row, actual, market)) return;
      if (verifyManagedUsdtFills(row, actual, market)) {
        syncBalance(row, market);
        row.status.state = "closed";
        row.status.issue = void 0;
        row.managed.pending = void 0;
        return write(row);
      }
      current = syncBalance(row, market);
      if (!pending) {
        if (row.status.issue === externalReductionIssue) return;
        if (row.status.state !== "tracking" && !closing) {
          row.status.state = "tracking";
          row.status.issue = void 0;
          write(row);
        }
        return;
      }
    }
    if (!row.managed && readPositions && readManaged && opened?.exchangeId && opened.fills?.length && current.held) {
      const positionSide = mode === "hedge" ? "LONG" : "BOTH";
      const snapshot = await readPositions();
      const position = snapshot.positions.find((item) => item.symbol === market.symbol && item.positionSide === positionSide && item.direction === "long");
      if (!position || quantityUnits(position.quantity, market.step) !== current.held || Math.abs(Number(position.entryPrice) - current.entry) > Math.max(1e-8, current.entry * 1e-5)) {
        const actual = await readOriginalPosition(row, market);
        if (reconcileExit(row, actual, market)) return;
      }
    }
    if (opened && !current.held) {
      row.status.state = current.initial ? "closed" : "ignored";
      if (!current.initial) row.status.issue ||= "\u9996\u4ED3\u672A\u6210\u4EA4";
      return write(row);
    }
    let action = unsettledBuyId ? closing : row.managed?.followBasis ? row.managed.pending?.action : campaign.actions.find((event) => !row.orders[event.id] && !row.skipped.includes(event.id));
    if (closing && current.held && action?.action !== "close") {
      row.skipped.push(...campaign.actions.filter((event) => event.action !== "close" && !row.orders[event.id] && !row.skipped.includes(event.id)).map((event) => event.id));
      action = closing;
    }
    if (closing && current.held && !action && !row.skipped.includes(closing.id)) action = closing;
    if (!action || row.skipped.includes(action.id)) return;
    const side = action.action === "open" || action.action === "add" ? "BUY" : "SELL";
    const signalNow = row.managed ? managedClock() : now;
    if (side === "BUY" && !mayIncrease(row, action, now, signalNow)) {
      row.skipped.push(action.id);
      row.status.issue = "\u8BE5\u7B14\u4E70\u5165\u5DF2\u8FC7\u65F6\uFF0C\u672A\u8FFD\u5355";
      skipManagedAction(row, market, action, current);
      return write(row);
    }
    const pendingOther = [...rows.values()].some((other) => other !== row && other.campaign.source.symbol === market.symbol && (balance(other).held > 0 || Object.values(other.orders).some((order2) => !order2.terminal)));
    if (pendingOther) throw Error("\u540C\u4E00\u5408\u7EA6\u5DF2\u6709\u53E6\u4E00\u7B14\u5B9E\u76D8\u6218\u5F79");
    const book = action.action === "close" ? void 0 : await exchange.book(market.symbol, side);
    const price = Number(book);
    const notional = action.action === "open" ? campaign.notional : action.action === "add" ? action.notional : 0;
    const stepSize = Number(market.step);
    const desired = action.action === "close" ? current.held : "fraction" in action ? Math.floor((action.action === "mirror" ? row.managed?.followBasis ? Math.round(row.managed.followBasis.quantity / stepSize) : current.initial : current.held) * action.fraction + 1e-9) : Math.floor(notional / price / stepSize + 1e-9);
    const decision = row.managed?.pending;
    let limit = side === "BUY" ? market.max : current.held;
    if (decision?.kind === "add" && decision.evidence.sizing) {
      const { support } = decision.evidence.sizing;
      if (price <= support) limit = 0;
      else if (decision.evidence.positionVersion === HOLDING_LEDGER_ADDITION_VERSION) {
        const held = current.held * stepSize;
        const budget = calculateHoldingLedgerAddition({
          held,
          cost: held * current.entry,
          realized: current.realized - (row.managed?.followBasis?.realizedBefore ?? 0)
        }, price, support);
        limit = budget.error ? 0 : Math.min(limit, Math.floor(budget.addCoins / stepSize + 1e-9));
      } else {
        const plannedRisk = decision.evidence.quantity * (decision.evidence.price - support);
        limit = Math.min(limit, Math.max(0, Math.floor(plannedRisk / (price - support) / stepSize + 1e-9)));
      }
    }
    const units2 = Math.min(desired, market.max, limit);
    const quantity2 = formatQuantity(units2, market.step);
    if (units2 < market.min || side === "BUY" && Number(quantity2) * price < market.minNotional || side === "SELL" && action.action !== "close" && Number(quantity2) * price < market.minNotional) {
      row.skipped.push(action.id);
      row.status.state = opened ? "tracking" : "ignored";
      if (action.action === "close") row.status.state = "blocked";
      row.status.issue = "\u6309\u65B9\u6848\u91D1\u989D\u6216\u51CF\u4ED3\u6BD4\u4F8B\u6362\u7B97\u540E\u4F4E\u4E8E\u5E01\u5B89\u6700\u5C0F\u59D4\u6258";
      if (action.action !== "close") skipManagedAction(row, market, action, current);
      return write(row);
    }
    const opening = opened?.fills?.[0];
    const liveId = opened?.exchangeId && opening ? usdtLiveCampaignId({
      symbol: market.symbol,
      positionSide: mode === "hedge" ? "LONG" : "BOTH",
      direction: "long",
      fills: [{ id: opening.id, orderId: opened.exchangeId }]
    }) : void 0;
    const liveLeverage = !campaign.frozenMonitor?.admission.round.instantPosition && readPositions && liveId ? store.positionLeverage(liveId)?.leverage : void 0;
    const maySendBuy = () => {
      const checkedAt = Math.max(now, Date.now());
      return mayIncrease(row, action, checkedAt, row.managed ? managedClock() : checkedAt) && !(row.managed ? row.managed.pending?.action.action === "close" : row.campaign.actions.some((event) => event.action === "close"));
    };
    const confirmOpening = () => {
      if (!maySendBuy()) throw Error("\u5F00\u4ED3\u6761\u4EF6\u5DF2\u5931\u6548\uFF0C\u6682\u7F13\u4FEE\u6539\u5B9E\u76D8\u5408\u7EA6\u8BBE\u7F6E");
    };
    if (action.action === "open") await protection?.beforeOpening(market.symbol);
    const openingArgs = action.action === "open" ? [confirmOpening, Number(quantity2) * price] : [];
    const executionLeverage = await exchange.check(
      market,
      mode,
      current.held,
      current.entry,
      action.action === "open",
      side === "BUY" ? liveLeverage ?? row.status.executionLeverage ?? campaign.leverage : 0,
      row.managed ? campaign.frozenMonitor?.admission.round.instantPosition && row.managed.followBasis ? "frozen-leverage" : "existing-position" : void 0,
      liveId ? protectionIds?.(market.symbol, liveId) : void 0,
      unsettledBuyId,
      ...openingArgs
    );
    if (action.action === "open" && executionLeverage) row.status.executionLeverage = executionLeverage;
    if (action.action !== "open") {
      const actual = await readOriginalPosition(row, market);
      if (row !== rows.get(campaign.id) || reconcileExit(row, actual, market)) return;
      if (quantityUnits(actual.quantity, market.step) !== current.held) throw Error("\u5E01\u5B89\u9996\u4ED3\u5DF2\u6838\u5B9E\uFF0C\u5B9E\u9645\u4F59\u4ED3\u4ECD\u5F85\u5BF9\u8D26");
    }
    if (side === "BUY" && !maySendBuy()) return;
    const attempts = Object.entries(row.orders).filter(([key2]) => key2 === closing?.id || key2.startsWith(closing?.id + ":"));
    const failedCloses = attempts.filter(([, order2]) => !order2.fills?.length).length;
    if (action.action === "close" && (row.managed ? failedCloses >= 3 : attempts.length && !attempts.at(-1)?.[1].fills?.length)) {
      row.skipped.push(action.id);
      row.status.state = "blocked";
      row.status.issue = "\u5E73\u4ED3\u672A\u6210\u4EA4\uFF0C\u5E01\u5B89\u4ECD\u6709\u4F59\u4ED3\uFF0C\u7B49\u5F85\u4EBA\u5DE5\u6838\u5BF9";
      return write(row);
    }
    const priorCloses = attempts.length;
    const key = action.action === "close" && priorCloses ? action.id + ":" + priorCloses : action.id;
    const order = {
      id: usdtOrderId(owner, campaign.id, key),
      side,
      quantity: quantity2,
      terminal: false,
      ...side === "BUY" ? { limitPrice: book } : {}
    };
    row.orders[key] = order;
    row.status.state = "waiting";
    row.status.issue = unsettledBuyId ? unsettledBuyIssue : void 0;
    write(row);
    const report = await exchange.order(market, mode, order, true);
    if (!report) throw Error("\u5E01\u5B89\u8BA2\u5355\u56DE\u62A5\u672A\u9F50\uFF0C\u6B63\u5728\u6309\u539F\u7F16\u53F7\u6838\u5BF9");
    applyReport(row, key, market, report);
  }
  function applyReport(row, key, market, report) {
    const previous = row.orders[key];
    const previousManaged = row.managed && structuredClone(row.managed);
    if (previous.exchangeId && report.exchangeId !== previous.exchangeId) throw Error("\u5E01\u5B89\u8BA2\u5355\u7F16\u53F7\u4E0E\u672C\u673A\u8BB0\u5F55\u4E0D\u540C");
    if (report.fills.reduce((sum, fill) => sum + fill.quantity, 0) < (previous.fills ?? []).reduce((sum, fill) => sum + fill.quantity, 0))
      throw Error("\u5E01\u5B89\u8FD4\u56DE\u4E86\u8F83\u65E7\u7684\u7D2F\u8BA1\u6210\u4EA4\u8BB0\u5F55");
    const next = { ...previous, terminal: report.terminal, exchangeId: report.exchangeId, fills: report.fills };
    row.orders[key] = next;
    try {
      const held = syncBalance(row, market);
      const pendingBuy = Object.values(row.orders).some((order) => order.side === "BUY" && !order.terminal);
      row.status.state = report.terminal ? pendingBuy ? "blocked" : held.held ? "tracking" : held.initial ? "closed" : "ignored" : "waiting";
      row.status.orderId = report.exchangeId;
      row.status.issue = pendingBuy && report.terminal ? unsettledBuyIssue : report.issue ?? (report.terminal && report.fills.reduce((sum, fill) => sum + fill.quantity, 0) < quantityUnits(previous.quantity, market.step) ? "\u8BA2\u5355\u90E8\u5206\u6210\u4EA4\uFF0C\u4F59\u4ED3\u6309\u5E01\u5B89\u56DE\u62A5\u8DDF\u8E2A" : void 0);
      settleManagedUsdtDecision(row, key, market, held, report.insufficientMargin);
      if (row.managed?.pending?.kind === "close" && report.terminal && !report.fills.length) {
        cooldown.set(row.campaign.id, Date.now() + 5e3);
      }
      write(row);
    } catch (error) {
      row.orders[key] = previous;
      row.managed = previousManaged;
      throw error;
    }
  }
  return {
    ingest,
    adopt,
    switchManaged,
    switchFollowMonitor,
    updateManaged,
    updateRecovered(incoming) {
      const row = rows.get(incoming.id);
      if (!row || row.managed || !store.local("imported-monitor:" + incoming.id) || !incoming.frozenMonitor || JSON.stringify(row.campaign.frozenMonitor?.admission) !== JSON.stringify(incoming.frozenMonitor.admission) || (incoming.frozenMonitor.checkpoint?.endTime ?? 0) < (row.campaign.frozenMonitor?.checkpoint?.endTime ?? 0))
        throw Error("\u4EA4\u63A5\u76D1\u6D4B\u72B6\u6001\u8EAB\u4EFD\u6216\u8FDB\u5EA6\u4E0D\u7B26");
      ingest([incoming], Date.now(), true);
      row.campaign.frozenMonitor = incoming.frozenMonitor;
      write(row);
    },
    captureFrozenMonitors(campaigns) {
      for (const incoming of campaigns) {
        const row = rows.get(incoming.id), frozen2 = incoming.frozenMonitor;
        if (!row || row.managed || !frozen2 || store.local("imported-monitor:" + incoming.id) || ["closed", "ignored"].includes(row.status.state)) continue;
        if (row.campaign.source.symbol !== incoming.source.symbol || row.campaign.notional !== incoming.notional || row.campaign.leverage !== incoming.leverage || row.campaign.admittedAt !== incoming.admittedAt || row.campaign.liveEntry?.templateId !== frozen2.admission.round.instantMonitor?.templateId || JSON.stringify(row.campaign.actions[0]) !== JSON.stringify(incoming.actions[0]))
          throw Error("\u539F\u7F51\u9875\u76D1\u6D4B\u5FEB\u7167\u4E0E\u5B9E\u76D8\u6218\u5F79\u4E0D\u7B26");
        if ((frozen2.checkpoint?.endTime ?? 0) < (row.campaign.frozenMonitor?.checkpoint?.endTime ?? 0)) continue;
        if (row.campaign.frozenMonitor && JSON.stringify(row.campaign.frozenMonitor.admission.round.instantMonitor) !== JSON.stringify(frozen2.admission.round.instantMonitor))
          throw Error("\u539F\u51BB\u7ED3\u6A21\u677F\u5DF2\u53D8\u5316\uFF0C\u7981\u6B62\u8986\u76D6");
        row.campaign.frozenMonitor = frozen2;
        write(row);
      }
    },
    async runPositionControl(run) {
      if (frozen) throw Error("\u6267\u884C\u5668\u5DF2\u51BB\u7ED3\uFF0C\u7981\u6B62\u5B9E\u76D8\u64CD\u4F5C");
      if (manual) throw Error("\u53E6\u4E00\u7B14\u5B9E\u76D8\u64CD\u4F5C\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      manual = true;
      try {
        if (active) await new Promise((resolve2) => {
          finishTick = resolve2;
        });
        return await run();
      } finally {
        manual = false;
      }
    },
    async quiesce() {
      frozen = true;
      accepting = false;
      while (active || manual) await new Promise((resolve2) => setTimeout(resolve2, 10));
    },
    thaw() {
      frozen = false;
      accepting = !store.paused();
      entryAfter = Date.now();
      lastContactAt = 0;
    },
    async reconcileForHandoff() {
      if (active || manual) throw Error("\u6267\u884C\u5668\u4ECD\u5728\u5904\u7406\u4E0A\u4E00\u7B14\u64CD\u4F5C");
      for (const row of rows.values()) {
        if (["closed", "ignored"].includes(row.status.state)) continue;
        const market = await readMarket(row.campaign.source.symbol);
        if (!market) throw Error("\u4EA4\u63A5\u7F3A\u5C11\u539F\u5408\u7EA6\u89C4\u683C");
        for (const [key, order] of Object.entries(row.orders)) {
          if (order.terminal) continue;
          const report = await exchange.order(market, mode, order, false);
          if (!report) throw Error("\u672A\u51B3\u8BA2\u5355\u5C1A\u672A\u67E5\u660E\uFF0C\u4EA4\u63A5\u4FDD\u6301\u51BB\u7ED3\uFF0C\u7981\u6B62\u6362\u7F16\u53F7\u8865\u5355");
          applyReport(row, key, market, report);
        }
        const held = syncBalance(row, market);
        if (held.held && readManaged && row.orders.open?.exchangeId && row.orders.open.fills?.length) {
          const actual = await readOriginalPosition(row, market);
          if (reconcileExit(row, actual, market)) continue;
        }
        write(row);
      }
    },
    managed: (includeFollow = false) => [...rows.values()].filter((row) => row.managed && row.status.state !== "closed" && (includeFollow || !row.managed.followBasis)).map((row) => ({ position: row.managed, status: row.status })),
    managedArchive: (id2) => {
      const managed = rows.get(id2)?.managed;
      return managed && {
        version: managed.version,
        monitor: managed.monitor,
        armedAt: managed.armedAt,
        ...managed.checkpoint ? { checkpoint: managed.checkpoint } : {},
        ...managed.checkpoint?.selectedL0Pct !== void 0 ? { selectedL0Pct: managed.checkpoint.selectedL0Pct } : {},
        ...managed.checkpoint?.instantMonitorSwitches ? { switches: managed.checkpoint.instantMonitorSwitches } : {},
        ...managed.checkpoint?.status === "closed" ? { exitReason: managed.checkpoint.reason } : {}
      };
    },
    pauseNewOrders: () => {
      store.setPaused(true);
      accepting = false;
    },
    resumeNewOrders: (now = Date.now()) => {
      if (frozen) throw Error("\u4EA4\u63A5\u51BB\u7ED3\u5C1A\u672A\u89E3\u9664");
      store.setPaused(false);
      entryAfter = now;
      accepting = true;
    },
    get entryAfter() {
      return entryAfter;
    },
    get paused() {
      return !accepting;
    },
    statuses: () => [...rows.values()].map((row) => row.campaign.liveEntry && (!row.managed || row.managed.followBasis) ? {
      ...row.status,
      followMonitorTemplateId: row.managed?.monitor.templateId ?? row.campaign.liveEntry.templateId,
      canSwitchFollowMonitor: !row.managed?.pending && (row.status.state === "tracking" || row.status.issue === externalReductionIssue)
    } : row.status),
    async tick(now = Date.now()) {
      if (active || manual || frozen) return;
      active = true;
      try {
        const prioritized = [...rows.values()].sort((a, b) => Number(b.campaign.actions.some((event) => event.action === "close")) - Number(a.campaign.actions.some((event) => event.action === "close")));
        for (const row of prioritized) {
          if (manual || frozen) break;
          if (row !== rows.get(row.campaign.id)) continue;
          if ((cooldown.get(row.campaign.id) ?? 0) > now) continue;
          if (row.status.state === "closed") continue;
          try {
            await step(row, now);
          } catch (error) {
            if (row !== rows.get(row.campaign.id)) continue;
            row.status.state = "blocked";
            row.status.issue = error instanceof Error ? error.message : "\u5E01\u5B89\u540C\u6B65\u6682\u4E0D\u53EF\u7528";
            write(row);
            cooldown.set(row.campaign.id, Date.now() + 3e3);
          }
          if (rows.get(row.campaign.id)?.status.state === "closed") {
            await protection?.cleanup(row.campaign.source.symbol).catch(() => void 0);
          }
        }
      } finally {
        active = false;
        finishTick?.();
        finishTick = void 0;
      }
    }
  };
}

// scripts/usdt-order-desk.ts
var regularOrderPath = "/fapi/v1/order";
var conditionalOrderPath = "/fapi/v1/algoOrder";
var symbolPattern2 = /^[A-Z0-9]{2,24}USDT$/;
var decimal4 = /^\d{1,20}(?:\.\d{1,18})?$/;
var positive4 = (value) => typeof value === "string" && decimal4.test(value) && Number(value) > 0;
var validId2 = (value) => typeof value === "string" && /^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/.test(value);
function validDeskOrder(order) {
  if (order?.type === "limit") return positive4(order.price) && ["GTC", "IOC", "FOK", "GTX"].includes(order.timeInForce);
  if (order?.type === "conditional") return positive4(order.triggerPrice);
  return order?.type === "market" && (order.slippage === void 0 || Number.isFinite(order.slippage) && order.slippage >= 0.01 && order.slippage <= 10);
}
async function deskOrderParameters(order, market, side, clientId, mark, book) {
  const tick = market.priceTick;
  const checkedPrice = (price) => {
    if (!tick || !quantityUnits(price, tick)) throw Error("\u4EF7\u683C\u4E0D\u7B26\u5408\u5E01\u5B89\u6700\u5C0F\u4EF7\u683C\u5355\u4F4D");
    return price;
  };
  const regular = { newClientOrderId: clientId, newOrderRespType: "RESULT" };
  if (order.type === "limit") return {
    path: regularOrderPath,
    params: { ...regular, type: "LIMIT", price: checkedPrice(order.price), timeInForce: order.timeInForce }
  };
  if (order.type === "conditional") {
    const triggerPrice = checkedPrice(order.triggerPrice), trigger = Number(triggerPrice);
    if (!(mark > 0) || mark === trigger) throw Error("\u89E6\u53D1\u4EF7\u987B\u4E0E\u5E01\u5B89\u5F53\u524D\u6807\u8BB0\u4EF7\u4E0D\u540C");
    const stop = side === "BUY" === trigger > mark;
    return { path: conditionalOrderPath, params: {
      algoType: "CONDITIONAL",
      type: stop ? "STOP_MARKET" : "TAKE_PROFIT_MARKET",
      workingType: "MARK_PRICE",
      triggerPrice,
      clientAlgoId: clientId
    } };
  }
  if (order.slippage !== void 0) {
    if (!tick) throw Error("\u65E0\u6CD5\u6838\u5BF9\u5E01\u5B89\u6700\u5C0F\u4EF7\u683C\u5355\u4F4D");
    const multiplier = 1 + (side === "BUY" ? 1 : -1) * order.slippage / 100;
    const boundary = Number(await book()) * multiplier / Number(tick);
    const ticks = side === "BUY" ? Math.floor(boundary) : Math.ceil(boundary);
    return { path: regularOrderPath, params: {
      ...regular,
      type: "LIMIT",
      price: checkedPrice(formatQuantity(ticks, tick)),
      timeInForce: "IOC"
    } };
  }
  return { path: regularOrderPath, params: { ...regular, type: "MARKET" } };
}
function createUsdtOrderDesk(request, exchange, store, owner, mode, checkOpening, clock = Date.now, markPrice = readUsdtMark) {
  const contracts = /* @__PURE__ */ new Map();
  const marketFor = async (symbol2) => {
    if (typeof symbol2 !== "string" || !symbolPattern2.test(symbol2)) throw Error("\u8BF7\u9009\u62E9\u5E01\u5B89 USDT \u6C38\u7EED\u5408\u7EA6");
    const cached = contracts.get(symbol2);
    if (cached && cached.expires > clock()) return cached.market;
    const market = await exchange.market(symbol2);
    if (!market?.priceTick) throw Error("\u8BE5\u5408\u7EA6\u7684\u4EA4\u6613\u89C4\u683C\u6682\u4E0D\u53EF\u7528");
    contracts.set(symbol2, { market, expires: clock() + 6e4 });
    return market;
  };
  const details = async (symbol2, market) => {
    const [account, config, mark, ask, bid] = await Promise.all([
      request("GET", "/fapi/v3/account"),
      request("GET", "/fapi/v1/symbolConfig", { symbol: symbol2 }),
      markPrice(symbol2),
      exchange.book(symbol2, "BUY"),
      exchange.book(symbol2, "SELL")
    ]);
    const available = account.assets?.find((row) => row.asset === "USDT")?.availableBalance;
    const terms = config?.find((row) => row.symbol === symbol2);
    const leverage = Number(terms?.leverage), maxNotional = terms?.maxNotionalValue;
    if (!decimal4.test(String(available)) || !positive4(String(maxNotional)) || !Number.isInteger(leverage) || leverage < 1 || !positive4(mark)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u914D\u7F6E\u6216\u53EF\u7528\u4F59\u989D\u6682\u4E0D\u53EF\u7528");
    return {
      symbol: symbol2,
      ask,
      bid,
      mark,
      available: String(available),
      leverage,
      priceTick: market.priceTick,
      orderStep: market.step,
      marketStep: market.marketStep && Number(market.marketStep) > 0 ? market.marketStep : market.step,
      maxQuantity: formatQuantity(market.max, market.step),
      maxNotional: String(maxNotional)
    };
  };
  const info = async (symbol2) => {
    const market = await marketFor(symbol2);
    return details(market.symbol, market);
  };
  async function execute(value) {
    if (!value || !validId2(value.id) || !symbolPattern2.test(value.symbol) || !["long", "short"].includes(value.direction) || !positive4(value.quantity) || !validDeskOrder(value.order)) throw Error("\u5F00\u4ED3\u59D4\u6258\u53C2\u6570\u65E0\u6548");
    const { id: id2, symbol: symbol2, direction, quantity: quantity2, order } = value;
    const fingerprint = JSON.stringify([symbol2, direction, quantity2, order]);
    let row = store.getDeskOrder(id2);
    if (row && row.fingerprint !== fingerprint) throw Error("\u540C\u4E00\u5B9E\u76D8\u59D4\u6258\u7F16\u53F7\u7684\u53C2\u6570\u4E0D\u4E00\u81F4");
    if (row?.result) return row.result;
    let response;
    if (!row) {
      if (store.pendingDeskOrders().some((item) => item.symbol === symbol2))
        throw Error("\u540C\u4E00\u5408\u7EA6\u4E0A\u4E00\u7B14\u5F00\u4ED3\u4ECD\u5728\u6838\u5BF9\uFF0C\u8BF7\u5148\u67E5\u539F\u7F16\u53F7");
      await checkOpening(symbol2);
      const market = await marketFor(symbol2);
      const [quote, currentMode, rawPositions] = await Promise.all([
        details(symbol2, market),
        request("GET", "/fapi/v1/positionSide/dual"),
        request("GET", "/fapi/v3/positionRisk", { symbol: symbol2 })
      ]);
      if (currentMode.dualSidePosition !== (mode === "hedge") || !Array.isArray(rawPositions)) throw Error("\u5E01\u5B89\u4ED3\u4F4D\u6A21\u5F0F\u6216\u4ED3\u4F4D\u6570\u636E\u5DF2\u53D8\u5316");
      const side = direction === "long" ? "BUY" : "SELL", positionSide = mode === "one-way" ? "BOTH" : direction === "long" ? "LONG" : "SHORT";
      if (mode === "one-way" && rawPositions.some((item) => Number(item.positionAmt) && Number(item.positionAmt) > 0 !== (side === "BUY")))
        throw Error("\u5355\u5411\u6A21\u5F0F\u4E2D\u6709\u53CD\u5411\u4ED3\u4F4D\uFF0C\u8BF7\u5148\u5728\u5E73\u4ED3\u680F\u5904\u7406");
      const units2 = quantityUnits(quantity2, market.step);
      if (units2 < market.min || units2 > market.max) throw Error("\u6570\u91CF\u8D85\u51FA\u5E01\u5B89\u5355\u7B14\u59D4\u6258\u89C4\u683C");
      if (order.type !== "limit") quantityUnits(quantity2, quote.marketStep);
      const book = side === "BUY" ? quote.ask : quote.bid;
      const basis = Number(order.type === "limit" ? order.price : order.type === "conditional" ? order.triggerPrice : book);
      const notional = Number(quantity2) * basis;
      if (notional < market.minNotional) throw Error("\u4F4E\u4E8E\u5E01\u5B89\u6700\u4F4E\u59D4\u6258\u91D1\u989D");
      if (notional > Math.min(Number(quote.available) * quote.leverage, Number(quote.maxNotional)))
        throw Error("\u5E01\u5B89\u53EF\u7528\u4FDD\u8BC1\u91D1\u6216\u5408\u7EA6\u989D\u5EA6\u4E0D\u8DB3");
      const wire2 = await deskOrderParameters(order, market, side, usdtOrderId(owner, "desk-open", id2), Number(quote.mark), async () => book);
      row = { fingerprint, symbol: symbol2, side, positionSide, quantity: quantity2, wire: wire2, sentAt: clock() };
      store.saveDeskOrder(id2, row, true);
      const params = Object.fromEntries(Object.entries(wire2.params).filter(([, item]) => typeof item === "string"));
      try {
        response = await request("POST", wire2.path, { ...params, symbol: symbol2, side, positionSide, quantity: quantity2 });
      } catch (error) {
        if (error instanceof UsdtApiError && [-1013, -1021, -1100, -1102, -1111, -2019, -2021, -4164].includes(error.code ?? 0)) {
          row.result = { issue: error.message };
          store.saveDeskOrder(id2, row, false);
          return row.result;
        }
      }
    }
    const { wire } = row;
    const conditional = wire.path === conditionalOrderPath;
    if (!response) {
      const query = conditional ? { clientAlgoId: wire.params.clientAlgoId } : { symbol: symbol2, origClientOrderId: wire.params.newClientOrderId };
      try {
        response = await request("GET", wire.path, query);
      } catch (error) {
        if (error instanceof UsdtApiError && [-2011, -2013].includes(error.code ?? 0) && clock() - row.sentAt > 6e4) {
          row.result = { issue: "\u5E01\u5B89\u672A\u67E5\u5230\u539F\u59D4\u6258\uFF0C\u8BF7\u5728\u5E01\u5B89\u6838\u5BF9\u540E\u518D\u64CD\u4F5C" };
          store.saveDeskOrder(id2, row, false);
          return row.result;
        }
        return { pending: true };
      }
    }
    const reportedId = conditional ? response?.clientAlgoId : response?.clientOrderId;
    if (reportedId !== (wire.params.clientAlgoId ?? wire.params.newClientOrderId) || response?.symbol !== symbol2 || response?.side !== row.side || response?.positionSide !== row.positionSide) return { pending: true };
    const status = conditional ? response.algoStatus : response.status;
    const filled = Number(response.executedQty) > 0 && Number(response.executedQty) <= Number(quantity2) ? String(response.executedQty) : void 0;
    if (!["NEW", "PARTIALLY_FILLED", "FILLED", "TRIGGERING", "TRIGGERED", "FINISHED", "REJECTED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED"].includes(status))
      return { pending: true };
    row.result = { filledQuantity: filled, issue: ["REJECTED", "EXPIRED", "EXPIRED_IN_MATCH", "CANCELED"].includes(status) ? filled ? "\u90E8\u5206\u6210\u4EA4\uFF0C\u4F59\u91CF\u5DF2\u7ED3\u675F" : "\u59D4\u6258\u672A\u6210\u4EA4\uFF0C\u5DF2\u7ED3\u675F" : void 0 };
    store.saveDeskOrder(id2, row, false);
    return row.result;
  }
  return { info, execute };
}

// scripts/usdt-position-controls.ts
init_usdtLiveCampaign();
var riskPath = "/fapi/v3/positionRisk";
var openAlgoPath = "/fapi/v1/openAlgoOrders";
var algoPath = "/fapi/v1/algoOrder";
var orderPath = "/fapi/v1/order";
var configPath = "/fapi/v1/symbolConfig";
var leveragePath = "/fapi/v1/leverage";
var marginPath = "/fapi/v1/positionMargin";
var numberId = /^\d{1,25}$/;
var marketSymbol = /^[A-Z0-9]{2,24}USDT$/;
var positiveDecimal = /^\d{1,20}(?:\.\d{1,18})?$/;
var closingSide = (position) => position.direction === "long" ? "SELL" : "BUY";
var matchingLeg = (row, target) => row.symbol === target.symbol && row.positionSide === target.positionSide && row.direction === target.direction;
var percent = (value) => Number.isFinite(value) && value > 0 && value <= 1;
var isDone = (step) => step.state === "done";
var isTrackedProtection = (step) => step.method === "POST" && step.path === algoPath && !step.retired && (step.state === "sent" || step.state === "done");
function parseCommand(value, now) {
  const { id: id2, target, action } = value ?? {};
  if (typeof id2 !== "string" || !/^[a-f0-9-]{36}$/.test(id2) || !target || !marketSymbol.test(target.symbol) || !["BOTH", "LONG", "SHORT"].includes(target.positionSide) || !["long", "short"].includes(target.direction) || !Number.isSafeInteger(target.openedAt) || target.openedAt <= 0 || target.openedAt > now || typeof target.revision !== "string" || target.revision.length > 300 || !isUsdtLiveCampaignId(target.campaignId) || !action) throw Error("\u5E01\u5B89\u5B9E\u76D8\u64CD\u4F5C\u53C2\u6570\u65E0\u6548");
  switch (action.kind) {
    case "close":
      if (percent(action.fraction) && (action.order === void 0 || validDeskOrder(action.order))) return value;
      break;
    case "protect":
      if (percent(action.fraction) && (action.tp !== null || action.sl !== null) && [action.tp, action.sl].every((price) => price === null || Number.isFinite(price) && price > 0)) return value;
      break;
    case "cancel":
      if (typeof action.orderId === "string" && numberId.test(action.orderId)) return value;
      break;
    case "leverage":
      if (Number.isInteger(action.leverage) && action.leverage >= 1 && action.leverage <= 125) return value;
      break;
    case "margin":
      if (Number.isFinite(action.delta) && action.delta !== 0 && positiveDecimal.test(String(Math.abs(action.delta)))) return value;
      break;
  }
  throw Error("\u5E01\u5B89\u5B9E\u76D8\u64CD\u4F5C\u53C2\u6570\u65E0\u6548");
}
function quantityFor(raw, fraction, market) {
  const step = market.marketStep && Number(market.marketStep) > 0 ? market.marketStep : market.step;
  const lots = quantityUnits(raw, market.step);
  const factor = Number(step) / Number(market.step);
  const marketLots = Math.min(lots, Math.floor(lots * fraction + 1e-9));
  const quantity2 = formatQuantity(Math.floor(marketLots / factor + 1e-9), step);
  const checked2 = quantityUnits(quantity2, market.step);
  if (checked2 < market.min || checked2 > market.max || checked2 > lots) throw Error("\u6570\u91CF\u4E0D\u7B26\u5408\u5E01\u5B89\u5E02\u4EF7\u59D4\u6258\u4E0A\u4E0B\u9650\uFF0C\u8BF7\u8C03\u6574\u6BD4\u4F8B");
  if (fraction === 1 && checked2 !== lots) throw Error("\u5168\u90E8\u5E73\u4ED3\u7684\u6570\u91CF\u4E0E\u5E01\u5B89\u5E02\u4EF7\u6B65\u957F\u4E0D\u7B26\uFF0C\u8BF7\u6838\u5BF9\u4F59\u4ED3");
  return quantity2;
}
function protectionRows(raw, position) {
  if (!Array.isArray(raw)) throw Error("\u5E01\u5B89\u6B62\u76C8\u6B62\u635F\u59D4\u6258\u6682\u4E0D\u53EF\u8BFB");
  return raw.flatMap((row) => {
    const tp = row.orderType === "TAKE_PROFIT_MARKET" || row.orderType === "TAKE_PROFIT";
    const sl = row.orderType === "STOP_MARKET" || row.orderType === "STOP";
    if (!tp && !sl || row.symbol !== position.symbol || row.side !== closingSide(position) || row.positionSide !== position.positionSide || !(row.closePosition === true || row.reduceOnly === true || row.positionSide !== "BOTH") || !numberId.test(String(row.algoId)) || !positiveDecimal.test(String(row.triggerPrice)) || Number(row.triggerPrice) <= 0) return [];
    return [{
      id: String(row.algoId),
      clientId: typeof row.clientAlgoId === "string" ? row.clientAlgoId : void 0,
      kind: tp ? "tp" : "sl",
      triggerPrice: String(row.triggerPrice),
      quantity: row.closePosition === true ? void 0 : String(row.quantity),
      workingType: row.workingType === "MARK_PRICE" ? "MARK_PRICE" : "CONTRACT_PRICE"
    }];
  });
}
var definitelyRejected = (error) => error instanceof UsdtApiError && error.status < 500 && (error.status >= 400 || error.code !== void 0) && error.status !== 408 && error.status !== 429 && ![-1e3, -1001, -1006, -1007, -4116].includes(error.code ?? 0);
function createUsdtPositionControls(request, store, owner, readMarket, readCampaigns, invalidate, clock = Date.now, readBook) {
  const rawOrders = (symbol2) => request("GET", openAlgoPath, { symbol: symbol2 });
  const risk = async (symbol2) => decodePositions(await request("GET", riskPath, { symbol: symbol2 }));
  const activeCampaign = async (target) => (await readCampaigns(
    Math.max(1, target.openedAt - 1e3),
    [{ symbol: target.symbol, openedAt: target.openedAt }],
    target.symbol
  )).campaigns.find((row) => usdtLiveCampaignId(row) === target.campaignId);
  async function freshTarget(target) {
    const evidence = await activeCampaign(target);
    const current = (await risk(target.symbol)).find((row) => matchingLeg(row, target));
    if (!evidence || evidence.closedAt || evidence.openedAt !== target.openedAt || !current || usdtPositionDecimal(evidence.quantity) !== usdtPositionDecimal(current.quantity) || usdtMirrorRevision(current) !== target.revision)
      throw Error("\u8FD9\u7B14\u5B9E\u76D8\u4ED3\u4F4D\u5DF2\u53D8\u5316\uFF0C\u8BF7\u540C\u6B65\u540E\u91CD\u65B0\u786E\u8BA4");
    return current;
  }
  const readDetails = async (snapshot) => {
    const symbols = [...new Set(snapshot.positions.map((row) => row.symbol))];
    const details = new Map(await Promise.all(symbols.map(async (symbol2) => {
      const [orders, settings] = await Promise.allSettled([rawOrders(symbol2), request("GET", configPath, { symbol: symbol2 })]);
      return [symbol2, { orders, settings }];
    })));
    return { ...snapshot, positions: snapshot.positions.map((position) => {
      const { orders, settings } = details.get(position.symbol);
      const config = settings.status === "fulfilled" && Array.isArray(settings.value) ? settings.value.find((row) => row.symbol === position.symbol) : void 0;
      const leverage = Number(config?.leverage);
      let protectionOrders;
      let protectionIssue;
      try {
        protectionOrders = protectionRows(orders.status === "fulfilled" ? orders.value : void 0, position).map(({ clientId, ...order }) => order);
      } catch {
        protectionIssue = "\u5E01\u5B89\u6B62\u76C8\u6B62\u635F\u6682\u672A\u540C\u6B65";
      }
      return {
        ...position,
        leverage: leverage > 0 ? leverage : position.leverage,
        marginMode: config?.marginType === "ISOLATED" ? "isolated" : config?.marginType === "CROSSED" || config?.marginType === "CROSS" ? "cross" : position.marginMode,
        protectionOrders,
        protectionIssue
      };
    }) };
  };
  const save = (row) => {
    store.savePositionControl(row.id, row, row.steps.some((step) => isTrackedProtection(step) || trackedLimit(step) || step.state === "sent"));
    const leverage = row.steps.find((step) => step.path === leveragePath && isDone(step));
    if (leverage?.sentAt !== void 0)
      store.savePositionLeverage(row.target.campaignId, { leverage: Number(leverage.params.leverage), at: leverage.sentAt });
  };
  const matchedOrder = (row, step) => row?.symbol === step.params.symbol && row?.side === step.params.side && row?.positionSide === step.params.positionSide;
  const protectionMatches = (row, step) => matchedOrder(row, step) && row.clientAlgoId === step.params.clientAlgoId && (row.orderType ?? row.type) === step.params.type && Number(row.triggerPrice) === Number(step.params.triggerPrice) && row.workingType === step.params.workingType && (step.params.closePosition === "true" ? row.closePosition === true : row.closePosition !== true && Number(row.quantity) === Number(step.params.quantity) && (step.params.reduceOnly !== "true" || row.reduceOnly === true));
  async function accept(step, response) {
    if (step.path === orderPath) {
      if (!matchedOrder(response, step) || response.clientOrderId !== step.params.newClientOrderId || !positiveDecimal.test(String(response.executedQty)) || Number(response.executedQty) > Number(step.params.quantity)) return;
      step.filledQuantity = String(response.executedQty);
      if (step.params.type === "LIMIT" && ["NEW", "PARTIALLY_FILLED"].includes(response.status) && ["GTC", "GTX"].includes(step.params.timeInForce)) step.state = "done";
      if (["FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"].includes(response.status)) {
        step.state = "done";
        if (Number(step.filledQuantity) !== Number(step.params.quantity))
          step.issue = "\u5E01\u5B89\u5E73\u4ED3\u672A\u5168\u90E8\u6210\u4EA4\uFF0C\u4F59\u4ED3\u4EE5\u5B9E\u9645\u540C\u6B65\u4E3A\u51C6";
      }
    } else if (step.method === "DELETE" && numberId.test(String(response?.algoId)) && String(response.algoId) === step.params.algoId) {
      step.state = "done";
    } else if (step.path === algoPath && protectionMatches(response, step)) {
      if (response.algoStatus === "NEW") step.state = "done";
      else if (["CANCELED", "EXPIRED", "REJECTED", "TRIGGERING", "TRIGGERED", "FINISHED"].includes(response.algoStatus)) {
        step.state = "failed";
        step.issue = "\u5E01\u5B89\u672A\u786E\u8BA4\u65B0\u4FDD\u62A4\u5355\u4ECD\u5728\u6302\u5355\u4E2D";
      }
    } else if (step.path === leveragePath && response?.symbol === step.params.symbol && Number(response.leverage) === Number(step.params.leverage)) {
      step.state = "done";
    } else if (step.path === marginPath && Number(response?.code) === 200 && Number(response.amount) === Number(step.params.amount) && Number(response.type) === Number(step.params.type)) {
      step.state = "done";
    }
  }
  async function recover(step) {
    try {
      if (step.path === orderPath) {
        await accept(step, await request("GET", orderPath, { symbol: step.params.symbol, origClientOrderId: step.params.newClientOrderId }));
      } else if (step.method === "DELETE") {
        const orders = await rawOrders(step.params.symbol);
        if (Array.isArray(orders) && !orders.some((row) => String(row.algoId) === step.params.algoId)) step.state = "done";
      } else if (step.path === algoPath) {
        await accept(step, await request("GET", algoPath, { clientAlgoId: step.params.clientAlgoId }));
      } else if (step.path === marginPath && step.sentAt !== void 0) {
        const rows = await request("GET", marginPath + "/history", {
          symbol: step.params.symbol,
          type: step.params.type,
          startTime: String(step.sentAt),
          endTime: String(clock()),
          limit: "100"
        });
        if (Array.isArray(rows) && rows.some((row) => row.symbol === step.params.symbol && row.positionSide === step.params.positionSide && Number(row.type) === Number(step.params.type) && Math.abs(Number(row.amount)) === Number(step.params.amount) && Number(row.time) >= step.sentAt && Number(row.time) <= step.sentAt + 3e4)) step.state = "done";
      } else {
        const rows = await request("GET", configPath, { symbol: step.params.symbol });
        if (Array.isArray(rows)) await accept(step, rows.find((row) => row.symbol === step.params.symbol));
      }
    } catch (error) {
      if (error instanceof UsdtApiError && (error.code === -2011 || error.code === -2013) && step.sentAt !== void 0 && clock() - step.sentAt > 6e4) {
        step.state = "failed";
        step.issue = "\u5E01\u5B89\u67E5\u8BE2\u4E0D\u5230\u539F\u59D4\u6258\uFF0C\u5DF2\u7ED3\u675F\u6838\u5BF9\uFF0C\u8BF7\u786E\u8BA4\u5F53\u524D\u4ED3\u4F4D\u540E\u91CD\u65B0\u64CD\u4F5C";
      }
    }
  }
  const trackedLimit = (step) => step.path === orderPath && step.params.type === "LIMIT" && ["GTC", "GTX"].includes(step.params.timeInForce) && isDone(step) && !step.retired;
  async function execute(value) {
    const { id: id2, target, action } = parseCommand(value, clock());
    const fingerprint = JSON.stringify([target, action]);
    let row = store.getPositionControl(id2);
    if (row && row.fingerprint !== fingerprint) throw Error("\u540C\u4E00\u5B9E\u76D8\u8BF7\u6C42\u7F16\u53F7\u7684\u53C2\u6570\u4E0D\u4E00\u81F4");
    if (!row) {
      const previous = store.pendingPositionControls().filter((item) => item.target.symbol === target.symbol && item.target.positionSide === target.positionSide);
      for (const item of previous) {
        for (const step of item.steps.filter((step2) => step2.state === "sent")) await recover(step);
        save(item);
      }
      if (previous.some((item) => item.steps.some((step) => step.state === "sent"))) throw Error("\u4E0A\u4E00\u7B14\u5B9E\u76D8\u64CD\u4F5C\u7B49\u5F85\u5E01\u5B89\u56DE\u62A5");
      const position = await freshTarget(target);
      const base = { symbol: position.symbol, positionSide: position.positionSide, side: closingSide(position) };
      const reduce = position.positionSide === "BOTH" ? { reduceOnly: "true" } : {};
      const steps = [];
      if (action.kind === "cancel") {
        if (!protectionRows(await rawOrders(position.symbol), position).some((order) => order.id === action.orderId))
          throw Error("\u8FD9\u5F20\u6B62\u76C8\u6B62\u635F\u5355\u5DF2\u6210\u4EA4\u6216\u5DF2\u64A4\u9500");
        steps.push({ method: "DELETE", path: algoPath, params: { symbol: position.symbol, algoId: action.orderId } });
      } else if (action.kind === "leverage") {
        steps.push({ method: "POST", path: leveragePath, params: { symbol: position.symbol, leverage: String(action.leverage) } });
      } else if (action.kind === "margin") {
        const config = await request("GET", configPath, { symbol: position.symbol });
        if (!Array.isArray(config) || !config.some((row2) => row2.symbol === position.symbol && row2.marginType === "ISOLATED"))
          throw Error("\u53EA\u6709\u5E01\u5B89\u9010\u4ED3\u4ED3\u4F4D\u53EF\u4EE5\u8C03\u6574\u5355\u72EC\u4FDD\u8BC1\u91D1");
        steps.push({ method: "POST", path: marginPath, params: {
          symbol: position.symbol,
          positionSide: position.positionSide,
          amount: String(Math.abs(action.delta)),
          type: action.delta > 0 ? "1" : "2"
        } });
      } else {
        const market = await readMarket(position.symbol);
        if (!market) throw Error("\u65E0\u6CD5\u6838\u5BF9\u5E01\u5B89 USDT \u6C38\u7EED\u4EA4\u6613\u89C4\u683C");
        if (action.kind === "close") {
          const side = closingSide(position);
          const wire = await deskOrderParameters(
            action.order ?? { type: "market" },
            market,
            side,
            usdtOrderId(owner, target.campaignId, id2),
            Number(position.markPrice),
            () => {
              if (!readBook) throw Error("\u76D8\u53E3\u4EF7\u683C\u8BFB\u53D6\u4E0D\u53EF\u7528");
              return readBook(position.symbol, side);
            }
          );
          const spec = wire.params.type === "LIMIT" ? { ...market, marketStep: market.step } : market;
          const params = Object.fromEntries(Object.entries(wire.params).filter(([, value2]) => typeof value2 === "string"));
          steps.push({ method: "POST", path: wire.path, params: {
            ...base,
            ...reduce,
            ...params,
            quantity: quantityFor(position.quantity, action.fraction, spec)
          } });
        } else {
          const size = action.fraction === 1 ? { closePosition: "true" } : { quantity: quantityFor(position.quantity, action.fraction, market), ...reduce };
          const mark = Number(position.markPrice);
          const existing = protectionRows(await rawOrders(position.symbol), position);
          for (const [kind, value2] of [["sl", action.sl], ["tp", action.tp]]) {
            if (value2 === null) continue;
            if (!(mark > 0) || (position.direction === "long" === (kind === "tp") ? value2 <= mark : value2 >= mark))
              throw Error("\u89E6\u53D1\u4EF7\u4E0E\u5F53\u524D\u5E01\u5B89\u6807\u8BB0\u4EF7\u683C\u65B9\u5411\u4E0D\u7B26");
            if (!market.priceTick || !quantityUnits(String(value2), market.priceTick)) throw Error("\u89E6\u53D1\u4EF7\u4E0E\u5E01\u5B89\u4EF7\u683C\u6B65\u957F\u4E0D\u7B26");
            const replacementId = usdtOrderId(owner, target.campaignId, id2 + kind);
            steps.push({ method: "POST", path: algoPath, params: {
              ...base,
              ...size,
              algoType: "CONDITIONAL",
              type: kind === "tp" ? "TAKE_PROFIT_MARKET" : "STOP_MARKET",
              workingType: "MARK_PRICE",
              triggerPrice: String(value2),
              clientAlgoId: replacementId
            } });
            for (const order of existing.filter((order2) => order2.kind === kind)) {
              steps.push({ method: "DELETE", path: algoPath, replacementId, params: { symbol: position.symbol, algoId: order.id } });
            }
          }
        }
      }
      row = { id: id2, target, fingerprint, steps };
      save(row);
    }
    await advance(row, action.kind === "protect");
    const pending = row.steps.some((step) => step.state === "sent");
    const filledQuantity = row.steps.find((step) => step.path === orderPath)?.filledQuantity;
    let issue = row.steps.find((step) => step.issue)?.issue;
    if (action.kind === "close" && !pending && Number(filledQuantity) > 0) {
      try {
        await cleanup(target.symbol);
      } catch {
        issue ||= "\u5E73\u4ED3\u6210\u4EA4\u5DF2\u6536\u5230\uFF0C\u539F\u4ED3\u4F4D\u7684\u6761\u4EF6\u5355\u7B49\u5F85\u6838\u5BF9";
      }
    }
    return { pending, issue, filledQuantity: Number(filledQuantity) > 0 ? filledQuantity : void 0 };
  }
  async function advance(row, protecting, onlyReplacement = false) {
    for (const step of row.steps) {
      if (step.state === "failed") break;
      if (step.state === "done") continue;
      if (step.state === "sent") {
        if (onlyReplacement) break;
        await recover(step);
      } else {
        if (onlyReplacement && !step.replacementId) break;
        try {
          if (protecting && step.method === "DELETE" && !step.replacementId) throw Error("\u65E7\u7248\u66FF\u6362\u8BF7\u6C42\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u786E\u8BA4\u6B62\u76C8\u6B62\u635F");
          await freshTarget(row.target);
          if (step.replacementId) {
            const replacement = row.steps.find((candidate) => candidate.params.clientAlgoId === step.replacementId);
            const orders = await rawOrders(row.target.symbol);
            if (!Array.isArray(orders) || !replacement || !isDone(replacement) || !orders.some((order) => order.algoStatus === "NEW" && protectionMatches(order, replacement))) {
              throw Error("\u5E01\u5B89\u672A\u786E\u8BA4\u65B0\u4FDD\u62A4\u5355\uFF0C\u672A\u53D1\u9001\u65E7\u5355\u64A4\u9500\u8BF7\u6C42");
            }
            if (!orders.some((order) => String(order.algoId) === step.params.algoId)) {
              step.state = "done";
              save(row);
              continue;
            }
          }
        } catch (error) {
          step.state = "failed";
          step.issue = error instanceof Error ? error.message : "\u65E0\u6CD5\u6838\u5BF9\u5F53\u524D\u5B9E\u76D8\u4ED3\u4F4D";
          save(row);
          break;
        }
        step.state = "sent";
        step.sentAt = clock();
        save(row);
        try {
          const params = step.method === "DELETE" ? { algoId: step.params.algoId } : step.params;
          await accept(step, await request(step.method, step.path, params));
        } catch (error) {
          if (definitelyRejected(error)) {
            step.state = "failed";
            step.issue = error instanceof Error ? error.message : "\u5E01\u5B89\u62D2\u7EDD\u5B9E\u76D8\u59D4\u6258";
          } else await recover(step);
        }
        invalidate();
      }
      save(row);
      if (!isDone(step)) break;
    }
  }
  async function cleanup(symbol2) {
    const rows = store.pendingPositionControls();
    for (const row of rows) {
      if (symbol2 && row.target.symbol !== symbol2) continue;
      const awaiting = row.steps.filter((step) => step.state === "sent");
      for (const step of awaiting) await recover(step);
      if (row.steps.some((step) => step.replacementId && !step.state)) await advance(row, true, true);
      const linked = row.steps.filter((step) => isTrackedProtection(step) && step.state === "done");
      const limits = row.steps.filter(trackedLimit);
      if (limits.length) {
        const orders = await request("GET", "/fapi/v1/openOrders", { symbol: row.target.symbol });
        if (!Array.isArray(orders)) throw Error("\u5E01\u5B89\u9650\u4EF7\u6302\u5355\u6682\u4E0D\u53EF\u8BFB");
        const active = limits.filter((step) => orders.some((order) => order.clientOrderId === step.params.newClientOrderId));
        for (const step of limits.filter((step2) => !active.includes(step2))) step.retired = true;
        if (active.length && (await activeCampaign(row.target))?.closedAt) {
          for (const step of active) {
            const order = orders.find((order2) => order2.clientOrderId === step.params.newClientOrderId);
            if (!matchedOrder(order, step)) continue;
            const canceled = await request("DELETE", orderPath, { symbol: row.target.symbol, origClientOrderId: step.params.newClientOrderId });
            if (canceled?.status === "CANCELED" && canceled.clientOrderId === step.params.newClientOrderId) step.retired = true;
          }
        }
      }
      if (linked.length) {
        const active = await rawOrders(row.target.symbol);
        if (!Array.isArray(active)) continue;
        const present = linked.filter((step) => active.some((order) => order.clientAlgoId === step.params.clientAlgoId));
        for (const step of linked.filter((step2) => !present.includes(step2))) step.retired = true;
        if (present.length) {
          const position = (await risk(row.target.symbol)).find((item) => matchingLeg(item, row.target));
          const revision = position && usdtMirrorRevision(position);
          if (symbol2 || !revision || revision !== (row.checkedRevision ?? row.target.revision)) {
            const campaign = await activeCampaign(row.target);
            if (campaign?.closedAt) {
              for (const step of present) {
                if (!active.some((order) => protectionMatches(order, step))) continue;
                const result = await request("DELETE", algoPath, { clientAlgoId: step.params.clientAlgoId });
                if (result?.clientAlgoId === step.params.clientAlgoId && String(result.code) === "200") {
                  step.retired = true;
                  save(row);
                }
              }
              invalidate();
            } else if (campaign && revision) row.checkedRevision = revision;
          }
        }
      }
      save(row);
    }
  }
  async function beforeOpening(symbol2) {
    await cleanup(symbol2);
    if (store.pendingPositionControls().some((row) => row.target.symbol === symbol2 && row.steps.some((step) => isTrackedProtection(step) || trackedLimit(step) || step.path === orderPath && step.state === "sent")))
      throw Error("\u539F\u5B9E\u76D8\u4ED3\u4F4D\u7684\u5E73\u4ED3\u6216\u4FDD\u62A4\u59D4\u6258\u5F85\u6838\u5BF9\uFF0C\u6682\u7F13\u65B0\u5F00\u4ED3");
  }
  const protectionIds = (symbol2, campaignId) => store.pendingPositionControls().flatMap((row) => row.target.symbol === symbol2 && row.target.campaignId === campaignId ? row.steps.filter((step) => isTrackedProtection(step) && step.state === "done").map((step) => step.params.clientAlgoId) : []);
  return { execute, cleanup, beforeOpening, readDetails, protectionIds, hasPending: () => store.pendingPositionControls().length > 0 };
}

// scripts/usdt-follow-server.ts
var origin = "https://veil-of-ignorance-ten.vercel.app";
var dashPort = 47321;
var bodyLimit = 8e6;
function parseCampaigns(value, now) {
  if (!Array.isArray(value) || value.length > 250) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
  const campaigns = /* @__PURE__ */ new Set();
  const safeTime = (at) => Number.isSafeInteger(at) && at > 0 && at <= now + 1e4;
  const validPositive = (n) => Number.isFinite(n) && n > 0;
  for (const row of value) {
    if (!row || !/^fish-instant-[\w-]{3,80}$/.test(row.id ?? "") || campaigns.has(row.id) || typeof row.source?.symbol !== "string" || !/^[A-Za-z0-9_/.:-]{1,35}$/.test(row.source.symbol) || row.source.exchange != null && typeof row.source.exchange !== "string" || row.source.market != null && typeof row.source.market !== "string" || !safeTime(row.admittedAt) || !validPositive(row.notional) || !Number.isInteger(row.leverage) || row.leverage < 1 || row.leverage > 125 || row.liveEntry !== void 0 && !validUsdtLiveEntry(row) || !Array.isArray(row.actions) || row.actions.length < 1 || row.actions.length > 250 || row.actions[0]?.id !== "open" || row.actions[0].action !== "open") throw Error("\u5373\u65F6\u4EA4\u6613\u6218\u5F79\u683C\u5F0F\u65E0\u6548");
    if (row.liveEntry?.confirmedAt !== void 0 && row.actions[0].at !== row.liveEntry.confirmedAt)
      throw Error("\u5B9E\u76D8\u9996\u4ED3\u52A8\u4F5C\u4E0E\u9996\u6B21\u5165\u9009\u786E\u8BA4\u65F6\u95F4\u4E0D\u4E00\u81F4");
    const ids = /* @__PURE__ */ new Set();
    for (const [index, action] of row.actions.entries()) {
      if (!action || ids.has(action.id) || !safeTime(action.at) || index > 0 && row.actions[index - 1].at > action.at) throw Error("\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u987A\u5E8F\u65E0\u6548");
      const actionValid = action.action === "open" ? index === 0 && action.id === "open" : action.action === "close" ? /^(close|mirror|manual-[1-9]\d*)$/.test(action.id) : action.action === "add" ? validPositive(action.notional) && (action.impulseFreshUntil === void 0 ? /^add-[1-9]\d*$/.test(action.id) : row.requiresGuardPlus === true && /^add-impulse-[a-f0-9]{32}$/.test(action.id) && action.at % 3e5 === 0 && action.impulseFreshUntil === action.at + 3e5) : action.action === "mirror" ? action.id === "mirror" && validPositive(action.fraction) && action.fraction < 1 : action.action === "support-reduction" ? /^support-[1-9]\d*$/.test(action.id) && validPositive(action.fraction) && action.fraction < 1 : action.action === "manual-reduction" && /^manual-[1-9]\d*$/.test(action.id) && validPositive(action.fraction) && action.fraction < 1;
      if (!actionValid) throw Error("\u5373\u65F6\u4EA4\u6613\u52A8\u4F5C\u53C2\u6570\u65E0\u6548");
      ids.add(action.id);
    }
    campaigns.add(row.id);
  }
  return value;
}
async function jsonBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    if ((size += chunk.length) > bodyLimit) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u8D85\u8FC7\u5927\u5C0F\u9650\u5236");
    chunks.push(chunk);
  }
  const request = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  if (!request || typeof request !== "object" || Array.isArray(request)) throw Error("\u5373\u65F6\u4EA4\u6613\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
  return request;
}
var digest = (value) => createHash7("sha256").update(value).digest();
var json = (res, status, data) => {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
};
function manualAnchor(value, now) {
  if (!value || !/^[A-Z0-9]{2,24}USDT$/.test(value.symbol) || value.positionSide !== "LONG" && value.positionSide !== "BOTH" || !Number.isSafeInteger(value.openedAt) || value.openedAt <= 0 || value.openedAt > now + 1e3 || typeof value.openingTradeId !== "string" || !/^\d{1,25}$/.test(value.openingTradeId) || typeof value.openingOrderId !== "string" || !/^\d{1,25}$/.test(value.openingOrderId)) throw Error("\u5E01\u5B89\u9996\u4ED3\u8EAB\u4EFD\u65E0\u6548");
  return {
    symbol: value.symbol,
    positionSide: value.positionSide,
    openedAt: value.openedAt,
    openingTradeId: value.openingTradeId,
    openingOrderId: value.openingOrderId
  };
}
function manualMonitor(value) {
  if (!value || value.version !== "instant-template-monitor-v1" || typeof value.templateId !== "string" || typeof value.name !== "string" || value.name.length > 200 || typeof value.plan?.id !== "string" || !Array.isArray(value.plan.frozenVersions) || !value.plan.frozenVersions.length || value.plan.preEntryThreeStage || value.plan.preEntryConditions) throw Error("\u624B\u52A8\u4ED3\u4F4D\u9700\u8981\u5DF2\u4FDD\u5B58\u4E14\u7248\u672C\u53EF\u6838\u9A8C\u7684\u4E70\u540E\u7B56\u7565");
  return value;
}
function serveUsdtFollower({
  owner,
  token,
  exchange,
  store,
  mode,
  startedAt,
  positionReader,
  campaignReader,
  managedClock,
  positionRequest,
  allowedOrigin = origin,
  port = dashPort,
  statusFile,
  handoff
}) {
  const readManaged = campaignReader && managedClock ? async (anchor) => {
    const from = Math.max(1, anchor.openedAt - 1e3);
    const result = await campaignReader(from, [{ symbol: anchor.symbol, openedAt: anchor.openedAt }], anchor.symbol);
    const actual = result.campaigns.find((campaign) => matchesManualAnchor(anchor, campaign));
    if (!actual) throw Error("\u5E01\u5B89\u672A\u8FD4\u56DE\u8FD9\u4E00\u7B14\u4ED3\u4F4D\u7684\u5B8C\u6574\u6210\u4EA4");
    return actual;
  } : void 0;
  const controls = positionRequest && positionReader && campaignReader ? createUsdtPositionControls(positionRequest, store, owner, exchange.market, campaignReader, positionReader.invalidate, managedClock, exchange.book) : void 0;
  const follower = createUsdtFollower(
    store,
    exchange,
    owner,
    mode,
    startedAt,
    readManaged,
    managedClock,
    controls?.protectionIds,
    controls ? positionReader?.positions : void 0,
    controls
  );
  const desk = controls && positionRequest && createUsdtOrderDesk(positionRequest, exchange, store, owner, mode, async (symbol2) => {
    if (follower.statuses().some((row) => (row.market ?? row.symbol) === symbol2 && !["closed", "ignored"].includes(row.state)))
      throw Error("\u8BE5\u5408\u7EA6\u5B58\u5728\u7B56\u7565\u8DDF\u968F\u7684\u4ED3\u4F4D\u6216\u5F85\u6838\u5BF9\u59D4\u6258\uFF0C\u8BF7\u5148\u5904\u7406\u539F\u4ED3\u4F4D");
    await controls.beforeOpening(symbol2);
  }, managedClock);
  void handoff?.begin(follower);
  const tokenDigest = digest(token);
  const snapshot = () => ({
    connected: true,
    paused: follower.paused,
    startedAt: follower.entryAfter,
    statuses: follower.statuses(),
    guardPlusAdditions: 1,
    executionSafety: USDT_EXECUTION_SAFETY,
    controlRevision: store.controlRevision(),
    ...positionReader ? { positionMirror: 1 } : {},
    ...campaignReader ? { campaignMirror: 1 } : {},
    ...readManaged ? { manualMonitor: 1, monitorSwitch: 1, marginRejectExit: 1, atrRejectExit: 1 } : {},
    ...controls ? { positionControls: 1 } : {},
    ...readManaged && controls ? { followMonitorSwitch: USDT_FOLLOW_MONITOR_BASIS } : {},
    ...desk ? { orderDesk: 1 } : {},
    ...handoff ? { handoff: handoff.describe() } : {}
  });
  const server = createServer({ maxHeaderSize: 4e3, requestTimeout: 1e4, headersTimeout: 6e3 }, (req, res) => {
    const work = async () => {
      if (req.headers.origin !== allowedOrigin || req.headers.host !== "127.0.0.1:" + server.address().port || req.url !== "/api/usdt-follow" && req.url !== USDT_EXECUTION_PATH) {
        json(res, 403, { error: "\u672C\u673A\u6267\u884C\u7AEF\u53EA\u63A5\u53D7\u914D\u5BF9\u9875\u9762" });
        return;
      }
      res.setHeader("Access-Control-Allow-Origin", allowedOrigin);
      res.setHeader("Vary", "Origin");
      if (req.method === "OPTIONS") {
        res.writeHead(204, {
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Allow-Private-Network": "true"
        }).end();
        return;
      }
      if (req.method !== "POST" || !req.headers["content-type"]?.startsWith("application/json") || !timingSafeEqual(tokenDigest, digest(req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.slice(7) : ""))) {
        json(res, 401, { error: "\u672C\u673A\u914D\u5BF9\u7801\u65E0\u6548" });
        return;
      }
      const content = await jsonBody(req);
      if (content.owner !== owner) return json(res, 403, { error: "\u672C\u673A\u6267\u884C\u7AEF\u7ED1\u5B9A\u4E86\u53E6\u4E00\u4E2A\u65E0\u77E5\u4E4B\u5E55\u8D26\u53F7" });
      if (content.command === "status") return json(res, 200, snapshot());
      if (handoff && ["handoff-freeze", "handoff-export", "handoff-resume", "handoff-cancellation", "handoff-initialize", "handoff-request"].includes(content.command))
        return json(res, 200, await handoff.command(content, follower));
      if (content.command === "handoff-monitor-state") return json(res, 200, {
        epoch: handoff?.describe().epoch,
        handoff: handoff?.describe(),
        campaigns: store.readAll().filter((row) => !row.managed && !["closed", "ignored"].includes(row.status.state) && store.local("imported-monitor:" + row.campaign.id)).map((row) => ({
          campaign: row.campaign,
          revision: store.local("monitor-revision:" + row.campaign.id) ?? 0
        }))
      });
      if (handoff && content.command === "sync" && handoff.capturable()) {
        follower.captureFrozenMonitors(parseCampaigns(content.campaigns, Date.now()));
        return json(res, 200, snapshot());
      }
      const readCommands = ["positions", "position-history", "position-campaigns", "manual-monitor-status", "desk-info"];
      if (handoff && !readCommands.includes(content.command)) handoff.assertWritable();
      if (content.command === "handoff-monitor-update") {
        const entries = parseCampaigns([content.campaign], Date.now()), id2 = entries[0].id;
        if (content.epoch !== handoff?.describe().epoch || content.revision !== (store.local("monitor-revision:" + id2) ?? 0))
          throw Error("\u63A5\u7BA1\u76D1\u6D4B\u72B6\u6001\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6");
        follower.updateRecovered(entries[0]);
        store.setLocal("monitor-revision:" + id2, content.revision + 1);
        return json(res, 200, { ok: true });
      }
      if (req.url === USDT_EXECUTION_PATH && desk) {
        if (content.command === "desk-info") return json(res, 200, await desk.info(content.symbol));
        if (content.command === "desk-open")
          return json(res, 200, await follower.runPositionControl(() => desk.execute(content.request)));
        if (content.command === "desk-close" && content.request?.action?.kind === "close" && content.request.action.order)
          return json(res, 200, await follower.runPositionControl(() => controls.execute(content.request)));
      }
      if (content.command === "position-control") {
        if (!controls) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u64CD\u4F5C\u5E01\u5B89\u5B9E\u76D8\u4ED3\u4F4D" });
        return json(res, 200, await follower.runPositionControl(() => controls.execute(content.request)));
      }
      if (readManaged && managedClock) {
        if (content.command === "manual-monitor-status") {
          return json(res, 200, { observedAt: managedClock(), positions: follower.managed(content.followBasisVersion === USDT_FOLLOW_MONITOR_BASIS).filter(({ position }) => (!position.monitor.plan.addition?.marginRejectExit || content.marginRejectExit === 1) && (!position.monitor.plan.addition?.atrRejectExit || content.atrRejectExit === 1)) });
        }
        if (content.command === "manual-monitor-adopt") {
          if (content.confirmed !== true || content.controlRevision !== store.controlRevision())
            throw Error("\u8BF7\u6309\u5F53\u524D\u5B9E\u76D8\u72B6\u6001\u9010\u7B14\u786E\u8BA4\u7B56\u7565\u6258\u7BA1");
          const position = await follower.runPositionControl(() => follower.adopt(manualAnchor(content.anchor, managedClock()), manualMonitor(content.monitor), content.controlRevision));
          return json(res, 200, { position });
        }
        if (content.command === "manual-monitor-switch" && req.url === USDT_EXECUTION_PATH) {
          if (content.confirmed !== true || typeof content.id !== "string" || !Number.isSafeInteger(content.planEpoch) || content.planEpoch < 0)
            throw Error("\u8BF7\u9010\u7B14\u786E\u8BA4\u5B9E\u76D8\u6301\u4ED3\u65B9\u6848\u5207\u6362");
          const position = await follower.runPositionControl(() => follower.switchManaged(content.id, content.planEpoch, manualMonitor(content.monitor)));
          return json(res, 200, { position });
        }
        if (content.command === "manual-monitor-update") {
          if (typeof content.id !== "string" || !Number.isSafeInteger(content.revision) || !content.checkpoint) throw Error("\u624B\u52A8\u6258\u7BA1\u8FDB\u5EA6\u65E0\u6548");
          follower.updateManaged(content.id, content.revision, content.checkpoint, content.decision, content.planEpoch, content.followBasisVersion);
          json(res, 200, { ok: true });
          void follower.tick();
          return;
        }
        if (content.command === "follow-monitor-switch" && controls && req.url === USDT_EXECUTION_PATH) {
          if (content.confirmed !== true || content.followBasisVersion !== USDT_FOLLOW_MONITOR_BASIS || typeof content.id !== "string" || !Number.isSafeInteger(content.planEpoch) || content.planEpoch < 0) throw Error("\u8BF7\u9010\u7B14\u786E\u8BA4\u8DDF\u5355\u6301\u4ED3\u7684\u65B0\u65B9\u6848");
          const anchor = manualAnchor(content.anchor, managedClock());
          const monitor = manualMonitor(content.monitor);
          const original = content.original && manualMonitor(content.original);
          const position = await follower.runPositionControl(() => follower.switchFollowMonitor(
            content.id,
            anchor,
            content.planEpoch,
            monitor,
            original,
            content.followSample
          ));
          return json(res, 200, { position });
        }
      }
      if (content.command === "position-campaigns") {
        if (!campaignReader) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u540C\u6B65\u5B9E\u76D8\u6218\u5F79" });
        const result = await campaignReader(content.since, content.open);
        const statuses = follower.statuses();
        return json(res, 200, { ...result, campaigns: result.campaigns.map((campaign) => {
          const follow = findUsdtCampaignFollow(campaign, statuses);
          const liveId = usdtLiveCampaignId(campaign);
          const management = follower.managedArchive(follow?.id ?? liveId);
          return { ...campaign, ...management ? { management } : {}, ...follow && follow.id !== liveId ? { followId: follow.id } : {} };
        }) });
      }
      if (content.command === "positions" || content.command === "position-history") {
        if (!positionReader) return json(res, 501, { error: "\u8BF7\u66F4\u65B0 Windows \u672C\u673A\u6267\u884C\u7AEF\u4EE5\u540C\u6B65\u5E01\u5B89\u6301\u4ED3" });
        if (content.command === "positions") {
          const state2 = await positionReader.positions();
          return json(res, 200, content.withDetails === true && controls ? await controls.readDetails(state2) : state2);
        }
        const state = await positionReader.history(content.symbol, content.positionSide, content.revision);
        return json(res, 200, state);
      }
      if (content.command !== "sync" && content.command !== "pause" && content.command !== "resume") throw Error("\u672A\u77E5\u7684\u5B9E\u76D8\u6307\u4EE4");
      const campaigns = parseCampaigns(content.campaigns, Date.now());
      if (content.command !== "sync") {
        const legacyPause = content.command === "pause" && content.controlRevision === void 0;
        if (!legacyPause && campaigns.length || content.command === "resume" && content.controlRevision !== store.controlRevision()) {
          return json(res, 409, { ...snapshot(), staleControl: true, error: "\u5B9E\u76D8\u8DDF\u968F\u72B6\u6001\u5DF2\u53D8\u5316\uFF0C\u8BF7\u6838\u5BF9\u540E\u91CD\u65B0\u64CD\u4F5C" });
        }
        if (content.command === "pause") follower.pauseNewOrders();
        else follower.resumeNewOrders();
      } else follower.ingest(campaigns);
      json(res, 200, snapshot());
      void follower.tick();
    };
    void work().catch((error) => {
      if (!res.headersSent) json(res, 400, { error: error instanceof SyntaxError ? "\u672C\u673A\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548" : error instanceof Error ? error.message : "\u672C\u673A\u6267\u884C\u7AEF\u62D2\u7EDD\u8BF7\u6C42" });
    });
  });
  let nextCleanup = 0;
  const timer = setInterval(() => {
    if (controls && Date.now() >= nextCleanup) {
      nextCleanup = Date.now() + 1e4;
      if (controls.hasPending()) void follower.runPositionControl(controls.cleanup).catch(() => void 0);
    }
    void follower.tick();
    if (statusFile) {
      try {
        writeFileSync2(statusFile, JSON.stringify(snapshot()), { mode: 384 });
      } catch {
      }
    }
  }, 1e3);
  server.once("close", () => clearInterval(timer));
  server.listen(port, "127.0.0.1");
  return Object.assign(server, { follower });
}
async function main() {
  const directory = process.argv[2];
  if (!directory) throw Error("\u8BF7\u6307\u5B9A\u4FDD\u5B58\u5E01\u5B89\u51ED\u8BC1\u7684\u672C\u673A\u76EE\u5F55");
  const live = process.argv.includes("--live");
  const setup = process.argv.includes("--prepare");
  const credentials = loadUsdtCredentials(directory);
  let authorizeWrite = () => {
    throw Error("\u6267\u884C\u6743\u5C1A\u672A\u6838\u9A8C\uFF0C\u7981\u6B62\u4EA4\u6613");
  };
  const request = createUsdtRequest(credentials, fetch, () => authorizeWrite());
  const exchange = createUsdtExchange(request);
  let verified;
  try {
    verified = await exchange.account();
  } catch (error) {
    credentials.secret.fill(0);
    if (error instanceof TypeError) throw Error("\u672C\u673A\u7F51\u7EDC\u65E0\u6CD5\u8BBF\u95EE\u5E01\u5B89 U \u672C\u4F4D\u8D26\u6237\u63A5\u53E3");
    throw error;
  }
  if (setup) {
    const account = createHash7("sha256").update(verified.id).digest("hex");
    credentials.secret.fill(0);
    console.log(JSON.stringify({ connected: true, market: "USDT-M", mode: verified.mode, account }));
    return;
  }
  if (!live) {
    credentials.secret.fill(0);
    console.log(JSON.stringify({ connected: true, market: "USDT-M", mode: verified.mode }));
    return;
  }
  const config = readUsdtConfig(directory);
  if (config.account !== createHash7("sha256").update(verified.id).digest("hex")) throw Error("\u672C\u673A\u914D\u5BF9\u8D26\u6237\u4E0D\u7B26");
  const unlock = lockUsdtDirectory(directory);
  const store = openUsdtFollowStore(join3(directory, "usdt-follow.sqlite"), verified.id, config.owner);
  const handoff = createUsdtHandoffService(store, verified.id, config.owner, usdtRuntime(), exchange, request);
  authorizeWrite = handoff.assertWritable;
  process.once("exit", () => {
    try {
      store.close();
    } finally {
      unlock();
      credentials.secret.fill(0);
    }
  });
  const clockStart = performance.now();
  const clockReply = await fetch("https://fapi.binance.com/fapi/v1/time", { redirect: "error", signal: AbortSignal.timeout(1e4) });
  const { serverTime } = await clockReply.json();
  if (!clockReply.ok || !Number.isSafeInteger(serverTime) || serverTime <= 0) throw Error("\u5E01\u5B89\u670D\u52A1\u5668\u65F6\u95F4\u6682\u4E0D\u53EF\u7528");
  const clockMidpoint = (clockStart + performance.now()) / 2;
  const managedClock = () => Math.round(serverTime + performance.now() - clockMidpoint);
  const server = serveUsdtFollower({
    owner: config.owner,
    token: config.token,
    exchange,
    store,
    mode: verified.mode,
    managedClock,
    startedAt: Date.now(),
    positionReader: createUsdtPositionReader(request, managedClock),
    campaignReader: createUsdtCampaignReader(request, managedClock),
    positionRequest: request,
    handoff,
    statusFile: join3(directory, "usdt-follow-status.json")
  });
  server.once("listening", () => console.log("\u672C\u673A\u63A5\u53E3\u5DF2\u5C31\u7EEA\uFF1B\u4EE5\u4EA4\u63A5\u72B6\u6001\u53CA\u672C\u6B21\u8D26\u6237\u5BF9\u8D26\u7ED3\u679C\u51B3\u5B9A\u662F\u5426\u5141\u8BB8\u6267\u884C\u3002"));
  for (const signal of ["SIGINT", "SIGTERM"]) process.once(signal, () => {
    void handoff.stop(server.follower).then(() => server.close(() => process.exit(0)));
  });
  server.once("error", () => {
    console.error("\u672C\u673A\u6267\u884C\u7AEF\u7AEF\u53E3\u4E0D\u53EF\u7528");
    process.exit(1);
  });
}
if (process.argv[1] && /usdt-follow-server\.(?:mjs|ts)$/.test(process.argv[1])) {
  void main().catch((error) => {
    console.error(error instanceof Error && !error.stack?.includes("readFileSync") ? error.message : "\u672C\u673A\u6267\u884C\u7AEF\u65E0\u6CD5\u542F\u52A8");
    process.exitCode = 1;
  });
}
export {
  serveUsdtFollower
};
/*! Bundled license information:

decimal.js-light/decimal.js:
  (*! decimal.js-light v2.5.1 https://github.com/MikeMcl/decimal.js-light/LICENCE *)
*/
