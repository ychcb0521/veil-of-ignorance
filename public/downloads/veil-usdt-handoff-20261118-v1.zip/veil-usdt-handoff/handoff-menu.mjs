// scripts/usdt-handoff-menu.ts
import { spawnSync } from "node:child_process";
import { createInterface } from "node:readline/promises";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { existsSync } from "node:fs";
var folder = dirname(fileURLToPath(import.meta.url));
var mac = process.platform === "darwin";
var prompt = createInterface({ input: process.stdin, output: process.stdout });
var ask = async (label) => (await prompt.question(label)).trim().replace(/^"(.*)"$/, "$1");
var preload = pathToFileURL(join(folder, mac ? "macos-preload.mjs" : "windows-preload.mjs")).href;
var directory = mac ? join(homedir(), "Library", "Application Support", "VeilUSDTExecutor") : resolve(process.argv[2] || await ask("\u73B0\u6709 Windows \u8D26\u6237\u76EE\u5F55\uFF08\u4FDD\u7559\u539F\u76EE\u5F55\uFF0C\u4E0D\u642C\u5BC6\u94A5\uFF09\uFF1A"));
function run(entry, ...args) {
  const result = spawnSync(process.execPath, [...entry === "macos-setup.mjs" ? [] : ["--import", preload], join(folder, entry), ...args], { stdio: "inherit", windowsHide: false });
  if (result.error || result.status !== 0) console.log("\u64CD\u4F5C\u672A\u5B8C\u6210\u3002\u6267\u884C\u6743\u4FDD\u62A4\u4FDD\u7559\uFF0C\u8BF7\u6309\u6062\u590D\u8BF4\u660E\u6838\u5BF9\u3002");
}
async function main() {
  for (; ; ) {
    console.log("\n\u65E0\u77E5\u4E4B\u5E55 \xB7 Windows / Mac \u8F6E\u6D41\u63A5\u7BA1");
    console.log("\u4EFB\u4F55\u65B0\u7AEF\u5FC5\u987B\u5BFC\u5165\u4EA4\u63A5\u5305\u5E76\u91CD\u65B0\u5BF9\u8D26\uFF1B\u542F\u52A8\u63A5\u53E3\u672C\u8EAB\u4E0D\u4F1A\u83B7\u5F97\u6267\u884C\u6743\u3002");
    console.log("1 " + (mac ? "\u9996\u6B21\u914D\u7F6E Mac \u672C\u673A\u51ED\u8BC1\uFF08\u53EA\u8BFB\u9274\u6743\uFF09" : "\u9996\u6B21\u5347\u7EA7 Windows \u539F\u7AEF\uFF08\u505C\u6B62\u65E7\u4EFB\u52A1\uFF0C\u5B89\u88C5\u4EA4\u63A5\u4FDD\u62A4\uFF09"));
    console.log("2 \u542F\u52A8\u672C\u673A\u63A5\u53E3\uFF08" + (mac ? "\u4FDD\u6301\u6B64\u7A97\u53E3\u53CA\u672C\u673A\u7F51\u9875\u6253\u5F00" : "\u4F7F\u7528\u73B0\u6709\u8BA1\u5212\u4EFB\u52A1\u5728\u540E\u53F0\u8FD0\u884C") + "\uFF09");
    console.log("3 \u67E5\u770B\u672C\u673A\u63A5\u53E3\u4E0E\u4EA4\u63A5\u72B6\u6001");
    console.log("4 \u65B0\u7AEF\uFF1A\u751F\u6210\u63A5\u7BA1\u8BF7\u6C42\u6587\u4EF6");
    console.log("5 \u65E7\u7AEF\uFF1A\u51BB\u7ED3\u5E76\u5BFC\u51FA\u7ED9\u6307\u5B9A\u65B0\u7AEF");
    console.log("6 \u65B0\u7AEF\uFF1A\u5BFC\u5165\u4EA4\u63A5\u5305\uFF08\u4FDD\u6301\u53EA\u8BFB\uFF09");
    console.log("7 \u65B0\u7AEF\uFF1A\u5411\u5E01\u5B89\u6838\u5BF9\u8D26\u6237\u3001\u4F59\u4ED3\u3001\u6302\u5355\u548C\u6210\u4EA4");
    console.log("8 \u65B0\u7AEF\uFF1A\u518D\u6B21\u5BF9\u8D26\u5E76\u5141\u8BB8\u6267\u884C");
    console.log("9 \u539F\u7AEF\u9996\u6B21\u5347\u7EA7\uFF1A\u7F51\u9875\u540C\u6B65\u540E\u5EFA\u7ACB\u6267\u884C\u6743");
    console.log("R \u5931\u8D25\u6062\u590D / \u4F5C\u5E9F\u4EA4\u63A5 / \u6062\u590D\u51BB\u7ED3\u539F\u7AEF");
    if (!mac) console.log("S \u51BB\u7ED3\u5E76\u505C\u6B62 Windows \u540E\u53F0\u4EFB\u52A1\uFF08\u5173\u95ED\u81EA\u52A8\u91CD\u8BD5\uFF09");
    console.log("0 \u9000\u51FA");
    const choice = (await ask("\u8BF7\u9009\u62E9\uFF1A")).toUpperCase();
    if (choice === "0") return;
    if (choice === "1") {
      if (mac) {
        if (existsSync(join(directory, "usdt-follow.json"))) run("handoff.mjs", "prepare-account", directory);
        else run("macos-setup.mjs");
      } else if (await ask("\u6B64\u64CD\u4F5C\u4F1A\u505C\u6B62\u73B0\u6709 Windows \u5B9E\u76D8\u5E76\u5173\u95ED\u65E7\u81EA\u52A8\u91CD\u8BD5\u3002\u786E\u8BA4\u5347\u7EA7\u8BF7\u8F93\u5165\u201C\u505C\u6B62\u65E7\u7AEF\u201D\uFF1A") === "\u505C\u6B62\u65E7\u7AEF")
        run("handoff.mjs", "upgrade-windows", directory);
    } else if (choice === "2") {
      console.log("\u82E5\u5C1A\u672A\u53D6\u5F97\u6267\u884C\u6743\uFF0C\u63A5\u53E3\u53EA\u8BFB\uFF1B\u5DF2\u6709\u6267\u884C\u6743\u4E5F\u5FC5\u987B\u901A\u8FC7\u672C\u6B21\u542F\u52A8\u5BF9\u8D26\u3002\u505C\u6B62\u8BF7\u6309 Ctrl+C\u3002");
      if (mac) run("usdt-follow-server.mjs", directory, "--live");
      else run("handoff.mjs", "start-windows", directory);
    } else if (choice === "3") run("handoff.mjs", "status", directory);
    else if (choice === "4") run("handoff.mjs", "receive", directory, await ask("\u63A5\u7BA1\u8BF7\u6C42\u4FDD\u5B58\u5230\u54EA\u4E2A\u5168\u65B0\u6587\u4EF6\uFF1A"));
    else if (choice === "5") {
      const request = await ask("\u65B0\u7AEF\u63A5\u7BA1\u8BF7\u6C42\u6587\u4EF6\u8DEF\u5F84\uFF1A"), out = await ask("\u4EA4\u63A5\u5305\u4FDD\u5B58\u5230\u54EA\u4E2A\u5168\u65B0\u6587\u4EF6\uFF1A");
      if (await ask("\u65E7\u7AEF\u4F1A\u7ACB\u5373\u505C\u6B62\u6240\u6709\u8D26\u6237\u5199\u64CD\u4F5C\uFF1B\u5BFC\u51FA\u540E\u4FDD\u6301\u9501\u5B9A\u3002\u786E\u8BA4\u8BF7\u8F93\u5165\u201C\u4EA4\u51FA\u6267\u884C\u6743\u201D\uFF1A") === "\u4EA4\u51FA\u6267\u884C\u6743")
        run("handoff.mjs", "export", directory, request, out);
    } else if (choice === "6") run("handoff.mjs", "import", directory, await ask("\u65E7\u7AEF\u4EA4\u63A5\u5305\u6587\u4EF6\u8DEF\u5F84\uFF1A"));
    else if (choice === "7") run("handoff.mjs", "reconcile", directory);
    else if (choice === "8") {
      if (await ask("\u53EA\u5141\u8BB8\u5DF2\u6536\u5230\u4EA4\u63A5\u5305\u7684\u65B0\u7AEF\u7EE7\u7EED\u3002\u786E\u8BA4\u8BF7\u8F93\u5165\u201C\u672C\u7AEF\u63A5\u7BA1\u201D\uFF1A") === "\u672C\u7AEF\u63A5\u7BA1") run("handoff.mjs", "activate", directory);
    } else if (choice === "9") {
      if (mac) {
        console.log("\u9996\u6B21\u6267\u884C\u6743\u53EA\u80FD\u7531\u73B0\u6709 Windows \u539F\u7AEF\u5EFA\u7ACB\u3002");
        continue;
      }
      if (await ask("\u8BF7\u786E\u8BA4\u65E7\u4EFB\u52A1\u5DF2\u505C\u3001\u5F53\u524D\u7F51\u9875\u5DF2\u540C\u6B65\u539F\u76D1\u6D4B\u72B6\u6001\u3002\u8F93\u5165\u201C\u539F\u7AEF\u7EE7\u7EED\u201D\uFF1A") === "\u539F\u7AEF\u7EE7\u7EED")
        run("handoff.mjs", "initialize-source", directory);
    } else if (choice === "S" && !mac) run("handoff.mjs", "stop-windows", directory);
    else if (choice === "R") {
      console.log("1 \u65B0\u7AEF\u5C1A\u672A\u6267\u884C\uFF1A\u6C38\u4E45\u4F5C\u5E9F\u6B64\u6B21\u63A5\u7BA1\u5E76\u51FA\u5177\u51ED\u636E\n2 \u8FD0\u884C\u4E2D\u7684\u65E7\u7AEF\uFF1A\u63A5\u6536\u4F5C\u5E9F\u51ED\u636E\n3 \u5DF2\u505C\u6B62\u7684\u65E7\u7AEF\uFF1A\u63A5\u6536\u4F5C\u5E9F\u51ED\u636E\n4 \u51BB\u7ED3\u4E14\u672A\u4EA4\u51FA/\u5DF2\u6536\u56DE\u7684\u65E7\u7AEF\uFF1A\u91CD\u65B0\u5BF9\u8D26\u540E\u6062\u590D\n\u5DF2\u63A5\u7BA1\u5E76\u6267\u884C\u8FC7\u7684\u65B0\u7AEF\uFF0C\u5FC5\u987B\u6309 4\u21925\u21926\u21927\u21928 \u53CD\u5411\u4EA4\u63A5\u6700\u65B0\u8D26\u672C\u3002");
      const recovery = await ask("\u8BF7\u9009\u62E9\u6062\u590D\u8DEF\u5F84\uFF1A");
      if (recovery === "1") run("handoff.mjs", "reject", directory, await ask("\u539F\u4EA4\u63A5\u5305\u8DEF\u5F84\uFF1A"), await ask("\u4F5C\u5E9F\u51ED\u636E\u4FDD\u5B58\u5230\u54EA\u4E2A\u5168\u65B0\u6587\u4EF6\uFF1A"));
      if (recovery === "2" || recovery === "3") run("handoff.mjs", recovery === "2" ? "accept-cancellation-live" : "accept-cancellation", directory, await ask("\u65B0\u7AEF\u4F5C\u5E9F\u51ED\u636E\u8DEF\u5F84\uFF1A"));
      if (recovery === "4") run("handoff.mjs", "resume", directory);
    }
  }
}
try {
  await main();
} finally {
  prompt.close();
}
