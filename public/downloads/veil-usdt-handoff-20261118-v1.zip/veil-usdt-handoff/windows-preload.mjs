// scripts/usdt-windows-preload.ts
import { existsSync } from "node:fs";
import { join } from "node:path";
import { setGlobalProxyFromEnv } from "node:http";
var paths = [
  join(process.env.USERPROFILE, ".cache", "codex-runtimes", "codex-primary-runtime", "dependencies", "native", "powershell"),
  join(process.env.ProgramFiles, "PowerShell", "7")
];
var powerShell = paths.find((path) => existsSync(join(path, "pwsh.exe")));
if (!powerShell) throw Error("\u627E\u4E0D\u5230 PowerShell 7\uFF0C\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u7528\u6237\u7684\u52A0\u5BC6\u51ED\u8BC1");
process.env.PATH = powerShell + ";" + process.env.PATH;
var proxy = process.env.HTTPS_PROXY || "http://127.0.0.1:10808";
setGlobalProxyFromEnv({ HTTPS_PROXY: proxy, HTTP_PROXY: proxy, NO_PROXY: "127.0.0.1,localhost" });
