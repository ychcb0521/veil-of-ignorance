#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
node -e 'if(Number(process.versions.node.split(".")[0])!==24)throw Error("请安装 Node.js 24.22.2")'
node ./handoff-menu.mjs
