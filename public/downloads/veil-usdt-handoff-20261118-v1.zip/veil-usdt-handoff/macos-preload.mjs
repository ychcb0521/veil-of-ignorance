// scripts/usdt-macos-preload.ts
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { setGlobalProxyFromEnv } from "node:http";
if (process.platform !== "darwin") throw Error("\u6B64\u542F\u52A8\u5165\u53E3\u7528\u4E8E Mac\u3002");
var directory = join(homedir(), "Library", "Application Support", "VeilUSDTExecutor");
var { proxy } = JSON.parse(readFileSync(join(directory, "proxy.json"), "utf8"));
setGlobalProxyFromEnv({ HTTPS_PROXY: proxy, HTTP_PROXY: proxy, NO_PROXY: "127.0.0.1,localhost" });
